package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class FreezeManager {

    private final GalaxydeStaff plugin;
    private final Set<UUID> frozen = ConcurrentHashMap.newKeySet();

    public FreezeManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public boolean isFrozen(UUID uuid) {
        return frozen.contains(uuid);
    }

    /** Returns true if the player is now frozen (false if this call unfroze them). */
    public boolean toggle(UUID uuid) {
        if (frozen.contains(uuid)) {
            frozen.remove(uuid);
            return false;
        } else {
            frozen.add(uuid);
            return true;
        }
    }

    public boolean isCommandAllowedWhileFrozen(String commandLabel) {
        List<String> allowed = plugin.getConfig().getStringList("freeze.allowed-commands-while-frozen");
        String label = commandLabel.startsWith("/") ? commandLabel.substring(1) : commandLabel;
        return allowed.stream().anyMatch(a -> a.equalsIgnoreCase(label));
    }

    public void clearAllOnShutdown() {
        frozen.clear();
    }
}
