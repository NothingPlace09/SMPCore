package me.nothing.smpcore.systems.staff;

import java.io.File;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;

/** Sistema "staff" (main-config.yml -> systems.staff). Cartella dati: plugins/SmpCore/staff/ */
public class StaffModule implements Module {
   private final SmpCore plugin;
   private GalaxydeStaff staff;

   public StaffModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "staff";
   }

   public void onEnable() {
      new File(this.plugin.getDataFolder(), "staff").mkdirs();

      try {
         this.staff = new GalaxydeStaff(this.plugin);
         this.staff.enable();
      } catch (Throwable t) {
         this.plugin.getLogger().warning("Staff system failed to start: " + t.getMessage());
         t.printStackTrace();
      }
   }

   public void onDisable() {
      if (this.staff != null) {
         try {
            this.staff.disable();
         } catch (Throwable t) {
         }

         this.staff = null;
      }
   }

   public void reload() {
      this.onDisable();
      this.onEnable();
   }
}
