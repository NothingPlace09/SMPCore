package me.nothing.smpcore.systems.chat;

import me.clip.placeholderapi.PlaceholderAPI;
import me.nothing.smpcore.economy.CoreEconomy;
import me.nothing.smpcore.systems.tab.TabPlaceholders;
import org.bukkit.Bukkit;
import org.bukkit.Statistic;
import org.bukkit.entity.Player;

public class PlaceholderUtil {
   public static String replace(Player player, String text) {
      if (text == null) {
         return "";
      }

      text = text.replace("%player%", player.getName());
      if (text.indexOf('%') < 0) {
         return text;
      }

      try {
         text = text.replace("%kills%", String.valueOf(player.getStatistic(Statistic.PLAYER_KILLS)));
         text = text.replace("%deaths%", String.valueOf(player.getStatistic(Statistic.DEATHS)));
         long ticks = (long)player.getStatistic(Statistic.PLAY_ONE_MINUTE);
         long hours = ticks / 20L / 3600L;
         long minutes = ticks / 20L % 3600L / 60L;
         text = text.replace("%playtime%", hours + "h " + minutes + "m");
      } catch (Throwable t) {
      }

      if (text.contains("%money%")) {
         String money = "0";
         try {
            money = CoreEconomy.formatMoney(CoreEconomy.balanceOf(player));
         } catch (Throwable t) {
         }

         text = text.replace("%money%", money);
      }

      // Funzionano anche senza l'espansione LuckPerms di PlaceholderAPI (che molti server non scaricano).
      if (text.contains("%luckperms_prefix%") || text.contains("%luckperms_suffix%") || text.contains("%vault_prefix%") || text.contains("%vault_suffix%")) {
         String prefix = TabPlaceholders.meta(player, true);
         String suffix = TabPlaceholders.meta(player, false);
         text = text.replace("%luckperms_prefix%", prefix).replace("%vault_prefix%", prefix).replace("%luckperms_suffix%", suffix).replace("%vault_suffix%", suffix);
      }

      if (text.indexOf('%') >= 0 && Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
         try {
            text = PlaceholderAPI.setPlaceholders(player, text);
         } catch (Throwable t) {
         }
      }

      return text;
   }
}
