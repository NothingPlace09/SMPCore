package me.nothing.smpcore.systems.tab;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import org.bukkit.Bukkit;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/**
 * Il modulo tab crea team (nome in tablist/nametag) e un objective "belowname" sulla scoreboard principale, che il
 * server salva su disco. Se il server si ferma male, o se il modulo viene spento, restano li' e il plugin TAB li trova
 * al riavvio come "conflitto". Questa classe li toglie.
 */
public final class TabCleanup {
   /** Prefisso dei team creati dal modulo tab. */
   public static final String TEAM_PREFIX = "smptab_";
   public static final String BELOW_NAME = "smpcore_bn";
   /** Nome dei team creati dalle versioni vecchie: due cifre (ordine del gruppo) + nome giocatore. */
   private static final Pattern LEGACY_TEAM = Pattern.compile("^\\d{2}.+");

   private TabCleanup() {
   }

   /** Toglie dalla scoreboard principale team e objective del modulo tab. Restituisce quanti ne ha tolti. */
   public static int purgeMain() {
      try {
         return purge(Bukkit.getScoreboardManager().getMainScoreboard());
      } catch (Throwable t) {
         return 0;
      }
   }

   public static int purge(Scoreboard board) {
      int removed = 0;
      List<Team> teams = new ArrayList<>(board.getTeams());
      for(Team team : teams) {
         String name = team.getName();
         if (name.startsWith(TEAM_PREFIX) || LEGACY_TEAM.matcher(name).matches()) {
            try {
               team.unregister();
               ++removed;
            } catch (IllegalStateException e) {
            }
         }
      }

      Objective belowName = board.getObjective(BELOW_NAME);
      if (belowName != null) {
         try {
            belowName.unregister();
            ++removed;
         } catch (IllegalStateException e) {
         }
      }

      return removed;
   }
}
