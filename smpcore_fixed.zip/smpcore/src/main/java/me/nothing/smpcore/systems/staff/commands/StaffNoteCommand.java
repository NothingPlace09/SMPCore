package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import me.nothing.smpcore.systems.staff.managers.NoteEntry;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StaffNoteCommand extends BaseCommand {

    public StaffNoteCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.staffnote")) return;

        if (args.length < 2) {
            plugin.msg().send(staff, "general.invalid-usage",
                    MessagesManager.pairs("usage", "/staffnote (add|list|remove) (player|id) [text]"));
            return;
        }

        String sub = args[0].toLowerCase();

        switch (sub) {
            case "add" -> {
                if (args.length < 3) {
                    plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/staffnote add %player% %text%"));
                    return;
                }
                @SuppressWarnings("deprecation")
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                if (!target.hasPlayedBefore() && !target.isOnline()) {
                    plugin.msg().send(staff, "general.player-not-found", MessagesManager.pairs("target", args[1]));
                    return;
                }
                String text = String.join(" ", java.util.Arrays.copyOfRange(args, 2, args.length));
                plugin.staffNotes().add(target.getUniqueId(), target.getName(), staff.getUniqueId(), staff.getName(), text, id -> {
                    plugin.msg().send(staff, "staffnote.added", MessagesManager.pairs("target", target.getName(), "id", String.valueOf(id)));
                    plugin.discord().sendStaffNoteLog(target.getName(), staff.getName(), text);
                    plugin.audit().log(staff.getUniqueId(), staff.getName(), "STAFFNOTE_ADD", target.getUniqueId(), target.getName(), text);
                });
            }
            case "list" -> {
                @SuppressWarnings("deprecation")
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
                if (!target.hasPlayedBefore() && !target.isOnline()) {
                    plugin.msg().send(staff, "general.player-not-found", MessagesManager.pairs("target", args[1]));
                    return;
                }
                plugin.staffNotes().list(target.getUniqueId(), notes -> {
                    if (notes.isEmpty()) {
                        plugin.msg().send(staff, "staffnote.list-empty");
                        return;
                    }
                    plugin.msg().send(staff, "staffnote.list-header", MessagesManager.pairs("target", target.getName()));
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
                    for (NoteEntry note : notes) {
                        plugin.msg().send(staff, "staffnote.list-entry", MessagesManager.pairs(
                                "id", String.valueOf(note.id()), "text", note.text(),
                                "staff", note.staffName(), "date", sdf.format(new Date(note.createdAt()))));
                    }
                });
            }
            case "remove" -> {
                if (!staff.hasPermission("galaxydestaff.staffnote.remove")) {
                    plugin.msg().send(staff, "general.no-permission");
                    return;
                }
                try {
                    int id = Integer.parseInt(args[1]);
                    plugin.staffNotes().remove(id, success -> {
                        plugin.msg().send(staff, success ? "staffnote.removed" : "staffnote.not-found",
                                MessagesManager.pairs("id", String.valueOf(id)));
                        if (success) {
                            plugin.audit().log(staff.getUniqueId(), staff.getName(), "STAFFNOTE_REMOVE", null, null, "#" + id);
                            plugin.discord().sendStaffNoteRemovalLog(id, staff.getName());
                        }
                    });
                } catch (NumberFormatException e) {
                    plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/staffnote remove %id%"));
                }
            }
            default -> plugin.msg().send(staff, "general.invalid-usage",
                    MessagesManager.pairs("usage", "/staffnote (add|list|remove) (player|id) [text]"));
        }
    }
}
