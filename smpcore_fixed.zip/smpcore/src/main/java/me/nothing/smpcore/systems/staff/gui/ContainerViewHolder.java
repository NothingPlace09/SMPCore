package me.nothing.smpcore.systems.staff.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

/**
 * Marker holder for a "ghost" read-only copy of a world container's contents (chest, barrel,
 * shulker, furnace, hopper, etc.) shown to a staff member in staff mode. Because this inventory
 * is a standalone copy — not tied to the actual block/tile entity — opening it never triggers
 * the block's own open animation, sound, or "someone is viewing this container" state, so nobody
 * nearby sees anything happen. Always read-only; StaffGuiListener cancels every click on it.
 */
public class ContainerViewHolder implements InventoryHolder {

    private Inventory inventory;

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
