package me.nothing.smpcore.systems.punishment2.utils;

public class TimeUtil {
   public static String formatTime(long millis) {
      if (millis <= 0L) {
         return "Permanent";
      } else {
         long seconds = millis / 1000L;
         long days = seconds / 86400L;
         seconds %= 86400L;
         long hours = seconds / 3600L;
         seconds %= 3600L;
         long minutes = seconds / 60L;
         seconds %= 60L;
         StringBuilder result = new StringBuilder();
         if (days > 0L) {
            result.append(days).append("d ");
         }

         if (hours > 0L) {
            result.append(hours).append("h ");
         }

         if (minutes > 0L) {
            result.append(minutes).append("m ");
         }

         if (seconds > 0L) {
            result.append(seconds).append("s");
         }

         return result.length() == 0 ? "0s" : result.toString().trim();
      }
   }

   public static long getExpireTime(String duration) {
      if (duration == null) {
         return -1L;
      } else if (duration.equalsIgnoreCase("permanent")) {
         return -1L;
      } else {
         long multiplier = 1000L;

         try {
            char unit = duration.charAt(duration.length() - 1);
            long number = Long.parseLong(duration.substring(0, duration.length() - 1));
            switch (unit) {
               case 'M' -> multiplier = 2592000000L;
               case 'd' -> multiplier = 86400000L;
               case 'h' -> multiplier = 3600000L;
               case 'm' -> multiplier = 60000L;
            }

            return System.currentTimeMillis() + number * multiplier;
         } catch (Exception e) {
            return -1L;
         }
      }
   }

   public static boolean hasExpired(long expireTime) {
      if (expireTime <= 0L) {
         return false;
      } else {
         return System.currentTimeMillis() >= expireTime;
      }
   }

   /**
    * Durata scritta da uno staffer (30s, 15m, 12h, 7d, 2w, 1M) in millisecondi.
    * Restituisce -1 se il formato non e' valido (a differenza di getExpireTime, che in quel caso diventa "permanente").
    */
   public static long parseDuration(String text) {
      if (text != null && text.matches("(?i)\\d{1,9}[smhdw]|\\d{1,9}M")) {
         long number = Long.parseLong(text.substring(0, text.length() - 1));
         if (number <= 0L) {
            return -1L;
         } else {
            char unit = text.charAt(text.length() - 1);
            long multiplier = switch (unit) {
               case 'M' -> 2592000000L;
               case 'w', 'W' -> 604800000L;
               case 'd', 'D' -> 86400000L;
               case 'h', 'H' -> 3600000L;
               case 'm' -> 60000L;
               default -> 1000L;
            };
            return number * multiplier;
         }
      } else {
         return -1L;
      }
   }
}
