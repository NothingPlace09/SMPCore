package me.nothing.smpcore.systems.punishment2.utils;

import java.util.Locale;
import java.util.UUID;
import me.nothing.smpcore.data.PlayerDataStore;
import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

/**
 * Trova un giocatore dal nome senza badare alle maiuscole ("justnothing7" = "JustNothing7"), anche se e' offline.
 * Cerca tra: giocatori online, dati di SmpCore, storico delle punizioni, cache del server, giocatori gia' visti.
 */
public final class PlayerLookup {
   public record Found(UUID uuid, String name) {
      public OfflinePlayer offline() {
         return Bukkit.getOfflinePlayer(this.uuid);
      }

      public Player online() {
         return Bukkit.getPlayer(this.uuid);
      }
   }

   private PlayerLookup() {
   }

   public static Found find(SmpCorePunishment plugin, String input) {
      if (input == null || input.isBlank()) {
         return null;
      }

      String name = input.trim();
      for(Player p : Bukkit.getOnlinePlayers()) {
         if (p.getName().equalsIgnoreCase(name)) {
            return new Found(p.getUniqueId(), p.getName());
         }
      }

      try {
         UUID asUuid = UUID.fromString(name);
         OfflinePlayer byUuid = Bukkit.getOfflinePlayer(asUuid);
         return new Found(asUuid, byUuid.getName() != null ? byUuid.getName() : name);
      } catch (IllegalArgumentException e) {
         // non e' un UUID
      }

      try {
         PlayerDataStore store = PlayerDataStore.get();
         synchronized(store.lock()) {
            String uuid = store.config().getString("names." + name.toLowerCase(Locale.ROOT));
            if (uuid != null) {
               UUID id = UUID.fromString(uuid);
               String canonical = store.config().getString("players." + uuid + ".name", name);
               return new Found(id, canonical);
            }
         }
      } catch (Throwable t) {
         // dati di SmpCore non disponibili: si passa alla ricerca successiva
      }

      Found fromHistory = plugin.getDatabaseManager().findByName(name);
      if (fromHistory != null) {
         return fromHistory;
      }

      OfflinePlayer cached = Bukkit.getOfflinePlayerIfCached(name);
      if (cached != null && cached.getName() != null) {
         return new Found(cached.getUniqueId(), cached.getName());
      }

      for(OfflinePlayer off : Bukkit.getOfflinePlayers()) {
         if (off.getName() != null && off.getName().equalsIgnoreCase(name)) {
            return new Found(off.getUniqueId(), off.getName());
         }
      }

      return null;
   }
}
