package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TpHereCommand extends BaseCommand {

    public TpHereCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.tphere")) return;

        if (args.length < 1) {
            plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/tphere %player%"));
            return;
        }

        Player target = requireOnlinePlayer(staff, args[0]);
        if (target == null) return;

        target.teleport(staff.getLocation());
        plugin.msg().send(staff, "tphere.sender-notified", MessagesManager.pairs("target", target.getName()));
        plugin.msg().send(target, "tphere.target-notified", MessagesManager.pairs("staff", staff.getName()));
        plugin.audit().log(staff.getUniqueId(), staff.getName(), "TPHERE", target.getUniqueId(), target.getName(), null);
    }
}
