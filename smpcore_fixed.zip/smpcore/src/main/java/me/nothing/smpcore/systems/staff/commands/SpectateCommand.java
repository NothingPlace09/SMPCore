package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpectateCommand extends BaseCommand {

    public SpectateCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.spectate")) return;

        if (args.length < 1) {
            if (plugin.spectate().isSpectating(staff.getUniqueId())) {
                plugin.spectate().stop(staff);
                plugin.msg().send(staff, "spectate.stopped");
            } else {
                plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/spectate %player%"));
            }
            return;
        }

        Player target = requireOnlinePlayer(staff, args[0]);
        if (target == null) return;

        if (plugin.spectate().isSpectating(staff.getUniqueId())) {
            plugin.spectate().stop(staff);
        }

        plugin.spectate().start(staff, target);
        plugin.msg().send(staff, "spectate.started", MessagesManager.pairs("target", target.getName()));
    }
}
