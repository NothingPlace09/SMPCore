package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.CreatureSpawner;
import org.bukkit.block.data.type.Chest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.logging.Level;

public class SpawnStashManager {

    private final GalaxydeStaff plugin;

    public SpawnStashManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    /** Builds the configured structure around the player's current position. Runs synchronously (block edits). */
    public void paste(Player player) {
        ConfigurationSection structureSection = plugin.getConfig().getConfigurationSection("spawnstash.structure");
        if (structureSection == null) {
            plugin.getLogger().warning("spawnstash.structure is missing from config.yml — nothing to paste.");
            return;
        }

        String platformMaterialName = structureSection.getString("platform-material", "DARK_OAK_PLANKS");
        String chestFacingName = structureSection.getString("chest-facing", "SOUTH");
        String shulkerColor = structureSection.getString("shulker-color", "PURPLE");
        String spawnerEntityName = structureSection.getString("spawner-entity", "SKELETON");

        Material platformMaterial = safeMaterial(platformMaterialName, Material.DARK_OAK_PLANKS);
        BlockFace chestFacing = safeBlockFace(chestFacingName, BlockFace.SOUTH);
        Material shulkerMaterial = safeMaterial(shulkerColor.toUpperCase() + "_SHULKER_BOX", Material.PURPLE_SHULKER_BOX);
        EntityType spawnerEntity = safeEntityType(spawnerEntityName, EntityType.SKELETON);

        Location base = player.getLocation().getBlock().getLocation();
        List<?> blocks = structureSection.getMapList("blocks");

        for (Object raw : blocks) {
            if (!(raw instanceof Map<?, ?> map)) continue;

            int dx = toInt(map.get("x"));
            int dy = toInt(map.get("y"));
            int dz = toInt(map.get("z"));
            String blockType = String.valueOf(map.get("block"));

            Block block = base.clone().add(dx, dy, dz).getBlock();

            switch (blockType.toUpperCase()) {
                case "PLATFORM" -> block.setType(platformMaterial);
                case "SPAWNER" -> {
                    block.setType(Material.SPAWNER);
                    if (block.getState() instanceof CreatureSpawner spawner) {
                        spawner.setSpawnedType(spawnerEntity);
                        spawner.update();
                    }
                }
                case "CHEST" -> {
                    block.setType(Material.CHEST);
                    if (block.getBlockData() instanceof Chest chestData) {
                        chestData.setFacing(chestFacing);
                        block.setBlockData(chestData);
                    }
                }
                case "SHULKER_BOX" -> block.setType(shulkerMaterial);
                default -> {
                    Material material = Material.matchMaterial(blockType);
                    if (material != null) {
                        block.setType(material);
                    } else {
                        plugin.getLogger().warning("Unknown block '" + blockType + "' in spawnstash.structure, skipping.");
                    }
                }
            }
        }
    }

    private int toInt(Object o) {
        if (o instanceof Number n) return n.intValue();
        try {
            return Integer.parseInt(String.valueOf(o));
        } catch (Exception e) {
            return 0;
        }
    }

    private Material safeMaterial(String name, Material fallback) {
        Material m = Material.matchMaterial(name);
        if (m == null) {
            plugin.getLogger().log(Level.WARNING, "Invalid material '" + name + "' in spawnstash config, using " + fallback);
            return fallback;
        }
        return m;
    }

    private BlockFace safeBlockFace(String name, BlockFace fallback) {
        try {
            return BlockFace.valueOf(name.toUpperCase());
        } catch (Exception e) {
            return fallback;
        }
    }

    private EntityType safeEntityType(String name, EntityType fallback) {
        try {
            return EntityType.valueOf(name.toUpperCase());
        } catch (Exception e) {
            return fallback;
        }
    }
}
