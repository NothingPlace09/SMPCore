package me.nothing.smpcore.systems.punishment2.commands;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

/** /punishment (/punish): elenca i comandi di sanzione che chi scrive puo' usare. */
public class PunishmentHelpCommand implements CommandExecutor {
   private static final String[][] ENTRIES = new String[][]{
      {"/ban <player> [reason]", "smpcore.system.punishment.ban"},
      {"/tempban <player> <duration> [reason]", "smpcore.system.punishment.ban"},
      {"/unban <player> [reason]", "smpcore.system.punishment.unban"},
      {"/mute <player> [reason]", "smpcore.system.punishment.mute"},
      {"/tempmute <player> <duration> [reason]", "smpcore.system.punishment.mute"},
      {"/unmute <player> [reason]", "smpcore.system.punishment.unmute"},
      {"/warn <player> <reason>", "smpcore.system.punishment.warn"},
      {"/kick <player> [reason]", "smpcore.system.punishment.kick"},
      {"/offend <player> <reason>", "smpcore.system.punishment.offend"},
      {"/offendip <player> <reason>", "smpcore.system.punishment.offendip"},
      {"/unoffend <player> [reason]", "smpcore.system.punishment.unoffend"},
      {"/checkban <player>", "smpcore.system.punishment.check"},
      {"/checkmute <player>", "smpcore.system.punishment.check"},
      {"/history <player>", "smpcore.system.punishment.history"},
      {"/smpcorepunishment reload", "smpcore.system.punishment.admin"}
   };

   private final SmpCorePunishment plugin;

   public PunishmentHelpCommand(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      sender.sendMessage(ColorUtil.color("&#72EEFF&lPUNISHMENT &#9B9B9B» &#9B9B9BCommands"));
      boolean any = false;
      for(String[] e : ENTRIES) {
         if (sender.hasPermission(e[1])) {
            sender.sendMessage(ColorUtil.color("&#9B9B9B- &#71F521" + e[0]));
            any = true;
         }
      }

      if (!any) {
         sender.sendMessage(ColorUtil.color("&cYou do not have permission."));
      }

      return true;
   }
}
