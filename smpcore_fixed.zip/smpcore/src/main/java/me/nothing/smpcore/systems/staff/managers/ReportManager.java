package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import java.util.logging.Level;

public class ReportManager {

    private final GalaxydeStaff plugin;
    private final Map<UUID, Long> lastReportAt = new ConcurrentHashMap<>();

    public enum SubmitResult { OK, COOLDOWN, MAX_ACTIVE }

    public ReportManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public boolean isOnCooldown(UUID reporter) {
        long cooldownMs = plugin.getConfig().getLong("reports.cooldown-seconds", 30) * 1000L;
        Long last = lastReportAt.get(reporter);
        return last != null && System.currentTimeMillis() - last < cooldownMs;
    }

    public long cooldownRemainingSeconds(UUID reporter) {
        long cooldownMs = plugin.getConfig().getLong("reports.cooldown-seconds", 30) * 1000L;
        Long last = lastReportAt.get(reporter);
        if (last == null) return 0;
        long remaining = cooldownMs - (System.currentTimeMillis() - last);
        return Math.max(0, remaining / 1000L);
    }

    /** Submits a report asynchronously. `onResult` is called back on the main thread. */
    public void submit(UUID reporterUuid, String reporterName, UUID targetUuid, String targetName, String reason,
                        Consumer<SubmitResult> onResult) {

        if (isOnCooldown(reporterUuid)) {
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> onResult.accept(SubmitResult.COOLDOWN));
            return;
        }

        int maxActive = plugin.getConfig().getInt("reports.max-active-per-reporter", 3);

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            String prefix = plugin.db().prefix();
            try (Connection c = plugin.db().getConnection()) {

                try (PreparedStatement count = c.prepareStatement(
                        "SELECT COUNT(*) FROM `" + prefix + "reports` WHERE reporter_uuid = ? AND status = 'OPEN'")) {
                    count.setString(1, reporterUuid.toString());
                    try (ResultSet rs = count.executeQuery()) {
                        rs.next();
                        if (rs.getInt(1) >= maxActive) {
                            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> onResult.accept(SubmitResult.MAX_ACTIVE));
                            return;
                        }
                    }
                }

                try (PreparedStatement insert = c.prepareStatement(
                        "INSERT INTO `" + prefix + "reports` (target_uuid, target_name, reporter_uuid, reporter_name, reason, status, created_at) "
                                + "VALUES (?, ?, ?, ?, ?, 'OPEN', ?)")) {
                    insert.setString(1, targetUuid.toString());
                    insert.setString(2, targetName);
                    insert.setString(3, reporterUuid.toString());
                    insert.setString(4, reporterName);
                    insert.setString(5, reason);
                    insert.setLong(6, System.currentTimeMillis());
                    insert.executeUpdate();
                }

                lastReportAt.put(reporterUuid, System.currentTimeMillis());
                plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> onResult.accept(SubmitResult.OK));

            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to submit report", e);
            }
        });
    }

    /** Fetches a page of open reports. Callback runs on the main thread. */
    public void listOpen(int page, int perPage, Consumer<List<ReportEntry>> callback) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            List<ReportEntry> results = new ArrayList<>();
            String prefix = plugin.db().prefix();
            String sql = "SELECT id, target_name, reporter_name, reason, created_at, status FROM `" + prefix + "reports` "
                    + "WHERE status = 'OPEN' ORDER BY created_at DESC LIMIT ? OFFSET ?";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, perPage);
                ps.setInt(2, Math.max(0, (page - 1) * perPage));
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        results.add(new ReportEntry(
                                rs.getInt("id"), rs.getString("target_name"), rs.getString("reporter_name"),
                                rs.getString("reason"), rs.getLong("created_at"), rs.getString("status")));
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to list reports", e);
            }
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> callback.accept(results));
        });
    }

    public void countOpen(Consumer<Integer> callback) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            int count = 0;
            String sql = "SELECT COUNT(*) FROM `" + plugin.db().prefix() + "reports` WHERE status = 'OPEN'";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql);
                 ResultSet rs = ps.executeQuery()) {
                if (rs.next()) count = rs.getInt(1);
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to count reports", e);
            }
            int finalCount = count;
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> callback.accept(finalCount));
        });
    }

    /** Resolves a report and, on success, returns its details (target/reporter/reason) via callback. Returns null if not found/already resolved. */
    public void resolve(int id, String resolvedBy, Consumer<ReportEntry> callback) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            ReportEntry resolved = null;
            String prefix = plugin.db().prefix();

            try (Connection c = plugin.db().getConnection()) {
                String selectSql = "SELECT id, target_name, reporter_name, reason, created_at, status FROM `" + prefix + "reports` "
                        + "WHERE id = ? AND status = 'OPEN'";
                ReportEntry found = null;
                try (PreparedStatement select = c.prepareStatement(selectSql)) {
                    select.setInt(1, id);
                    try (ResultSet rs = select.executeQuery()) {
                        if (rs.next()) {
                            found = new ReportEntry(rs.getInt("id"), rs.getString("target_name"), rs.getString("reporter_name"),
                                    rs.getString("reason"), rs.getLong("created_at"), rs.getString("status"));
                        }
                    }
                }

                if (found != null) {
                    String updateSql = "UPDATE `" + prefix + "reports` SET status = 'RESOLVED', resolved_at = ?, resolved_by = ? "
                            + "WHERE id = ? AND status = 'OPEN'";
                    try (PreparedStatement update = c.prepareStatement(updateSql)) {
                        update.setLong(1, System.currentTimeMillis());
                        update.setString(2, resolvedBy);
                        update.setInt(3, id);
                        if (update.executeUpdate() > 0) resolved = found;
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to resolve report", e);
            }

            ReportEntry finalResolved = resolved;
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> callback.accept(finalResolved));
        });
    }
}
