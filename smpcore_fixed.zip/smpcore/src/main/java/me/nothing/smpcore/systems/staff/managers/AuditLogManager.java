package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.UUID;
import java.util.logging.Level;

public class AuditLogManager {

    private final GalaxydeStaff plugin;
    private final boolean enabled;
    private final boolean logToConsole;

    public AuditLogManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
        this.enabled = plugin.getConfig().getBoolean("audit-log.enabled", true);
        this.logToConsole = plugin.getConfig().getBoolean("audit-log.log-to-console", true);
    }

    /**
     * Records a staff action. target/reason may be null for actions with no specific target
     * (e.g. VANISH_ON, STAFFMODE_ON).
     */
    public void log(UUID staffUuid, String staffName, String action, UUID targetUuid, String targetName, String reason) {
        if (!enabled) return;

        if (logToConsole) {
            plugin.getLogger().info("[AUDIT] " + staffName + " -> " + action
                    + (targetName != null ? " -> " + targetName : "")
                    + (reason != null && !reason.isBlank() ? " (" + reason + ")" : ""));
        }

        // DB write off the main thread.
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            String sql = "INSERT INTO `" + plugin.db().prefix() + "audit_log` "
                    + "(staff_uuid, staff_name, action, target_uuid, target_name, reason, created_at) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, staffUuid.toString());
                ps.setString(2, staffName);
                ps.setString(3, action);
                ps.setString(4, targetUuid != null ? targetUuid.toString() : null);
                ps.setString(5, targetName);
                ps.setString(6, reason);
                ps.setLong(7, System.currentTimeMillis());
                ps.executeUpdate();
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to write audit log entry", e);
            }
        });
    }

    public void log(UUID staffUuid, String staffName, String action) {
        log(staffUuid, staffName, action, null, null, null);
    }

    /** Fetches a page of actions performed by a given staff member, for /staffhistory. Callback runs on the main thread. */
    public void getStaffHistoryPage(UUID staffUuid, int page, int perPage, java.util.function.Consumer<java.util.List<AuditEntry>> callback) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            java.util.List<AuditEntry> results = new java.util.ArrayList<>();
            String sql = "SELECT action, target_name, reason, created_at FROM `" + plugin.db().prefix() + "audit_log` "
                    + "WHERE staff_uuid = ? ORDER BY created_at DESC LIMIT ? OFFSET ?";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, staffUuid.toString());
                ps.setInt(2, perPage);
                ps.setInt(3, Math.max(0, (page - 1) * perPage));
                try (var rs = ps.executeQuery()) {
                    while (rs.next()) {
                        results.add(new AuditEntry(rs.getString("action"), rs.getString("target_name"),
                                rs.getString("reason"), rs.getLong("created_at")));
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to read staff history", e);
            }
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> callback.accept(results));
        });
    }
}
