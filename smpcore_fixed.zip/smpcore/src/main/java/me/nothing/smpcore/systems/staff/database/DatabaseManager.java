package me.nothing.smpcore.systems.staff.database;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import me.nothing.smpcore.systems.staff.GalaxydeStaff;

/**
 * Database locale dello staff (note, report, audit log): plugins/SmpCore/staff/staff.db (SQLite, incluso in Paper).
 * Nessuna configurazione: ogni getConnection() apre una connessione nuova, chi la chiama la chiude (try-with-resources).
 */
public class DatabaseManager {
    private static final String TABLE_PREFIX = "gds_";

    private final GalaxydeStaff plugin;
    private String url;

    public DatabaseManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public void connect() throws SQLException {
        File dir = plugin.getDataFolder();
        dir.mkdirs();
        this.url = "jdbc:sqlite:" + new File(dir, "staff.db").getAbsolutePath();
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            throw new SQLException("SQLite driver not found on this server", e);
        }

        try (Connection c = getConnection()) {
            // apre (e crea) il file subito, cosi' un problema esce all'avvio e non al primo comando
        }
    }

    /** Connessione nuova al database dello staff. */
    public Connection getConnection() throws SQLException {
        Connection c = DriverManager.getConnection(url);
        try (Statement s = c.createStatement()) {
            s.execute("PRAGMA busy_timeout = 5000");
            s.execute("PRAGMA journal_mode = WAL");
        }

        return c;
    }

    public String prefix() {
        return TABLE_PREFIX;
    }

    public void initSchema() throws SQLException {
        try (Connection c = getConnection(); Statement s = c.createStatement()) {
            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS `%snotes` (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    target_uuid VARCHAR(36) NOT NULL,
                    target_name VARCHAR(16) NOT NULL,
                    staff_uuid VARCHAR(36) NOT NULL,
                    staff_name VARCHAR(16) NOT NULL,
                    note TEXT NOT NULL,
                    created_at BIGINT NOT NULL
                )
                """.formatted(TABLE_PREFIX));
            s.executeUpdate("CREATE INDEX IF NOT EXISTS `%snotes_target` ON `%snotes` (target_uuid)".formatted(TABLE_PREFIX, TABLE_PREFIX));

            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS `%sreports` (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    target_uuid VARCHAR(36) NOT NULL,
                    target_name VARCHAR(16) NOT NULL,
                    reporter_uuid VARCHAR(36) NOT NULL,
                    reporter_name VARCHAR(16) NOT NULL,
                    reason VARCHAR(256) NOT NULL,
                    status VARCHAR(16) NOT NULL DEFAULT 'OPEN',
                    created_at BIGINT NOT NULL,
                    resolved_at BIGINT NULL,
                    resolved_by VARCHAR(16) NULL
                )
                """.formatted(TABLE_PREFIX));
            s.executeUpdate("CREATE INDEX IF NOT EXISTS `%sreports_status` ON `%sreports` (status)".formatted(TABLE_PREFIX, TABLE_PREFIX));
            s.executeUpdate("CREATE INDEX IF NOT EXISTS `%sreports_target` ON `%sreports` (target_uuid)".formatted(TABLE_PREFIX, TABLE_PREFIX));

            s.executeUpdate("""
                CREATE TABLE IF NOT EXISTS `%saudit_log` (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    staff_uuid VARCHAR(36) NOT NULL,
                    staff_name VARCHAR(16) NOT NULL,
                    action VARCHAR(32) NOT NULL,
                    target_uuid VARCHAR(36) NULL,
                    target_name VARCHAR(16) NULL,
                    reason VARCHAR(256) NULL,
                    created_at BIGINT NOT NULL
                )
                """.formatted(TABLE_PREFIX));
            s.executeUpdate("CREATE INDEX IF NOT EXISTS `%saudit_staff` ON `%saudit_log` (staff_uuid)".formatted(TABLE_PREFIX, TABLE_PREFIX));
            s.executeUpdate("CREATE INDEX IF NOT EXISTS `%saudit_target` ON `%saudit_log` (target_uuid)".formatted(TABLE_PREFIX, TABLE_PREFIX));
        }
    }

    public void close() {
        // nessun pool da chiudere: le connessioni vengono chiuse da chi le usa
    }
}
