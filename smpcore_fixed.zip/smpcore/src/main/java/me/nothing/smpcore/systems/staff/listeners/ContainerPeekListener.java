package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.gui.ContainerViewHolder;
import net.kyori.adventure.text.Component;
import org.bukkit.block.Block;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;

/**
 * While in staff mode, right-clicking a real container (chest, barrel, shulker, furnace,
 * hopper, dispenser, brewing stand...) never actually opens it. Instead we read its contents
 * into a standalone "ghost" copy and open THAT — since it isn't tied to the block/tile entity,
 * there's no lid animation, no sound, and nobody nearby sees the container being opened at all.
 * The copy is always read-only (StaffGuiListener cancels every click on it).
 */
public class ContainerPeekListener implements Listener {

    private final GalaxydeStaff plugin;

    public ContainerPeekListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    // HIGH + ignoreCancelled: if StaffModeItemListener already handled this click (player was
    // holding a command item), this defers to that instead of also trying to peek a container.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("staffmode.prevent-container-interaction", true)) return;

        Block block = event.getClickedBlock();
        if (block == null) return;
        if (!(block.getState() instanceof Container container)) return;

        // Deny the vanilla open entirely — this is what stops the lid animation/sound from
        // ever happening in the first place.
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setCancelled(true);

        Inventory real = container.getInventory();
        InventoryType type = real.getType();

        ContainerViewHolder holder = new ContainerViewHolder();
        Inventory copy = (type == InventoryType.CHEST && real.getSize() > 27)
                ? plugin.getServer().createInventory(holder, real.getSize(), viewTitle(block))
                : plugin.getServer().createInventory(holder, type, viewTitle(block));
        holder.setInventory(copy);
        copy.setContents(real.getContents());

        player.openInventory(copy);
    }

    private Component viewTitle(Block block) {
        String name = block.getType().name().replace("_", " ").toLowerCase();
        name = Character.toUpperCase(name.charAt(0)) + name.substring(1);
        return Component.text(name + " (view only)");
    }
}
