package me.nothing.smpcore.systems.punishment2.commands;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class CheckMuteCommand implements CommandExecutor {
   private final SmpCorePunishment plugin;

   public CheckMuteCommand(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("smpcore.system.punishment.checkmute") && !sender.hasPermission("smpcore.system.punishment.check")) {
         sender.sendMessage(ColorUtil.color("&cYou do not have permission."));
         return true;
      } else if (args.length != 1) {
         sender.sendMessage(ColorUtil.color("&cUsage: /checkmute <player>"));
         return true;
      } else {
         me.nothing.smpcore.systems.punishment2.utils.PlayerLookup.Found target = me.nothing.smpcore.systems.punishment2.utils.PlayerLookup.find(this.plugin, args[0]);
         if (target == null) {
            sender.sendMessage(ColorUtil.color("&cPlayer not found."));
            return true;
         } else {
            Punishment punishment = this.plugin.getDatabaseManager().getActivePunishment(target.uuid(), "MUTE");
            if (punishment == null) {
               sender.sendMessage(ColorUtil.color("&aThis player has no active mute."));
               return true;
            } else {
               sender.sendMessage(ColorUtil.color("&8&m-----------------------------"));
               sender.sendMessage(ColorUtil.color("&#ff9933&lActive Mute"));
               sender.sendMessage(ColorUtil.color("&#9B9B9BPlayer: &#71F521" + punishment.getPlayer()));
               sender.sendMessage(ColorUtil.color("&#9B9B9BReason: &#71F521" + punishment.getReason()));
               sender.sendMessage(ColorUtil.color("&#9B9B9BStaff: &#71F521" + punishment.getStaff()));
               sender.sendMessage(ColorUtil.color("&#9B9B9BDuration: &#71F521" + punishment.getDuration()));
               long l = punishment.getExpireTime();
               sender.sendMessage(ColorUtil.color("&#9B9B9BTime Left: &#71F521" + TimeUtil.formatTime(l - System.currentTimeMillis())));
               sender.sendMessage(ColorUtil.color("&#9B9B9BOffense: &#71F521" + punishment.getOffense()));
               sender.sendMessage(ColorUtil.color("&8&m-----------------------------"));
               return true;
            }
         }
      }
   }
}
