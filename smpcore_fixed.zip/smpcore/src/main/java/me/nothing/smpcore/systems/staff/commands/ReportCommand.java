package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReportCommand extends BaseCommand {

    public ReportCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player reporter = requirePlayer(sender);
        if (reporter == null) return;
        if (!requirePermission(reporter, "galaxydestaff.report.use")) return;

        if (args.length < 2) {
            plugin.msg().send(reporter, "general.invalid-usage", MessagesManager.pairs("usage", "/report %player% %reason%"));
            return;
        }

        @SuppressWarnings("deprecation")
        org.bukkit.OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            plugin.msg().send(reporter, "general.player-not-found", MessagesManager.pairs("target", args[0]));
            return;
        }
        String targetName = target.getName() != null ? target.getName() : args[0];

        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

        plugin.reports().submit(reporter.getUniqueId(), reporter.getName(), target.getUniqueId(), targetName, reason, result -> {
            switch (result) {
                case OK -> {
                    plugin.msg().send(reporter, "report.submitted");

                    if (plugin.getConfig().getBoolean("reports.auto-broadcast-to-staff", true)) {
                        var placeholders = MessagesManager.pairs("staff", reporter.getName(), "target", targetName, "reason", reason);
                        for (Component line : plugin.msg().render("report.broadcast-staff", placeholders)) {
                            Bukkit.getOnlinePlayers().stream()
                                    .filter(p -> p.hasPermission("galaxydestaff.reports"))
                                    .forEach(p -> p.sendMessage(line));
                        }
                    }
                    plugin.discord().sendReportLog(targetName, reporter.getName(), reason);
                }
                case COOLDOWN -> plugin.msg().send(reporter, "report.cooldown",
                        MessagesManager.pairs("time", plugin.reports().cooldownRemainingSeconds(reporter.getUniqueId()) + "s"));
                case MAX_ACTIVE -> plugin.msg().send(reporter, "report.max-active",
                        MessagesManager.pairs("amount", String.valueOf(plugin.getConfig().getInt("reports.max-active-per-reporter", 3))));
            }
        });
    }
}
