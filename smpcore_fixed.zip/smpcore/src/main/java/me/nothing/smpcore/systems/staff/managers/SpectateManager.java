package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class SpectateManager {

    private record PreSpectateState(GameMode gameMode, Location location) {}

    private final GalaxydeStaff plugin;
    private final Map<UUID, PreSpectateState> savedStates = new ConcurrentHashMap<>();
    private final Map<UUID, UUID> spectating = new ConcurrentHashMap<>(); // staff -> target

    public SpectateManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public boolean isSpectating(UUID staffUuid) {
        return spectating.containsKey(staffUuid);
    }

    public UUID getTarget(UUID staffUuid) {
        return spectating.get(staffUuid);
    }

    public void start(Player staff, Player target) {
        savedStates.put(staff.getUniqueId(), new PreSpectateState(staff.getGameMode(), staff.getLocation().clone()));
        spectating.put(staff.getUniqueId(), target.getUniqueId());

        staff.setGameMode(GameMode.SPECTATOR);
        staff.teleport(target.getLocation());
        staff.setSpectatorTarget(target);

        plugin.audit().log(staff.getUniqueId(), staff.getName(), "SPECTATE_START", target.getUniqueId(), target.getName(), null);
    }

    public void stop(Player staff) {
        UUID targetUuid = spectating.remove(staff.getUniqueId());
        PreSpectateState state = savedStates.remove(staff.getUniqueId());

        staff.setSpectatorTarget(null);
        if (state != null) {
            staff.setGameMode(state.gameMode());
            staff.teleport(state.location());
        } else {
            staff.setGameMode(GameMode.SURVIVAL);
        }

        String targetName = targetUuid != null && plugin.getServer().getPlayer(targetUuid) != null
                ? plugin.getServer().getPlayer(targetUuid).getName() : null;
        plugin.audit().log(staff.getUniqueId(), staff.getName(), "SPECTATE_STOP", targetUuid, targetName, null);
    }

    /** Call when the spectated target disconnects, to pull the staff member out automatically. */
    public void stopAllSpectating(UUID targetUuid) {
        for (UUID staffUuid : spectating.keySet()) {
            if (targetUuid.equals(spectating.get(staffUuid))) {
                Player staff = plugin.getServer().getPlayer(staffUuid);
                if (staff != null) {
                    stop(staff);
                    plugin.msg().send(staff, "spectate.target-offline");
                }
            }
        }
    }

    public void clearAllOnShutdown() {
        savedStates.clear();
        spectating.clear();
    }
}
