package me.nothing.smpcore.systems.staff.managers;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.List;

public record PlayerSnapshot(
        Location location,
        GameMode gameMode,
        ItemStack[] inventoryContents,
        ItemStack[] armorContents,
        ItemStack offHand,
        float exp,
        int level,
        double health,
        int foodLevel,
        boolean allowFlight,
        boolean flying,
        List<PotionEffect> potionEffects,
        boolean wasVanishedBefore
) {}
