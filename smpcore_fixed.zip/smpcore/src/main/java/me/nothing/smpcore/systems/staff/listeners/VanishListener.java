package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class VanishListener implements Listener {

    private final GalaxydeStaff plugin;

    public VanishListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        Player joining = event.getPlayer();

        // Hide already-vanished staff from the new player.
        plugin.vanish().hideAllVanishedFrom(joining);

        // If the joining player was left vanished from a previous session (e.g. server restart
        // while in staff mode), nothing to restore here — vanish state doesn't persist across restarts.

        if (plugin.getConfig().getBoolean("vanish.hide-join-leave-messages", true)
                && plugin.vanish().isVanished(joining.getUniqueId())) {
            event.joinMessage(null);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        Player quitting = event.getPlayer();
        if (plugin.getConfig().getBoolean("vanish.hide-join-leave-messages", true)
                && plugin.vanish().isVanished(quitting.getUniqueId())) {
            event.quitMessage(null);
        }
    }
}
