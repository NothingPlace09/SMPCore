package me.nothing.smpcore.systems.chat;

import me.nothing.smpcore.utils.Rich;
import net.kyori.adventure.text.Component;

public class MessageUtil {
   /**
    * Stringa con codici § pronta per sendMessage(String).
    * (Prima restituiva codici "&": i messaggi di /chat, /smpcorechat e /clearchat comparivano con le & visibili.)
    */
   public static String color(String message) {
      return message == null ? "" : Rich.toLegacy(message);
   }

   public static Component component(String message) {
      return message == null ? Component.empty() : Rich.parseTrusted(message);
   }

   public static Component colorComponent(String message) {
      return message == null ? Component.empty() : Rich.parseTrusted(message);
   }
}
