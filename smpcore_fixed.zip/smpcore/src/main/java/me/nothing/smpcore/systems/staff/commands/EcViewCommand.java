package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import me.nothing.smpcore.systems.staff.gui.PlayerViewHolder;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class EcViewCommand extends BaseCommand {

    public EcViewCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.ecview")) return;

        if (args.length < 1) {
            plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/ecview %player%"));
            return;
        }

        // If the EnderChest plugin is installed, hand off to its own /ecsee command so staff
        // see the player's REAL (possibly paged/custom) ender chest instead of the vanilla one.
        if (plugin.getConfig().getBoolean("ecview.use-enderchest-plugin", true)
                && (Bukkit.getPluginManager().isPluginEnabled("EnderChest") || plugin.smp().configs().isEnabled("enderchest"))) {
            StringBuilder forwarded = new StringBuilder("ecsee ").append(args[0]);
            if (args.length >= 2) forwarded.append(" ").append(args[1]);
            staff.performCommand(forwarded.toString());
            plugin.audit().log(staff.getUniqueId(), staff.getName(), "ECVIEW", null, args[0], "via /ecsee");
            return;
        }

        Player target = requireOnlinePlayer(staff, args[0]);
        if (target == null) return;

        plugin.msg().send(staff, "ecview.header", MessagesManager.pairs("target", target.getName()));

        boolean editable = staff.hasPermission("galaxydestaff.ecview.edit");
        PlayerViewHolder holder = new PlayerViewHolder(PlayerViewHolder.Type.ECVIEW, target.getUniqueId(), editable);

        Inventory gui = Bukkit.createInventory(holder, 27, Component.text(target.getName() + "'s Ender Chest"));
        holder.setInventory(gui);
        gui.setContents(target.getEnderChest().getContents());

        staff.openInventory(gui);
        plugin.audit().log(staff.getUniqueId(), staff.getName(), "ECVIEW", target.getUniqueId(), target.getName(), null);
    }
}
