package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.stream.Collectors;

public class RandomTpCommand extends BaseCommand {

    public RandomTpCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.randomtp")) return;

        List<Player> eligible = Bukkit.getOnlinePlayers().stream()
                .filter(p -> !p.equals(staff))
                .filter(p -> !plugin.vanish().isVanished(p.getUniqueId()) || staff.hasPermission("galaxydestaff.vanish.see"))
                .collect(Collectors.toList());

        if (eligible.isEmpty()) {
            plugin.msg().send(staff, "randomtp.no-players");
            return;
        }

        Player target = eligible.get((int) (Math.random() * eligible.size()));
        staff.teleport(target.getLocation());
        plugin.msg().send(staff, "randomtp.teleported", MessagesManager.pairs("target", target.getName()));
        plugin.audit().log(staff.getUniqueId(), staff.getName(), "RANDOMTP", target.getUniqueId(), target.getName(), null);
    }
}
