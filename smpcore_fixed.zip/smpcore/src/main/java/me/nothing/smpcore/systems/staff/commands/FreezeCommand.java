package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FreezeCommand extends BaseCommand {

    public FreezeCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.freeze")) return;

        if (args.length < 1) {
            plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/freeze %player%"));
            return;
        }

        // Freeze works on offline players too — it's just a UUID flag, so a "pre-frozen" player
        // gets caught by FreezeListener the moment they join, without needing to be online now.
        Player onlineTarget = Bukkit.getPlayerExact(args[0]);
        @SuppressWarnings("deprecation")
        OfflinePlayer offlineTarget = onlineTarget != null ? onlineTarget : Bukkit.getOfflinePlayer(args[0]);

        if (onlineTarget == null && !offlineTarget.hasPlayedBefore()) {
            plugin.msg().send(staff, "general.player-not-found", MessagesManager.pairs("target", args[0]));
            return;
        }

        String targetName = offlineTarget.getName() != null ? offlineTarget.getName() : args[0];
        boolean nowFrozen = plugin.freeze().toggle(offlineTarget.getUniqueId());

        plugin.msg().send(staff, nowFrozen ? "freeze.frozen-other" : "freeze.unfrozen-other",
                MessagesManager.pairs("target", targetName));

        if (onlineTarget != null) {
            plugin.msg().send(onlineTarget, nowFrozen ? "freeze.frozen-self" : "freeze.unfrozen-self");
        }

        if (nowFrozen
                && plugin.getConfig().getBoolean("freeze.notify-staffchat", true)
                && !staff.hasPermission("galaxydestaff.freeze.notify-bypass")) {
            var placeholders = MessagesManager.pairs("staff", staff.getName(), "target", targetName);
            for (var line : plugin.msg().render("freeze.staffchat-notify", placeholders)) {
                Bukkit.getOnlinePlayers().stream()
                        .filter(p -> p.hasPermission("galaxydestaff.staffchat"))
                        .forEach(p -> p.sendMessage(line));
            }
        }

        var punishment = me.nothing.smpcore.systems.punishment2.SmpCorePunishment.getInstance();
        if (punishment != null && plugin.smp().configs().isEnabled("punishment")) {
            punishment.logFreeze(offlineTarget.getUniqueId(), targetName, staff.getName(), nowFrozen);
        }

        plugin.audit().log(staff.getUniqueId(), staff.getName(), nowFrozen ? "FREEZE" : "UNFREEZE",
                offlineTarget.getUniqueId(), targetName, null);
    }
}
