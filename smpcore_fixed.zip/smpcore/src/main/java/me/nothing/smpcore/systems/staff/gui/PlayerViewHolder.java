package me.nothing.smpcore.systems.staff.gui;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

/**
 * Marker holder for the /invsee and /ecview GUIs. Slot layout for INVSEE:
 *   0 = helmet, 1 = chestplate, 2 = leggings, 3 = boots, 4 = offhand,
 *   5-8 = unused, 9-44 = main inventory storage (36 slots, hotbar first).
 * ECVIEW just mirrors the 27 ender chest slots 1:1 with no armor row.
 *
 * When editable, clicks are allowed (StaffGuiListener doesn't cancel them) and this holder
 * writes the GUI's contents back onto the target's real inventory after every click and on
 * close. When read-only, StaffGuiListener cancels every click so nothing here ever changes.
 */
public class PlayerViewHolder implements InventoryHolder {

    public enum Type { INVSEE, ECVIEW }

    private final Type type;
    private final UUID targetUuid;
    private final boolean editable;
    private Inventory inventory;

    public PlayerViewHolder(Type type, UUID targetUuid, boolean editable) {
        this.type = type;
        this.targetUuid = targetUuid;
        this.editable = editable;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    public Type getType() {
        return type;
    }

    public UUID getTargetUuid() {
        return targetUuid;
    }

    public boolean isEditable() {
        return editable;
    }

    /** Writes whatever is currently in the GUI back onto the target's real inventory. No-op if they've gone offline. */
    public void syncToTarget(GalaxydeStaff plugin) {
        if (!editable || inventory == null) return;
        Player target = plugin.getServer().getPlayer(targetUuid);
        if (target == null) return;

        if (type == Type.INVSEE) {
            ItemStack[] storage = new ItemStack[36];
            for (int i = 0; i < 36; i++) storage[i] = inventory.getItem(9 + i);
            target.getInventory().setStorageContents(storage);

            target.getInventory().setHelmet(inventory.getItem(0));
            target.getInventory().setChestplate(inventory.getItem(1));
            target.getInventory().setLeggings(inventory.getItem(2));
            target.getInventory().setBoots(inventory.getItem(3));
            target.getInventory().setItemInOffHand(inventory.getItem(4));
        } else {
            ItemStack[] contents = new ItemStack[27];
            for (int i = 0; i < 27; i++) contents[i] = inventory.getItem(i);
            target.getEnderChest().setContents(contents);
        }
    }
}
