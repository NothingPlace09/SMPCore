package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import me.nothing.smpcore.systems.staff.gui.PlayerViewHolder;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class InvSeeCommand extends BaseCommand {

    public InvSeeCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.invsee")) return;

        if (args.length < 1) {
            plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/invsee %player%"));
            return;
        }

        Player target = requireOnlinePlayer(staff, args[0]);
        if (target == null) return;

        plugin.msg().send(staff, "invsee.header", MessagesManager.pairs("target", target.getName()));

        boolean editable = staff.hasPermission("galaxydestaff.invsee.edit");
        PlayerViewHolder holder = new PlayerViewHolder(PlayerViewHolder.Type.INVSEE, target.getUniqueId(), editable);

        Inventory gui = Bukkit.createInventory(holder, 45, Component.text(target.getName() + "'s Inventory"));
        holder.setInventory(gui);

        // Slots 0-3: armor (helmet, chestplate, leggings, boots). Slot 4: offhand. 5-8 unused.
        // Slots 9-44: main inventory storage (36 slots, hotbar first) — same layout as PlayerInventory#getStorageContents().
        gui.setItem(0, target.getInventory().getHelmet());
        gui.setItem(1, target.getInventory().getChestplate());
        gui.setItem(2, target.getInventory().getLeggings());
        gui.setItem(3, target.getInventory().getBoots());
        gui.setItem(4, target.getInventory().getItemInOffHand());

        ItemStack[] storage = target.getInventory().getStorageContents();
        for (int i = 0; i < storage.length; i++) {
            gui.setItem(9 + i, storage[i]);
        }

        staff.openInventory(gui);
        plugin.audit().log(staff.getUniqueId(), staff.getName(), "INVSEE", target.getUniqueId(), target.getName(), null);
    }
}
