package me.nothing.smpcore.systems.staff.config;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.util.ChatCenter;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Every entry in messages.yml is a YAML list of lines, exactly like item lore.
 * Colors use legacy & codes (&c, &l, &o, ...) plus hex colors as &#RRGGBB.
 * Placeholders use %key% (e.g. %target%, %staff%, %reason%).
 * Wrap a line's text in <center>...</center> to have it centered in chat automatically.
 */
public class MessagesManager {

    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final Pattern CENTER_PATTERN = Pattern.compile("(?is)^\\s*<center>(.*)</center>\\s*$");
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();

    private final GalaxydeStaff plugin;
    private YamlConfiguration messages;
    private List<String> prefixLines;

    public MessagesManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
        load();
    }

    public void reload() {
        load();
    }

    private void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        this.messages = YamlConfiguration.loadConfiguration(file);
        this.prefixLines = messages.getStringList("prefix");
    }

    /** Raw lines for a message path, unresolved. Empty list if missing. */
    public List<String> raw(String path) {
        List<String> list = messages.getStringList(path);
        return list == null ? new ArrayList<>() : list;
    }

    private String prefix() {
        return prefixLines.isEmpty() ? "" : String.join("", prefixLines);
    }

    /** Expands the shorthand &#RRGGBB into the &x&R&R&G&G&B&B form the legacy ampersand serializer understands. */
    private String expandHex(String input) {
        Matcher matcher = HEX_PATTERN.matcher(input);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("&x");
            for (char c : hex.toCharArray()) {
                replacement.append('&').append(c);
            }
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement.toString()));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    /** If the whole line is wrapped in <center>...</center>, strips the tags and pads it with leading spaces to center it. */
    private String applyCenter(String input) {
        Matcher matcher = CENTER_PATTERN.matcher(input);
        if (!matcher.matches()) return input;
        return ChatCenter.center(matcher.group(1));
    }

    /** Resolves a message into rendered Components, one per line, with %placeholders% applied and %prefix% expanded. */
    public List<Component> render(String path, Map<String, String> placeholders) {
        List<Component> out = new ArrayList<>();
        for (String line : raw(path)) {
            String resolved = line.replace("%prefix%", prefix());
            if (placeholders != null) {
                for (Map.Entry<String, String> e : placeholders.entrySet()) {
                    resolved = resolved.replace("%" + e.getKey() + "%", e.getValue());
                }
            }
            resolved = applyCenter(resolved);
            resolved = expandHex(resolved);
            out.add(me.nothing.smpcore.utils.Rich.parseTrusted(resolved));
        }
        return out;
    }

    public List<Component> render(String path) {
        return render(path, Map.of());
    }

    /** Sends every line of a message to a sender. */
    public void send(CommandSender sender, String path, Map<String, String> placeholders) {
        for (Component c : render(path, placeholders)) {
            sender.sendMessage(c);
        }
    }

    public void send(CommandSender sender, String path) {
        send(sender, path, Map.of());
    }

    /** Convenience builder for placeholders: pairs("target", name, "reason", reason...) */
    public static Map<String, String> pairs(String... kv) {
        Map<String, String> map = new LinkedHashMap<>();
        for (int i = 0; i + 1 < kv.length; i += 2) {
            map.put(kv[i], kv[i + 1]);
        }
        return map;
    }
}
