package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class FreezeListener implements Listener {

    private final GalaxydeStaff plugin;

    public FreezeListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    private boolean frozen(Player p) {
        return plugin.freeze().isFrozen(p.getUniqueId());
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!plugin.getConfig().getBoolean("freeze.cancel-movement", true)) return;
        if (!frozen(event.getPlayer())) return;

        // Allow head/camera rotation, only block actual position change.
        if (event.getFrom().getX() != event.getTo().getX()
                || event.getFrom().getY() != event.getTo().getY()
                || event.getFrom().getZ() != event.getTo().getZ()) {
            event.setTo(event.getFrom());
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!plugin.getConfig().getBoolean("freeze.cancel-commands", true)) return;
        Player player = event.getPlayer();
        if (!frozen(player)) return;

        // /message[0] includes the leading slash, e.g. "/msg foo bar" -> label "msg"
        String label = event.getMessage().split(" ")[0].substring(1);
        if (!plugin.freeze().isCommandAllowedWhileFrozen(label)) {
            event.setCancelled(true);
            plugin.msg().send(player, "freeze.blocked-action");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (frozen(event.getPlayer())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (frozen(event.getPlayer())) {
            event.setCancelled(true);
            plugin.msg().send(event.getPlayer(), "freeze.blocked-action");
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (frozen(event.getPlayer())) {
            event.setCancelled(true);
            plugin.msg().send(event.getPlayer(), "freeze.blocked-action");
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        // Catches players who were frozen while offline (pre-freeze via /freeze <offline player>) —
        // movement/interact/etc are already blocked by the handlers above regardless of when the
        // freeze was applied, this just makes sure they get told about it.
        Player player = event.getPlayer();
        if (frozen(player)) {
            plugin.msg().send(player, "freeze.frozen-self");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        // Con punish-on-quit attivo, chi esce da congelato viene bannato (sistema punishment) e scongelato.
        // Altrimenti resta congelato anche alla riconnessione.
        Player player = event.getPlayer();
        if (!frozen(player)
                || !plugin.getConfig().getBoolean("freeze.punish-on-quit.enabled", true)
                || player.hasPermission("smpcore.system.punishment.bypass")) {
            return;
        }

        var punishment = me.nothing.smpcore.systems.punishment2.SmpCorePunishment.getInstance();
        if (punishment != null && plugin.smp().configs().isEnabled("punishment")) {
            punishment.banFrozenQuit(player,
                    plugin.getConfig().getString("freeze.punish-on-quit.reason", "Leaving while Frozen"),
                    plugin.getConfig().getString("freeze.punish-on-quit.duration", "7d"));
            plugin.freeze().toggle(player.getUniqueId());
        }
    }
}
