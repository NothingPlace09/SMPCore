package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.util.List;

public class StaffHelpCommand extends BaseCommand {

    private record Entry(String command, String description, String permission) {}

    private static final List<Entry> ENTRIES = List.of(
            new Entry("/staffmode", "Toggle staff mode (creative, fly, vanish, saved inventory)", "galaxydestaff.staffmode"),
            new Entry("/vanish", "Toggle invisibility to other players", "galaxydestaff.vanish"),
            new Entry("/staffchat [message]", "Toggle sticky staffchat, or send one message", "galaxydestaff.staffchat"),
            new Entry("/freeze <player>", "Freeze/unfreeze a player (works even if they're offline)", "galaxydestaff.freeze"),
            new Entry("/invsee <player>", "View a player's inventory + armor", "galaxydestaff.invsee"),
            new Entry("/ecview <player>", "View a player's ender chest", "galaxydestaff.ecview"),
            new Entry("/staffspectate <player>", "Spectate a player (no args to stop)", "galaxydestaff.spectate"),
            new Entry("/randomtp", "Teleport to a random online player", "galaxydestaff.randomtp"),
            new Entry("/tphere <player>", "Teleport a player to you", "galaxydestaff.tphere"),
            new Entry("/spawnstash", "Place the staff stash structure at your position", "galaxydestaff.spawnstash"),
            new Entry("/playeralert <player> <reason>", "Alert all staff about a player", "galaxydestaff.playeralert"),
            new Entry("/report <player> <reason>", "Report a player", "galaxydestaff.report.use"),
            new Entry("/reports [page]", "View open reports", "galaxydestaff.reports"),
            new Entry("/reports resolve <id>", "Mark a report as resolved", "galaxydestaff.reports"),
            new Entry("/staffhistory <staff>", "View a staff member's logged actions", "galaxydestaff.staffhistory"),
            new Entry("/staffnote add <player> <text>", "Add a note to a player", "galaxydestaff.staffnote"),
            new Entry("/staffnote list <player>", "List a player's notes", "galaxydestaff.staffnote"),
            new Entry("/staffnote remove <id>", "Remove a note by id", "galaxydestaff.staffnote.remove"),
            new Entry("/galaxydestaff reload", "Reload config.yml and messages.yml", "galaxydestaff.admin")
    );

    public StaffHelpCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        plugin.msg().send(sender, "staffhelp.header");

        boolean anyShown = false;
        for (Entry entry : ENTRIES) {
            if (!sender.hasPermission(entry.permission())) continue;
            anyShown = true;
            plugin.msg().send(sender, "staffhelp.entry",
                    MessagesManager.pairs("command", entry.command(), "description", entry.description()));
        }

        if (!anyShown) {
            plugin.msg().send(sender, "general.no-permission");
            return;
        }

        plugin.msg().send(sender, "staffhelp.footer");
    }
}
