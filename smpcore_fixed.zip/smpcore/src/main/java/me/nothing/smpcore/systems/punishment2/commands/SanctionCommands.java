package me.nothing.smpcore.systems.punishment2.commands;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.BanIdUtil;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

/**
 * /ban /tempban /unban /mute /tempmute /unmute /warn /kick /unoffend: un solo esecutore, la modalita' dice cosa fa.
 * Salva nel database delle punizioni, applica la sanzione, avvisa la chat e manda l'embed sul webhook.
 */
public class SanctionCommands implements TabExecutor {
   public enum Mode {
      BAN("ban", false, false),
      TEMPBAN("ban", true, false),
      MUTE("mute", false, false),
      TEMPMUTE("mute", true, false),
      WARN("warn", false, false),
      KICK("kick", false, false),
      UNBAN("unban", false, true),
      UNMUTE("unmute", false, true),
      UNOFFEND("unoffend", false, true);

      final String permission;
      final boolean timed;
      final boolean removal;

      private Mode(String permission, boolean timed, boolean removal) {
         this.permission = "smpcore.system.punishment." + permission;
         this.timed = timed;
         this.removal = removal;
      }
   }

   private static final List<String> DURATIONS = List.of("30m", "1h", "12h", "1d", "3d", "7d", "14d", "30d");

   private final SmpCorePunishment plugin;
   private final Mode mode;

   public SanctionCommands(SmpCorePunishment plugin, Mode mode) {
      this.plugin = plugin;
      this.mode = mode;
   }

   private String msg(String path, String def) {
      return this.plugin.getMessages().getString(path, def);
   }

   private void send(CommandSender to, String text) {
      to.sendMessage(ColorUtil.color(text));
   }

   private String usage(String label) {
      return switch (this.mode) {
         case TEMPBAN, TEMPMUTE -> "/" + label + " <player> <duration> [reason]";
         case WARN -> "/" + label + " <player> <reason>";
         default -> "/" + label + " <player> [reason]";
      };
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission(this.mode.permission)) {
         this.send(sender, this.msg("no-permission", "&cYou do not have permission."));
         return true;
      }

      int minArgs = this.mode.timed ? 2 : 1;
      if (args.length < minArgs) {
         this.send(sender, this.msg("usage." + label.toLowerCase(Locale.ROOT), "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Usage: " + this.usage(label)));
         return true;
      }

      // il nome si scrive come si vuole (justnothing7 = JustNothing7), anche per chi e' offline
      me.nothing.smpcore.systems.punishment2.utils.PlayerLookup.Found found = me.nothing.smpcore.systems.punishment2.utils.PlayerLookup.find(this.plugin, args[0]);
      if (found == null) {
         this.send(sender, this.msg("player-not-found", "&cPlayer not found: &#71F521") + args[0]);
         return true;
      }

      OfflinePlayer target = found.offline();
      String name = found.name();
      int reasonFrom = this.mode.timed ? 2 : 1;
      String reason = String.join(" ", java.util.Arrays.copyOfRange(args, Math.min(reasonFrom, args.length), args.length)).trim();
      if (reason.isEmpty()) {
         if (this.mode == Mode.WARN) {
            this.send(sender, this.msg("usage.warn", "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Usage: " + this.usage(label)));
            return true;
         }

         reason = this.plugin.getConfig().getString("settings.default-reason", "No reason specified");
      }

      if (this.mode.removal) {
         return this.remove(sender, target, name, reason);
      }

      if (sender instanceof Player p && p.getUniqueId().equals(found.uuid())) {
         this.send(sender, this.msg("cannot-self", "&cYou cannot punish yourself."));
         return true;
      }

      Player online = target.getPlayer();
      if (online != null && online.hasPermission("smpcore.system.punishment.bypass")) {
         this.send(sender, this.msg("cannot-punish", "&cThat player cannot be punished."));
         return true;
      }

      if (this.mode == Mode.KICK) {
         return this.kick(sender, online, name, reason);
      }

      if (this.mode == Mode.WARN) {
         return this.warn(sender, target, online, name, reason);
      }

      boolean ban = this.mode == Mode.BAN || this.mode == Mode.TEMPBAN;
      String type = ban ? "BAN" : "MUTE";
      String duration = "Permanent";
      long expire = -1L;
      if (this.mode.timed) {
         long millis = TimeUtil.parseDuration(args[1]);
         if (millis < 0L) {
            this.send(sender, this.msg("invalid-duration", "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Invalid duration. Examples: 30m, 12h, 7d, 2w, 1M"));
            return true;
         }

         duration = args[1];
         expire = System.currentTimeMillis() + millis;
      }

      if (this.plugin.getDatabaseManager().getActivePunishment(target.getUniqueId(), type) != null) {
         this.send(sender, this.msg(ban ? "already-banned" : "already-muted", ban ? "&cThat player is already banned. Use /unban first." : "&cThat player is already muted. Use /unmute first.").replace("%player%", name));
         return true;
      }

      int offense = this.plugin.getDatabaseManager().countType(target.getUniqueId(), type) + 1;
      Punishment punishment = new Punishment(target.getUniqueId(), name, type, reason, duration, expire, sender.getName(), offense, BanIdUtil.generate(), System.currentTimeMillis(), true);
      this.plugin.getDatabaseManager().savePunishment(punishment);
      boolean permanent = expire == -1L;
      if (ban) {
         if (online != null) {
            online.kickPlayer(this.plugin.getBanScreenManager().createScreen(punishment));
         }

         this.broadcast(permanent ? "punishment.permban-broadcast" : "punishment.ban-broadcast", permanent ? "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Permanently Banned &#71F521%player% &#FF2121Reason: &#71F521%reason%" : "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Temporary Banned &#71F521%player% &#FF2121for &#71F521%duration% &#FF2121Reason: &#71F521%reason%", name, duration, reason, sender.getName());
      } else {
         if (online != null) {
            for(String line : this.plugin.getMessages().getStringList("mute.notify")) {
               online.sendMessage(ColorUtil.color(line.replace("%reason%", reason).replace("%duration%", duration).replace("%time%", TimeUtil.formatTime(permanent ? -1L : expire - System.currentTimeMillis())).replace("%staff%", sender.getName())));
            }
         }

         this.broadcast(permanent ? "punishment.permmute-broadcast" : "punishment.mute-broadcast", permanent ? "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Permanently Muted &#71F521%player% &#FF2121Reason: &#71F521%reason%" : "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Temporary Muted &#71F521%player% &#FF2121for &#71F521%duration% &#FF2121Reason: &#71F521%reason%", name, duration, reason, sender.getName());
      }

      this.plugin.getWebhookManager().sendPunishment(type, punishment);
      return true;
   }

   private boolean kick(CommandSender sender, Player online, String name, String reason) {
      if (online == null) {
         this.send(sender, this.msg("player-not-online", "&cThat player is not online."));
         return true;
      }

      Punishment punishment = new Punishment(online.getUniqueId(), online.getName(), "KICK", reason, "Instant", 0L, sender.getName(), this.plugin.getDatabaseManager().countType(online.getUniqueId(), "KICK") + 1, "NONE", System.currentTimeMillis(), false);
      this.plugin.getDatabaseManager().savePunishment(punishment);
      FileConfiguration messages = this.plugin.getMessages();
      StringBuilder screen = new StringBuilder(ColorUtil.color(messages.getString("kick.screen.title", "&#9B9B9BConnection Lost")));
      for(String line : messages.getStringList("kick.screen.lines")) {
         screen.append("\n").append(ColorUtil.color(line.replace("{reason}", reason).replace("{staff}", sender.getName())));
      }

      online.kickPlayer(screen.toString());
      this.broadcast("punishment.kick-broadcast", "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Player &#71F521%player% &#FF2121was kicked. Reason: &#71F521%reason%", name, "Instant", reason, sender.getName());
      this.plugin.getWebhookManager().sendPunishment("KICK", punishment);
      return true;
   }

   private boolean warn(CommandSender sender, OfflinePlayer target, Player online, String name, String reason) {
      int offense = this.plugin.getDatabaseManager().countType(target.getUniqueId(), "WARN") + 1;
      Punishment punishment = new Punishment(target.getUniqueId(), name, "WARN", reason, "Instant", 0L, sender.getName(), offense, "NONE", System.currentTimeMillis(), false);
      this.plugin.getDatabaseManager().savePunishment(punishment);
      if (online != null) {
         for(String line : this.plugin.getMessages().getStringList("warn.notify")) {
            online.sendMessage(ColorUtil.color(line.replace("%reason%", reason).replace("%staff%", sender.getName()).replace("%offense%", String.valueOf(offense))));
         }
      }

      this.broadcast("punishment.warn-broadcast", "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FFD900Player &#71F521%player% &#FFD900was warned. Reason: &#71F521%reason%", name, "Instant", reason, sender.getName());
      this.plugin.getWebhookManager().sendPunishment("WARN", punishment);
      return true;
   }

   private boolean remove(CommandSender sender, OfflinePlayer target, String name, String reason) {
      java.util.UUID id = target.getUniqueId();
      // /unoffend con un motivo uguale a quello di una punizione attiva toglie solo quella; altrimenti toglie tutto
      boolean targeted = false;
      if (this.mode == Mode.UNOFFEND) {
         for(Punishment p : this.plugin.getDatabaseManager().getHistory(id)) {
            if (p.isActive() && p.getReason() != null && p.getReason().equalsIgnoreCase(reason)) {
               targeted = true;
               break;
            }
         }
      }

      int removed;
      switch (this.mode) {
         case UNBAN -> removed = this.plugin.getDatabaseManager().deactivateType(id, "BAN");
         case UNMUTE -> removed = this.plugin.getDatabaseManager().deactivateType(id, "MUTE");
         default -> removed = targeted ? this.plugin.getDatabaseManager().deactivateByReason(id, reason) : this.plugin.getDatabaseManager().deactivateAll(id);
      }

      boolean ipRemoved = false;
      if (this.mode != Mode.UNMUTE) {
         if (targeted) {
            ipRemoved = this.plugin.getIpBanManager().hasActiveForPlayer(name, reason);
            this.plugin.getIpBanManager().removeByPlayerAndReason(name, reason);
         } else {
            ipRemoved = !this.plugin.getIpBanManager().getActiveReasonsForPlayer(name).isEmpty();
            this.plugin.getIpBanManager().removeAllForPlayer(name);
         }
      }

      if (removed == 0 && !ipRemoved) {
         this.send(sender, this.msg(switch (this.mode) {
            case UNBAN -> "remove.no-ban";
            case UNMUTE -> "remove.no-mute";
            default -> "remove.none";
         }, "&cNo active punishment found for &#71F521%player%&c.").replace("%player%", name));
         return true;
      }

      Punishment log = new Punishment(id, name, "UNOFFEND", reason, "N/A", 0L, sender.getName(), 0, "NONE", System.currentTimeMillis(), false);
      this.plugin.getWebhookManager().sendUnoffend(log, sender.getName());
      this.broadcast("punishment.unoffend-broadcast", "&#72EEFF&lPUNISHMENT &#9B9B9B» &#71F521Punishment removed from &#71F521%player% &#71F521Reason: &#71F521%reason%", name, "N/A", reason, sender.getName());
      this.send(sender, this.msg("remove.done", "&aPunishment removed successfully."));
      return true;
   }

   private void broadcast(String path, String def, String player, String duration, String reason, String staff) {
      String text = this.msg(path, def).replace("%player%", player).replace("%duration%", duration).replace("%reason%", reason).replace("%staff%", staff);
      Bukkit.broadcastMessage(ColorUtil.color(text));
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> out = new ArrayList<>();
      if (!sender.hasPermission(this.mode.permission)) {
         return out;
      }

      String typed = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
      if (args.length == 1) {
         for(Player p : Bukkit.getOnlinePlayers()) {
            if (p.getName().toLowerCase(Locale.ROOT).startsWith(typed)) {
               out.add(p.getName());
            }
         }

         // unban / unmute / unoffend suggeriscono anche i giocatori offline che hanno davvero una sanzione attiva
         if (this.mode.removal) {
            String type = this.mode == Mode.UNBAN ? "BAN" : this.mode == Mode.UNMUTE ? "MUTE" : null;
            for(String n : this.plugin.getDatabaseManager().activeNames(type)) {
               if (n != null && n.toLowerCase(Locale.ROOT).startsWith(typed) && !out.contains(n)) {
                  out.add(n);
               }
            }
         }
      } else if (args.length == 2 && this.mode.timed) {
         for(String d : DURATIONS) {
            if (d.startsWith(typed)) {
               out.add(d);
            }
         }
      }

      return out;
   }
}
