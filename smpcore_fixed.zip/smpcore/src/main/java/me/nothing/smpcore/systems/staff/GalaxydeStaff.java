package me.nothing.smpcore.systems.staff;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.systems.SystemHost;
import me.nothing.smpcore.systems.staff.commands.*;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import me.nothing.smpcore.systems.staff.database.DatabaseManager;
import me.nothing.smpcore.systems.staff.discord.DiscordWebhookManager;
import me.nothing.smpcore.systems.staff.listeners.*;
import me.nothing.smpcore.systems.staff.managers.*;
import me.nothing.smpcore.systems.staff.util.CommandUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;

/**
 * Sistema "staff" di SmpCore (ex GalaxydeStaff): staffmode, vanish, freeze, invsee, ecview, report, history, note...
 * Dati in plugins/SmpCore/staff/ (config.yml, messages.yml). Sanzioni (ban/mute/kick...) sono nel sistema punishment.
 */
public final class GalaxydeStaff extends SystemHost {
   /** Tutti i comandi dello staff: nome in plugin.yml -> permesso. */
   private static final Map<String, String> PERMISSIONS = new LinkedHashMap<>();

   static {
      PERMISSIONS.put("spawnstash", "galaxydestaff.spawnstash");
      PERMISSIONS.put("playeralert", "galaxydestaff.playeralert");
      PERMISSIONS.put("staffchat", "galaxydestaff.staffchat");
      PERMISSIONS.put("vanish", "galaxydestaff.vanish");
      PERMISSIONS.put("freeze", "galaxydestaff.freeze");
      PERMISSIONS.put("invsee", "galaxydestaff.invsee");
      PERMISSIONS.put("ecview", "galaxydestaff.ecview");
      PERMISSIONS.put("staffspectate", "galaxydestaff.spectate");
      PERMISSIONS.put("randomtp", "galaxydestaff.randomtp");
      PERMISSIONS.put("tphere", "galaxydestaff.tphere");
      PERMISSIONS.put("staffmode", "galaxydestaff.staffmode");
      PERMISSIONS.put("report", "galaxydestaff.report.use");
      PERMISSIONS.put("reports", "galaxydestaff.reports");
      PERMISSIONS.put("staffhistory", "galaxydestaff.staffhistory");
      PERMISSIONS.put("staffnote", "galaxydestaff.staffnote");
      PERMISSIONS.put("galaxydestaff", "galaxydestaff.admin");
      PERMISSIONS.put("staffhelp", "galaxydestaff.staffhelp");
   }

   private static GalaxydeStaff instance;

   private final SmpCore smp;
   private DatabaseManager databaseManager;
   private MessagesManager messagesManager;
   private DiscordWebhookManager discordWebhookManager;
   private VanishManager vanishManager;
   private StaffModeManager staffModeManager;
   private FreezeManager freezeManager;
   private SpectateManager spectateManager;
   private ReportManager reportManager;
   private StaffNoteManager staffNoteManager;
   private AuditLogManager auditLogManager;
   private StaffChatManager staffChatManager;
   private SpawnStashManager spawnStashManager;

   private final List<Listener> listeners = new ArrayList<>();
   private final List<PluginCommand> ownCommands = new ArrayList<>();
   private boolean started;

   public GalaxydeStaff(SmpCore core) {
      super("staff");
      this.smp = core;
      this.init(core, new File(core.getDataFolder(), "staff"));
   }

   public boolean isStarted() {
      return this.started;
   }

   public void enable() {
      instance = this;
      this.saveDefaultConfig();
      this.saveResource("messages.yml", false);
      this.messagesManager = new MessagesManager(this);

      try {
         this.databaseManager = new DatabaseManager(this);
         this.databaseManager.connect();
         this.databaseManager.initSchema();
      } catch (Throwable e) {
         this.getLogger().log(Level.SEVERE, "[staff] Could not open the staff database (plugins/SmpCore/staff/staff.db): " + e.getMessage());
         if (this.databaseManager != null) {
            this.databaseManager.close();
         }

         this.databaseManager = null;
         this.registerOfflineFallback();
         return;
      }

      this.discordWebhookManager = new DiscordWebhookManager(this);
      this.auditLogManager = new AuditLogManager(this);
      this.vanishManager = new VanishManager(this);
      this.staffModeManager = new StaffModeManager(this);
      this.freezeManager = new FreezeManager(this);
      this.spectateManager = new SpectateManager(this);
      this.reportManager = new ReportManager(this);
      this.staffNoteManager = new StaffNoteManager(this);
      this.staffChatManager = new StaffChatManager(this);
      this.spawnStashManager = new SpawnStashManager(this);
      this.registerCommands();
      this.registerListeners();
      this.started = true;
      List<String> forceCommands = this.getConfig().getStringList("force-commands");
      if (!forceCommands.isEmpty()) {
         Bukkit.getScheduler().runTask(this.smp, () -> {
            for(String name : forceCommands) {
               CommandUtil.forceOverride(this.smp, name);
            }
         });
      }

      this.getLogger().info("[staff] Staff system enabled.");
   }

   public void disable() {
      this.started = false;
      if (this.staffModeManager != null) {
         this.staffModeManager.restoreAllOnShutdown();
      }

      if (this.vanishManager != null) {
         this.vanishManager.clearAllOnShutdown();
      }

      for(Listener l : this.listeners) {
         HandlerList.unregisterAll(l);
      }

      this.listeners.clear();

      for(PluginCommand pc : this.ownCommands) {
         pc.setExecutor((CommandExecutor)null);
      }

      this.ownCommands.clear();
      if (this.databaseManager != null) {
         this.databaseManager.close();
         this.databaseManager = null;
      }
   }

   /** Senza database i comandi solo-staff dicono perche' non funzionano, invece di restare muti. */
   private void registerOfflineFallback() {
      CommandExecutor off = (sender, command, label, args) -> {
         sender.sendMessage("§cStaff system offline: could not open its database (staff/staff.db). Check the console.");
         return true;
      };

      for(String name : PERMISSIONS.keySet()) {
         PluginCommand pc = this.getCommand(name);
         if (pc != null) {
            pc.setExecutor(off);
            this.ownCommands.add(pc);
         }
      }
   }

   private void registerCommands() {
      List<String> disabled = this.getConfig().getStringList("disabled-commands").stream().map(String::toLowerCase).toList();
      this.registerCommand("spawnstash", new SpawnStashCommand(this), disabled);
      this.registerCommand("playeralert", new PlayerAlertCommand(this), disabled);
      this.registerCommand("staffchat", new StaffChatCommand(this), disabled);
      this.registerCommand("vanish", new VanishCommand(this), disabled);
      this.registerCommand("freeze", new FreezeCommand(this), disabled);
      this.registerCommand("invsee", new InvSeeCommand(this), disabled);
      this.registerCommand("ecview", new EcViewCommand(this), disabled);
      this.registerCommand("staffspectate", new SpectateCommand(this), disabled);
      this.registerCommand("randomtp", new RandomTpCommand(this), disabled);
      this.registerCommand("tphere", new TpHereCommand(this), disabled);
      this.registerCommand("staffmode", new StaffModeCommand(this), disabled);
      this.registerCommand("report", new ReportCommand(this), disabled);
      this.registerCommand("reports", new ReportsCommand(this), disabled);
      this.registerCommand("staffhistory", new StaffHistoryCommand(this), disabled);
      this.registerCommand("staffnote", new StaffNoteCommand(this), disabled);
      this.registerCommand("galaxydestaff", new GalaxydeStaffAdminCommand(this), disabled);
      this.registerCommand("staffhelp", new StaffHelpCommand(this), disabled);
   }

   /**
    * Collega un comando dello staff. Se il nome e' in disabled-commands il comando non viene collegato e viene tolto dal server.
    */
   private void registerCommand(String name, CommandExecutor executor, List<String> disabled) {
      if (disabled.contains(name.toLowerCase())) {
         CommandUtil.unregister(this.smp, name);
      } else {
         PluginCommand pc = this.getCommand(name);
         if (pc != null) {
            pc.setExecutor(executor);
            pc.setPermission(PERMISSIONS.get(name));
            this.ownCommands.add(pc);
         }
      }
   }

   private void registerListeners() {
      this.listen(new StaffModeListener(this));
      this.listen(new FreezeListener(this));
      this.listen(new VanishListener(this));
      this.listen(new StaffChatListener(this));
      this.listen(new SpectateListener(this));
      this.listen(new StaffGuiListener(this));
      this.listen(new StaffModeItemListener(this));
      this.listen(new ContainerPeekListener(this));
   }

   private void listen(Listener l) {
      this.listeners.add(l);
      this.getServer().getPluginManager().registerEvents(l, this.smp);
   }

   public void reload() {
      this.reloadConfig();
      this.messagesManager.reload();
   }

   public static GalaxydeStaff get() {
      return instance;
   }

   public SmpCore smp() {
      return this.smp;
   }

   public DatabaseManager db() {
      return this.databaseManager;
   }

   public MessagesManager msg() {
      return this.messagesManager;
   }

   public DiscordWebhookManager discord() {
      return this.discordWebhookManager;
   }

   public VanishManager vanish() {
      return this.vanishManager;
   }

   public StaffModeManager staffMode() {
      return this.staffModeManager;
   }

   public FreezeManager freeze() {
      return this.freezeManager;
   }

   public SpectateManager spectate() {
      return this.spectateManager;
   }

   public ReportManager reports() {
      return this.reportManager;
   }

   public StaffNoteManager staffNotes() {
      return this.staffNoteManager;
   }

   public AuditLogManager audit() {
      return this.auditLogManager;
   }

   public StaffChatManager staffChat() {
      return this.staffChatManager;
   }

   public SpawnStashManager spawnStash() {
      return this.spawnStashManager;
   }
}
