package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.logging.Level;

public class StaffNoteManager {

    private final GalaxydeStaff plugin;

    public StaffNoteManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public void add(UUID targetUuid, String targetName, UUID staffUuid, String staffName, String text,
                     Consumer<Integer> onCreatedId) {

        int maxLength = plugin.getConfig().getInt("staffnote.max-length", 512);
        String trimmed = text.length() > maxLength ? text.substring(0, maxLength) : text;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            int id = -1;
            String sql = "INSERT INTO `" + plugin.db().prefix() + "notes` "
                    + "(target_uuid, target_name, staff_uuid, staff_name, note, created_at) VALUES (?, ?, ?, ?, ?, ?)";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, targetUuid.toString());
                ps.setString(2, targetName);
                ps.setString(3, staffUuid.toString());
                ps.setString(4, staffName);
                ps.setString(5, trimmed);
                ps.setLong(6, System.currentTimeMillis());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) id = keys.getInt(1);
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to add staff note", e);
            }
            int finalId = id;
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> onCreatedId.accept(finalId));
        });
    }

    public void list(UUID targetUuid, Consumer<List<NoteEntry>> callback) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            List<NoteEntry> notes = new ArrayList<>();
            String sql = "SELECT id, note, staff_name, created_at FROM `" + plugin.db().prefix() + "notes` "
                    + "WHERE target_uuid = ? ORDER BY created_at DESC";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, targetUuid.toString());
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        notes.add(new NoteEntry(rs.getInt("id"), rs.getString("note"),
                                rs.getString("staff_name"), rs.getLong("created_at")));
                    }
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to list staff notes", e);
            }
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> callback.accept(notes));
        });
    }

    public void remove(int id, Consumer<Boolean> callback) {
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            boolean success = false;
            String sql = "DELETE FROM `" + plugin.db().prefix() + "notes` WHERE id = ?";
            try (Connection c = plugin.db().getConnection();
                 PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setInt(1, id);
                success = ps.executeUpdate() > 0;
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to remove staff note", e);
            }
            boolean finalSuccess = success;
            plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> callback.accept(finalSuccess));
        });
    }
}
