package me.nothing.smpcore.systems.punishment2.listeners;

import io.papermc.paper.event.player.AsyncChatEvent;
import java.util.List;
import java.util.Locale;
import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

/** Un giocatore mutato non puo' scrivere in chat ne' usare i comandi di messaggio elencati in config. */
public class ChatListener implements Listener {
   private final SmpCorePunishment plugin;

   public ChatListener(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   /** La sanzione di mute attiva del giocatore (anche IP-mute), oppure null. */
   private Punishment activeMute(Player player) {
      if (player.hasPermission("smpcore.system.punishment.bypass")) {
         return null;
      } else {
         Punishment mute = this.plugin.getDatabaseManager().getActivePunishment(player.getUniqueId(), "MUTE");
         if (mute != null) {
            return mute;
         } else {
            try {
               if (player.getAddress() != null && player.getAddress().getAddress() != null) {
                  return this.plugin.getIpBanManager().getIPMutePunishment(player.getAddress().getAddress().getHostAddress());
               }
            } catch (Exception e) {
            }

            return null;
         }
      }
   }

   private void tell(Player player, Punishment mute) {
      long left = mute.getExpireTime() <= 0L ? -1L : mute.getExpireTime() - System.currentTimeMillis();
      List<String> lines = this.plugin.getMessages().getStringList("mute.chat-message");
      if (lines.isEmpty()) {
         lines = List.of("&cYou are muted. Reason: &#71F521%reason% &cTime left: &#71F521%time%");
      }

      for(String line : lines) {
         player.sendMessage(ColorUtil.color(line.replace("%reason%", String.valueOf(mute.getReason())).replace("%time%", TimeUtil.formatTime(left)).replace("%duration%", String.valueOf(mute.getDuration()))));
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onChat(AsyncChatEvent event) {
      Punishment mute = this.activeMute(event.getPlayer());
      if (mute != null) {
         event.setCancelled(true);
         this.tell(event.getPlayer(), mute);
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onCommand(PlayerCommandPreprocessEvent event) {
      List<String> blocked = this.plugin.getConfig().getStringList("settings.muted-blocked-commands");
      if (!blocked.isEmpty()) {
         String label = event.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
         int colon = label.indexOf(58);
         if (colon >= 0) {
            label = label.substring(colon + 1);
         }

         String command = label;
         if (blocked.stream().anyMatch((b) -> b.equalsIgnoreCase(command))) {
            Punishment mute = this.activeMute(event.getPlayer());
            if (mute != null) {
               event.setCancelled(true);
               this.tell(event.getPlayer(), mute);
            }
         }
      }
   }
}
