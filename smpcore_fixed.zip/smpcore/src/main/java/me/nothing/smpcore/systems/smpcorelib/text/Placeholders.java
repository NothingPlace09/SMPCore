package me.nothing.smpcore.systems.smpcorelib.text;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class Placeholders {
   private static final String PFAD = "menus.placeholderapi";
   private static final ThreadLocal<Player> BETRACHTER = new ThreadLocal();
   private static volatile Boolean konfiguriert;
   private static volatile Boolean aktiv;
   private static volatile boolean gescheitert;

   private Placeholders() {
   }

   public static void load(ConfigurationSection configurationSection) {
      konfiguriert = configurationSection == null || configurationSection.getBoolean("menus.placeholderapi", true);
      aktiv = null;
   }

   public static boolean aktiv() {
      Boolean booleanVal = aktiv;
      if (booleanVal == null) {
         booleanVal = entscheide();
         aktiv = booleanVal;
      }

      return booleanVal;
   }

   private static boolean entscheide() {
      if (gescheitert) {
         return false;
      } else {
         Boolean booleanVal = konfiguriert;
         if (booleanVal == null) {
            booleanVal = ausEigenerDatei();
            konfiguriert = booleanVal;
         }

         return booleanVal && Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null;
      }
   }

   private static boolean ausEigenerDatei() {
      try {
         JavaPlugin javaPlugin = JavaPlugin.getProvidingPlugin(Placeholders.class);
         File file = new File(javaPlugin.getDataFolder(), "config.yml");
         return !file.isFile() || YamlConfiguration.loadConfiguration(file).getBoolean("menus.placeholderapi", true);
      } catch (LinkageError | RuntimeException e) {
         return true;
      }
   }

   public static void zeichneFuer(Player player, Runnable runnable) {
      Player previous = (Player)BETRACHTER.get();
      BETRACHTER.set(player);

      try {
         runnable.run();
      } finally {
         if (previous == null) {
            BETRACHTER.remove();
         } else {
            BETRACHTER.set(previous);
         }

      }

   }

   public static String imMenue(String str) {
      if (str != null && str.indexOf(37) >= 0 && aktiv()) {
         Player player = (Player)BETRACHTER.get();
         return player == null ? str : loese(player, str);
      } else {
         return str;
      }
   }

   public static List<String> imMenue(List<String> list) {
      if (list != null && !list.isEmpty() && aktiv()) {
         ArrayList arrayList = null;

         for(int var2 = 0; var2 < list.size(); ++var2) {
            String str = (String)list.get(var2);
            String str2 = imMenue(str);
            if (str2 != str) {
               if (arrayList == null) {
                  arrayList = new ArrayList(list);
               }

               arrayList.set(var2, str2);
            }
         }

         return (List<String>)(arrayList == null ? list : arrayList);
      } else {
         return list;
      }
   }

   public static String apply(Player player, String str) {
      return str != null && str.indexOf(37) >= 0 && aktiv() ? loese(player, str) : str;
   }

   private static String loese(Player player, String str) {
      try {
         return PapiBridge.apply(player, str);
      } catch (RuntimeException | LinkageError e) {
         gescheitert = true;
         aktiv = false;
         Bukkit.getLogger().warning("[SmpCore] PlaceholderAPI hat beim Aufloesen von Menuetext abgebrochen (" + String.valueOf(e) + ") - fremde Platzhalter bleiben ab jetzt stehen. Mit menus.placeholderapi: false in der config.yml des Kerns laesst sich die Bruecke dauerhaft abschalten.");
         return str;
      }
   }
}
