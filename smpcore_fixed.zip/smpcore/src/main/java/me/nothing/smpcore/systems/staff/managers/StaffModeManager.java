package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class StaffModeManager {

    private final GalaxydeStaff plugin;
    private final Map<UUID, PlayerSnapshot> snapshots = new ConcurrentHashMap<>();

    public StaffModeManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public boolean isInStaffMode(UUID uuid) {
        return snapshots.containsKey(uuid);
    }

    public boolean toggle(Player player) {
        if (isInStaffMode(player.getUniqueId())) {
            disable(player);
            return false;
        } else {
            enable(player);
            return true;
        }
    }

    public void enable(Player player) {
        PlayerSnapshot snapshot = new PlayerSnapshot(
                player.getLocation().clone(),
                player.getGameMode(),
                player.getInventory().getContents().clone(),
                player.getInventory().getArmorContents().clone(),
                player.getInventory().getItemInOffHand().clone(),
                player.getExp(),
                player.getLevel(),
                player.getHealth(),
                player.getFoodLevel(),
                player.getAllowFlight(),
                player.isFlying(),
                new java.util.ArrayList<>(player.getActivePotionEffects()),
                plugin.vanish().isVanished(player.getUniqueId())
        );
        snapshots.put(player.getUniqueId(), snapshot);

        player.getInventory().clear();
        player.getInventory().setArmorContents(null);
        player.setGameMode(GameMode.CREATIVE);
        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));

        if (plugin.getConfig().getBoolean("staffmode.give-items", true)) {
            var items = me.nothing.smpcore.systems.staff.util.ConfigItemFactory.buildSlotMap(
                    plugin.getConfig().getConfigurationSection("staffmode.items"), plugin.getLogger());
            items.forEach((slot, item) -> player.getInventory().setItem(slot, item));
        }

        if (plugin.getConfig().getBoolean("staffmode.auto-fly", true)) {
            player.setAllowFlight(true);
            player.setFlying(true);
        }

        if (plugin.getConfig().getBoolean("staffmode.auto-vanish", true) && !plugin.vanish().isVanished(player.getUniqueId())) {
            plugin.vanish().enable(player);
        }

        plugin.audit().log(player.getUniqueId(), player.getName(), "STAFFMODE_ON");
    }

    public void disable(Player player) {
        PlayerSnapshot snapshot = snapshots.remove(player.getUniqueId());
        if (snapshot == null) return;

        player.getInventory().clear();
        player.getInventory().setContents(snapshot.inventoryContents());
        player.getInventory().setArmorContents(snapshot.armorContents());
        player.getInventory().setItemInOffHand(snapshot.offHand());
        player.setGameMode(snapshot.gameMode());
        player.setExp(snapshot.exp());
        player.setLevel(snapshot.level());
        player.setHealth(Math.min(snapshot.health(), player.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue()));
        player.setFoodLevel(snapshot.foodLevel());
        player.setAllowFlight(snapshot.allowFlight());
        player.setFlying(snapshot.flying());

        player.getActivePotionEffects().forEach(e -> player.removePotionEffect(e.getType()));
        snapshot.potionEffects().forEach(player::addPotionEffect);

        // Only auto-unvanish if staffmode is what turned vanish on in the first place.
        if (plugin.getConfig().getBoolean("staffmode.auto-vanish", true)
                && !snapshot.wasVanishedBefore()
                && plugin.vanish().isVanished(player.getUniqueId())) {
            plugin.vanish().disable(player);
        }

        plugin.audit().log(player.getUniqueId(), player.getName(), "STAFFMODE_OFF");
    }

    /** Used for accidental item drop/pickup prevention checks. */
    public boolean shouldPreventDrop() {
        return plugin.getConfig().getBoolean("staffmode.prevent-item-drop", true);
    }

    public boolean shouldPreventPickup() {
        return plugin.getConfig().getBoolean("staffmode.prevent-item-pickup", true);
    }

    public void restoreAllOnShutdown() {
        for (UUID uuid : snapshots.keySet()) {
            Player p = plugin.getServer().getPlayer(uuid);
            if (p != null) disable(p);
        }
    }
}
