package me.nothing.smpcore.systems.staff.managers;

public record NoteEntry(int id, String text, String staffName, long createdAt) {}
