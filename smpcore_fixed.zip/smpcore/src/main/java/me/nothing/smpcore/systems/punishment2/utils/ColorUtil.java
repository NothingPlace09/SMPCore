package me.nothing.smpcore.systems.punishment2.utils;

import me.nothing.smpcore.utils.Rich;

/** Testi del modulo punishment: &c, &#RRGGBB, #RRGGBB, <#RRGGBB> e tag MiniMessage (gradient, shadow...). */
public class ColorUtil {
   public static String color(String message) {
      return message == null ? "" : Rich.toLegacy(message);
   }
}
