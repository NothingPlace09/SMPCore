package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VanishCommand extends BaseCommand {

    public VanishCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        if (!requirePermission(player, "galaxydestaff.vanish")) return;

        boolean nowVanished = plugin.vanish().toggle(player);
        plugin.msg().send(player, nowVanished ? "vanish.enabled" : "vanish.disabled");
    }
}
