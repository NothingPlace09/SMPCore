package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.gui.ContainerViewHolder;
import me.nothing.smpcore.systems.staff.gui.PlayerViewHolder;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

/**
 * Handles our custom GUIs:
 * - /invsee and /ecview (PlayerViewHolder): cancels every click when read-only, or syncs the
 *   GUI's contents back onto the target's real inventory when editable (per-click and on close).
 * - Silent container peeking in staff mode (ContainerViewHolder): always read-only, every click
 *   is cancelled — it's just a disconnected copy of what was in the container.
 */
public class StaffGuiListener implements Listener {

    private final GalaxydeStaff plugin;

    public StaffGuiListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getInventory().getHolder() instanceof ContainerViewHolder) {
            event.setCancelled(true);
            return;
        }

        if (!(event.getInventory().getHolder() instanceof PlayerViewHolder holder)) return;

        if (!holder.isEditable()) {
            event.setCancelled(true);
            return;
        }

        // Let the click apply to the GUI copy, then push the result onto the real target next tick.
        plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> holder.syncToTarget(plugin));
    }

    @EventHandler
    public void onDrag(InventoryDragEvent event) {
        if (event.getInventory().getHolder() instanceof ContainerViewHolder) {
            event.setCancelled(true);
            return;
        }

        if (!(event.getInventory().getHolder() instanceof PlayerViewHolder holder)) return;

        if (!holder.isEditable()) {
            event.setCancelled(true);
            return;
        }

        plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> holder.syncToTarget(plugin));
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (event.getInventory().getHolder() instanceof PlayerViewHolder holder && holder.isEditable()) {
            holder.syncToTarget(plugin);
        }
    }
}
