package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class VanishManager {

    private final GalaxydeStaff plugin;
    private final Set<UUID> vanished = ConcurrentHashMap.newKeySet();
    private BukkitTask hotbarTask;

    public VanishManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
        startHotbarIndicator();
    }

    /** Sends a persistent "VANISH ON" action bar to every vanished player, on a repeating timer. */
    private void startHotbarIndicator() {
        if (!plugin.getConfig().getBoolean("vanish.hotbar-indicator", true)) return;

        long interval = plugin.getConfig().getLong("vanish.hotbar-indicator-interval-ticks", 40);
        hotbarTask = plugin.getServer().getScheduler().runTaskTimer(plugin.getCore(), () -> {
            if (vanished.isEmpty()) return;
            Component text = plugin.msg().render("vanish.hotbar").stream().findFirst().orElse(null);
            if (text == null) return;
            for (UUID uuid : vanished) {
                Player player = plugin.getServer().getPlayer(uuid);
                if (player != null) player.sendActionBar(text);
            }
        }, 20L, interval);
    }

    public boolean isVanished(UUID uuid) {
        return vanished.contains(uuid);
    }

    public boolean toggle(Player player) {
        if (isVanished(player.getUniqueId())) {
            disable(player);
            return false;
        } else {
            enable(player);
            return true;
        }
    }

    public void enable(Player player) {
        vanished.add(player.getUniqueId());
        applyVisibility(player);
        // Actual join/quit message suppression for vanished staff is handled in VanishListener.
        plugin.audit().log(player.getUniqueId(), player.getName(), "VANISH_ON");
    }

    public void disable(Player player) {
        vanished.remove(player.getUniqueId());

        // Re-show to everyone who can now see them.
        for (Player other : plugin.getServer().getOnlinePlayers()) {
            other.showPlayer(plugin.getCore(), player);
        }

        plugin.audit().log(player.getUniqueId(), player.getName(), "VANISH_OFF");
    }

    /** Hides `player` from everyone who doesn't have the bypass permission. Call also on join for existing vanished staff. */
    public void applyVisibility(Player player) {
        for (Player viewer : plugin.getServer().getOnlinePlayers()) {
            if (viewer.equals(player)) continue;
            if (viewer.hasPermission("galaxydestaff.vanish.see")) {
                viewer.showPlayer(plugin.getCore(), player);
            } else {
                viewer.hidePlayer(plugin.getCore(), player);
            }
        }
    }

    /** Called on player join: hide all currently-vanished staff from the joining player (unless they can see vanish). */
    public void hideAllVanishedFrom(Player joining) {
        if (joining.hasPermission("galaxydestaff.vanish.see")) return;
        for (Player online : plugin.getServer().getOnlinePlayers()) {
            if (isVanished(online.getUniqueId())) {
                joining.hidePlayer(plugin.getCore(), online);
            }
        }
    }

    public void clearAllOnShutdown() {
        vanished.clear();
        if (hotbarTask != null) hotbarTask.cancel();
    }
}
