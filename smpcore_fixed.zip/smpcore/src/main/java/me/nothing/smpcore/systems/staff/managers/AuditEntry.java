package me.nothing.smpcore.systems.staff.managers;

public record AuditEntry(String action, String targetName, String reason, long createdAt) {}
