package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

public class GalaxydeStaffAdminCommand extends BaseCommand {

    public GalaxydeStaffAdminCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        if (!requirePermission(sender, "galaxydestaff.admin")) return;

        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            plugin.reload();
            plugin.msg().send(sender, "general.reload-success");
            return;
        }

        sender.sendMessage("§7SmpCore Staff §fv" + plugin.getPluginMeta().getVersion() + " §7— use §f/galaxydestaff reload");
    }
}
