package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class StaffChatCommand extends BaseCommand {

    public StaffChatCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        if (!requirePermission(player, "galaxydestaff.staffchat")) return;

        if (args.length == 0) {
            plugin.staffChat().toggle(player);
            return;
        }

        String message = String.join(" ", args);
        plugin.staffChat().broadcast(player, message);
    }
}
