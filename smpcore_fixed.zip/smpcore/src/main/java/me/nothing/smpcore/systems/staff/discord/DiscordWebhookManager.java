package me.nothing.smpcore.systems.staff.discord;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.logging.Level;

public class DiscordWebhookManager {

    private final GalaxydeStaff plugin;
    private final HttpClient httpClient;

    public DiscordWebhookManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(5))
                .build();
    }

    public void sendPunishmentLog(String type, String target, String staff, String reason, String duration) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Target", target);
        fields.put("Staff", staff);
        fields.put("Reason", reason);
        if (duration != null && !duration.isBlank()) fields.put("Duration", duration);
        send(plugin.getConfig().getString("discord.punishment-log-webhook"), type, fields);
    }

    /** For unban/unmute — includes both the revoke reason and the original punishment's reason/duration, like the old poller bot did. */
    public void sendPunishmentRemovalLog(String type, String target, String revokedBy, String revokeReason,
                                          String originalReason, String originalDuration) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Target", target);
        fields.put("Revoked by", revokedBy);
        if (revokeReason != null && !revokeReason.isBlank()) fields.put("Revoke reason", revokeReason);
        if (originalReason != null && !originalReason.isBlank()) fields.put("Original reason", originalReason);
        if (originalDuration != null && !originalDuration.isBlank()) fields.put("Original duration", originalDuration);
        send(plugin.getConfig().getString("discord.punishment-log-webhook"), type, fields);
    }

    public void sendReportLog(String target, String reporter, String reason) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Target", target);
        fields.put("Reporter", reporter);
        fields.put("Reason", reason);
        send(plugin.getConfig().getString("discord.report-log-webhook"), "New Report", fields);
    }

    public void sendReportResolvedLog(int id, String target, String reporter, String reason, String resolvedBy) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Report", "#" + id);
        if (target != null) fields.put("Target", target);
        if (reporter != null) fields.put("Reporter", reporter);
        if (reason != null) fields.put("Reason", reason);
        fields.put("Resolved by", resolvedBy);
        send(plugin.getConfig().getString("discord.report-log-webhook"), "Report Resolved", fields);
    }

    public void sendStaffNoteLog(String target, String staff, String note) {
        String url = plugin.getConfig().getString("discord.staffnote-log-webhook");
        if (url == null || url.isBlank()) return; // this webhook is genuinely optional, stay silent
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Target", target);
        fields.put("Staff", staff);
        fields.put("Note", note);
        send(url, "Staff Note Added", fields);
    }

    public void sendStaffNoteRemovalLog(int id, String staff) {
        String url = plugin.getConfig().getString("discord.staffnote-log-webhook");
        if (url == null || url.isBlank()) return;
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Note", "#" + id);
        fields.put("Removed by", staff);
        send(url, "Staff Note Removed", fields);
    }

    public void sendAuditLog(String action, String staff, String target, String reason) {
        Map<String, String> fields = new LinkedHashMap<>();
        fields.put("Staff", staff);
        if (target != null) fields.put("Target", target);
        if (reason != null && !reason.isBlank()) fields.put("Reason", reason);
        send(plugin.getConfig().getString("discord.punishment-log-webhook"), action, fields);
    }

    private void send(String webhookUrl, String title, Map<String, String> fields) {
        // Re-read config fresh every call so /galaxydestaff reload actually takes effect,
        // and so we always know the CURRENT reason for silently doing nothing.
        boolean enabled = plugin.getConfig().getBoolean("discord.enabled", true);
        if (!enabled) {
            plugin.getLogger().fine("Discord webhook skipped: discord.enabled is false in config.yml.");
            return;
        }

        if (webhookUrl == null || webhookUrl.isBlank()) {
            plugin.getLogger().warning("Discord webhook not sent (" + title + "): no webhook URL configured in config.yml.");
            return;
        }
        if (webhookUrl.contains("CHANGE/ME")) {
            plugin.getLogger().warning("Discord webhook not sent (" + title + "): the webhook URL in config.yml is still the "
                    + "placeholder 'CHANGE/ME' — replace it with a real Discord webhook URL.");
            return;
        }
        if (!webhookUrl.startsWith("https://discord.com/api/webhooks/") && !webhookUrl.startsWith("https://discordapp.com/api/webhooks/")) {
            plugin.getLogger().warning("Discord webhook not sent (" + title + "): '" + webhookUrl + "' doesn't look like a "
                    + "valid Discord webhook URL (should start with https://discord.com/api/webhooks/).");
            return;
        }

        String color = plugin.getConfig().getString("discord.embed-color", "#8B5CF6");
        String json = buildEmbedJson(title, fields, color);

        // Fire and forget, off the main thread.
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin.getCore(), () -> {
            try {
                HttpRequest request = HttpRequest.newBuilder()
                        .uri(URI.create(webhookUrl))
                        .timeout(Duration.ofSeconds(8))
                        .header("Content-Type", "application/json")
                        .header("User-Agent", "GalaxydeStaff/1.0")
                        .POST(HttpRequest.BodyPublishers.ofString(json))
                        .build();
                HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
                if (response.statusCode() >= 300) {
                    plugin.getLogger().warning("Discord webhook returned HTTP " + response.statusCode()
                            + " for '" + title + "': " + response.body());
                }
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Failed to send Discord webhook for '" + title + "'", e);
            }
        });
    }

    private String buildEmbedJson(String title, Map<String, String> fields, String color) {
        int colorInt;
        try {
            colorInt = Integer.parseInt(color.replace("#", ""), 16);
        } catch (Exception e) {
            colorInt = 0x8B5CF6;
        }

        StringBuilder fieldsJson = new StringBuilder();
        int i = 0;
        for (Map.Entry<String, String> entry : fields.entrySet()) {
            if (i++ > 0) fieldsJson.append(",");
            fieldsJson.append("{\"name\":\"").append(escape(entry.getKey())).append("\",")
                    .append("\"value\":\"").append(escape(entry.getValue())).append("\",")
                    .append("\"inline\":true}");
        }

        return "{\"embeds\":[{"
                + "\"title\":\"" + escape(title) + "\","
                + "\"color\":" + colorInt + ","
                + "\"fields\":[" + fieldsJson + "],"
                + "\"timestamp\":\"" + Instant.now() + "\""
                + "}]}";
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
