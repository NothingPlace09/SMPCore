package me.nothing.smpcore.systems.punishment2;

import java.io.File;
import java.util.List;
import java.util.logging.Logger;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.systems.punishment2.commands.CheckBanCommand;
import me.nothing.smpcore.systems.punishment2.commands.CheckMuteCommand;
import me.nothing.smpcore.systems.punishment2.commands.HistoryCommand;
import me.nothing.smpcore.systems.punishment2.commands.OffendCommand;
import me.nothing.smpcore.systems.punishment2.commands.PunishmentHelpCommand;
import me.nothing.smpcore.systems.punishment2.commands.SanctionCommands;
import me.nothing.smpcore.systems.punishment2.commands.OffendIPCommand;
import me.nothing.smpcore.systems.punishment2.commands.ReloadCommand;
import me.nothing.smpcore.systems.punishment2.database.DatabaseManager;
import me.nothing.smpcore.systems.punishment2.listeners.ChatListener;
import me.nothing.smpcore.systems.punishment2.listeners.HistoryListener;
import me.nothing.smpcore.systems.punishment2.listeners.IPBanListener;
import me.nothing.smpcore.systems.punishment2.listeners.JoinListener;
import me.nothing.smpcore.systems.punishment2.managers.BanScreenManager;
import me.nothing.smpcore.systems.punishment2.managers.HistoryManager;
import me.nothing.smpcore.systems.punishment2.managers.IPBanManager;
import me.nothing.smpcore.systems.punishment2.managers.PunishmentManager;
import me.nothing.smpcore.systems.punishment2.managers.ReasonManager;
import me.nothing.smpcore.systems.punishment2.managers.WebhookManager;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.BanIdUtil;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.Server;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class SmpCorePunishment {
   private final JavaPlugin core;
   private static SmpCorePunishment instance;
   private DatabaseManager databaseManager;
   private PunishmentManager punishmentManager;
   private HistoryManager historyManager;
   private WebhookManager webhookManager;
   private ReasonManager reasonManager;
   private IPBanManager ipBanManager;
   private BanScreenManager banScreenManager;
   private FileConfiguration messages;
   private FileConfiguration configCache;

   public SmpCorePunishment(JavaPlugin core) {
      this.core = core;
   }

   public static SmpCorePunishment getInstance() {
      return instance;
   }

   public JavaPlugin getPlugin() {
      return this.core;
   }

   public Plugin asPlugin() {
      return this.core;
   }

   public Logger getLogger() {
      return this.core.getLogger();
   }

   public Server getServer() {
      return this.core.getServer();
   }

   public File getDataFolder() {
      File d = new File(this.core.getDataFolder(), "punishment");
      if (!d.exists()) {
         d.mkdirs();
      }

      return d;
   }

   public FileConfiguration getConfig() {
      if (this.configCache == null) {
         File f = new File(this.getDataFolder(), "config.yml");
         this.configCache = f.exists() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
      }

      return this.configCache;
   }

   public void reloadConfig() {
      this.configCache = null;
      this.getConfig();
   }

   public void saveDefaultConfig() {
      File f = new File(this.getDataFolder(), "config.yml");
      if (!f.exists()) {
         try {
            this.core.saveResource("punishment/config.yml", false);
         } catch (Exception e) {
         }
      }

   }

   public void saveResource(String name, boolean replace) {
      try {
         this.core.saveResource("punishment/" + name, replace);
      } catch (Exception e) {
      }

   }

   public PluginCommand getCommand(String name) {
      return this.core.getCommand(name);
   }

   public FileConfiguration getMessages() {
      if (this.messages == null) {
         this.reloadMessages();
      }

      return this.messages;
   }

   public void reloadMessages() {
      File file = new File(this.getDataFolder(), "messages.yml");
      if (!file.exists()) {
         try {
            this.core.saveResource("punishment/messages.yml", false);
         } catch (Exception e) {
         }
      }

      this.messages = YamlConfiguration.loadConfiguration(file);
   }

   public void enable() {
      instance = this;
      this.getDataFolder().mkdirs();
      this.saveDefaultConfig();

      for(String r : new String[]{"messages.yml", "reasons.yml", "webhook.yml"}) {
         File out = new File(this.getDataFolder(), r);
         if (!out.exists()) {
            try {
               this.core.saveResource("punishment/" + r, false);
            } catch (Exception e) {
            }
         }
      }

      this.reloadMessages();
      this.databaseManager = new DatabaseManager(this);
      this.databaseManager.connect();
      this.databaseManager.createTables();
      me.nothing.smpcore.data.PlayerDatabase.registerContributor("punishment", new me.nothing.smpcore.data.PlayerDatabase.Contributor() {
         public void export(java.util.UUID id, org.bukkit.configuration.ConfigurationSection out) {
            java.util.List<java.util.Map<String, Object>> list = new java.util.ArrayList();

            for(Punishment p : SmpCorePunishment.this.databaseManager.getHistory(id)) {
               java.util.Map<String, Object> m = new java.util.LinkedHashMap();
               m.put("player", p.getPlayer());
               m.put("type", p.getType());
               m.put("reason", p.getReason());
               m.put("duration", p.getDuration());
               m.put("expire-time", p.getExpireTime());
               m.put("staff", p.getStaff());
               m.put("offense", p.getOffense());
               m.put("ban-id", p.getBanId());
               m.put("created", p.getDate());
               m.put("active", p.isActive());
               list.add(m);
            }

            if (!list.isEmpty()) {
               out.set("entries", list);
            }

            String name = org.bukkit.Bukkit.getOfflinePlayer(id).getName();
            if (name != null) {
               java.util.List<java.util.Map<String, Object>> ipBans = SmpCorePunishment.this.getIpBanManager().exportForPlayer(name);
               if (!ipBans.isEmpty()) {
                  out.set("ip-bans", ipBans);
               }
            }
         }

         public void apply(java.util.UUID id, org.bukkit.configuration.ConfigurationSection in) {
            DatabaseManager db = SmpCorePunishment.this.databaseManager;
            db.deleteAllFor(id);
            if (in != null) {
               for(java.util.Map<?, ?> m : in.getMapList("entries")) {
                  db.savePunishment(new Punishment(id, SmpCorePunishment.text(m.get("player")), SmpCorePunishment.text(m.get("type")), SmpCorePunishment.text(m.get("reason")), SmpCorePunishment.text(m.get("duration")), SmpCorePunishment.number(m.get("expire-time")), SmpCorePunishment.text(m.get("staff")), (int)SmpCorePunishment.number(m.get("offense")), SmpCorePunishment.text(m.get("ban-id")), SmpCorePunishment.number(m.get("created")), Boolean.parseBoolean(String.valueOf(m.get("active")))));
               }
            }

            String name = org.bukkit.Bukkit.getOfflinePlayer(id).getName();
            if (name != null) {
               SmpCorePunishment.this.getIpBanManager().replaceForPlayer(name, in == null ? java.util.List.of() : (java.util.List)in.getMapList("ip-bans"));
            }
         }
      });
      this.punishmentManager = new PunishmentManager(this);
      this.historyManager = new HistoryManager(this);
      this.webhookManager = new WebhookManager(this);
      this.reasonManager = new ReasonManager(this);
      this.ipBanManager = new IPBanManager(this);
      this.banScreenManager = new BanScreenManager(this);
      this.registerCommands();
      this.registerListeners();
      this.getLogger().info("SmpCorePunishment enabled.");
   }

   /** Embed freeze/unfreeze sul webhook delle sanzioni (lo staff gestisce il freeze, qui si manda solo l'avviso). */
   public void logFreeze(java.util.UUID id, String name, String staff, boolean frozen) {
      Punishment p = new Punishment(id, name, frozen ? "FREEZE" : "UNFREEZE", frozen ? "Frozen" : "Unfrozen", frozen ? "Until Unfrozen" : "N/A", -1L, staff, 1, "NONE", System.currentTimeMillis(), false);
      this.webhookManager.sendPunishment(frozen ? "FREEZE" : "UNFREEZE", p);
   }

   /** Ban di un giocatore che esce dal server mentre e' congelato: salvato, mandato sul webhook e applicato. */
   public void banFrozenQuit(org.bukkit.entity.Player player, String reason, String duration) {
      long millis = duration == null ? -1L : TimeUtil.parseDuration(duration);
      long expire = millis < 0L ? -1L : System.currentTimeMillis() + millis;
      String shown = expire == -1L ? "Permanent" : duration;
      int offense = this.databaseManager.countType(player.getUniqueId(), "BAN") + 1;
      Punishment p = new Punishment(player.getUniqueId(), player.getName(), "BAN", reason, shown, expire, "Console", offense, BanIdUtil.generate(), System.currentTimeMillis(), true);
      this.databaseManager.savePunishment(p);
      this.webhookManager.sendPunishment("BAN", p);
      String broadcast = this.getMessages().getString(expire == -1L ? "punishment.permban-broadcast" : "punishment.ban-broadcast", "&#72EEFF&lPUNISHMENT &#9B9B9B» &#FF2121Banned &#71F521%player% &#FF2121Reason: &#71F521%reason%");
      org.bukkit.Bukkit.broadcastMessage(ColorUtil.color(broadcast.replace("%player%", player.getName()).replace("%duration%", shown).replace("%reason%", reason).replace("%staff%", "Console")));
   }

   private static String text(Object o) {
      return o == null ? null : String.valueOf(o);
   }

   private static long number(Object o) {
      if (o instanceof Number n) {
         return n.longValue();
      } else {
         try {
            return o == null ? 0L : Long.parseLong(String.valueOf(o));
         } catch (NumberFormatException e) {
            return 0L;
         }
      }
   }

   public void disable() {
      if (instance == this) {
         instance = null;
      }

      if (this.databaseManager != null) {
         try {
            this.databaseManager.close();
         } catch (Exception e) {
         }
      }

      if (this.ipBanManager != null) {
         try {
            this.ipBanManager.close();
         } catch (Exception e) {
         }
      }

      this.getLogger().info("SmpCorePunishment disabled.");
   }

   private void registerCommands() {
      this.bind("offend", new OffendCommand(this));
      this.bind("offendip", new OffendIPCommand(this));
      for(SanctionCommands.Mode mode : SanctionCommands.Mode.values()) {
         this.bind(mode.name().toLowerCase(java.util.Locale.ROOT), new SanctionCommands(this, mode));
      }
      this.bind("history", new HistoryCommand(this));
      this.bind("checkban", new CheckBanCommand(this));
      this.bind("checkmute", new CheckMuteCommand(this));
      this.bind("smpcorepunishment", new ReloadCommand(this));
      this.bind("punishment", new PunishmentHelpCommand(this));
      this.bind("punish", new PunishmentHelpCommand(this));
   }

   private void bind(String name, CommandExecutor executor) {
      PluginCommand pc = this.core.getCommand(name);
      if (pc != null) {
         pc.setExecutor(executor);
         if (executor instanceof TabCompleter) {
            TabCompleter tab = (TabCompleter)executor;
            pc.setTabCompleter(tab);
         }
      }

      JavaPlugin javaPlugin = this.core;
      if (javaPlugin instanceof SmpCore asmp) {
         asmp.commands().registerHandler(name, (sender, args) -> {
            try {
               return executor.onCommand(sender, (Command)(pc != null ? pc : this.dummyCmd(name)), name, args);
            } catch (Throwable ex) {
               sender.sendMessage("§cPunishment error: " + ex.getMessage());
               return true;
            }
         });
         if (executor instanceof TabCompleter tab) {
            asmp.commands().registerTabCompleter(name, (sender, command, alias, args) -> {
               try {
                  List<String> r = tab.onTabComplete(sender, command, alias, args);
                  return r != null ? r : List.of();
               } catch (Throwable t) {
                  return List.of();
               }
            });
         }
      }

   }

   private Command dummyCmd(String name) {
      return new Command(name) {
         public boolean execute(CommandSender sender, String commandLabel, String[] args) {
            return true;
         }
      };
   }

   private void registerListeners() {
      PluginManager pm = this.getServer().getPluginManager();
      pm.registerEvents(new ChatListener(this), this.core);
      pm.registerEvents(new JoinListener(this), this.core);
      pm.registerEvents(new IPBanListener(this), this.core);
      pm.registerEvents(new HistoryListener(), this.core);
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public PunishmentManager getPunishmentManager() {
      return this.punishmentManager;
   }

   public HistoryManager getHistoryManager() {
      return this.historyManager;
   }

   public WebhookManager getWebhookManager() {
      return this.webhookManager;
   }

   public ReasonManager getReasonManager() {
      return this.reasonManager;
   }

   public IPBanManager getIpBanManager() {
      return this.ipBanManager;
   }

   public BanScreenManager getBanScreenManager() {
      return this.banScreenManager;
   }
}
