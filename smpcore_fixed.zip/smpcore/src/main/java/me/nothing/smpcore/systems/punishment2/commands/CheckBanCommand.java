package me.nothing.smpcore.systems.punishment2.commands;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class CheckBanCommand implements CommandExecutor {
   private final SmpCorePunishment plugin;

   public CheckBanCommand(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("smpcore.system.punishment.checkban") && !sender.hasPermission("smpcore.system.punishment.check")) {
         sender.sendMessage(ColorUtil.color("&cNo permission."));
         return true;
      } else if (args.length != 1) {
         sender.sendMessage(ColorUtil.color("&cUsage: /checkban <player>"));
         return true;
      } else {
         me.nothing.smpcore.systems.punishment2.utils.PlayerLookup.Found target = me.nothing.smpcore.systems.punishment2.utils.PlayerLookup.find(this.plugin, args[0]);
         if (target == null) {
            sender.sendMessage(ColorUtil.color("&cPlayer not found."));
            return true;
         } else {
            Punishment punishment = this.plugin.getDatabaseManager().getActivePunishment(target.uuid(), "BAN");
            if (punishment == null) {
               sender.sendMessage(ColorUtil.color("&aThis player has no active bans."));
               return true;
            } else {
               sender.sendMessage(ColorUtil.color("&c&m------------------------"));
               sender.sendMessage(ColorUtil.color("&cPlayer: &#71F521" + target.name()));
               sender.sendMessage(ColorUtil.color("&cReason: &#71F521" + punishment.getReason()));
               sender.sendMessage(ColorUtil.color("&cStaff: &#71F521" + punishment.getStaff()));
               sender.sendMessage(ColorUtil.color("&cDuration: &#71F521" + punishment.getDuration()));
               long l = punishment.getExpireTime();
               sender.sendMessage(ColorUtil.color("&cTime Left: &#71F521" + TimeUtil.formatTime(l - System.currentTimeMillis())));
               sender.sendMessage(ColorUtil.color("&cBan ID: &#71F521" + punishment.getBanId()));
               sender.sendMessage(ColorUtil.color("&cOffense: &#71F521" + punishment.getOffense()));
               sender.sendMessage(ColorUtil.color("&c&m------------------------"));
               return true;
            }
         }
      }
   }
}
