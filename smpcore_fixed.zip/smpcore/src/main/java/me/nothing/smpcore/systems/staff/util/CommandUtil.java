package me.nothing.smpcore.systems.staff.util;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandMap;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.SimpleCommandMap;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Field;
import java.util.Map;
import java.util.logging.Level;

/**
 * Fully removes one of OUR OWN commands from the server's command map, including its aliases.
 * Used when the user disables a command in config to avoid clashing with another plugin (e.g.
 * EssentialsX also ships its own /invsee and /vanish).
 *
 * IMPORTANT: every removal here is identity-checked against our own PluginCommand instance
 * before touching the map. Earlier versions blindly did knownCommands.remove(name), which — if
 * another plugin's command currently owned that plain name (e.g. it loaded before us and "won"
 * the slot) — deleted THEIR command instead of ours. That must never happen: disabling one of
 * our commands must only ever affect GalaxydeStaff, never another plugin's identically-named one.
 */
public final class CommandUtil {

    private CommandUtil() {}

    @SuppressWarnings("unchecked")
    public static void unregister(JavaPlugin plugin, String commandName) {
        // getCommand() resolves to OUR OWN PluginCommand instance specifically (falling back to
        // the "pluginname:command" form internally if another plugin currently owns the plain
        // name) — see JavaPlugin#getCommand(). It never returns another plugin's command object.
        PluginCommand command = plugin.getCommand(commandName);
        if (command == null) return;

        try {
            Field commandMapField = Bukkit.getServer().getClass().getDeclaredField("commandMap");
            commandMapField.setAccessible(true);
            CommandMap commandMap = (CommandMap) commandMapField.get(Bukkit.getServer());

            // Command#unregister(CommandMap) is identity-safe: Bukkit's own implementation only
            // removes map entries that point at THIS exact command instance, never another
            // plugin's. This alone correctly handles the case where we own the plain name.
            command.unregister(commandMap);

            if (commandMap instanceof SimpleCommandMap simpleCommandMap) {
                Field knownCommandsField = SimpleCommandMap.class.getDeclaredField("knownCommands");
                knownCommandsField.setAccessible(true);
                Map<String, Command> knownCommands = (Map<String, Command>) knownCommandsField.get(simpleCommandMap);

                // Belt and braces cleanup for anything unregister() might have missed — but every
                // removal is still gated on an identity check first, never a blind remove(key).
                removeIfOurs(knownCommands, commandName, command);
                for (String alias : command.getAliases()) {
                    removeIfOurs(knownCommands, alias, command);
                }

                // Our plugin-prefixed fallback form ("galaxydestaff:vanish") is always safe to
                // remove unconditionally — by construction it can only ever refer to us.
                String prefix = plugin.getName().toLowerCase() + ":";
                knownCommands.remove(prefix + commandName);
                for (String alias : command.getAliases()) {
                    knownCommands.remove(prefix + alias);
                }
            }

            plugin.getLogger().info("Command '/" + commandName + "' unregistered for GalaxydeStaff (disabled in config.yml).");
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to unregister command '" + commandName + "'", e);
        }
    }

    private static void removeIfOurs(Map<String, Command> knownCommands, String key, PluginCommand ours) {
        Command mapped = knownCommands.get(key);
        if (mapped == ours) {
            knownCommands.remove(key);
        }
        // If mapped != ours, some other plugin currently owns that exact name/alias slot —
        // leave it completely untouched.
    }

    /**
     * Forcibly makes OUR command own the plain command name, even if another plugin currently
     * has it — including plugins (like NamelessMC) that register their commands dynamically at
     * runtime instead of declaring them in plugin.yml, so they can't be detected any other way.
     * The other plugin's command still exists and still works via its own "pluginname:command"
     * prefixed form, it just no longer answers to the plain name.
     * <p>
     * Must be called from a task scheduled AFTER all plugins have finished enabling (e.g.
     * Bukkit.getScheduler().runTask with a 1-tick delay from onEnable) — otherwise a plugin that
     * enables after us could still steal the name back.
     */
    @SuppressWarnings("unchecked")
    public static void forceOverride(JavaPlugin plugin, String commandName) {
        PluginCommand ours = plugin.getCommand(commandName);
        if (ours == null) return;

        try {
            Field commandMapField = Bukkit.getServer().getClass().getDeclaredField("commandMap");
            commandMapField.setAccessible(true);
            CommandMap commandMap = (CommandMap) commandMapField.get(Bukkit.getServer());

            if (!(commandMap instanceof SimpleCommandMap simpleCommandMap)) return;

            Field knownCommandsField = SimpleCommandMap.class.getDeclaredField("knownCommands");
            knownCommandsField.setAccessible(true);
            Map<String, Command> knownCommands = (Map<String, Command>) knownCommandsField.get(simpleCommandMap);

            Command previous = knownCommands.get(commandName);
            if (previous != null && previous != ours) {
                try {
                    previous.unregister(commandMap);
                } catch (Exception ignored) {
                    // Some plugins register raw Command objects that don't support clean
                    // unregistration — the map overwrite below still takes effect regardless.
                }
                plugin.getLogger().info("Took over '/" + commandName + "' from " + describeOwner(previous)
                        + " (force-commands in config.yml). Their command still works via its own prefixed form.");
            }

            knownCommands.put(commandName, ours);
            for (String alias : ours.getAliases()) {
                knownCommands.put(alias, ours);
            }
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Failed to force-override command '" + commandName + "'", e);
        }
    }

    private static String describeOwner(Command command) {
        if (command instanceof PluginCommand pc && pc.getPlugin() != null) {
            return pc.getPlugin().getName();
        }
        return command.getClass().getSimpleName();
    }
}
