package me.nothing.smpcore.systems.chat;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.utils.SoundUtil;
import me.nothing.smpcore.utils.TextUtil;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

/** /chat e /smpcorechat: toggle personale, enable/disable della chat globale, reload, info. */
public class SmpCoreChatCommand implements CommandExecutor, TabCompleter {
   private final SmpCoreChat plugin;

   public SmpCoreChatCommand(SmpCoreChat plugin) {
      this.plugin = plugin;
   }

   private boolean canManage(CommandSender sender) {
      return sender.isOp() || sender.hasPermission("smpcore.system.chat.manage");
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         sender.sendMessage(MessageUtil.color("&bSmpCoreChat"));
         sender.sendMessage(MessageUtil.color("&7/" + label + " &btoggle &7- personal chat on/off"));
         if (this.canManage(sender)) {
            sender.sendMessage(MessageUtil.color("&7/" + label + " &benable&7|&bdisable &7- global chat"));
            sender.sendMessage(MessageUtil.color("&7/" + label + " &breload&7|&binfo"));
         }

         return true;
      }

      String sub = args[0].toLowerCase(Locale.ROOT);
      switch (sub) {
         case "toggle":
            if (!(sender instanceof Player player)) {
               sender.sendMessage("Players only.");
               return true;
            }

            boolean on = this.plugin.getChatManager().togglePersonal(player.getUniqueId());
            // tiene allineato anche /settings: stesso comportamento di /chattoggle
            try {
               SmpCore core = SmpCore.get();
               if (core != null) {
                  Module mod = core.modules().get("settings");
                  if (mod instanceof SettingsModule sm) {
                     if (on && sm.isChatOff(player.getUniqueId())) {
                        sm.toggleChatOff(player.getUniqueId());
                     }

                     if (!on && !sm.isChatOff(player.getUniqueId())) {
                        sm.toggleChatOff(player.getUniqueId());
                     }
                  }
               }
            } catch (Throwable t) {
            }

            TextUtil.send(player, on ? "&#00a3fbGeneral chat &#00FF00enabled&7." : "&#00a3fbGeneral chat &#fc0404disabled&7.");
            return true;
         case "enable":
         case "disable":
            if (!this.canManage(sender)) {
               sender.sendMessage(MessageUtil.colorComponent(this.plugin.getConfigManager().getMessage("chat.no-permission")));
               return true;
            }

            if (sub.equals("enable")) {
               this.plugin.getChatManager().enableChat();
               sender.sendMessage(MessageUtil.color("&aGlobal chat enabled."));
            } else {
               this.plugin.getChatManager().disableChat();
               sender.sendMessage(MessageUtil.color("&cGlobal chat disabled."));
            }

            this.plugin.getChatManager().saveState();
            return true;
         case "reload":
            if (!sender.isOp() && !sender.hasPermission("smpcore.system.chat.reload")) {
               sender.sendMessage(MessageUtil.colorComponent(this.plugin.getConfigManager().getMessage("chat.no-permission")));
               return true;
            }

            this.plugin.reloadSmpCoreChat();
            sender.sendMessage(MessageUtil.colorComponent(this.plugin.getConfigManager().getMessage("reload.success")));
            if (sender instanceof Player p) {
               SoundUtil.play(p, p.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
            }

            return true;
         case "info":
            sender.sendMessage(MessageUtil.color("&b&m----------------"));
            sender.sendMessage(MessageUtil.color("&bSmpCoreChat"));
            sender.sendMessage(MessageUtil.color("&7Global chat: " + (this.plugin.getChatManager().isChatDisabled() ? "&cDisabled" : "&aEnabled")));
            sender.sendMessage(MessageUtil.color("&7DiscordSRV: " + (this.plugin.getDiscordSRVHook().isEnabled() ? "&aEnabled" : "&cDisabled")));
            sender.sendMessage(MessageUtil.color("&b&m----------------"));
            return true;
         default:
            sender.sendMessage(MessageUtil.color("&cUsage: /" + label + " <toggle|enable|disable|reload|info>"));
            return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> out = new ArrayList<>();
      if (args.length == 1) {
         List<String> subs = new ArrayList<>(List.of("toggle"));
         if (this.canManage(sender)) {
            subs.addAll(List.of("enable", "disable", "reload", "info"));
         }

         for(String s : subs) {
            if (s.startsWith(args[0].toLowerCase(Locale.ROOT))) {
               out.add(s);
            }
         }
      }

      return out;
   }
}
