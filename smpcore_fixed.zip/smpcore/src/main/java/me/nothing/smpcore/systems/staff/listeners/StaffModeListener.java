package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.gui.PlayerViewHolder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCreativeEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class StaffModeListener implements Listener {

    private final GalaxydeStaff plugin;

    public StaffModeListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    // Blocks specific commands (e.g. /warp, /home, /tpa...) from being used while in staff mode,
    // configured via staffmode.disabled-commands in config.yml.
    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;

        java.util.List<String> disabled = plugin.getConfig().getStringList("staffmode.disabled-commands");
        if (disabled.isEmpty()) return;

        String label = event.getMessage().split(" ")[0].substring(1).toLowerCase();
        boolean blocked = disabled.stream().anyMatch(c -> c.toLowerCase().equals(label));
        if (!blocked) return;

        event.setCancelled(true);
        plugin.msg().send(player, "staffmode.command-disabled", me.nothing.smpcore.systems.staff.config.MessagesManager.pairs("command", "/" + label));
    }

    // Break/place are silently blocked — no chat message, just cancelled.
    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("staffmode.prevent-block-break", true)) return;

        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("staffmode.prevent-block-place", true)) return;

        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.staffMode().shouldPreventDrop()) return;

        event.setCancelled(true);
        plugin.msg().send(player, "staffmode.cannot-drop");
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.staffMode().shouldPreventPickup()) return;

        event.setCancelled(true);
    }

    // Prevents grabbing free items from the creative inventory ("give" palette) while in staff mode.
    @EventHandler(ignoreCancelled = true)
    public void onCreativeGive(InventoryCreativeEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("staffmode.prevent-creative-give", true)) return;

        event.setCancelled(true);
    }

    // Safety net: world containers no longer open for real in staff mode at all (see
    // ContainerPeekListener, which substitutes a silent read-only ghost copy instead) — but this
    // still cancels clicks in ANY non-player inventory just in case something else (another
    // plugin, an NPC shop GUI...) opens a real container by some other path.
    @EventHandler(ignoreCancelled = true)
    public void onContainerClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("staffmode.prevent-container-interaction", true)) return;
        if (event.getView().getTopInventory().getHolder() instanceof PlayerViewHolder) return;

        InventoryType topType = event.getView().getTopInventory().getType();
        if (topType == InventoryType.PLAYER || topType == InventoryType.CRAFTING) return;

        event.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onContainerDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;
        if (!plugin.getConfig().getBoolean("staffmode.prevent-container-interaction", true)) return;
        if (event.getView().getTopInventory().getHolder() instanceof PlayerViewHolder) return;

        InventoryType topType = event.getView().getTopInventory().getType();
        if (topType == InventoryType.PLAYER || topType == InventoryType.CRAFTING) return;

        event.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (plugin.staffMode().isInStaffMode(player.getUniqueId())) {
            plugin.staffMode().disable(player);
        }
    }
}
