package me.nothing.smpcore.systems.staff.listeners;

import io.papermc.paper.event.player.AsyncChatEvent;
import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

public class StaffChatListener implements Listener {

    private final GalaxydeStaff plugin;

    public StaffChatListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncChatEvent event) {
        Player player = event.getPlayer();
        if (!plugin.staffChat().isToggled(player.getUniqueId())) return;

        event.setCancelled(true);
        String message = PlainTextComponentSerializer.plainText().serialize(event.message());

        // Broadcast must happen on the main thread (sends messages, reads permissions).
        plugin.getServer().getScheduler().runTask(plugin.getCore(), () -> plugin.staffChat().broadcast(player, message));
    }
}
