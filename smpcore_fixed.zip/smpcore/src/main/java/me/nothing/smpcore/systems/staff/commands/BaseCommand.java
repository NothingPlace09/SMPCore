package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public abstract class BaseCommand implements CommandExecutor {

    protected final GalaxydeStaff plugin;

    protected BaseCommand(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    /** Returns the sender as a Player, or null (and sends the player-only message) if it's console. */
    protected Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player player) return player;
        plugin.msg().send(sender, "general.player-only");
        return null;
    }

    protected boolean requirePermission(CommandSender sender, String permission) {
        if (!sender.hasPermission(permission)) {
            plugin.msg().send(sender, "general.no-permission");
            return false;
        }
        return true;
    }

    /**
     * For commands that physically need the target ONLINE (teleport, live inventory, spectate...).
     * Sends "player-offline" if the name belongs to a known player who just isn't connected right
     * now, or "player-not-found" if that name has never played on this server — clearer than a
     * generic not-found either way.
     */
    protected Player requireOnlinePlayer(CommandSender sender, String name) {
        Player online = org.bukkit.Bukkit.getPlayerExact(name);
        if (online != null) return online;

        @SuppressWarnings("deprecation")
        org.bukkit.OfflinePlayer offline = org.bukkit.Bukkit.getOfflinePlayer(name);
        if (offline.hasPlayedBefore()) {
            plugin.msg().send(sender, "general.player-offline", me.nothing.smpcore.systems.staff.config.MessagesManager.pairs("target", name));
        } else {
            plugin.msg().send(sender, "general.player-not-found", me.nothing.smpcore.systems.staff.config.MessagesManager.pairs("target", name));
        }
        return null;
    }

    @Override
    public final boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        execute(sender, command, label, args);
        return true;
    }

    protected abstract void execute(CommandSender sender, Command command, String label, String[] args);
}
