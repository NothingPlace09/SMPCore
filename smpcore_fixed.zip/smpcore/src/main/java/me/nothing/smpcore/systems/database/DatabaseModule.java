package me.nothing.smpcore.systems.database;

import java.io.File;
import java.util.UUID;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.data.PlayerDatabase;
import me.nothing.smpcore.modules.Module;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/**
 * Cartella "database": un file yml per giocatore (plugins/SmpCore/database/&lt;uuid&gt;.yml).
 *
 * - all'avvio crea i file mancanti per tutti i giocatori conosciuti (export-on-startup)
 * - al join: se il file e' stato messo/modificato da fuori viene caricato in gioco, altrimenti viene creato/aggiornato
 * - ogni watch-seconds controlla i giocatori online: un file sostituito a server acceso viene caricato subito
 * - alla quit, ogni autosave-minutes e allo spegnimento riscrive i file dei giocatori online
 */
public class DatabaseModule implements Module, Listener {
   private final SmpCore plugin;
   private PlayerDatabase database;
   private int watchTask = -1;
   private int saveTask = -1;

   public DatabaseModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "database";
   }

   public PlayerDatabase database() {
      return this.database;
   }

   public void onEnable() {
      this.database = new PlayerDatabase(this.plugin, this.plugin.getConfig().getString("database.folder", "database"));
      this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
      // La scansione parte al tick dopo l'avvio: core-systems (hide, teams, tpa, coinflip, invest, ...) viene caricato
      // DOPO questo modulo e registra i suoi contributori solo allora.
      Bukkit.getScheduler().runTask(this.plugin, this::startupScan);

      long watch = Math.max(1L, (long)this.plugin.getConfig().getInt("database.watch-seconds", 5)) * 20L;
      this.watchTask = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, this::watch, watch, watch);
      long save = Math.max(1L, (long)this.plugin.getConfig().getInt("database.autosave-minutes", 5)) * 1200L;
      this.saveTask = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, this::saveOnline, save, save);
   }

   private void startupScan() {
      if (this.database == null) {
         return;
      }

      int imported = 0;
      for(UUID id : this.database.listFiles()) {
         try {
            if (!this.database.inSync(id) && this.database.importPlayer(id)) {
               ++imported;
            }
         } catch (Throwable t) {
            this.plugin.getLogger().warning("[database] import failed for " + id + ": " + t.getMessage());
         }
      }

      int created = 0;
      if (this.plugin.getConfig().getBoolean("database.export-on-startup", true)) {
         for(UUID id : this.database.knownPlayers()) {
            try {
               if (!this.database.fileOf(id).exists() && this.database.export(id, false)) {
                  ++created;
               }
            } catch (Throwable t) {
               this.plugin.getLogger().warning("[database] export failed for " + id + ": " + t.getMessage());
            }
         }
      }

      for(Player p : Bukkit.getOnlinePlayers()) {
         this.syncOnJoin(p.getUniqueId());
      }

      this.plugin.getLogger().info("[database] folder '" + this.database.folder().getName() + "': loaded " + imported + " changed file(s), created " + created + " new file(s).");
   }

   public void onDisable() {
      if (this.watchTask != -1) {
         Bukkit.getScheduler().cancelTask(this.watchTask);
      }

      if (this.saveTask != -1) {
         Bukkit.getScheduler().cancelTask(this.saveTask);
      }

      this.watchTask = -1;
      this.saveTask = -1;
      if (this.database != null) {
         this.saveOnline();
      }
   }

   public void reload() {
      this.onDisable();
      this.onEnable();
   }

   private void saveOnline() {
      for(Player p : Bukkit.getOnlinePlayers()) {
         try {
            this.database.export(p.getUniqueId(), false);
         } catch (Throwable t) {
            this.plugin.getLogger().warning("[database] export failed for " + p.getName() + ": " + t.getMessage());
         }
      }
   }

   /** File cambiato da fuori per un giocatore online: lo carica subito. */
   private void watch() {
      for(UUID id : this.database.listFiles()) {
         Player p = Bukkit.getPlayer(id);
         if (p != null && !this.database.inSync(id)) {
            try {
               if (this.database.importPlayer(id)) {
                  p.sendMessage("§aYour player data was reloaded from the database.");
               }
            } catch (Throwable t) {
               this.plugin.getLogger().warning("[database] import failed for " + p.getName() + ": " + t.getMessage());
            }
         }
      }
   }

   private void syncOnJoin(UUID id) {
      File f = this.database.fileOf(id);
      if (f.exists()) {
         if (!this.database.inSync(id)) {
            this.database.importPlayer(id);
         }
      } else {
         Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.database.export(id, false), 40L);
      }
   }

   @EventHandler(priority = EventPriority.LOWEST)
   public void onJoin(PlayerJoinEvent e) {
      try {
         this.syncOnJoin(e.getPlayer().getUniqueId());
      } catch (Throwable t) {
         this.plugin.getLogger().warning("[database] join sync failed for " + e.getPlayer().getName() + ": " + t.getMessage());
      }
   }

   @EventHandler(priority = EventPriority.MONITOR)
   public void onQuit(PlayerQuitEvent e) {
      try {
         this.database.export(e.getPlayer().getUniqueId(), false);
      } catch (Throwable t) {
         this.plugin.getLogger().warning("[database] quit export failed for " + e.getPlayer().getName() + ": " + t.getMessage());
      }
   }
}
