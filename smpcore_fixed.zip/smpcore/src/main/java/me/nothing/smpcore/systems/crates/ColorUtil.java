package me.nothing.smpcore.systems.crates;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').hexCharacter('#').build();

   private ColorUtil() {
   }

   /** &c, &#RRGGBB, #RRGGBB, <#RRGGBB> e tag MiniMessage (gradient, shadow...) nello stesso testo. */
   public static Component parse(String text) {
      return (Component)(text != null && !text.isEmpty() ? me.nothing.smpcore.utils.Rich.parse(text).decoration(TextDecoration.ITALIC, false) : Component.empty());
   }

   public static String strip(String text) {
      return text == null ? "" : text.replaceAll("(?i)§[0-9a-fk-orx]", "").replaceAll("(?i)&[0-9a-fk-orx]", "").replaceAll("&#[0-9a-fA-F]{6}", "");
   }
}
