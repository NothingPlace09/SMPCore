package me.nothing.smpcore.systems.staff.util;

/**
 * Centers a chat line by padding it with leading spaces, based on the estimated pixel width
 * of Minecraft's default font. Understands &-color codes, &l bold (which widens every
 * following character by 1px) and &#RRGGBB hex codes (treated as zero-width, like any color code).
 */
public final class ChatCenter {

    // Half the default chat box width in pixels — the widely-used constant for this technique.
    private static final int CENTER_PX = 154;

    private ChatCenter() {}

    public static String center(String message) {
        if (message == null || message.isEmpty()) return message;

        int messagePxSize = 0;
        boolean isBold = false;

        char[] chars = message.toCharArray();
        int i = 0;
        while (i < chars.length) {
            char c = chars[i];

            if (c == '&' && i + 1 < chars.length) {
                char next = chars[i + 1];

                // &#RRGGBB hex color — zero width, skip all 8 characters, resets bold like any color code.
                if (next == '#' && i + 7 < chars.length && isHex(chars, i + 2)) {
                    isBold = false;
                    i += 8;
                    continue;
                }

                // Standard &x code (bold toggle, other formatting, or color reset).
                if (next == 'l' || next == 'L') {
                    isBold = true;
                } else if (isColorOrReset(next)) {
                    isBold = false;
                }
                i += 2;
                continue;
            }

            DefaultFontInfo info = DefaultFontInfo.getDefaultFontInfo(c);
            messagePxSize += isBold ? info.getBoldLength() : info.getLength();
            messagePxSize++;
            i++;
        }

        int halvedMessageSize = messagePxSize / 2;
        int toCompensate = CENTER_PX - halvedMessageSize;
        if (toCompensate <= 0) return message;

        int spaceLength = DefaultFontInfo.SPACE.getLength() + 1;
        int compensated = 0;
        StringBuilder sb = new StringBuilder();
        while (compensated < toCompensate) {
            sb.append(' ');
            compensated += spaceLength;
        }
        return sb + message;
    }

    private static boolean isHex(char[] chars, int start) {
        for (int j = start; j < start + 6; j++) {
            char c = chars[j];
            boolean hex = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F');
            if (!hex) return false;
        }
        return true;
    }

    private static boolean isColorOrReset(char c) {
        return "0123456789abcdefrABCDEFR".indexOf(c) >= 0;
    }
}
