package me.nothing.smpcore.systems.staff.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Builds ItemStacks from a config section shaped like:
 *   material: COMPASS
 *   name: "&eSome Name"
 *   lore: [ "&7line 1", "&7line 2" ]
 * Colors use legacy & codes plus hex colors as &#RRGGBB — same syntax as messages.yml.
 */
public class ConfigItemFactory {

    private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder()
            .character('&')
            .hexColors()
            .build();

    private static String expandHex(String input) {
        Matcher matcher = HEX_PATTERN.matcher(input);
        StringBuilder sb = new StringBuilder();
        while (matcher.find()) {
            String hex = matcher.group(1);
            StringBuilder replacement = new StringBuilder("&x");
            for (char c : hex.toCharArray()) {
                replacement.append('&').append(c);
            }
            matcher.appendReplacement(sb, Matcher.quoteReplacement(replacement.toString()));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    private static Component deserialize(String raw) {
        return LEGACY.deserialize(expandHex(raw)).decoration(TextDecoration.ITALIC, false);
    }

    /** Reads every numeric-keyed child of `section` (e.g. staffmode.items) into slot -> ItemStack. */
    public static Map<Integer, ItemStack> buildSlotMap(ConfigurationSection section, Logger logger) {
        Map<Integer, ItemStack> result = new java.util.LinkedHashMap<>();
        if (section == null) return result;

        for (String key : section.getKeys(false)) {
            int slot;
            try {
                slot = Integer.parseInt(key);
            } catch (NumberFormatException e) {
                logger.warning("Ignoring non-numeric staffmode item slot key: " + key);
                continue;
            }

            ConfigurationSection itemSection = section.getConfigurationSection(key);
            if (itemSection == null) continue;

            ItemStack item = build(itemSection, logger);
            if (item != null) result.put(slot, item);
        }
        return result;
    }

    public static ItemStack build(ConfigurationSection itemSection, Logger logger) {
        String materialName = itemSection.getString("material", "STONE");
        Material material = Material.matchMaterial(materialName);
        if (material == null) {
            logger.warning("Unknown material '" + materialName + "' in staffmode items config, skipping.");
            return null;
        }

        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            String name = itemSection.getString("name");
            if (name != null && !name.isBlank()) {
                meta.displayName(deserialize(name));
            }

            List<String> loreLines = itemSection.getStringList("lore");
            if (!loreLines.isEmpty()) {
                List<Component> lore = new ArrayList<>();
                for (String line : loreLines) {
                    lore.add(deserialize(line));
                }
                meta.lore(lore);
            }

            item.setItemMeta(meta);
        }
        return item;
    }
}
