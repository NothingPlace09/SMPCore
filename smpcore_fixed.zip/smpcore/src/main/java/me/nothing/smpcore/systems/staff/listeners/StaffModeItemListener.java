package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.entity.Entity;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Event;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

public class StaffModeItemListener implements Listener {

    private final GalaxydeStaff plugin;

    public StaffModeItemListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    // Deliberately NOT ignoreCancelled=true: some blocks (chests, doors, protected regions...)
    // can end up with this event already cancelled by something else before we see it. We still
    // want the staffmode item's command to fire regardless, so we process it unconditionally
    // and then suppress the block/item's own vanilla behavior ourselves below.
    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        // Right-click only (left-click stays free, e.g. for attacking) — covers both air and block.
        if (event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_AIR
                && event.getAction() != org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK) return;

        // Only handle the main-hand event, otherwise this fires twice per click (main + off hand).
        if (event.getHand() != EquipmentSlot.HAND) return;

        Player player = event.getPlayer();
        if (!plugin.staffMode().isInStaffMode(player.getUniqueId())) return;

        int slot = player.getInventory().getHeldItemSlot();
        ConfigurationSection itemsSection = plugin.getConfig().getConfigurationSection("staffmode.items");
        if (itemsSection == null) return;

        ConfigurationSection itemSection = itemsSection.getConfigurationSection(String.valueOf(slot));
        if (itemSection == null) return;

        String command = itemSection.getString("command");
        if (command == null || command.isBlank()) return;

        // This is one of our command items — always fully suppress the block/item's normal
        // behavior (opening a chest, using a door, etc.) so only our command happens, no matter
        // whether the player right-clicked air or a block.
        event.setCancelled(true);
        event.setUseInteractedBlock(Event.Result.DENY);
        event.setUseItemInHand(Event.Result.DENY);

        command = command.startsWith("/") ? command.substring(1) : command;

        // If this item needs a target player, auto-fill it from whoever the staff member is
        // currently looking at — that way it works the same whether they're aiming at air or a block.
        if (itemSection.getBoolean("requires-target", false)) {
            Player target = findLookedAtPlayer(player);
            if (target == null) {
                plugin.msg().send(player, "staffmode.item-no-target");
                return;
            }
            command = command + " " + target.getName();
        }

        if (itemSection.getBoolean("console", false)) {
            String finalCommand = command.replace("%player%", player.getName());
            plugin.getServer().dispatchCommand(plugin.getServer().getConsoleSender(), finalCommand);
        } else {
            player.performCommand(command);
        }
    }

    private Player findLookedAtPlayer(Player staff) {
        double range = plugin.getConfig().getDouble("staffmode.item-target-range", 100);
        Entity entity = staff.getTargetEntity((int) range);
        return entity instanceof Player p ? p : null;
    }
}
