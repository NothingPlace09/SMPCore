package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import me.nothing.smpcore.systems.staff.managers.AuditEntry;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.text.SimpleDateFormat;
import java.util.Date;

public class StaffHistoryCommand extends BaseCommand {

    public StaffHistoryCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        if (!requirePermission(sender, "galaxydestaff.staffhistory")) return;

        if (args.length < 1) {
            plugin.msg().send(sender, "general.invalid-usage", MessagesManager.pairs("usage", "/staffhistory %staff%"));
            return;
        }

        int page = 1;
        if (args.length >= 2) {
            try {
                page = Math.max(1, Integer.parseInt(args[1]));
            } catch (NumberFormatException ignored) {
            }
        }

        @SuppressWarnings("deprecation")
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (!target.hasPlayedBefore() && !target.isOnline()) {
            plugin.msg().send(sender, "general.player-not-found", MessagesManager.pairs("target", args[0]));
            return;
        }

        int perPage = plugin.getConfig().getInt("staffhistory.entries-per-page", 8);
        int finalPage = page;

        plugin.audit().getStaffHistoryPage(target.getUniqueId(), finalPage, perPage, list -> {
            if (list.isEmpty()) {
                plugin.msg().send(sender, "staffhistory.empty");
                return;
            }
            plugin.msg().send(sender, "staffhistory.header", MessagesManager.pairs(
                    "staff", target.getName() != null ? target.getName() : args[0],
                    "page", String.valueOf(finalPage), "max_page", String.valueOf(finalPage)));

            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
            for (AuditEntry entry : list) {
                plugin.msg().send(sender, "staffhistory.entry", MessagesManager.pairs(
                        "action", entry.action(),
                        "target", entry.targetName() != null ? entry.targetName() : "-",
                        "reason", entry.reason() != null ? entry.reason() : "-",
                        "date", sdf.format(new Date(entry.createdAt()))
                ));
            }
        });
    }
}
