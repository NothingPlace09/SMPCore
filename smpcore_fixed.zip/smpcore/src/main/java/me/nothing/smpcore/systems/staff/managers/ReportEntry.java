package me.nothing.smpcore.systems.staff.managers;

public record ReportEntry(int id, String targetName, String reporterName, String reason, long createdAt, String status) {}
