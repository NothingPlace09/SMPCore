package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class PlayerAlertCommand extends BaseCommand {

    public PlayerAlertCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player staff = requirePlayer(sender);
        if (staff == null) return;
        if (!requirePermission(staff, "galaxydestaff.playeralert")) return;

        if (args.length < 2) {
            plugin.msg().send(staff, "general.invalid-usage", MessagesManager.pairs("usage", "/playeralert %player% %reason%"));
            return;
        }

        String target = args[0];
        String reason = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));

        var placeholders = MessagesManager.pairs("target", target, "staff", staff.getName(), "reason", reason);

        Sound sound;
        try {
            sound = Sound.valueOf(plugin.getConfig().getString("alerts.sound", "ENTITY_EXPERIENCE_ORB_PICKUP"));
        } catch (IllegalArgumentException e) {
            sound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP;
        }
        final Sound finalSound = sound;

        for (Component line : plugin.msg().render("playeralert.broadcast", placeholders)) {
            Bukkit.getOnlinePlayers().stream()
                    .filter(p -> p.hasPermission("galaxydestaff.alerts.receive"))
                    .forEach(p -> {
                        p.sendMessage(line);
                        p.playSound(p.getLocation(), finalSound, 1f, 1f);
                    });
            Bukkit.getConsoleSender().sendMessage(line);
        }

        plugin.msg().send(staff, "playeralert.sent", placeholders);
        plugin.audit().log(staff.getUniqueId(), staff.getName(), "PLAYERALERT", null, target, reason);
    }
}
