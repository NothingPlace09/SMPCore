package me.nothing.smpcore.systems.staff.listeners;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class SpectateListener implements Listener {

    private final GalaxydeStaff plugin;

    public SpectateListener(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();

        // If this player was being spectated, pull all watching staff out.
        plugin.spectate().stopAllSpectating(player.getUniqueId());

        // If this player was themselves spectating someone, just drop the bookkeeping
        // (no need to restore gamemode/location — they're disconnecting anyway).
        if (plugin.spectate().isSpectating(player.getUniqueId())) {
            plugin.spectate().stop(player);
        }
    }
}
