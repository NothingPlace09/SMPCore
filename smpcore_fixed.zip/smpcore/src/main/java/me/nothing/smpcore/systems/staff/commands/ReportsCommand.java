package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import me.nothing.smpcore.systems.staff.managers.ReportEntry;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ReportsCommand extends BaseCommand {

    public ReportsCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        if (!requirePermission(sender, "galaxydestaff.reports")) return;

        if (args.length >= 2 && args[0].equalsIgnoreCase("resolve")) {
            try {
                int id = Integer.parseInt(args[1]);
                plugin.reports().resolve(id, sender.getName(), resolved -> {
                    if (resolved != null) {
                        plugin.msg().send(sender, "reports.resolved", MessagesManager.pairs("id", String.valueOf(id)));
                        plugin.discord().sendReportResolvedLog(id, resolved.targetName(), resolved.reporterName(),
                                resolved.reason(), sender.getName());
                    } else {
                        plugin.msg().send(sender, "general.player-not-found", MessagesManager.pairs("target", "#" + id));
                    }
                });
            } catch (NumberFormatException e) {
                plugin.msg().send(sender, "general.invalid-usage", MessagesManager.pairs("usage", "/reports resolve %id%"));
            }
            return;
        }

        int page = 1;
        if (args.length >= 1) {
            try {
                page = Math.max(1, Integer.parseInt(args[0]));
            } catch (NumberFormatException ignored) {
            }
        }

        int perPage = plugin.getConfig().getInt("history.entries-per-page", 8);
        int finalPage = page;

        plugin.reports().countOpen(total -> {
            int maxPage = Math.max(1, (int) Math.ceil(total / (double) perPage));
            plugin.reports().listOpen(finalPage, perPage, list -> {
                if (list.isEmpty()) {
                    plugin.msg().send(sender, "reports.empty");
                    return;
                }
                plugin.msg().send(sender, "reports.header",
                        MessagesManager.pairs("page", String.valueOf(finalPage), "max_page", String.valueOf(maxPage)));
                SimpleDateFormat sdf = new SimpleDateFormat("dd/MM HH:mm");
                for (ReportEntry entry : list) {
                    plugin.msg().send(sender, "reports.entry", MessagesManager.pairs(
                            "id", String.valueOf(entry.id()),
                            "target", entry.targetName(),
                            "staff", entry.reporterName(),
                            "reason", entry.reason(),
                            "date", sdf.format(new Date(entry.createdAt()))
                    ));
                }
            });
        });
    }
}
