package me.nothing.smpcore.systems.staff.managers;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import me.nothing.smpcore.systems.staff.config.MessagesManager;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;

import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class StaffChatManager {

    private final GalaxydeStaff plugin;
    private final Set<UUID> toggled = ConcurrentHashMap.newKeySet();

    public StaffChatManager(GalaxydeStaff plugin) {
        this.plugin = plugin;
    }

    public boolean isToggled(UUID uuid) {
        return toggled.contains(uuid);
    }

    public boolean toggle(Player player) {
        if (isToggled(player.getUniqueId())) {
            toggled.remove(player.getUniqueId());
            plugin.msg().send(player, "staffchat.toggled-off");
            return false;
        } else {
            toggled.add(player.getUniqueId());
            plugin.msg().send(player, "staffchat.toggled-on");
            return true;
        }
    }

    /**
     * Sends a message to every online player with staffchat permission, formatted via messages.yml.
     * If staffchat.broadcast-to-public is enabled in config, it's also echoed to everyone else
     * (regular players) using the staffchat.public-format template.
     */
    public void broadcast(Player staff, String message) {
        var placeholders = MessagesManager.pairs("staff", staff.getName(), "message", message);

        for (Component line : plugin.msg().render("staffchat.format", placeholders)) {
            plugin.getServer().getOnlinePlayers().stream()
                    .filter(p -> p.hasPermission("galaxydestaff.staffchat"))
                    .forEach(p -> p.sendMessage(line));
            plugin.getServer().getConsoleSender().sendMessage(line);
        }

        if (plugin.getConfig().getBoolean("staffchat.broadcast-to-public", true)) {
            for (Component line : plugin.msg().render("staffchat.public-format", placeholders)) {
                plugin.getServer().getOnlinePlayers().stream()
                        .filter(p -> !p.hasPermission("galaxydestaff.staffchat")) // avoid double delivery to staff
                        .forEach(p -> p.sendMessage(line));
            }
        }
    }
}
