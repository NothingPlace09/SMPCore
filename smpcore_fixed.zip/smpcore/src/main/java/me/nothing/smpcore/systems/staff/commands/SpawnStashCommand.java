package me.nothing.smpcore.systems.staff.commands;

import me.nothing.smpcore.systems.staff.GalaxydeStaff;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpawnStashCommand extends BaseCommand {

    public SpawnStashCommand(GalaxydeStaff plugin) {
        super(plugin);
    }

    @Override
    protected void execute(CommandSender sender, Command command, String label, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        if (!requirePermission(player, "galaxydestaff.spawnstash")) return;

        plugin.spawnStash().paste(player);
        plugin.msg().send(player, "spawnstash.placed");
        plugin.audit().log(player.getUniqueId(), player.getName(), "SPAWNSTASH");
    }
}
