package me.nothing.smpcore.systems.voucher;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.config.ConfigFile;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import me.nothing.smpcore.systems.smpcorelib.gui.Menu;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuListener;
import me.nothing.smpcore.systems.smpcorelib.item.Items;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import me.nothing.smpcore.systems.smpcorelib.sound.Sounds;
import me.nothing.smpcore.systems.smpcorelib.storage.StorageFactory;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public final class VoucherPlugin extends VoucherBase {
   private ConfigFile vouchersFile;
   private ConfigFile adminFile;
   private ConfigFile confirmFile;
   private ConfigFile editFile;
   private MenuConfig adminMenu;
   private MenuConfig confirmMenu;
   private MenuConfig editCreateMenu;
   private MenuConfig editEditMenu;
   private char adminContentSymbol = '#';
   private List<Integer> adminContentSlots = List.of();
   private List<VoucherDef> vouchers = List.of();
   private Map<String, VoucherDef> byId = Map.of();
   private VoucherTags tags;
   private Redeemer redeemer;
   private Ledger ledger;
   private Sounds sounds;
   private TimeText time;
   private EconomyHook economy;
   private ChatPrompt prompt;
   private List<String> blockedWorlds = List.of();
   private List<String> loreSuffix = List.of();
   private boolean confirmDefault = true;
   private boolean requireFreeSlots = true;
   private String menuPermission = "smpcorevoucher.menu";
   private String givePermission = "smpcorevoucher.give";
   private String editPermission = "smpcorevoucher.edit";
   private String reloadPermission = "smpcorevoucher.reload";
   private String usePermission = "smpcorevoucher.use";
   private Scheduler.Task flushTask;

   protected void start() {
      this.adminFile = (new ConfigFile(this, "menu-admin.yml")).load(true);
      this.confirmFile = (new ConfigFile(this, "menu-confirm.yml")).load(true);
      this.editFile = (new ConfigFile(this, "menu-edit.yml")).load(true);
      this.tags = new VoucherTags(this);
      this.redeemer = new Redeemer(this);
      this.economy = new EconomyHook(this);
      this.economy.hook();
      this.prompt = new ChatPrompt(this);
      this.loadVouchers();
      this.applySettings();
      this.loadMenus();
      this.ledger = new Ledger(this, StorageFactory.baue(this, this.config().yaml().getConfigurationSection("storage")), this.config().yaml().getBoolean("security.remember-redeemed", true), this.config().yaml().getLong("security.forget-after-days", 0L));
      this.ledger.load();
      this.startFlushing();
      MenuListener.useSounds(this, this.sounds);
      this.getServer().getPluginManager().registerEvents(new MenuListener(this), this.core());
      this.getServer().getPluginManager().registerEvents(new VoucherListener(this), this.core());
      this.getServer().getPluginManager().registerEvents(this.prompt, this.core());
      if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         if (VoucherPlaceholders.register(this)) {
            this.getLogger().info("PlaceholderAPI hooked: %smpcorevoucher_...% is available.");
         } else {
            this.getLogger().warning("PlaceholderAPI is installed but refused the expansion.");
         }
      }

      Logger logger = this.getLogger();
      int i = this.vouchers.size();
      logger.info("SmpCoreVoucher ready - " + i + " voucher(s)" + (this.economy.available() ? ", Vault economy found." : ", no Vault economy."));
   }

   protected void stop() {
      try {
         VoucherPlaceholders.dropActive();
      } catch (Throwable ignored) {
      }
      if (this.flushTask != null) {
         this.flushTask.cancel();
         this.flushTask = null;
      }

      try {
         this.closeOurMenus();
      } catch (RuntimeException e) {
         this.getLogger().warning("Could not close the voucher menus on shutdown: " + String.valueOf(e));
      }

      if (this.ledger != null) {
         this.ledger.flush();
         this.ledger.shutdown();
      }

   }

   private void loadVouchers() {
      this.vouchersFile = ConfigFile.shared(this, "vouchers.yml").load(false);
      this.buildVouchers();
   }

   private void buildVouchers() {
      ConfigurationSection configurationSection = this.vouchersFile.yaml().getConfigurationSection("vouchers");
      ArrayList arrayList = new ArrayList();
      LinkedHashMap linkedHashMap = new LinkedHashMap();
      if (configurationSection == null) {
         this.getLogger().warning("vouchers.yml has no `vouchers:` section - there is nothing to hand out. Delete the file and restart to get the shipped one back.");
      } else {
         for(String var5 : configurationSection.getKeys(false)) {
            String str = var5.toLowerCase(Locale.ROOT);
            VoucherDef voucherDef = VoucherDef.load(configurationSection.getConfigurationSection(var5), str, this.getLogger());
            if (voucherDef != null) {
               arrayList.add(voucherDef);
               linkedHashMap.put(str, voucherDef);
            }
         }
      }

      this.vouchers = List.copyOf(arrayList);
      this.byId = Map.copyOf(linkedHashMap);
   }

   private void loadMenus() {
      this.adminMenu = MenuConfig.load(this.adminFile.yaml(), "menu.layout", this.getLogger());
      String str = this.adminFile.yaml().getString("menu.content-symbol", "#");
      this.adminContentSymbol = str != null && !str.isEmpty() ? str.charAt(0) : 35;
      this.adminContentSlots = this.adminMenu.layout().slotsOf(this.adminContentSymbol);
      if (this.adminContentSlots.isEmpty()) {
         this.getLogger().warning("menu-admin.yml has no '" + this.adminContentSymbol + "' in its layout, so /voucher admin shows an empty window. Put the content symbol into menu.layout.");
      }

      this.confirmMenu = MenuConfig.load(this.confirmFile.yaml(), "menu.layout", this.getLogger());
      this.editCreateMenu = MenuConfig.load(this.editFile.yaml(), "menu.layout-create", this.getLogger());
      this.editEditMenu = MenuConfig.load(this.editFile.yaml(), "menu.layout-edit", this.getLogger());
   }

   private void applySettings() {
      YamlConfiguration yamlConfiguration = this.config().yaml();
      this.sounds = new Sounds(yamlConfiguration.getConfigurationSection("sounds"));
      this.time = new TimeText(yamlConfiguration.getConfigurationSection("time"));
      this.blockedWorlds = List.copyOf(yamlConfiguration.getStringList("redeem.blocked-worlds"));
      this.loreSuffix = List.copyOf(yamlConfiguration.getStringList("voucher-item.lore"));
      this.confirmDefault = yamlConfiguration.getBoolean("redeem.confirm", true);
      this.requireFreeSlots = yamlConfiguration.getBoolean("redeem.require-free-slots", true);
      this.menuPermission = yamlConfiguration.getString("command.menu-permission", "smpcorevoucher.menu");
      this.givePermission = yamlConfiguration.getString("command.give-permission", "smpcorevoucher.give");
      this.editPermission = yamlConfiguration.getString("command.edit-permission", "smpcorevoucher.edit");
      this.reloadPermission = yamlConfiguration.getString("command.reload-permission", "smpcorevoucher.reload");
      this.usePermission = yamlConfiguration.getString("command.use-permission", "smpcorevoucher.use");
      if (this.prompt != null) {
         this.prompt.configure(yamlConfiguration.getStringList("editor.cancel-words"), yamlConfiguration.getInt("editor.timeout-seconds", 60));
      }

   }

   public int reload() {
      this.closeOurMenusSoon();
      this.config().load(true);
      this.adminFile.load(true);
      this.confirmFile.load(true);
      this.editFile.load(true);
      this.vouchersFile.load(true);
      this.buildVouchers();
      this.applySettings();
      this.loadMenus();
      if (this.sounds != null) {
         MenuListener.useSounds(this, this.sounds);
      }

      this.startFlushing();
      return this.vouchers.size();
   }

   private void startFlushing() {
      if (this.flushTask != null) {
         this.flushTask.cancel();
         this.flushTask = null;
      }

      long l = Math.max(10L, this.config().yaml().getLong("security.save-seconds", 60L));
      long l2 = l * 20L;
      this.flushTask = Scheduler.timer(this, () -> this.ledger.flush(), l2, l2);
   }

   private void closeOurMenus() {
      for(Player var2 : Bukkit.getOnlinePlayers()) {
         if (this.isOurs(var2)) {
            var2.closeInventory();
         }
      }

   }

   private void closeOurMenusSoon() {
      for(Player var2 : Bukkit.getOnlinePlayers()) {
         Scheduler.atEntity(this, var2, () -> {
            if (var2.isOnline() && this.isOurs(var2)) {
               var2.closeInventory();
            }

         });
      }

   }

   private boolean isOurs(Player player) {
      InventoryHolder inventoryHolder = player.getOpenInventory().getTopInventory().getHolder();
      boolean flag;
      if (inventoryHolder instanceof Menu menu) {
         if (menu.isOwnedBy(this)) {
            flag = true;
            return flag;
         }
      }

      flag = false;
      return flag;
   }

   public ItemStack issue(VoucherDef voucherDef) {
      long l = System.currentTimeMillis();
      long l2 = voucherDef.lifetimeMillis() > 0L ? l + voucherDef.lifetimeMillis() : 0L;
      VoucherTag voucherTag = new VoucherTag(voucherDef.id(), VoucherTags.newSerial(), l, l2);
      ItemStack itemStack = voucherDef.build(this.display(voucherDef, voucherTag), this.loreSuffix, this.getLogger());
      return itemStack == null ? null : this.tags.stamp(itemStack, voucherTag);
   }

   public ItemStack preview(VoucherDef voucherDef) {
      Map map = this.display(voucherDef, (VoucherTag)null);
      ItemStack itemStack = voucherDef.build(map, this.loreSuffix, this.getLogger());
      return itemStack == null ? new ItemStack(Material.BARRIER) : itemStack;
   }

   public Map<String, String> display(VoucherDef voucherDef, VoucherTag voucherTag) {
      HashMap hashMap = new HashMap();
      String str = this.config().yaml().getString("voucher-item.preview-serial", "--------");
      hashMap.put("voucher", voucherDef.displayName());
      hashMap.put("voucher_id", voucherDef.id());
      hashMap.put("serial", voucherTag == null ? str : voucherTag.serial());
      hashMap.put("serial_short", voucherTag == null ? str : voucherTag.shortSerial());
      hashMap.put("money", EconomyHook.format(voucherDef.money()));
      long l = voucherTag == null ? (voucherDef.lifetimeMillis() > 0L ? voucherDef.lifetimeMillis() / 1000L : -1L) : voucherTag.secondsLeft(System.currentTimeMillis());
      hashMap.put("time", this.time.format(l));
      boolean flag = voucherTag == null ? voucherDef.lifetimeMillis() > 0L : voucherTag.timed();
      hashMap.put("expires", flag ? Text.apply(this.config().yaml().getString("expiry.line", "Expires in %time%"), Map.of("time", this.time.format(l))) : this.config().yaml().getString("expiry.none", ""));
      return hashMap;
   }

   public int give(Player player, VoucherDef voucherDef, int count) {
      int i = 0;

      for(int var5 = 0; var5 < count; ++var5) {
         ItemStack itemStack = this.issue(voucherDef);
         if (itemStack == null) {
            break;
         }

         Items.give(player, itemStack);
         ++i;
      }

      return i;
   }

   public ConfigFile vouchersFile() {
      return this.vouchersFile;
   }

   public ConfigurationSection section(String str) {
      return this.vouchersFile.yaml().getConfigurationSection("vouchers." + str);
   }

   public void saveVouchers() {
      this.vouchersFile.save();
      this.buildVouchers();
   }

   public void rename(String str, String str2) {
      ConfigurationSection configurationSection = this.section(str);
      if (configurationSection != null && !str.equals(str2)) {
         ConfigurationSection configurationSection2 = this.vouchersFile.yaml().createSection("vouchers." + str2);
         copy(configurationSection, configurationSection2);
         this.vouchersFile.yaml().set("vouchers." + str, (Object)null);
      }
   }

   private static void copy(ConfigurationSection configurationSection, ConfigurationSection configurationSection2) {
      for(String var3 : configurationSection.getKeys(false)) {
         Object obj = configurationSection.get(var3);
         if (obj instanceof ConfigurationSection configurationSection3) {
            copy(configurationSection3, configurationSection2.createSection(var3));
         } else {
            configurationSection2.set(var3, obj);
         }
      }

   }

   public void deleteVoucher(String str) {
      this.vouchersFile.yaml().set("vouchers." + str, (Object)null);
      this.saveVouchers();
   }

   public VoucherTags tags() {
      return this.tags;
   }

   public Redeemer redeemer() {
      return this.redeemer;
   }

   public Ledger ledger() {
      return this.ledger;
   }

   public EconomyHook economy() {
      return this.economy;
   }

   public TimeText time() {
      return this.time;
   }

   public ChatPrompt prompt() {
      return this.prompt;
   }

   public List<VoucherDef> vouchers() {
      return this.vouchers;
   }

   public VoucherDef voucher(String str) {
      return str == null ? null : (VoucherDef)this.byId.get(str.toLowerCase(Locale.ROOT));
   }

   public MenuConfig adminMenuConfig() {
      return this.adminMenu;
   }

   public MenuConfig confirmMenuConfig() {
      return this.confirmMenu;
   }

   public MenuConfig editMenuConfig(boolean flag) {
      return flag ? this.editCreateMenu : this.editEditMenu;
   }

   public ConfigFile editFile() {
      return this.editFile;
   }

   public ConfigFile adminFile() {
      return this.adminFile;
   }

   public char adminContentSymbol() {
      return this.adminContentSymbol;
   }

   public List<Integer> adminContentSlots() {
      return this.adminContentSlots;
   }

   public List<String> loreSuffix() {
      return this.loreSuffix;
   }

   public boolean confirmDefault() {
      return this.confirmDefault;
   }

   public boolean requireFreeSlots() {
      return this.requireFreeSlots;
   }

   public boolean blockedWorld(String str) {
      for(String var3 : this.blockedWorlds) {
         if (var3.equalsIgnoreCase(str)) {
            return true;
         }
      }

      return false;
   }

   public void openAdmin(Player player) {
      (new AdminMenu(this, player, 0, SortMode.NAME_AZ, "")).open();
      this.playSound(player, "menu-open");
   }

   public void playSound(Player player, String str) {
      if (this.sounds != null) {
         this.sounds.play(player, str);
      }

   }

   public boolean allowed(CommandSender commandSender, String str) {
      return str == null || str.isEmpty() || commandSender.hasPermission(str);
   }

   public void denied(CommandSender commandSender) {
      this.message(commandSender, "no-permission");
      if (commandSender instanceof Player player) {
         this.playSound(player, "denied");
      }

   }

   public void explain(Player player, Redeemer.Result result, VoucherDef voucherDef, VoucherTag voucherTag) {
      if (!result.ok()) {
         HashMap hashMap = new HashMap();
         hashMap.put("player", player.getName());
         hashMap.put("voucher", voucherDef == null ? (voucherTag == null ? "?" : voucherTag.id()) : voucherDef.displayName());
         hashMap.put("voucher_id", voucherDef == null ? (voucherTag == null ? "?" : voucherTag.id()) : voucherDef.id());
         hashMap.put("serial", voucherTag == null ? "" : voucherTag.serial());
         hashMap.put("serial_short", voucherTag == null ? "" : voucherTag.shortSerial());
         if (voucherDef != null) {
            hashMap.put("max", String.valueOf(voucherDef.maxPerPlayer()));
            hashMap.put("time", this.time.format(this.redeemer.cooldownLeft(player, voucherDef)));
         } else {
            hashMap.put("max", "0");
            hashMap.put("time", this.time.none());
         }

         this.message(player, result.messageKey(), hashMap);
         this.playSound(player, "denied");
      }
   }

   public String menuPermission() {
      return this.menuPermission;
   }

   public String givePermission() {
      return this.givePermission;
   }

   public String editPermission() {
      return this.editPermission;
   }

   public String reloadPermission() {
      return this.reloadPermission;
   }

   public String usePermission() {
      return this.usePermission;
   }
}
