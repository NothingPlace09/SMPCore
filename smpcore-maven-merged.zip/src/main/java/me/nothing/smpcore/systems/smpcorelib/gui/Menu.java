package me.nothing.smpcore.systems.smpcorelib.gui;

import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import me.nothing.smpcore.systems.smpcorelib.text.Placeholders;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

public abstract class Menu implements InventoryHolder {
   protected final Player viewer;
   private Inventory inventory;
   private boolean creating;

   protected Menu(Player player) {
      this.viewer = player;
   }

   protected abstract String title();

   protected abstract int rows();

   protected abstract void draw();

   protected abstract void onClick(InventoryClickEvent var1);

   protected void onClose(InventoryCloseEvent inventoryCloseEvent) {
   }

   protected boolean cancelByDefault() {
      return true;
   }

   public Inventory getInventory() {
      if (this.inventory == null) {
         if (this.creating) {
            throw new IllegalStateException(this.getClass().getSimpleName() + ".title() or .rows() reads the menu's own inventory, which does not exist yet. Use inventoryOrNull() there and handle null.");
         }

         this.creating = true;

         try {
            this.inventory = Bukkit.createInventory(this, this.rows() * 9, Text.chat(Placeholders.apply(this.viewer, this.title())));
         } finally {
            this.creating = false;
         }
      }

      return this.inventory;
   }

   protected Inventory inventoryOrNull() {
      return this.inventory;
   }

   public void open() {
      Placeholders.zeichneFuer(this.viewer, this::draw);
      this.viewer.openInventory(this.getInventory());
   }

   public void refresh() {
      Placeholders.zeichneFuer(this.viewer, this::draw);
      this.viewer.updateInventory();
   }

   protected void spaeter(Runnable runnable) {
      JavaPlugin javaPlugin = JavaPlugin.getProvidingPlugin(this.getClass());

      try {
         Scheduler.atEntity(javaPlugin, this.viewer, runnable);
      } catch (RuntimeException e) {
         javaPlugin.getLogger().fine("Menue-Klick verworfen: " + String.valueOf(e));
      }

   }

   final void handleClick(InventoryClickEvent inventoryClickEvent) {
      if (this.cancelByDefault()) {
         inventoryClickEvent.setCancelled(true);
      }

      this.onClick(inventoryClickEvent);
   }

   final void handleClose(InventoryCloseEvent inventoryCloseEvent) {
      this.onClose(inventoryCloseEvent);
   }

   protected boolean clickedTopInventory(InventoryClickEvent inventoryClickEvent) {
      return inventoryClickEvent.getClickedInventory() != null && inventoryClickEvent.getClickedInventory().equals(this.getInventory());
   }

   public final boolean isOwnedBy(Plugin plugin) {
      if (plugin == null) {
         return false;
      } else {
         String str = plugin.getClass().getPackageName();
         String str2 = this.getClass().getPackageName();
         return str2.equals(str) || str2.startsWith(str + ".");
      }
   }
}
