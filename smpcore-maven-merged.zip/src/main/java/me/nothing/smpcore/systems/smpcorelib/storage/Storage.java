package me.nothing.smpcore.systems.smpcorelib.storage;

import java.util.Map;

public interface Storage extends AutoCloseable {
   Map<String, String> read(String var1, String var2);

   void write(String var1, String var2, Map<String, String> var3);

   void delete(String var1, String var2);

   Map<String, Map<String, String>> readAll(String var1);

   void flush();

   void close();
}
