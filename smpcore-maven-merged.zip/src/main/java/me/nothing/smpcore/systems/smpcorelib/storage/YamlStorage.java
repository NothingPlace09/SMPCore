package me.nothing.smpcore.systems.smpcorelib.storage;

import java.io.File;
import java.io.IOException;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;

public final class YamlStorage implements Storage {
   private final File ordner;
   private final Map<String, Map<String, Map<String, String>>> daten = new ConcurrentHashMap();
   private final Map<String, Boolean> schmutzig = new ConcurrentHashMap();
   private final Map<String, Boolean> unlesbar = new ConcurrentHashMap();
   private static final char TRENNER = '\u0000';

   public YamlStorage(File file) {
      this.ordner = file;
      if (!file.exists() && !file.mkdirs()) {
         throw new IllegalStateException("Ordner nicht anlegbar: " + String.valueOf(file));
      }
   }

   private Map<String, Map<String, String>> lade(String str) {
      return (Map)this.daten.computeIfAbsent(str, (var1x) -> {
         ConcurrentHashMap concurrentHashMap = new ConcurrentHashMap();
         File file = new File(this.ordner, var1x + ".yml");
         if (!file.exists()) {
            return concurrentHashMap;
         } else {
            YamlConfiguration yamlConfiguration = new YamlConfiguration();
            yamlConfiguration.options().pathSeparator('\u0000');

            try {
               yamlConfiguration.load(file);
            } catch (InvalidConfigurationException | IOException e) {
               this.unlesbar.put(var1x, Boolean.TRUE);
               Logger logger = Bukkit.getLogger();
               String fileName = file.getName();
               logger.severe("[SmpCore] " + fileName + " could not be read - this file will NOT be overwritten. Your data is still in it: " + String.valueOf(e));
               return concurrentHashMap;
            }

            for(String var6 : yamlConfiguration.getKeys(false)) {
               ConfigurationSection configurationSection = yamlConfiguration.getConfigurationSection(var6);
               if (configurationSection != null) {
                  ConcurrentHashMap concurrentHashMap2 = new ConcurrentHashMap();

                  for(String var10 : configurationSection.getKeys(false)) {
                     String value = configurationSection.getString(var10);
                     if (value != null) {
                        concurrentHashMap2.put(var10, value);
                     }
                  }

                  concurrentHashMap.put(var6, concurrentHashMap2);
               }
            }

            return concurrentHashMap;
         }
      });
   }

   public Map<String, String> read(String str, String str2) {
      Map map = (Map)this.lade(str).get(str2);
      return map == null ? new LinkedHashMap() : new LinkedHashMap(map);
   }

   public void write(String str, String str2, Map<String, String> map) {
      this.lade(str).put(str2, new ConcurrentHashMap(map));
      this.schmutzig.put(str, Boolean.TRUE);
   }

   public void delete(String str, String str2) {
      if (this.lade(str).remove(str2) != null) {
         this.schmutzig.put(str, Boolean.TRUE);
      }

   }

   public Map<String, Map<String, String>> readAll(String str) {
      LinkedHashMap linkedHashMap = new LinkedHashMap();
      this.lade(str).forEach((var1x, var2x) -> linkedHashMap.put(var1x, new LinkedHashMap(var2x)));
      return linkedHashMap;
   }

   public void flush() {
      for(Map.Entry var2 : this.daten.entrySet()) {
         if (!Boolean.TRUE.equals(this.unlesbar.get(var2.getKey())) && Boolean.TRUE.equals(this.schmutzig.get(var2.getKey()))) {
            YamlConfiguration yamlConfiguration = new YamlConfiguration();
            yamlConfiguration.options().pathSeparator('\u0000');
            ((Map)var2.getValue()).forEach((var1, var2x) -> var2x.forEach((feld, var3x) -> yamlConfiguration.set(var1 + "\u0000" + feld, var3x)));
            File file = new File(this.ordner, (String)var2.getKey() + ".yml");
            File file2 = new File(this.ordner, (String)var2.getKey() + ".yml.tmp");

            try {
               yamlConfiguration.save(file2);

               try {
                  Files.move(file2.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
               } catch (AtomicMoveNotSupportedException e) {
                  Files.move(file2.toPath(), file.toPath(), StandardCopyOption.REPLACE_EXISTING);
               }

               this.schmutzig.put((String)var2.getKey(), Boolean.FALSE);
            } catch (IOException e) {
               throw new IllegalStateException("Schreiben fehlgeschlagen: " + String.valueOf(file), e);
            }
         }
      }

   }

   public void close() {
      this.flush();
   }
}
