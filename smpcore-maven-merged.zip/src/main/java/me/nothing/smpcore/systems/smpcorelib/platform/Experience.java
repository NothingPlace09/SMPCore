package me.nothing.smpcore.systems.smpcorelib.platform;

import java.lang.reflect.Method;
import org.bukkit.entity.Player;

public final class Experience {
   private static volatile Method mitMending = sucheMitMending();

   private Experience() {
   }

   private static Method sucheMitMending() {
      try {
         return Player.class.getMethod("giveExp", Integer.TYPE, Boolean.TYPE);
      } catch (NoSuchMethodException e) {
         return null;
      }
   }

   public static boolean mending() {
      return mitMending != null;
   }

   public static void gib(Player player, int i) {
      if (player != null && i > 0) {
         Method method = mitMending;
         if (method != null) {
            try {
               method.invoke(player, i, true);
               return;
            } catch (ReflectiveOperationException e) {
               mitMending = null;
            }
         }

         player.giveExp(i);
      }
   }
}
