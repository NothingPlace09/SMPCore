package me.nothing.smpcore.systems.voucher;

import java.util.Comparator;
import java.util.Locale;

public enum SortMode {
   NAME_AZ(Comparator.comparing(VoucherDef::plainName, String.CASE_INSENSITIVE_ORDER)),
   NAME_ZA(Comparator.comparing(VoucherDef::plainName, String.CASE_INSENSITIVE_ORDER).reversed());

   private final Comparator<VoucherDef> comparator;

   private SortMode(Comparator<VoucherDef> comparator) {
      this.comparator = comparator;
   }

   public Comparator<VoucherDef> comparator() {
      return this.comparator;
   }

   public String key() {
      return this.name().toLowerCase(Locale.ROOT);
   }

   public SortMode next() {
      SortMode[] sortModeArr = values();
      return sortModeArr[(this.ordinal() + 1) % sortModeArr.length];
   }

   private static SortMode[] $values() {
      return new SortMode[]{NAME_AZ, NAME_ZA};
   }
}
