package me.nothing.smpcore.systems.smpcorelib;

import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;

public final class SmpCoreLookup {
   private SmpCoreLookup() {
   }

   public static Plugin find(String str) {
      return Bukkit.getPluginManager().getPlugin(str);
   }
}
