package me.nothing.smpcore.systems.voucher;

import java.util.UUID;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public final class VoucherTags {
   private final NamespacedKey idKey;
   private final NamespacedKey serialKey;
   private final NamespacedKey issuedKey;
   private final NamespacedKey expiresKey;

   public VoucherTags(VoucherPlugin voucherPlugin) {
      this.idKey = new NamespacedKey("smpcorevoucher", "voucher");
      this.serialKey = new NamespacedKey("smpcorevoucher", "serial");
      this.issuedKey = new NamespacedKey("smpcorevoucher", "issued");
      this.expiresKey = new NamespacedKey("smpcorevoucher", "expires");
   }

   public VoucherTag read(ItemStack itemStack) {
      if (itemStack != null && !itemStack.getType().isAir() && itemStack.hasItemMeta()) {
         ItemMeta itemMeta = itemStack.getItemMeta();
         if (itemMeta == null) {
            return null;
         } else {
            PersistentDataContainer persistentDataContainer = itemMeta.getPersistentDataContainer();
            String str = (String)persistentDataContainer.get(this.idKey, PersistentDataType.STRING);
            if (str != null && !str.isEmpty()) {
               String str2 = (String)persistentDataContainer.get(this.serialKey, PersistentDataType.STRING);
               if (str2 != null && !str2.isEmpty()) {
                  Long longVal = (Long)persistentDataContainer.get(this.issuedKey, PersistentDataType.LONG);
                  Long longVal2 = (Long)persistentDataContainer.get(this.expiresKey, PersistentDataType.LONG);
                  return new VoucherTag(str, str2, longVal == null ? 0L : longVal, longVal2 == null ? 0L : longVal2);
               } else {
                  return null;
               }
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   public boolean isVoucher(ItemStack itemStack) {
      return this.read(itemStack) != null;
   }

   public ItemStack stamp(ItemStack itemStack, VoucherTag voucherTag) {
      ItemMeta itemMeta = itemStack.getItemMeta();
      if (itemMeta == null) {
         return itemStack;
      } else {
         PersistentDataContainer persistentDataContainer = itemMeta.getPersistentDataContainer();
         persistentDataContainer.set(this.idKey, PersistentDataType.STRING, voucherTag.id());
         persistentDataContainer.set(this.serialKey, PersistentDataType.STRING, voucherTag.serial());
         persistentDataContainer.set(this.issuedKey, PersistentDataType.LONG, voucherTag.issued());
         persistentDataContainer.set(this.expiresKey, PersistentDataType.LONG, voucherTag.expires());
         itemStack.setItemMeta(itemMeta);
         itemStack.setAmount(1);
         return itemStack;
      }
   }

   public ItemStack clear(ItemStack itemStack) {
      if (itemStack == null) {
         return null;
      } else {
         ItemMeta itemMeta = itemStack.getItemMeta();
         if (itemMeta == null) {
            return itemStack;
         } else {
            PersistentDataContainer persistentDataContainer = itemMeta.getPersistentDataContainer();
            persistentDataContainer.remove(this.idKey);
            persistentDataContainer.remove(this.serialKey);
            persistentDataContainer.remove(this.issuedKey);
            persistentDataContainer.remove(this.expiresKey);
            itemStack.setItemMeta(itemMeta);
            return itemStack;
         }
      }
   }

   public static String newSerial() {
      return UUID.randomUUID().toString();
   }
}
