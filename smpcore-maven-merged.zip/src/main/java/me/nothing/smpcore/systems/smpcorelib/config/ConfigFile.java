package me.nothing.smpcore.systems.smpcorelib.config;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.Plugin;

public class ConfigFile {
   public static final String DEFAULT_LANGUAGE = "EN";
   private static final String TOGGLE = "config.yml";
   private static final Map<String, String> LANGUAGES = new ConcurrentHashMap();
   private static final Set<String> gewarnt = ConcurrentHashMap.newKeySet();
   private static final Set<String> SCHON_GEMELDET = ConcurrentHashMap.newKeySet();
   private final Plugin plugin;
   private final String path;
   private final String realPath;
   private final File file;
   private boolean kaputt;
   private YamlConfiguration config;
   private String[] eigeneAbschnitte;
   private static final Set<String> SCHON_GESCHRIEBEN = ConcurrentHashMap.newKeySet();

   public ConfigFile(Plugin var1, String var2) {
      this(var1, var2, true);
   }

   private ConfigFile(Plugin var1, String var2, boolean var3) {
      this.eigeneAbschnitte = new String[0];
      this.plugin = var1;
      this.path = var2;
      this.realPath = var3 ? "lang/" + language(var1) + "/" + var2 : var2;
      this.file = new File(var1.getDataFolder(), this.realPath);
   }

   public static ConfigFile shared(Plugin var0, String var1) {
      return new ConfigFile(var0, var1, false);
   }

   public static String language(Plugin var0) {
      return (String)LANGUAGES.computeIfAbsent(var0.getName(), (var1) -> liesSprache(var0));
   }

   private static String liesSprache(Plugin var0) {
      File file = new File(var0.getDataFolder(), "config.yml");
      if (!file.exists()) {
         var0.getDataFolder().mkdirs();
         String str = alteSprache(var0);
         if (var0.getResource("config.yml") != null) {
            var0.saveResource("config.yml", false);
            if (str != null) {
               setzeSprache(var0, file, str);
            }
         } else {
            schreibeStandardToggle(var0, file);
            if (str != null) {
               setzeSprache(var0, file, str);
            }
         }
      }

      String str = YamlConfiguration.loadConfiguration(file).getString("language", "EN");
      return str != null && !str.isBlank() ? str.trim().toUpperCase(Locale.ROOT) : "EN";
   }

   private static String alteSprache(Plugin var0) {
      File file = new File(var0.getDataFolder(), "settings.yml");
      if (!file.isFile()) {
         return null;
      } else {
         String str = YamlConfiguration.loadConfiguration(file).getString("language");
         if (str != null && !str.isBlank()) {
            String str2 = str.trim().toUpperCase(Locale.ROOT);
            return str2.equals("EN") ? null : str2;
         } else {
            return null;
         }
      }
   }

   private static void setzeSprache(Plugin var0, File var1, String var2) {
      try {
         String str = Files.readString(var1.toPath(), StandardCharsets.UTF_8);
         Files.writeString(var1.toPath(), str.replace("language: EN", "language: " + var2), StandardCharsets.UTF_8);
         var0.getLogger().info("Carried your old language setting (" + var2 + ") over into config.yml.");
      } catch (IOException e) {
         Logger logger = var0.getLogger();
         String str = String.valueOf(e);
         logger.warning("Could not carry the old language setting over: " + str + " - set language: " + var2 + " in config.yml yourself.");
      }

   }

   private static void schreibeStandardToggle(Plugin var0, File var1) {
      String str = "# =====================================================================\n#  Language / Sprache\n# =====================================================================\n#  EN  everything this plugin writes, and every comment in its config\n#      files, is English.  ->  lang/EN/\n#  DE  alles, was dieses Plugin schreibt, und jeder Kommentar in seinen\n#      Konfigurationsdateien ist deutsch.  ->  lang/DE/\n#\n#  Change this BEFORE you configure anything. Switching later creates\n#  the other folder from scratch - your settings do not move across.\n#\n#  Stelle das um, BEVOR du etwas einrichtest. Ein spaeterer Wechsel legt\n#  den anderen Ordner neu an - deine Einstellungen wandern nicht mit.\n# =====================================================================\nlanguage: EN\n\n# =====================================================================\n#  Menus / Menues\n# =====================================================================\nmenus:\n  #  Hand every menu name, lore line and title to PlaceholderAPI once\n  #  our own %placeholders% are filled in. That is what makes another\n  #  plugin's values - %nexo_ruby%, %vault_eco_balance%,\n  #  %luckperms_prefix% - work in any menu file of this plugin.\n  #  Needs PlaceholderAPI installed; without it this does nothing.\n  #  Costs nothing on lines that hold no percent sign.\n  #\n  #  Uebergibt jeden Menuenamen, jede Lorezeile und jeden Titel an\n  #  PlaceholderAPI, nachdem unsere eigenen %Platzhalter% eingesetzt\n  #  sind. Damit funktionieren fremde Werte in jeder Menuedatei\n  #  dieses Plugins. Ohne PlaceholderAPI passiert nichts.\n  placeholderapi: true\n";

      try {
         Files.writeString(var1.toPath(), str, StandardCharsets.UTF_8);
      } catch (IOException e) {
         var0.getLogger().warning("config.yml liess sich nicht anlegen: " + String.valueOf(e) + " - ich bleibe auf EN.");
      }

   }

   public ConfigFile load(boolean var1, String... var2) {
      this.eigeneAbschnitte = var2 == null ? new String[0] : var2;
      return this.load(var1);
   }

   private static boolean gehoertDemKaeufer(String var0, Set<String> var1) {
      for(String var3 : var1) {
         if (var0.equals(var3) || var0.startsWith(var3 + ".")) {
            return true;
         }
      }

      return false;
   }

   private boolean istBelegt(String var1) {
      if (!this.config.contains(var1)) {
         return false;
      } else {
         ConfigurationSection configurationSection = this.config.getConfigurationSection(var1);
         return configurationSection == null || !configurationSection.getKeys(false).isEmpty();
      }
   }

   private Set<String> vorhandeneEigeneAbschnitte() {
      HashSet hashSet = new HashSet();

      for(String var5 : this.eigeneAbschnitte) {
         if (this.istBelegt(var5)) {
            hashSet.add(var5);
         }
      }

      return hashSet;
   }

   public ConfigFile load(boolean var1) {
      this.holeAlteDatei();
      if (!this.file.exists()) {
         this.file.getParentFile().mkdirs();
         String str = this.quelle();
         if (str != null) {
            this.schreibe(str);
         }
      }

      this.config = new YamlConfiguration();

      try {
         if (this.file.isFile()) {
            this.config.load(this.file);
         }
      } catch (InvalidConfigurationException e) {
         this.kaputt = true;
         this.plugin.getLogger().severe(this.realPath + " has a YAML error and was NOT loaded:");
         this.plugin.getLogger().severe("  " + e.getMessage());
         this.plugin.getLogger().severe("Your file is left untouched - the defaults are NOT written over it. Fix the error and reload.");
         String str = this.quelle();
         if (str != null) {
            try {
               InputStream inputStream = this.plugin.getResource(str);

               try {
                  if (inputStream != null) {
                     this.config.load(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
                  }
               } catch (Throwable t) {
                  if (inputStream != null) {
                     try {
                        inputStream.close();
                     } catch (Throwable t2) {
                        t.addSuppressed(t2);
                     }
                  }

                  throw t;
               }

               if (inputStream != null) {
                  inputStream.close();
               }
            } catch (InvalidConfigurationException | IOException e2) {
            }
         }
      } catch (IOException e) {
         this.kaputt = true;
         Logger logger = this.plugin.getLogger();
         String str = this.realPath;
         logger.severe("Could not read " + str + ": " + String.valueOf(e));
      }

      if (var1 && !this.kaputt) {
         this.ergaenze();
      }

      return this;
   }

   private String quelle() {
      if (this.plugin.getResource(this.realPath) != null) {
         return this.realPath;
      } else {
         String str = "lang/EN/" + this.path;
         if (!this.realPath.equals(str) && this.plugin.getResource(str) != null) {
            String str2 = this.plugin.getName();
            String str3 = str2 + "/" + language(this.plugin);
            if (gewarnt.add(str3)) {
               this.plugin.getLogger().warning("No " + language(this.plugin) + " translation shipped with this plugin - using English. Set language: EN in config.yml to silence this.");
            }

            return str;
         } else {
            return this.plugin.getResource(this.path) != null ? this.path : null;
         }
      }
   }

   private void schreibe(String var1) {
      if (var1.equals(this.realPath)) {
         this.plugin.saveResource(this.realPath, false);
      } else {
         try {
            InputStream inputStream = this.plugin.getResource(var1);

            try {
               if (inputStream != null) {
                  Files.copy(inputStream, this.file.toPath(), new CopyOption[]{StandardCopyOption.REPLACE_EXISTING});
               }
            } catch (Throwable t) {
               if (inputStream != null) {
                  try {
                     inputStream.close();
                  } catch (Throwable t2) {
                     t.addSuppressed(t2);
                  }
               }

               throw t;
            }

            if (inputStream != null) {
               inputStream.close();
            }
         } catch (IOException e) {
            Logger logger = this.plugin.getLogger();
            String str = this.realPath;
            logger.warning(str + " liess sich nicht anlegen: " + String.valueOf(e));
         }

      }
   }

   private void ergaenze() {
      boolean flag = this.ergaenzeAus(this.quelle());
      String str = "lang/EN/" + this.path;
      if (!str.equals(this.quelle())) {
         flag |= this.ergaenzeAus(str);
      }

      Set set = SCHON_GESCHRIEBEN;
      String str2 = this.plugin.getName();
      boolean flag2 = set.add(str2 + "/" + this.realPath);
      if (flag && flag2) {
         this.plugin.getLogger().info("Added new options to " + this.realPath + " (your values were kept).");
         this.save();
      }

   }

   private boolean ergaenzeAus(String var1) {
      if (var1 == null) {
         return false;
      } else {
         InputStream inputStream = this.plugin.getResource(var1);
         if (inputStream == null) {
            return false;
         } else {
            YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration(new InputStreamReader(inputStream, StandardCharsets.UTF_8));
            Set set = this.vorhandeneEigeneAbschnitte();
            boolean flag = false;

            for(String var7 : yamlConfiguration.getKeys(true)) {
               if (!yamlConfiguration.isConfigurationSection(var7) && !this.config.contains(var7) && !gehoertDemKaeufer(var7, set)) {
                  this.config.set(var7, yamlConfiguration.get(var7));
                  this.config.setComments(var7, yamlConfiguration.getComments(var7));
                  flag = true;
               }
            }

            return flag;
         }
      }
   }

   private void holeAlteDatei() {
      if (!this.realPath.equals(this.path)) {
         File file = new File(this.plugin.getDataFolder(), this.path);
         if (file.isFile()) {
            File file2 = new File(this.plugin.getDataFolder(), "lang/EN/" + this.path);
            if (file2.exists()) {
               Set set = SCHON_GEMELDET;
               String str = this.plugin.getName();
               if (set.add(str + "/" + this.path)) {
                  this.plugin.getLogger().warning(this.path + " in the plugin folder is NOT read any more. Edit " + this.realPath + " instead - your changes there are ignored.");
               }

            } else {
               try {
                  file2.getParentFile().mkdirs();
                  Files.move(file.toPath(), file2.toPath(), StandardCopyOption.ATOMIC_MOVE);
                  this.plugin.getLogger().info("Moved " + this.path + " to lang/EN/" + this.path + " - that is where anything with text in it lives now.");
                  if (!"EN".equals(language(this.plugin))) {
                     Logger logger = this.plugin.getLogger();
                     String str = language(this.plugin);
                     logger.warning("You run language: " + str + ", so " + this.realPath + " was created fresh from the plugin. Anything you had changed is kept in lang/EN/" + this.path + " - copy it across if you need it.");
                  }
               } catch (IOException e) {
                  Logger logger = this.plugin.getLogger();
                  String str = this.path;
                  logger.warning("Could not move " + str + ": " + String.valueOf(e) + " - starting from the packaged defaults.");
               }

            }
         }
      }
   }

   public YamlConfiguration yaml() {
      if (this.config == null) {
         throw new IllegalStateException("load() zuerst aufrufen: " + this.realPath);
      } else {
         return this.config;
      }
   }

   public void save() {
      if (this.kaputt) {
         this.plugin.getLogger().warning("Not writing " + this.realPath + " - it has a YAML error and your version would be lost.");
      } else {
         try {
            this.file.getParentFile().mkdirs();
            this.config.save(this.file);
         } catch (IOException e) {
            Logger logger = this.plugin.getLogger();
            String str = this.realPath;
            logger.warning("Konnte " + str + " nicht schreiben: " + String.valueOf(e));
         }

      }
   }

   public File file() {
      return this.file;
   }

   public String path() {
      return this.path;
   }

   public String realPath() {
      return this.realPath;
   }
}
