package me.nothing.smpcore.systems.voucher;

import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

public final class ChatPrompt implements Listener {
   private final Plugin plugin;
   private final Map<UUID, Pending> waiting = new ConcurrentHashMap();
   private List<String> cancelWords = List.of("cancel");
   private long timeoutMillis = 60000L;

   public ChatPrompt(Plugin plugin) {
      this.plugin = plugin;
   }

   public void configure(List<String> list, int i) {
      if (list != null && !list.isEmpty()) {
         this.cancelWords = list.stream().map((var0) -> var0.toLowerCase(Locale.ROOT)).toList();
      }

      this.timeoutMillis = (long)Math.max(5, i) * 1000L;
   }

   public String cancelWord() {
      return (String)this.cancelWords.get(0);
   }

   public void ask(Player player, Consumer<String> consumer) {
      this.waiting.put(player.getUniqueId(), new Pending(consumer, System.currentTimeMillis() + this.timeoutMillis));
   }

   public void forget(UUID uUID) {
      this.waiting.remove(uUID);
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onChat(AsyncPlayerChatEvent asyncPlayerChatEvent) {
      UUID uUID = asyncPlayerChatEvent.getPlayer().getUniqueId();
      Pending pending = (Pending)this.waiting.get(uUID);
      if (pending != null) {
         this.waiting.remove(uUID);
         if (System.currentTimeMillis() <= pending.expiresAt()) {
            asyncPlayerChatEvent.setCancelled(true);
            String str = asyncPlayerChatEvent.getMessage().trim();
            boolean flag = this.cancelWords.contains(str.toLowerCase(Locale.ROOT));
            Player player = asyncPlayerChatEvent.getPlayer();
            Scheduler.atEntity(this.plugin, player, () -> pending.handler().accept(flag ? null : str));
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent playerQuitEvent) {
      this.waiting.remove(playerQuitEvent.getPlayer().getUniqueId());
   }

   private static record Pending(Consumer<String> handler, long expiresAt) {
   }
}
