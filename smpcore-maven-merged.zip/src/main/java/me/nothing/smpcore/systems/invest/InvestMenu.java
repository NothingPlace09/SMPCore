package me.nothing.smpcore.systems.invest;

import java.util.Locale;
import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.gui.ItemSpec;
import me.nothing.smpcore.systems.smpcorelib.gui.Menu;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public final class InvestMenu extends Menu {
   private final InvestPlugin plugin;
   private final MenuConfig config;

   public InvestMenu(Player player, InvestPlugin investPlugin) {
      super(player);
      this.plugin = investPlugin;
      this.config = investPlugin.investMenu();
   }

   protected String title() {
      return Text.apply(this.config.title(), this.values());
   }

   protected int rows() {
      return this.config.rows();
   }

   private Map<String, String> values() {
      Map map = this.plugin.values(this.viewer);
      boolean flag = this.plugin.store().get(this.viewer.getUniqueId()).autoCollect();
      map.put("status", this.plugin.investMenuFile().yaml().getString(flag ? "status.switched-on" : "status.switched-off", ""));
      return map;
   }

   protected void draw() {
      Map map = this.values();
      this.config.render(this.getInventory(), map);
      if (!this.plugin.mayAutoCollect(this.viewer)) {
         this.hide("autocollect");
      } else {
         this.drawToggle(map);
      }
   }

   private void drawToggle(Map<String, String> map) {
      ItemSpec itemSpec = this.config.item("autocollect");
      if (itemSpec != null) {
         boolean flag = this.plugin.store().get(this.viewer.getUniqueId()).autoCollect();
         Material material = flag ? this.onMaterial() : null;

         for(int var6 : this.config.slotsOfAction("autocollect")) {
            if (var6 >= 0 && var6 < this.getInventory().getSize()) {
               this.getInventory().setItem(var6, itemSpec.build(map, (String)null, material));
            }
         }

      }
   }

   private Material onMaterial() {
      ConfigurationSection configurationSection = this.plugin.investMenuFile().yaml().getConfigurationSection("items");
      if (configurationSection == null) {
         return null;
      } else {
         for(String var3 : configurationSection.getKeys(false)) {
            ConfigurationSection configurationSection2 = configurationSection.getConfigurationSection(var3);
            if (configurationSection2 != null && "autocollect".equalsIgnoreCase(configurationSection2.getString("action", ""))) {
               String str = configurationSection2.getString("material-on", "");
               if (str != null && !str.isEmpty()) {
                  try {
                     return Material.valueOf(str.trim().toUpperCase(Locale.ROOT));
                  } catch (IllegalArgumentException e) {
                     this.plugin.getLogger().warning("menu-invest.yml: material-on names " + str + ", which this server does not have.");
                     return null;
                  }
               }

               return null;
            }
         }

         return null;
      }
   }

   private void hide(String str) {
      ItemSpec itemSpec = this.config.item("filler");

      for(int var4 : this.config.slotsOfAction(str)) {
         if (var4 >= 0 && var4 < this.getInventory().getSize()) {
            ItemStack itemStack = itemSpec == null ? null : itemSpec.build();
            this.getInventory().setItem(var4, itemStack != null && itemStack.getType().isAir() ? null : itemStack);
         }
      }

   }

   protected void onClick(InventoryClickEvent inventoryClickEvent) {
      if (this.clickedTopInventory(inventoryClickEvent)) {
         String str = this.config.actionAt(inventoryClickEvent.getSlot());
         if (str != null) {
            switch (str) {
               case "invest":
                  (new ConfirmMenu(this.viewer, this.plugin, ConfirmMenu.Mode.INVEST)).open();
                  break;
               case "delete":
                  (new ConfirmMenu(this.viewer, this.plugin, ConfirmMenu.Mode.DELETE)).open();
                  break;
               case "collect":
                  this.plugin.collect(this.viewer);
                  this.refresh();
                  break;
               case "autocollect":
                  this.plugin.toggleAutoCollect(this.viewer);
                  this.refresh();
                  break;
               case "refresh":
                  this.refresh();
                  break;
               case "close":
                  this.viewer.closeInventory();
            }

         }
      }
   }
}
