package me.nothing.smpcore.systems.voucher;

import java.util.Locale;

public record VoucherTag(String id, String serial, long issued, long expires) {
   public boolean timed() {
      return this.expires > 0L;
   }

   public boolean expired(long l) {
      return this.expires > 0L && l >= this.expires;
   }

   public long secondsLeft(long l) {
      return this.expires <= 0L ? -1L : Math.max(0L, (this.expires - l) / 1000L);
   }

   public String shortSerial() {
      String str = this.serial.replace("-", "");
      return str.length() <= 8 ? str.toUpperCase(Locale.ROOT) : str.substring(0, 8).toUpperCase(Locale.ROOT);
   }
}
