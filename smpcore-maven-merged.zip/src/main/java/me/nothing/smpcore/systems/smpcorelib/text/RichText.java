package me.nothing.smpcore.systems.smpcorelib.text;

import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.BaseComponent;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import net.md_5.bungee.api.chat.ClickEvent.Action;
import net.md_5.bungee.api.chat.hover.content.Content;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

final class RichText {
   private RichText() {
   }

   static void actionBar(Player player, String str) {
      player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(str));
   }

   static void clickable(CommandSender commandSender, String str, String str2, String str3, boolean flag) {
      BaseComponent[] baseComponentArr = TextComponent.fromLegacyText(str);

      for(BaseComponent var9 : baseComponentArr) {
         if (str2 != null && !str2.isEmpty()) {
            var9.setClickEvent(new ClickEvent(flag ? Action.OPEN_URL : Action.RUN_COMMAND, !flag && !str2.startsWith("/") ? "/" + str2 : str2));
         }

         if (str3 != null && !str3.isEmpty()) {
            var9.setHoverEvent(new HoverEvent(net.md_5.bungee.api.chat.HoverEvent.Action.SHOW_TEXT, new Content[]{new net.md_5.bungee.api.chat.hover.content.Text(TextComponent.fromLegacyText(str3))}));
         }
      }

      if (commandSender instanceof Player player) {
         player.spigot().sendMessage(baseComponentArr);
      } else {
         commandSender.sendMessage(TextComponent.toLegacyText(baseComponentArr));
      }

   }
}
