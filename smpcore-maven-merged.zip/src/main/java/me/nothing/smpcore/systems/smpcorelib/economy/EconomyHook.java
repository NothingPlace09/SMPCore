package me.nothing.smpcore.systems.smpcorelib.economy;

import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class EconomyHook {
   private final Plugin plugin;
   private Economy economy;
   private static final DecimalFormatSymbols SYMBOLS;
   private static volatile int nachkomma;

   public EconomyHook(Plugin plugin) {
      this.plugin = plugin;
   }

   public void hook() {
      if (this.plugin.getServer().getPluginManager().getPlugin("Vault") == null) {
         this.plugin.getLogger().warning("Vault not found - selling is disabled until an economy is installed.");
      } else {
         this.resolve();
      }
   }

   private void resolve() {
      if (this.economy == null) {
         if (this.plugin.getServer().getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider registeredServiceProvider = this.plugin.getServer().getServicesManager().getRegistration(Economy.class);
            if (registeredServiceProvider != null) {
               this.economy = (Economy)registeredServiceProvider.getProvider();
               this.plugin.getLogger().info("Economy hooked: " + this.economy.getName());
            }

         }
      }
   }

   public boolean available() {
      this.resolve();
      return this.economy != null;
   }

   public double balance(OfflinePlayer offlinePlayer) {
      return this.available() ? this.economy.getBalance(offlinePlayer) : (double)0.0F;
   }

   public boolean deposit(OfflinePlayer offlinePlayer, double d) {
      return this.available() && !(d <= (double)0.0F) ? this.economy.depositPlayer(offlinePlayer, d).transactionSuccess() : false;
   }

   public boolean withdraw(OfflinePlayer offlinePlayer, double d) {
      if (this.available() && !(d <= (double)0.0F)) {
         return this.economy.getBalance(offlinePlayer) < d ? false : this.economy.withdrawPlayer(offlinePlayer, d).transactionSuccess();
      } else {
         return false;
      }
   }

   public static String format(double value) {
      double d = Math.abs(value);
      if (d >= 1.0E12) {
         return trim(d / 1.0E12) + "T";
      } else if (d >= (double)1.0E9F) {
         return trim(d / (double)1.0E9F) + "B";
      } else if (d >= (double)1000000.0F) {
         return trim(d / (double)1000000.0F) + "M";
      } else {
         return d >= (double)1000.0F ? trim(d / (double)1000.0F) + "K" : muster(nachkomma).format(d);
      }
   }

   public static void nachkomma(int i) {
      nachkomma = Math.max(0, Math.min(4, i));
   }

   public static int nachkomma() {
      return nachkomma;
   }

   private static DecimalFormat muster(int i) {
      StringBuilder stringBuilder = new StringBuilder("#,##0");
      if (i > 0) {
         stringBuilder.append('.').append("0".repeat(i));
      }

      DecimalFormat decimalFormat = new DecimalFormat(stringBuilder.toString(), SYMBOLS);
      decimalFormat.setRoundingMode(RoundingMode.DOWN);
      return decimalFormat;
   }

   private static String trim(double d) {
      DecimalFormat decimalFormat = new DecimalFormat("#,##0.##", SYMBOLS);
      decimalFormat.setRoundingMode(RoundingMode.DOWN);
      return decimalFormat.format(d);
   }

   public static String formatExact(double d) {
      return (new DecimalFormat("#,##0", SYMBOLS)).format(d);
   }

   public static double parseAmount(String input) {
      if (input == null) {
         return (double)0.0F;
      } else {
         String str = input.toLowerCase().replace(",", "").replace("$", "").trim();
         double d = (double)1.0F;
         if (str.endsWith("k")) {
            d = (double)1000.0F;
         } else if (str.endsWith("m")) {
            d = (double)1000000.0F;
         } else if (str.endsWith("b")) {
            d = (double)1.0E9F;
         } else if (str.endsWith("t")) {
            d = 1.0E12;
         }

         if (d > (double)1.0F) {
            str = str.substring(0, str.length() - 1);
         }

         try {
            return Math.max((double)0.0F, Double.parseDouble(str) * d);
         } catch (NumberFormatException e) {
            return (double)0.0F;
         }
      }
   }

   static {
      SYMBOLS = DecimalFormatSymbols.getInstance(Locale.ROOT);
   }
}
