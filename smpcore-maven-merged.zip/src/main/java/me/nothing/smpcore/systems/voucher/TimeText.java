package me.nothing.smpcore.systems.voucher;

import java.util.HashMap;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.configuration.ConfigurationSection;

public final class TimeText {
   private final String days;
   private final String hours;
   private final String minutes;
   private final String seconds;
   private final String none;
   private static final Pattern CHUNK = Pattern.compile("(\\d+)\\s*([smhdw])");

   public TimeText(ConfigurationSection configurationSection) {
      this.days = read(configurationSection, "days", "%d%d %h%h");
      this.hours = read(configurationSection, "hours", "%h%h %m%m");
      this.minutes = read(configurationSection, "minutes", "%m%m %s%s");
      this.seconds = read(configurationSection, "seconds", "%s%s");
      this.none = read(configurationSection, "none", "-");
   }

   private static String read(ConfigurationSection configurationSection, String str, String str2) {
      return configurationSection == null ? str2 : configurationSection.getString(str, str2);
   }

   public String format(long total) {
      if (total < 0L) {
         return this.none;
      } else {
         long l = total / 86400L;
         long l2 = total % 86400L / 3600L;
         long l3 = total % 3600L / 60L;
         long l4 = total % 60L;
         String str = l > 0L ? this.days : (l2 > 0L ? this.hours : (l3 > 0L ? this.minutes : this.seconds));
         HashMap hashMap = new HashMap(12);
         hashMap.put("d", String.valueOf(l));
         hashMap.put("h", String.valueOf(l2));
         hashMap.put("m", String.valueOf(l3));
         hashMap.put("s", String.valueOf(l4));
         hashMap.put("dd", pad(l));
         hashMap.put("hh", pad(l2));
         hashMap.put("mm", pad(l3));
         hashMap.put("ss", pad(l4));
         return Text.apply(str, hashMap);
      }
   }

   public String none() {
      return this.none;
   }

   private static String pad(long l) {
      return l < 10L ? "0" + l : String.valueOf(l);
   }

   public static long parse(String input) {
      if (input == null) {
         return 0L;
      } else {
         String str = input.trim().toLowerCase(Locale.ROOT);
         if (!str.isEmpty() && !str.equals("never") && !str.equals("none") && !str.equals("nie")) {
            Matcher matcher = CHUNK.matcher(str);
            long l = 0L;

            boolean flag;
            long l2;
            for(flag = false; matcher.find(); l += l2) {
               flag = true;
               long l3 = Long.parseLong(matcher.group(1));
               switch (matcher.group(2).charAt(0)) {
                  case 'd':
                     l2 = l3 * 86400L;
                     break;
                  case 'h':
                     l2 = l3 * 3600L;
                     break;
                  case 'm':
                     l2 = l3 * 60L;
                     break;
                  case 's':
                     l2 = l3;
                     break;
                  case 'w':
                     l2 = l3 * 604800L;
                     break;
                  default:
                     l2 = 0L;
               }
            }

            if (!flag) {
               try {
                  l = Long.parseLong(str);
               } catch (NumberFormatException e) {
                  return 0L;
               }
            }

            return Math.max(0L, l) * 1000L;
         } else {
            return 0L;
         }
      }
   }
}
