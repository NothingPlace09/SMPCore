package me.nothing.smpcore.systems.smpcorelib.item;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.net.URI;
import java.net.URL;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.MemoryConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ArmorMeta;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.inventory.meta.trim.ArmorTrim;
import org.bukkit.inventory.meta.trim.TrimMaterial;
import org.bukkit.inventory.meta.trim.TrimPattern;
import org.bukkit.potion.PotionType;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

public final class Items {
   private static final Method PAPER_READER = findPaperReader();

   private Items() {
   }

   public static ItemStack read(ConfigurationSection configurationSection, Logger logger, Map<String, String> map) {
      if (configurationSection == null) {
         return null;
      } else {
         String str = configurationSection.getString("base64", "");
         if (!str.isEmpty()) {
            ItemStack itemStack = decodeExact(str);
            if (itemStack != null) {
               if (configurationSection.isInt("amount")) {
                  itemStack.setAmount(Math.max(1, configurationSection.getInt("amount")));
               }

               return itemStack;
            }

            logger.warning("Unreadable base64 at " + configurationSection.getCurrentPath() + " - using the readable keys next to it instead.");
         }

         String str2 = configurationSection.getString("material", "");
         Material material = Material.matchMaterial(str2.toUpperCase());
         if (material != null && !material.isAir()) {
            ItemStack itemStack = new ItemStack(material, Math.max(1, configurationSection.getInt("amount", 1)));
            ItemMeta itemMeta = itemStack.getItemMeta();
            if (itemMeta == null) {
               return itemStack;
            } else {
               String str3 = configurationSection.getString("name", "");
               if (!str3.isEmpty()) {
                  itemMeta.setDisplayName(Text.item(Text.apply(str3, map)));
               }

               List list = configurationSection.getStringList("lore");
               if (!list.isEmpty()) {
                  itemMeta.setLore(Text.lore(Text.apply(list, map)));
               }

               int i = configurationSection.getInt("custom-model-data", -1);
               if (i >= 0) {
                  itemMeta.setCustomModelData(i);
               }

               if (configurationSection.getBoolean("unbreakable", false)) {
                  itemMeta.setUnbreakable(true);
               }

               applyTrim(itemMeta, configurationSection, logger);

               for(String var12 : configurationSection.getStringList("enchantments")) {
                  applyEnchantment(itemMeta, var12, configurationSection.getCurrentPath(), logger);
               }

               if (configurationSection.getBoolean("glow", false) && itemMeta.getEnchants().isEmpty()) {
                  itemMeta.addEnchant(Enchantment.UNBREAKING, 1, true);
                  itemMeta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
               }

               String str4 = configurationSection.getString("potion", "");
               if (!str4.isEmpty() && itemMeta instanceof PotionMeta) {
                  PotionMeta potionMeta = (PotionMeta)itemMeta;

                  try {
                     potionMeta.setBasePotionType(PotionType.valueOf(str4.toUpperCase(Locale.ROOT)));
                  } catch (IllegalArgumentException e) {
                     logger.warning("Unknown potion type '" + str4 + "' at " + configurationSection.getCurrentPath() + " - the item stays a water bottle.");
                  }
               }

               int i2 = configurationSection.getInt("flight", -1);
               if (i2 >= 0 && itemMeta instanceof FireworkMeta) {
                  FireworkMeta fireworkMeta = (FireworkMeta)itemMeta;
                  int i3 = Math.max(0, Math.min(3, i2));
                  if (i3 != i2) {
                     logger.warning("flight " + i2 + " at " + configurationSection.getCurrentPath() + " is outside 0-3 - using " + i3 + ".");
                  }

                  fireworkMeta.setPower(i3);
               }

               if (configurationSection.getBoolean("hide-attributes", false)) {
                  itemMeta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ADDITIONAL_TOOLTIP});
               }

               String str5 = configurationSection.getString("head-texture", "");
               if (itemMeta instanceof SkullMeta) {
                  SkullMeta skullMeta = (SkullMeta)itemMeta;
                  if (!str5.isEmpty()) {
                     applyHeadTexture(skullMeta, str5);
                  }
               }

               itemStack.setItemMeta(itemMeta);
               return itemStack;
            }
         } else {
            logger.warning("Unknown material '" + str2 + "' at " + configurationSection.getCurrentPath() + " - this entry was skipped.");
            return null;
         }
      }
   }

   public static String encodeExact(ItemStack itemStack) {
      if (itemStack != null && !itemStack.getType().isAir()) {
         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

         try {
            BukkitObjectOutputStream bukkitObjectOutputStream = new BukkitObjectOutputStream(byteArrayOutputStream);

            try {
               bukkitObjectOutputStream.writeObject(itemStack);
            } catch (Throwable t) {
               try {
                  bukkitObjectOutputStream.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }

               throw t;
            }

            bukkitObjectOutputStream.close();
            return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
         } catch (Exception e) {
            return "";
         }
      } else {
         return "";
      }
   }

   public static ItemStack decodeExact(String str) {
      if (str != null && !str.isEmpty()) {
         byte[] bArr;
         try {
            bArr = Base64.getDecoder().decode(str.trim());
         } catch (IllegalArgumentException e) {
            return null;
         }

         try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);

            label63: {
               ItemStack itemStack;
               try {
                  BukkitObjectInputStream bukkitObjectInputStream = new BukkitObjectInputStream(byteArrayInputStream);

                  label59: {
                     try {
                        Object obj = bukkitObjectInputStream.readObject();
                        if (obj instanceof ItemStack) {
                           ItemStack itemStack2 = (ItemStack)obj;
                           if (!itemStack2.getType().isAir()) {
                              itemStack = itemStack2;
                              break label59;
                           }
                        }
                     } catch (Throwable t) {
                        try {
                           bukkitObjectInputStream.close();
                        } catch (Throwable t2) {
                           t.addSuppressed(t2);
                        }

                        throw t;
                     }

                     bukkitObjectInputStream.close();
                     break label63;
                  }

                  bukkitObjectInputStream.close();
               } catch (Throwable t) {
                  try {
                     byteArrayInputStream.close();
                  } catch (Throwable t2) {
                     t.addSuppressed(t2);
                  }

                  throw t;
               }

               byteArrayInputStream.close();
               return itemStack;
            }

            byteArrayInputStream.close();
         } catch (Exception e) {
         }

         return paperBytes(bArr);
      } else {
         return null;
      }
   }

   private static Method findPaperReader() {
      try {
         return ItemStack.class.getMethod("deserializeBytes", byte[].class);
      } catch (NoSuchMethodException e) {
         return null;
      }
   }

   private static ItemStack paperBytes(byte[] bArr) {
      if (PAPER_READER == null) {
         return null;
      } else {
         try {
            Object obj = PAPER_READER.invoke((Object)null, bArr);
            ItemStack itemStack;
            if (obj instanceof ItemStack) {
               ItemStack itemStack2 = (ItemStack)obj;
               if (!itemStack2.getType().isAir()) {
                  itemStack = itemStack2;
                  return itemStack;
               }
            }

            itemStack = null;
            return itemStack;
         } catch (RuntimeException | ReflectiveOperationException e) {
            return null;
         }
      }
   }

   public static List<ItemStack> readList(ConfigurationSection configurationSection, String str, Logger logger) {
      ArrayList arrayList = new ArrayList();
      if (configurationSection.isList(str)) {
         for(Map var10 : configurationSection.getMapList(str)) {
            MemoryConfiguration memoryConfiguration = new MemoryConfiguration();
            ConfigurationSection configurationSection = memoryConfiguration.createSection("item", var10);
            ItemStack itemStack = read(configurationSection, logger, Map.of());
            if (itemStack != null) {
               arrayList.add(itemStack);
            }
         }

         return arrayList;
      } else {
         ConfigurationSection configurationSection = configurationSection.getConfigurationSection(str);
         if (configurationSection != null) {
            for(String var6 : configurationSection.getKeys(false)) {
               ItemStack itemStack = read(configurationSection.getConfigurationSection(var6), logger, Map.of());
               if (itemStack != null) {
                  arrayList.add(itemStack);
               }
            }
         }

         return arrayList;
      }
   }

   private static void applyTrim(ItemMeta itemMeta, ConfigurationSection configurationSection, Logger logger) {
      ConfigurationSection configurationSection = configurationSection.getConfigurationSection("trim");
      if (configurationSection != null && itemMeta instanceof ArmorMeta armorMeta) {
         String str = configurationSection.getString("pattern", "");
         String str2 = configurationSection.getString("material", "");
         if (!str.isEmpty() && !str2.isEmpty()) {
            TrimPattern trimPattern = (TrimPattern)Registry.TRIM_PATTERN.get(NamespacedKey.minecraft(str.toLowerCase(Locale.ROOT)));
            TrimMaterial trimMaterial = (TrimMaterial)Registry.TRIM_MATERIAL.get(NamespacedKey.minecraft(str2.toLowerCase(Locale.ROOT)));
            if (trimPattern != null && trimMaterial != null) {
               armorMeta.setTrim(new ArmorTrim(trimMaterial, trimPattern));
            } else {
               logger.warning("Unknown armour trim '" + str + "/" + str2 + "' at " + configurationSection.getCurrentPath() + " - the item was made without a trim.");
            }
         }
      }
   }

   private static void applyEnchantment(ItemMeta itemMeta, String spec, String str2, Logger logger) {
      String[] strArr = spec.split(":");
      String str = strArr[0].trim().toLowerCase();
      int i = 1;
      if (strArr.length > 1) {
         try {
            i = Math.max(1, Integer.parseInt(strArr[1].trim()));
         } catch (NumberFormatException e) {
         }
      }

      Enchantment enchantment = null;

      try {
         NamespacedKey namespacedKey = str.contains(":") ? NamespacedKey.fromString(str) : NamespacedKey.minecraft(str);
         if (namespacedKey != null) {
            enchantment = (Enchantment)Registry.ENCHANTMENT.get(namespacedKey);
         }
      } catch (Exception e) {
      }

      if (enchantment == null) {
         logger.warning("Unknown enchantment '" + str + "' at " + str2 + " - the item is given without it.");
      } else {
         itemMeta.addEnchant(enchantment, i, true);
      }
   }

   private static void applyHeadTexture(SkullMeta skullMeta, String str) {
      try {
         PlayerProfile playerProfile = Bukkit.createPlayerProfile(UUID.randomUUID(), "");
         PlayerTextures playerTextures = playerProfile.getTextures();
         URL uRL = URI.create(str.startsWith("http") ? str : "https://textures.minecraft.net/texture/" + str).toURL();
         playerTextures.setSkin(uRL);
         playerProfile.setTextures(playerTextures);
         skullMeta.setOwnerProfile(playerProfile);
      } catch (Exception e) {
      }

   }

   public static void give(Player player, ItemStack itemStack) {
      int i = itemStack.getAmount();
      int i2 = Math.max(1, itemStack.getMaxStackSize());

      while(i > 0) {
         ItemStack itemStack = itemStack.clone();
         itemStack.setAmount(Math.min(i, i2));
         i -= itemStack.getAmount();

         for(ItemStack var6 : player.getInventory().addItem(new ItemStack[]{itemStack}).values()) {
            player.getWorld().dropItemNaturally(player.getLocation(), var6);
         }
      }

   }

   public static int freeSlots(Player player) {
      int i = 0;

      for(ItemStack var5 : player.getInventory().getStorageContents()) {
         if (var5 == null || var5.getType().isAir()) {
            ++i;
         }
      }

      return i;
   }

   public static List<String> lines(List<String> list, Map<String, String> map) {
      return new ArrayList(Text.apply(list, map));
   }
}
