package me.nothing.smpcore.systems.smpcorelib.sound;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public final class Sounds {
   private final Map<String, Cue> cues = new HashMap();

   public Sounds(ConfigurationSection configurationSection) {
      this.reload(configurationSection);
   }

   public void reload(ConfigurationSection configurationSection) {
      this.cues.clear();
      if (configurationSection != null) {
         for(String var3 : configurationSection.getKeys(false)) {
            ConfigurationSection configurationSection = configurationSection.getConfigurationSection(var3);
            if (configurationSection != null) {
               String str = configurationSection.getString("sound", "");
               if (str != null && !str.isEmpty()) {
                  this.cues.put(var3, new Cue(str, (float)configurationSection.getDouble("volume", (double)1.0F), (float)configurationSection.getDouble("pitch", (double)1.0F)));
               }
            }
         }

      }
   }

   public void play(Player player, String str) {
      Cue cue = (Cue)this.cues.get(str);
      if (cue != null && player != null) {
         player.playSound(player.getLocation(), cue.key(), cue.volume(), cue.pitch());
      }
   }

   private static record Cue(String key, float volume, float pitch) {
   }
}
