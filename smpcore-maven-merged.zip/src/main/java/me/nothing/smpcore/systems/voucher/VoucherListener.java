package me.nothing.smpcore.systems.voucher;

import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.PrepareAnvilEvent;
import org.bukkit.event.inventory.PrepareItemCraftEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;

public final class VoucherListener implements Listener {
   private final VoucherPlugin plugin;

   public VoucherListener(VoucherPlugin voucherPlugin) {
      this.plugin = voucherPlugin;
   }

   @EventHandler(
      priority = EventPriority.NORMAL,
      ignoreCancelled = true
   )
   public void onInteract(PlayerInteractEvent playerInteractEvent) {
      Action action = playerInteractEvent.getAction();
      if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
         if (playerInteractEvent.getHand() != null) {
            Player player = playerInteractEvent.getPlayer();
            ItemStack itemStack = playerInteractEvent.getItem();
            VoucherTag voucherTag = this.plugin.tags().read(itemStack);
            if (voucherTag != null) {
               if (action == Action.RIGHT_CLICK_BLOCK && !player.isSneaking()) {
                  Block block = playerInteractEvent.getClickedBlock();
                  if (block != null && block.getType().isInteractable()) {
                     return;
                  }
               }

               playerInteractEvent.setCancelled(true);
               VoucherDef voucherDef = this.plugin.voucher(voucherTag.id());
               Redeemer.Result result = this.plugin.redeemer().check(player, voucherTag, voucherDef);
               if (!result.ok()) {
                  this.plugin.explain(player, result, voucherDef, voucherTag);
               } else if (voucherDef.confirm(this.plugin.confirmDefault())) {
                  (new ConfirmMenu(this.plugin, player, voucherTag)).open();
                  this.plugin.playSound(player, "menu-open");
               } else {
                  Redeemer.Result result2 = this.plugin.redeemer().redeem(player, voucherTag);
                  if (!result2.ok()) {
                     this.plugin.explain(player, result2, voucherDef, voucherTag);
                  }

               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onCraft(PrepareItemCraftEvent prepareItemCraftEvent) {
      if (this.plugin.config().yaml().getBoolean("security.block-crafting", true)) {
         for(ItemStack var5 : prepareItemCraftEvent.getInventory().getMatrix()) {
            if (this.plugin.tags().isVoucher(var5)) {
               prepareItemCraftEvent.getInventory().setResult((ItemStack)null);
               return;
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onAnvil(PrepareAnvilEvent prepareAnvilEvent) {
      if (this.plugin.config().yaml().getBoolean("security.block-anvil", true)) {
         if (this.plugin.tags().isVoucher(prepareAnvilEvent.getInventory().getItem(0)) || this.plugin.tags().isVoucher(prepareAnvilEvent.getInventory().getItem(1))) {
            prepareAnvilEvent.setResult((ItemStack)null);
         }

      }
   }
}
