package me.nothing.smpcore.systems.voucher;

import java.util.HashMap;
import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.gui.Menu;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public final class ConfirmMenu extends Menu {
   private final VoucherPlugin plugin;
   private final MenuConfig config;
   private final VoucherTag tag;
   private final long openedAt = System.currentTimeMillis();
   private boolean settled;

   public ConfirmMenu(VoucherPlugin voucherPlugin, Player player, VoucherTag voucherTag) {
      super(player);
      this.plugin = voucherPlugin;
      this.config = voucherPlugin.confirmMenuConfig();
      this.tag = voucherTag;
   }

   protected String title() {
      return Text.apply(this.config.title(), this.values());
   }

   protected int rows() {
      return this.config.rows();
   }

   private Map<String, String> values() {
      VoucherDef voucherDef = this.plugin.voucher(this.tag.id());
      HashMap hashMap = voucherDef == null ? new HashMap(Map.of("voucher", this.tag.id(), "voucher_id", this.tag.id())) : new HashMap(this.plugin.display(voucherDef, this.tag));
      hashMap.put("player", this.viewer.getName());
      return hashMap;
   }

   protected void draw() {
      VoucherDef voucherDef = this.plugin.voucher(this.tag.id());
      if (voucherDef != null) {
         Map map = this.values();
         this.config.render(this.getInventory(), map);
         ItemStack itemStack = this.plugin.redeemer().copyOf(this.viewer, this.tag.serial());
         if (itemStack == null) {
            itemStack = this.plugin.preview(voucherDef);
         }

         for(int var5 : this.config.slotsOfAction("display")) {
            this.getInventory().setItem(var5, itemStack.clone());
         }

      }
   }

   protected void onClick(InventoryClickEvent inventoryClickEvent) {
      if (this.clickedTopInventory(inventoryClickEvent) && !this.settled) {
         String str = this.config.actionAt(inventoryClickEvent.getSlot());
         if (str != null) {
            switch (str) {
               case "cancel":
                  this.settled = true;
                  this.viewer.closeInventory();
                  this.plugin.message(this.viewer, "voucher-cancelled", this.values());
                  this.plugin.playSound(this.viewer, "cancel");
                  break;
               case "confirm":
                  this.confirm();
            }

         }
      }
   }

   private void confirm() {
      if (System.currentTimeMillis() - this.openedAt >= this.plugin.config().yaml().getLong("redeem.confirm-click-delay-millis", 300L)) {
         this.settled = true;
         this.viewer.closeInventory();
         VoucherDef voucherDef = this.plugin.voucher(this.tag.id());
         Redeemer.Result result = this.plugin.redeemer().redeem(this.viewer, this.tag);
         if (!result.ok()) {
            this.plugin.explain(this.viewer, result, voucherDef, this.tag);
         }

      }
   }
}
