package me.nothing.smpcore.systems.voucher;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import me.nothing.smpcore.systems.smpcorelib.item.Items;
import me.nothing.smpcore.systems.smpcorelib.platform.Players;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;

public final class Redeemer {
   private final VoucherPlugin plugin;

   public Redeemer(VoucherPlugin voucherPlugin) {
      this.plugin = voucherPlugin;
   }

   public Result check(Player player, VoucherTag voucherTag, VoucherDef voucherDef) {
      if (voucherDef == null) {
         return Redeemer.Result.UNKNOWN;
      } else if (!voucherDef.enabled()) {
         return Redeemer.Result.DISABLED;
      } else if (!this.plugin.allowed(player, this.plugin.usePermission())) {
         return Redeemer.Result.NO_PERMISSION;
      } else if (!voucherDef.permission().isEmpty() && !player.hasPermission(voucherDef.permission())) {
         return Redeemer.Result.NO_PERMISSION;
      } else if (voucherTag.expired(System.currentTimeMillis())) {
         return Redeemer.Result.EXPIRED;
      } else if (this.plugin.blockedWorld(player.getWorld().getName())) {
         return Redeemer.Result.BLOCKED_WORLD;
      } else if (voucherDef.maxPerPlayer() >= 0 && this.plugin.ledger().count(player.getUniqueId(), voucherDef.id()) >= voucherDef.maxPerPlayer()) {
         return Redeemer.Result.LIMIT;
      } else {
         if (voucherDef.cooldownMillis() > 0L) {
            long l = this.plugin.ledger().last(player.getUniqueId(), voucherDef.id());
            if (l > 0L && System.currentTimeMillis() - l < voucherDef.cooldownMillis()) {
               return Redeemer.Result.COOLDOWN;
            }
         }

         return this.plugin.requireFreeSlots() && !this.hasRoom(player, voucherDef) ? Redeemer.Result.FULL : Redeemer.Result.OK;
      }
   }

   private boolean hasRoom(Player player, VoucherDef voucherDef) {
      int i = voucherDef.neededSlots();
      return i <= 0 || Items.freeSlots(player) + 1 >= i;
   }

   public long cooldownLeft(Player player, VoucherDef voucherDef) {
      long l = this.plugin.ledger().last(player.getUniqueId(), voucherDef.id());
      long l2 = voucherDef.cooldownMillis() - (System.currentTimeMillis() - l);
      return Math.max(0L, l2 / 1000L);
   }

   public Result redeem(Player player, VoucherTag voucherTag) {
      VoucherDef voucherDef = this.plugin.voucher(voucherTag.id());
      Result result = this.check(player, voucherTag, voucherDef);
      if (!result.ok()) {
         return result;
      } else {
         PlayerInventory playerInventory = player.getInventory();
         int i = this.findSerial(playerInventory, voucherTag.serial());
         if (i < 0) {
            return Redeemer.Result.GONE;
         } else if (!this.plugin.ledger().claim(voucherTag.serial())) {
            return Redeemer.Result.ALREADY;
         } else {
            ItemStack itemStack = playerInventory.getItem(i);
            VoucherTag held = this.plugin.tags().read(itemStack);
            if (held != null && held.serial().equals(voucherTag.serial())) {
               playerInventory.setItem(i, (ItemStack)null);
               long l = System.currentTimeMillis();
               this.grant(player, voucherDef, voucherTag);
               this.plugin.ledger().record(voucherTag.serial(), voucherDef.id(), player.getUniqueId(), player.getName(), l);
               return Redeemer.Result.OK;
            } else {
               this.plugin.ledger().release(voucherTag.serial());
               return Redeemer.Result.GONE;
            }
         }
      }
   }

   public ItemStack copyOf(Player player, String str) {
      int i = this.findSerial(player.getInventory(), str);
      if (i < 0) {
         return null;
      } else {
         ItemStack itemStack = player.getInventory().getItem(i);
         return itemStack == null ? null : itemStack.clone();
      }
   }

   private int findSerial(PlayerInventory playerInventory, String str) {
      ItemStack[] itemStackArr = playerInventory.getContents();

      for(int var4 = 0; var4 < itemStackArr.length; ++var4) {
         VoucherTag voucherTag = this.plugin.tags().read(itemStackArr[var4]);
         if (voucherTag != null && voucherTag.serial().equals(str)) {
            return var4;
         }
      }

      return -1;
   }

   private void grant(Player player, VoucherDef voucherDef, VoucherTag voucherTag) {
      Map map = this.placeholders(player, voucherDef, voucherTag);

      for(ItemStack var6 : voucherDef.rewardItems()) {
         Items.give(player, var6);
      }

      if (voucherDef.money() > (double)0.0F) {
         if (this.plugin.economy().available()) {
            this.plugin.economy().deposit(player, voucherDef.money());
         } else {
            Logger logger = this.plugin.getLogger();
            String str = voucherDef.id();
            logger.warning("Voucher '" + str + "' pays " + EconomyHook.format(voucherDef.money()) + " but no Vault economy is installed - nothing was paid.");
         }
      }

      for(String var12 : voucherDef.commands()) {
         String str = Text.apply(var12, map);
         if (str.startsWith("/")) {
            str = str.substring(1);
         }

         Scheduler.global(this.plugin, () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), str));
      }

      for(String var13 : voucherDef.messages()) {
         player.sendMessage(Text.chat(Text.apply(var13, map)));
      }

      if (!voucherDef.broadcast().isEmpty()) {
         String str = Text.chat(Text.apply(voucherDef.broadcast(), map));
         Players.each(this.plugin, (var1x) -> var1x.sendMessage(str));
      }

      this.plugin.message(player, "voucher-redeemed", map);
      this.plugin.playSound(player, "redeem");
   }

   public Map<String, String> placeholders(Player player, VoucherDef voucherDef, VoucherTag voucherTag) {
      HashMap hashMap = new HashMap();
      hashMap.put("player", player.getName());
      hashMap.put("uuid", player.getUniqueId().toString());
      hashMap.put("voucher", voucherDef.displayName());
      hashMap.put("voucher_id", voucherDef.id());
      hashMap.put("serial", voucherTag == null ? "" : voucherTag.serial());
      hashMap.put("serial_short", voucherTag == null ? "" : voucherTag.shortSerial());
      hashMap.put("money", EconomyHook.format(voucherDef.money()));
      hashMap.put("world", player.getWorld().getName());
      return hashMap;
   }

   public static enum Result {
      OK(""),
      UNKNOWN("voucher-unknown"),
      DISABLED("voucher-disabled"),
      NO_PERMISSION("voucher-no-permission"),
      EXPIRED("voucher-expired"),
      BLOCKED_WORLD("voucher-blocked-world"),
      LIMIT("voucher-limit"),
      COOLDOWN("voucher-cooldown"),
      FULL("inventory-full"),
      GONE("voucher-gone"),
      ALREADY("voucher-already-redeemed");

      private final String key;

      private Result(String str) {
         this.key = str;
      }

      public String messageKey() {
         return this.key;
      }

      public boolean ok() {
         return this == OK;
      }

      private static Result[] $values() {
         return new Result[]{OK, UNKNOWN, DISABLED, NO_PERMISSION, EXPIRED, BLOCKED_WORLD, LIMIT, COOLDOWN, FULL, GONE, ALREADY};
      }
   }
}
