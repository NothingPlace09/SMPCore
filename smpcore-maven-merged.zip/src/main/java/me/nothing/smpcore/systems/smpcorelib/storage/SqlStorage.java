package me.nothing.smpcore.systems.smpcorelib.storage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

public final class SqlStorage implements Storage {
   private final String url;
   private final String benutzer;
   private final String passwort;
   private final boolean mysql;
   private final String tabelle;
   private Connection conn;

   public SqlStorage(String str, String str2, String str3, String str4) {
      this.url = str;
      this.benutzer = str2;
      this.passwort = str3;
      this.mysql = str.startsWith("jdbc:mysql");
      this.tabelle = str4;
      this.lege_an();
   }

   private Connection verbindung() {
      try {
         if (this.conn == null || this.conn.isClosed() || !this.conn.isValid(2)) {
            this.conn = this.benutzer != null && !this.benutzer.isEmpty() ? DriverManager.getConnection(this.url, this.benutzer, this.passwort) : DriverManager.getConnection(this.url);
         }

         return this.conn;
      } catch (SQLException e) {
         throw new IllegalStateException("Keine Verbindung zu " + this.url, e);
      }
   }

   private void lege_an() {
      String str = this.mysql ? "VARCHAR(190)" : "TEXT";
      String str2 = "CREATE TABLE IF NOT EXISTS " + this.tabelle + " (ns " + str + " NOT NULL,k " + str + " NOT NULL,feld " + str + " NOT NULL,wert TEXT,PRIMARY KEY (ns, k, feld))";

      try {
         Statement statement = this.verbindung().createStatement();

         try {
            statement.executeUpdate(str2);
         } catch (Throwable t) {
            if (statement != null) {
               try {
                  statement.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }
            }

            throw t;
         }

         if (statement != null) {
            statement.close();
         }

      } catch (SQLException e) {
         throw new IllegalStateException("Tabelle " + this.tabelle + " nicht anlegbar", e);
      }
   }

   public Map<String, String> read(String str, String str2) {
      LinkedHashMap linkedHashMap = new LinkedHashMap();
      String sql = "SELECT feld, wert FROM " + this.tabelle + " WHERE ns=? AND k=?";

      try {
         PreparedStatement preparedStatement = this.verbindung().prepareStatement(sql);

         try {
            preparedStatement.setString(1, str);
            preparedStatement.setString(2, str2);
            ResultSet resultSet = preparedStatement.executeQuery();

            try {
               while(resultSet.next()) {
                  linkedHashMap.put(resultSet.getString(1), resultSet.getString(2));
               }
            } catch (Throwable t) {
               if (resultSet != null) {
                  try {
                     resultSet.close();
                  } catch (Throwable t2) {
                     t.addSuppressed(t2);
                  }
               }

               throw t;
            }

            if (resultSet != null) {
               resultSet.close();
            }
         } catch (Throwable t) {
            if (preparedStatement != null) {
               try {
                  preparedStatement.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }
            }

            throw t;
         }

         if (preparedStatement != null) {
            preparedStatement.close();
         }

         return linkedHashMap;
      } catch (SQLException e) {
         throw new IllegalStateException("Lesen fehlgeschlagen: " + str + "/" + str2, e);
      }
   }

   public void write(String str, String str2, Map<String, String> map) {
      String delSql = "DELETE FROM " + this.tabelle + " WHERE ns=? AND k=?";
      String insSql = "INSERT INTO " + this.tabelle + " (ns,k,feld,wert) VALUES (?,?,?,?)";
      Connection connection = this.verbindung();

      try {
         boolean flag = connection.getAutoCommit();
         connection.setAutoCommit(false);
         PreparedStatement preparedStatement = connection.prepareStatement(delSql);

         try {
            preparedStatement.setString(1, str);
            preparedStatement.setString(2, str2);
            preparedStatement.executeUpdate();
         } catch (Throwable t) {
            if (preparedStatement != null) {
               try {
                  preparedStatement.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }
            }

            throw t;
         }

         if (preparedStatement != null) {
            preparedStatement.close();
         }

         preparedStatement = connection.prepareStatement(insSql);

         try {
            for(Map.Entry var10 : map.entrySet()) {
               preparedStatement.setString(1, str);
               preparedStatement.setString(2, str2);
               preparedStatement.setString(3, (String)var10.getKey());
               preparedStatement.setString(4, (String)var10.getValue());
               preparedStatement.addBatch();
            }

            preparedStatement.executeBatch();
         } catch (Throwable t) {
            if (preparedStatement != null) {
               try {
                  preparedStatement.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }
            }

            throw t;
         }

         if (preparedStatement != null) {
            preparedStatement.close();
         }

         connection.commit();
         connection.setAutoCommit(flag);
      } catch (SQLException e) {
         try {
            connection.rollback();
         } catch (SQLException e2) {
         }

         throw new IllegalStateException("Schreiben fehlgeschlagen: " + str + "/" + str2, e);
      }
   }

   public void delete(String str, String str2) {
      try {
         PreparedStatement preparedStatement = this.verbindung().prepareStatement("DELETE FROM " + this.tabelle + " WHERE ns=? AND k=?");

         try {
            preparedStatement.setString(1, str);
            preparedStatement.setString(2, str2);
            preparedStatement.executeUpdate();
         } catch (Throwable t) {
            if (preparedStatement != null) {
               try {
                  preparedStatement.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }
            }

            throw t;
         }

         if (preparedStatement != null) {
            preparedStatement.close();
         }

      } catch (SQLException e) {
         throw new IllegalStateException("Loeschen fehlgeschlagen: " + str + "/" + str2, e);
      }
   }

   public Map<String, Map<String, String>> readAll(String str) {
      LinkedHashMap linkedHashMap = new LinkedHashMap();
      String sql = "SELECT k, feld, wert FROM " + this.tabelle + " WHERE ns=? ORDER BY k";

      try {
         PreparedStatement preparedStatement = this.verbindung().prepareStatement(sql);

         try {
            preparedStatement.setString(1, str);
            ResultSet resultSet = preparedStatement.executeQuery();

            try {
               while(resultSet.next()) {
                  ((Map)linkedHashMap.computeIfAbsent(resultSet.getString(1), (var0) -> new HashMap())).put(resultSet.getString(2), resultSet.getString(3));
               }
            } catch (Throwable t) {
               if (resultSet != null) {
                  try {
                     resultSet.close();
                  } catch (Throwable t2) {
                     t.addSuppressed(t2);
                  }
               }

               throw t;
            }

            if (resultSet != null) {
               resultSet.close();
            }
         } catch (Throwable t) {
            if (preparedStatement != null) {
               try {
                  preparedStatement.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }
            }

            throw t;
         }

         if (preparedStatement != null) {
            preparedStatement.close();
         }

         return linkedHashMap;
      } catch (SQLException e) {
         throw new IllegalStateException("Lesen fehlgeschlagen: " + str, e);
      }
   }

   public void flush() {
   }

   public void close() {
      try {
         if (this.conn != null && !this.conn.isClosed()) {
            this.conn.close();
         }
      } catch (SQLException e) {
      }

   }
}
