package me.nothing.smpcore.systems.voucher;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import me.nothing.smpcore.systems.smpcorelib.gui.ItemSpec;
import me.nothing.smpcore.systems.smpcorelib.gui.Menu;
import me.nothing.smpcore.systems.smpcorelib.gui.MenuConfig;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;

public final class EditMenu extends Menu {
   private final VoucherPlugin plugin;
   private final MenuConfig config;
   private final Draft draft;
   private final SortMode sort;
   private final String search;
   private boolean armed;

   public EditMenu(VoucherPlugin voucherPlugin, Player player, Draft draft, SortMode sortMode, String str) {
      super(player);
      this.plugin = voucherPlugin;
      this.draft = draft;
      this.config = voucherPlugin.editMenuConfig(draft.creating());
      this.sort = sortMode;
      this.search = str;
   }

   protected String title() {
      return Text.apply(this.config.title(), this.values());
   }

   protected int rows() {
      return this.config.rows();
   }

   private Map<String, String> values() {
      YamlConfiguration yamlConfiguration = this.plugin.editFile().yaml();
      String str = yamlConfiguration.getString("menu.unset", "not set");
      String str2 = yamlConfiguration.getString("menu.join", ", ");
      HashMap hashMap = new HashMap();
      hashMap.put("player", this.viewer.getName());
      hashMap.put("mode", yamlConfiguration.getString(this.draft.creating() ? "menu.mode-create" : "menu.mode-edit", ""));
      hashMap.put("voucher_id", this.draft.id().isEmpty() ? str : this.draft.id());
      hashMap.put("voucher_name", this.draft.displayName().isEmpty() ? str : this.draft.displayName());
      hashMap.put("voucher_material", this.draft.materialName());
      hashMap.put("voucher_command", this.draft.commandLine(str, str2));
      hashMap.put("voucher_lore", this.draft.loreLine(str, str2));
      hashMap.put("commands", String.valueOf(this.draft.commands().size()));
      hashMap.put("lines", String.valueOf(this.draft.lore().size()));
      return hashMap;
   }

   protected void draw() {
      Map map = this.values();
      this.config.render(this.getInventory(), map);
      if (this.armed) {
         ItemSpec itemSpec = this.config.item("delete_armed");
         if (itemSpec != null) {
            for(int var4 : this.config.slotsOfAction("delete")) {
               this.getInventory().setItem(var4, itemSpec.build(map));
            }

         }
      }
   }

   protected void onClick(InventoryClickEvent inventoryClickEvent) {
      if (this.clickedTopInventory(inventoryClickEvent)) {
         String str = this.config.actionAt(inventoryClickEvent.getSlot());
         if (str != null) {
            if (!str.equals("delete")) {
               this.armed = false;
            }

            switch (str) {
               case "cancel" -> this.back();
               case "id" -> this.ask("editor-ask-id", (var1x) -> {
   if (var1x != null && !this.draft.id(var1x)) {
      this.plugin.message(this.viewer, "invalid-id");
   }

});
               case "display_name" -> this.ask("editor-ask-name", (var1x) -> {
   if (var1x != null) {
      this.draft.displayName(var1x);
   }

});
               case "item" -> this.capture();
               case "command" -> this.command(inventoryClickEvent.isShiftClick());
               case "lore" -> this.ask("editor-ask-lore", (var1x) -> {
   if (var1x != null) {
      this.draft.lore(var1x, this.plugin.config().yaml().getString("editor.lore-separator", ";"));
   }

});
               case "delete" -> this.delete();
               case "confirm" -> this.confirm();
            }

         }
      }
   }

   private void ask(String str, Consumer<String> consumer) {
      this.viewer.closeInventory();
      this.plugin.message(this.viewer, str, Map.of("cancel", this.plugin.prompt().cancelWord()));
      this.plugin.prompt().ask(this.viewer, (var2x) -> {
         consumer.accept(var2x);
         (new EditMenu(this.plugin, this.viewer, this.draft, this.sort, this.search)).open();
      });
   }

   private void capture() {
      if (!this.draft.capture(this.plugin.tags(), this.viewer.getInventory().getItemInMainHand())) {
         this.plugin.message(this.viewer, "editor-no-item");
         this.plugin.playSound(this.viewer, "denied");
      } else {
         this.plugin.message(this.viewer, "editor-item-taken", Map.of("material", this.draft.materialName()));
         this.refresh();
      }
   }

   private void command(boolean flag) {
      if (flag) {
         this.draft.clearCommands();
         this.plugin.message(this.viewer, "editor-commands-cleared");
         this.refresh();
      } else {
         this.ask("editor-ask-command", (var1x) -> {
            if (var1x != null) {
               this.draft.addCommand(var1x);
            }

         });
      }
   }

   private void delete() {
      if (!this.draft.creating()) {
         if (!this.armed) {
            this.armed = true;
            this.plugin.message(this.viewer, "editor-delete-armed", Map.of("voucher_id", this.draft.originalId()));
            this.refresh();
         } else {
            String str = this.draft.originalId();
            this.plugin.deleteVoucher(str);
            this.plugin.message(this.viewer, "voucher-deleted", Map.of("voucher_id", str));
            this.plugin.playSound(this.viewer, "delete");
            this.back();
         }
      }
   }

   private void confirm() {
      if (!this.draft.complete()) {
         this.plugin.message(this.viewer, "invalid-id");
         this.plugin.playSound(this.viewer, "denied");
      } else {
         boolean flag = this.draft.creating();
         this.draft.save(this.plugin);
         this.plugin.message(this.viewer, flag ? "voucher-created" : "voucher-updated", Map.of("voucher_id", this.draft.id()));
         this.plugin.playSound(this.viewer, "saved");
         this.back();
      }
   }

   private void back() {
      (new AdminMenu(this.plugin, this.viewer, 0, this.sort, this.search)).open();
   }
}
