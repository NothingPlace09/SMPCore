package me.nothing.smpcore.systems.voucher;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.lang.reflect.Method;
import java.util.Base64;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

final class ItemCodec {
   private static final Method PAPER_LESER = suchePaperLeser();

   private ItemCodec() {
   }

   static String encode(ItemStack itemStack) {
      if (itemStack != null && !itemStack.getType().isAir()) {
         ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

         try {
            BukkitObjectOutputStream bukkitObjectOutputStream = new BukkitObjectOutputStream(byteArrayOutputStream);

            try {
               bukkitObjectOutputStream.writeObject(itemStack);
            } catch (Throwable t) {
               try {
                  bukkitObjectOutputStream.close();
               } catch (Throwable t2) {
                  t.addSuppressed(t2);
               }

               throw t;
            }

            bukkitObjectOutputStream.close();
            return Base64.getEncoder().encodeToString(byteArrayOutputStream.toByteArray());
         } catch (Exception e) {
            Logger logger = Bukkit.getLogger();
            String str = String.valueOf(itemStack.getType());
            logger.warning("[SmpCoreVoucher] Gegenstand liess sich nicht speichern: " + str + " - " + String.valueOf(e));
            return null;
         }
      } else {
         return null;
      }
   }

   static ItemStack decode(String str) {
      if (str != null && !str.isEmpty()) {
         byte[] bArr;
         try {
            bArr = Base64.getDecoder().decode(str);
         } catch (IllegalArgumentException e) {
            return null;
         }

         try {
            ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(bArr);

            label61: {
               ItemStack itemStack;
               try {
                  BukkitObjectInputStream bukkitObjectInputStream = new BukkitObjectInputStream(byteArrayInputStream);

                  label57: {
                     try {
                        Object obj = bukkitObjectInputStream.readObject();
                        if (obj instanceof ItemStack) {
                           ItemStack itemStack2 = (ItemStack)obj;
                           itemStack = itemStack2;
                           break label57;
                        }
                     } catch (Throwable t) {
                        try {
                           bukkitObjectInputStream.close();
                        } catch (Throwable t2) {
                           t.addSuppressed(t2);
                        }

                        throw t;
                     }

                     bukkitObjectInputStream.close();
                     break label61;
                  }

                  bukkitObjectInputStream.close();
               } catch (Throwable t) {
                  try {
                     byteArrayInputStream.close();
                  } catch (Throwable t2) {
                     t.addSuppressed(t2);
                  }

                  throw t;
               }

               byteArrayInputStream.close();
               return itemStack;
            }

            byteArrayInputStream.close();
         } catch (Exception e) {
         }

         return paper(bArr);
      } else {
         return null;
      }
   }

   private static Method suchePaperLeser() {
      try {
         return ItemStack.class.getMethod("deserializeBytes", byte[].class);
      } catch (NoSuchMethodException e) {
         return null;
      }
   }

   private static ItemStack paper(byte[] bArr) {
      if (PAPER_LESER == null) {
         return null;
      } else {
         try {
            Object obj = PAPER_LESER.invoke((Object)null, bArr);
            ItemStack itemStack;
            if (obj instanceof ItemStack) {
               ItemStack itemStack2 = (ItemStack)obj;
               itemStack = itemStack2;
            } else {
               itemStack = null;
            }

            return itemStack;
         } catch (RuntimeException | ReflectiveOperationException e) {
            Bukkit.getLogger().warning("[SmpCoreVoucher] Ein Eintrag im Paper-Format liess sich nicht lesen: " + String.valueOf(e));
            return null;
         }
      }
   }
}
