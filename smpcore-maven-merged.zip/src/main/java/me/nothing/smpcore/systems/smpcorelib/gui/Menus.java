package me.nothing.smpcore.systems.smpcorelib.gui;

import java.util.List;
import java.util.function.Predicate;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.platform.Scheduler;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.plugin.Plugin;

public final class Menus {
   private Menus() {
   }

   public static void closeAll(Plugin plugin, Predicate<InventoryHolder> predicate) {
      List list = List.copyOf(Bukkit.getOnlinePlayers());
      boolean flag = plugin.isEnabled();

      for(Player var5 : list) {
         if (flag) {
            Scheduler.atEntity(plugin, var5, () -> schliesse(var5, predicate));
         } else {
            try {
               schliesse(var5, predicate);
            } catch (RuntimeException e) {
               Logger logger = Bukkit.getLogger();
               String str = plugin.getName();
               logger.fine("[SmpCore] " + str + ": Menue von " + var5.getName() + " liess sich beim Herunterfahren nicht schliessen: " + String.valueOf(e));
            }
         }
      }

   }

   private static void schliesse(Player player, Predicate<InventoryHolder> predicate) {
      InventoryHolder inventoryHolder = player.getOpenInventory().getTopInventory().getHolder();
      if (inventoryHolder != null && predicate.test(inventoryHolder)) {
         player.closeInventory();
      }

   }
}
