package me.nothing.smpcore.systems.invest;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import me.nothing.smpcore.systems.smpcorelib.economy.EconomyHook;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class InvestCommand implements CommandExecutor, TabCompleter {
   private final InvestPlugin plugin;

   public InvestCommand(InvestPlugin var1) {
      this.plugin = var1;
   }

   public boolean onCommand(CommandSender var1, Command var2, String var3, String[] var4) {
      if (var4.length > 0) {
         String str = var4[0].toLowerCase(Locale.ROOT);
         if (str.equals("reload") || str.equals("reset") || str.equals("maxinvest")) {
            if (!var1.hasPermission("smpcoreinvest.admin")) {
               this.plugin.say(var1, "no-permission");
               return true;
            } else {
               boolean flag;
               switch (str) {
                  case "reload" -> flag = this.reload(var1);
                  case "reset" -> flag = this.reset(var1, var4);
                  default -> flag = this.maxInvest(var1, var4);
               }

               return flag;
            }
         }
      }

      if (!var1.hasPermission("smpcoreinvest.use")) {
         this.plugin.say(var1, "no-permission");
         return true;
      } else if (var1 instanceof Player) {
         Player player = (Player)var1;
         (new InvestMenu(player, this.plugin)).open();
         return true;
      } else {
         this.plugin.say(var1, "players-only");
         return true;
      }
   }

   private boolean reload(CommandSender var1) {
      this.plugin.reload();
      this.plugin.say(var1, "reloaded");
      return true;
   }

   private boolean reset(CommandSender var1, String[] var2) {
      if (var2.length < 2) {
         this.plugin.say(var1, "usage-reset");
         return true;
      } else {
         OfflinePlayer offlinePlayer = this.find(var2[1]);
         if (offlinePlayer == null) {
            this.plugin.say(var1, "player-not-found");
            return true;
         } else {
            this.plugin.store().reset(offlinePlayer.getUniqueId());
            this.plugin.say(var1, "reset-done", Map.of("player", this.name(offlinePlayer, var2[1])));
            return true;
         }
      }
   }

   private boolean maxInvest(CommandSender var1, String[] var2) {
      if (var2.length < 3) {
         this.plugin.say(var1, "usage-maxinvest");
         return true;
      } else {
         OfflinePlayer offlinePlayer = this.find(var2[1]);
         if (offlinePlayer == null) {
            this.plugin.say(var1, "player-not-found");
            return true;
         } else {
            double d = EconomyHook.parseAmount(var2[2]);
            if (Double.isFinite(d) && d != (double)0.0F) {
               this.plugin.store().addExtraMax(offlinePlayer.getUniqueId(), d);
               this.plugin.say(var1, "maxinvest-done", Map.of("player", this.name(offlinePlayer, var2[1]), "amount", EconomyHook.format(d)));
               return true;
            } else {
               this.plugin.say(var1, "invalid-amount");
               return true;
            }
         }
      }
   }

   private OfflinePlayer find(String var1) {
      Player player = Bukkit.getPlayerExact(var1);
      if (player != null) {
         return player;
      } else {
         OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer(var1);
         return offlinePlayer.hasPlayedBefore() ? offlinePlayer : null;
      }
   }

   private String name(OfflinePlayer var1, String var2) {
      String str = var1.getName();
      return str == null ? var2 : str;
   }

   public List<String> onTabComplete(CommandSender var1, Command var2, String var3, String[] var4) {
      if (!var1.hasPermission("smpcoreinvest.admin")) {
         return List.of();
      } else if (var4.length == 1) {
         return matching(List.of("reload", "reset", "maxinvest"), var4[0]);
      } else if (var4.length == 2 && !var4[0].equalsIgnoreCase("reload")) {
         ArrayList arrayList = new ArrayList();

         for(Player var7 : Bukkit.getOnlinePlayers()) {
            arrayList.add(var7.getName());
         }

         return matching(arrayList, var4[1]);
      } else {
         return List.of();
      }
   }

   private static List<String> matching(List<String> var0, String var1) {
      String str = var1.toLowerCase(Locale.ROOT);
      ArrayList arrayList = new ArrayList();

      for(String var5 : var0) {
         if (var5.toLowerCase(Locale.ROOT).startsWith(str)) {
            arrayList.add(var5);
         }
      }

      return arrayList;
   }
}
