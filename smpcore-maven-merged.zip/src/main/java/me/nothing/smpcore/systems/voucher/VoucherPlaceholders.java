package me.nothing.smpcore.systems.voucher;

import java.util.Locale;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

final class VoucherPlaceholders extends PlaceholderExpansion {
   private final VoucherPlugin plugin;

   private VoucherPlaceholders(VoucherPlugin voucherPlugin) {
      this.plugin = voucherPlugin;
   }

   private static VoucherPlaceholders active;

   static synchronized boolean register(VoucherPlugin voucherPlugin) {
      dropActive();
      VoucherPlaceholders expansion = new VoucherPlaceholders(voucherPlugin);
      boolean ok = expansion.register();
      if (ok) {
         active = expansion;
      }
      return ok;
   }

   static synchronized void dropActive() {
      if (active != null) {
         try {
            active.unregister();
         } catch (Throwable ignored) {
         }
         active = null;
      }
   }

   public String getIdentifier() {
      return "smpcorevoucher";
   }

   public String getAuthor() {
      return "nothing";
   }

   public String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onRequest(OfflinePlayer offlinePlayer, String params) {
      String var3 = params.toLowerCase(Locale.ROOT);
      switch (var3) {
         case "vouchers":
            return String.valueOf(this.plugin.vouchers().size());
         case "redeemed":
            return String.valueOf(this.plugin.ledger().redeemedTotal());
         case "players":
            return String.valueOf(this.plugin.ledger().knownPlayers());
         default:
            if (offlinePlayer == null) {
               return "";
            } else if (var3.startsWith("redeemed_")) {
               String voucherId = var3.substring("redeemed_".length());
               return String.valueOf(this.plugin.ledger().count(offlinePlayer.getUniqueId(), voucherId));
            } else if (var3.equals("my_redeemed")) {
               return String.valueOf(this.plugin.ledger().totalOf(offlinePlayer.getUniqueId()));
            } else if (offlinePlayer instanceof Player) {
               Player player = (Player)offlinePlayer;
               ItemStack itemStack = player.getInventory().getItemInMainHand();
               VoucherTag voucherTag = this.plugin.tags().read(itemStack);
               VoucherDef voucherDef = voucherTag == null ? null : this.plugin.voucher(voucherTag.id());
               String result;
               switch (var3) {
                  case "is_voucher" -> result = String.valueOf(voucherTag != null);
                  case "held" -> result = voucherTag == null ? "" : voucherTag.id();
                  case "held_name" -> result = voucherDef == null ? "" : voucherDef.plainName();
                  case "held_serial" -> result = voucherTag == null ? "" : voucherTag.serial();
                  case "held_serial_short" -> result = voucherTag == null ? "" : voucherTag.shortSerial();
                  case "held_time" -> result = voucherTag == null ? "" : this.plugin.time().format(voucherTag.secondsLeft(System.currentTimeMillis()));
                  case "held_expired" -> result = voucherTag == null ? "" : String.valueOf(voucherTag.expired(System.currentTimeMillis()));
                  default -> result = "";
               }

               return result;
            } else {
               return "";
            }
      }
   }
}
