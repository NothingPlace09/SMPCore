package me.nothing.smpcore.systems.smpcorelib.storage;

import java.io.File;
import java.util.Locale;
import java.util.logging.Level;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.plugin.Plugin;

public final class StorageFactory {
   private StorageFactory() {
   }

   public static Storage baue(Plugin plugin, ConfigurationSection configurationSection) {
      File file = new File(plugin.getDataFolder(), "data");
      if (configurationSection == null) {
         return new YamlStorage(file);
      } else {
         String str = configurationSection.getString("type", "yaml").trim().toLowerCase(Locale.ROOT);
         String str2 = configurationSection.getString("mysql.table", "smpcore_data");

         try {
            switch (str) {
               case "sqlite":
                  File file2 = new File(file, "data.db");
                  if (!file.exists() && !file.mkdirs()) {
                     throw new IllegalStateException("Ordner nicht anlegbar: " + String.valueOf(file));
                  }

                  plugin.getLogger().info("Speicher: SQLite (" + file2.getName() + ")");
                  return new SqlStorage("jdbc:sqlite:" + file2.getAbsolutePath(), (String)null, (String)null, str2);
               case "mysql":
                  String str3 = configurationSection.getString("mysql.host", "localhost");
                  int i = configurationSection.getInt("mysql.port", 3306);
                  String str4 = configurationSection.getString("mysql.database", "minecraft");
                  String str5 = "jdbc:mysql://" + str3 + ":" + i + "/" + str4 + "?useSSL=false&allowPublicKeyRetrieval=true&characterEncoding=utf8";
                  plugin.getLogger().info("Speicher: MySQL (" + str3 + ":" + i + "/" + str4 + ")");
                  return new SqlStorage(str5, configurationSection.getString("mysql.user", "root"), configurationSection.getString("mysql.password", ""), str2);
               default:
                  return new YamlStorage(file);
            }
         } catch (RuntimeException e) {
            plugin.getLogger().log(Level.SEVERE, "Speicher '" + str + "' nicht erreichbar - es wird mit YAML weitergearbeitet. Pruefe den storage-Block in der Konfiguration.", e);
            return new YamlStorage(file);
         }
      }
   }
}
