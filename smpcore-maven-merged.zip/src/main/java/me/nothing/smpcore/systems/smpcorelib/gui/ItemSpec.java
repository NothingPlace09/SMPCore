package me.nothing.smpcore.systems.smpcorelib.gui;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.smpcorelib.text.Placeholders;
import me.nothing.smpcore.systems.smpcorelib.text.Text;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;
import org.bukkit.profile.PlayerTextures;

public final class ItemSpec {
   private final Material material;
   private final String name;
   private final List<String> lore;
   private final char symbol;
   private final String action;
   private final String headTexture;
   private final int customModel;
   private final boolean glow;

   private ItemSpec(Material material, String str, List<String> list, char c, String str2, String str3, int i, boolean flag) {
      this.material = material;
      this.name = str;
      this.lore = list;
      this.symbol = c;
      this.action = str2;
      this.headTexture = str3;
      this.customModel = i;
      this.glow = flag;
   }

   public static ItemSpec from(ConfigurationSection configurationSection, String str, Logger logger) {
      if (!configurationSection.isSet("material") && !configurationSection.getKeys(false).isEmpty() && configurationSection.getValues(false).values().stream().anyMatch((var0x) -> var0x instanceof ConfigurationSection)) {
         logger.warning("Menu item '" + str + "' at " + configurationSection.getCurrentPath() + " has no `material:` but contains sub-sections - looks like the parent section was passed instead of the item itself.");
      }

      String materialName = configurationSection.getString("material", "STONE");
      Material material = Material.matchMaterial(materialName.toUpperCase());
      if (material == null) {
         logger.warning("Unknown material '" + materialName + "' at " + configurationSection.getCurrentPath() + " - falling back to STONE so the menu still opens.");
         material = Material.STONE;
      }

      if (material != Material.AIR && !material.isItem()) {
         logger.warning("Material '" + materialName + "' at " + configurationSection.getCurrentPath() + " exists as a block but not as an item and cannot go in a menu - falling back to STONE so the menu still opens.");
         material = Material.STONE;
      }

      String str2 = configurationSection.getString("symbol", "");
      char c = str2.isEmpty() ? 0 : str2.charAt(0);
      return new ItemSpec(material, configurationSection.getString("name", ""), new ArrayList(configurationSection.getStringList("lore")), c, configurationSection.getString("action", str), configurationSection.getString("head-texture", ""), configurationSection.getInt("custom-model", -1), configurationSection.getBoolean("glow", false));
   }

   public char symbol() {
      return this.symbol;
   }

   public String action() {
      return this.action;
   }

   public boolean uses(String str) {
      if (this.name.contains(str)) {
         return true;
      } else {
         for(String var3 : this.lore) {
            if (var3.contains(str)) {
               return true;
            }
         }

         return false;
      }
   }

   public Material material() {
      return this.material;
   }

   public ItemStack build() {
      return this.build(Collections.emptyMap());
   }

   public ItemStack build(Map<String, String> map) {
      return this.build(map, (String)null);
   }

   public ItemStack build(Map<String, String> map, String str) {
      return this.build(map, str, (Material)null);
   }

   public ItemStack build(Map<String, String> map, String str, Material material) {
      ItemStack itemStack = new ItemStack(material != null ? material : this.material);
      ItemMeta itemMeta = itemStack.getItemMeta();
      if (itemMeta == null) {
         return itemStack;
      } else {
         if (!this.name.isEmpty()) {
            itemMeta.setDisplayName(Text.item(Placeholders.imMenue(Text.apply(this.name, map))));
         }

         if (!this.lore.isEmpty()) {
            itemMeta.setLore(Text.lore(Placeholders.imMenue(Text.apply(this.lore, map))));
         }

         if (this.customModel >= 0) {
            itemMeta.setCustomModelData(this.customModel);
         }

         if (this.glow) {
            itemMeta.addEnchant(Enchantment.UNBREAKING, 1, true);
         }

         itemMeta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS, ItemFlag.HIDE_ADDITIONAL_TOOLTIP, ItemFlag.HIDE_DYE});
         if (itemMeta instanceof SkullMeta) {
            SkullMeta skullMeta = (SkullMeta)itemMeta;
            String texture = str != null && !str.isEmpty() ? str : this.headTexture;
            if (!texture.isEmpty()) {
               applyHeadTexture(skullMeta, texture);
            }
         }

         itemStack.setItemMeta(itemMeta);
         return itemStack;
      }
   }

   private static void applyHeadTexture(SkullMeta skullMeta, String str) {
      try {
         String url = str.startsWith("http") ? str : "https://textures.minecraft.net/texture/" + str;
         PlayerProfile playerProfile = Bukkit.createPlayerProfile(UUID.nameUUIDFromBytes(url.getBytes(StandardCharsets.UTF_8)), "");
         PlayerTextures playerTextures = playerProfile.getTextures();
         playerTextures.setSkin(URI.create(url).toURL());
         playerProfile.setTextures(playerTextures);
         skullMeta.setOwnerProfile(playerProfile);
      } catch (Exception e) {
      }

   }
}
