# SmpCore 1.5.0 – fix applicati

Nome, package (`me.nothing.smpcore`), permessi e cartella dati NON sono stati modificati.
Controllo fatto: sintassi (tree-sitter). Non compilato con Maven: esegui `mvn clean package`.

## Modifica 1 – systems/spawners/SpawnerListener.java
- Dupe off-hand: `consumeSpawnerUnits` svuotava sempre la mano principale. Ora usa lo slot reale
  (`event.getHand()`), nuovo helper `removeFromHand`.
- `max-stack` ora rispettato anche al primo piazzamento (shift-place di uno stack grande).
  Se `perItem > max-stack` il piazzamento viene annullato con il messaggio `stack-limit`.

## Modifica 2 – systems/ec/EcStorage.java, EcGui.java, EcListener.java
- Dupe EC vanilla: l'import dal vanilla avviene una sola volta (flag `players.<uuid>.enderchest.seeded`)
  e il vanilla viene svuotato dopo l'import.
- Perdita item dopo downgrade di rank: la cache tiene l'array completo e `save()` conserva le righe
  che il rank attuale non mostra.
- Dupe owner + `/ecsee`: un EC puo' essere aperto da una sola persona alla volta
  (messaggio opzionale `ec-in-use` in messages, default incluso nel codice).

## Da testare in gioco (modifiche 1-2)
1. Spawner in off-hand accanto a uno uguale -> deve consumarsi l'item in off-hand, la mano principale resta intatta.
2. Shift-place di uno stack oltre `max-stack` -> piazza il massimo, il resto resta in mano.
3. EC: svuota l'EC custom con item nel vanilla -> riaprendo NON devono ricomparire.
4. `/ecsee` su un player con EC aperto -> messaggio "already open".

## Modifica 3 – systems/auction/AuctionManager.java
- Item perso alla scadenza: se il venditore era offline il listing veniva chiuso senza restituire l'item.
  Ora il listing viene chiuso solo quando l'item e' restituito; da scaduto non e' acquistabile ne' annullabile,
  il timer riprova finche' il venditore torna online.

## Modifica 4 – systems/order/GuiListener.java (+ resources/order/messages.yml)
- Cancellazione admin (slot 13) con owner offline: gli item consegnati e non ritirati venivano distrutti.
  Ora l'operazione viene bloccata (nessun rimborso, nessuna cancellazione) finche' l'owner e' offline.
- Nuova chiave messaggio `order-delete-owner-offline` (in resources/order/messages.yml). Se manca nel
  messages.yml gia' deployato viene usato il testo di default scritto nel codice (`MessageManager.sendOrDefault`).

## Modifica 5 – systems/sell/GuiListener.java
- Item perso nel /sell: qualunque GLASS_PANE nell'area vendita non veniva venduta ne' restituita.
  Ora l'esclusione e' basata sullo slot (solo il bottone conferma), non sul tipo di materiale.

## Da testare (modifiche 3-5)
5. Metti in vendita, fai scadere con il venditore offline, rientra: l'item deve tornare.
6. Order con item consegnati non ritirati, owner offline, delete admin: deve dare il messaggio e non cancellare.
7. /sell con glass pane di vari colori: vengono vendute (o restituite se in blacklist), mai perse.

## Modifica 6 – combat: alias/namespace e teleport in combattimento
- Nuovo `systems/combat/CombatGuard.java`: helper unico (`isBlocked` / `deny`) che chiede al combat se il player e' taggato.
- `CombatListener`: i `blocked-commands` ora risolvono namespace e alias del comando reale
  (`/h`, `/essentials:home`, `/minecraft:tp` erano un bypass). Supporta anche voci con sottocomando (es. `team home`).
- Teleport volontari ora negati in combat, sia all'avvio sia al completamento del countdown (se ti tagghi durante
  il countdown il teleport viene annullato): `/team home` (TeamCommand), homes + GUI homes (homes/TeleportManager),
  warps/spawn (warps/TeleportManager), tpa accept (TpaManager), rtp (rtp/RTPManager).
- Non toccati di proposito: i teleport dei duelli e dello staff (permesso `smpcore.system.combat.bypass`).

## Da testare (modifica 6)
8. Tagga un player, poi prova `/essentials:home`, un alias di `/home` e `/minecraft:tp`: devono essere bloccati.
9. In combat: `/team home`, click su una home nella GUI, `/tpa` accettato, `/rtp`: tutti negati con il messaggio del combat.
10. Avvia un `/home` con countdown e fatti colpire: il teleport si annulla.
11. Un duello deve iniziare e finire normalmente anche se i player sono taggati.

## Modifica 7 – systems/tools/ToolListener.java
- Protezioni: i blocchi extra di drill, shovel, treechopper e hoe venivano rotti con `breakNaturally` senza `BlockBreakEvent`
  (claim/WorldGuard/CoreProtect non li vedevano). Ora ogni blocco extra passa da un `BlockBreakEvent` (helper `breakChecked`)
  e viene rotto solo se nessuno lo annulla. Effetto collaterale voluto: log e statistiche vedono anche i blocchi extra.
- Il drill non rompe piu' blocchi che `breakNaturally` distruggeva ignorando la durezza: portali dell'End, deepslate rinforzata,
  command block chain/repeating, structure block, jigsaw, chest/barile/ender chest/hopper/dropper/dispenser/forni/brewing stand/beacon/shulker.
- Treechopper: le foglie non consumano piu' il limite di 64 blocchi (alberi grandi restavano a meta') e segue anche i tronchi in diagonale.
- Hoe: raccoglie solo colture vere (grano, carote, patate, barbabietole, nether wart, torchflower, pitcher) invece di ogni blocco Ageable.
- Non risolti: la zappa (tillCube) trasforma ancora in farmland senza evento di protezione; l'hoe non replanta.

## Modifica 8 – banner nei config (resources/**)
- In 205 file di config il banner ASCII "ASTRAL" e' stato sostituito con "SMPCORE" (font ANSI Shadow) e la scritta
  "STUDIO" e' stata rimossa.

## Da testare (modifica 7)
12. Drill vicino al confine di un claim/regione WorldGuard: i blocchi protetti non devono rompersi.
13. Drill contro portale dell'End / deepslate rinforzata / una chest: non vengono rotti.
14. Treechopper su un albero grande (dark oak/jungle): deve abbattere tutti i tronchi fino a 64.
15. Hoe su un campo con canna da zucchero o cactus al massimo: non vengono rotti.

## Modifica 9 – teleport/countdown bloccati cambiando mondo (nuovo utils/MoveCheck.java)
- `Location#distance/distanceSquared` lanciano IllegalArgumentException se i mondi differiscono (portale durante il
  countdown): il task falliva a ogni tick, la console si riempiva e la sessione restava bloccata ("busy"/"already teleporting").
  Ora `MoveCheck.movedMoreThan(...)` considera un cambio di mondo come "ti sei mosso" e annulla il teleport.
- Applicato in: TeamCommand (team home), homes/TeleportManager, warps/TeleportManager, TpaManager (countdown + onMove), RTPCountdown.

## Modifica 10 – rimossa la scritta STUDIO dai banner dei config (vedi sopra).

## Modifica 11 – tutti gli "astral" -> "smpcore"
- Config (resources/**): testi, nomi modulo nei messaggi di reload, MOTD, TAB, regole, help, media, webhook username.
  `AstralSMP` -> `SmpCore`, `Astral+` -> `SmpCore+`, `Astral studio` -> `SmpCore`, gli altri `Astral` -> `SmpCore`.
- Codice: solo dentro le STRINGHE Java (log "enabled/disabled", help, prefissi di default, ecc.).
- Rinominati anche identificatori funzionali (aggiorna permessi/config se li usi):
  - Permessi: `AstralHide.reload` -> `SmpCoreHide.reload`, `AstralMobs.admin/use` -> `SmpCoreMobs.admin/use`,
    `AstralRTPQ.admin` -> `SmpCoreRTPQ.admin`.
  - Comandi (plugin.yml + codice coerenti): `astralpunishment` -> `smpcorepunishment`, alias `astraltools` -> `smpcoretools`,
    alias `astralauction` -> `smpcoreauction`. Alias del comando principale: rimossi `astralcore` e `AstralSMP`.
  - Identificatori PlaceholderAPI: `astralkeyall/combat/teams/sell/shards/shop/billford` -> `smpcorekeyall/...`.
  - Tag scoreboard degli holo crates: `astralcrates_holo` -> `smpcorecrates_holo` (entita' non persistenti).
- NON modificati di proposito (ora i nomi di classe SONO stati rinominati, vedi modifica 14): il link `discord.gg/AstralSMP` in rules.yml
  (e' un invito reale), `database: astralreports` in reports.yml (rinominarlo crea un database nuovo e vuoto),
  (il LicenseManager non c'e' piu' in questo zip). README spawners: percorso corretto in `plugins/SmpCore/spawners/spawners/` e comando `/as reload`.

## Da testare (modifiche 9-11)
16. Avvia un /home (o /tpa, /team home, /warp, /rtp) con countdown ed entra in un portale: il teleport si annulla senza errori in console.
17. `/smpcorepunishment` (ex astralpunishment) risponde; `/tools` e `/ah` funzionano.
18. Controlla TAB, MOTD, /help, /rules: niente "Astral" residuo (tranne il link discord di rules.yml).

## Modifica 12 – kill-reward farmabile (combat)
- Il cooldown era solo per killer (30s): con un alt si prendevano shard all'infinito. Ora in `CombatManager.applyReward(killer, victim)`:
  - `kill-reward.same-victim-cooldown` (default 600s): la STESSA vittima non da' premio piu' di una volta ogni 10 minuti;
  - `kill-reward.block-same-ip` (default true): nessun premio se killer e vittima hanno lo stesso IP;
  - `kill-reward.exclude-duels` (default true): nessun premio per le morti nei duelli (DuelsModule espone `consumeDuelDeath`);
  - `kill-reward.exclude-combat-log` (default true): nessun premio se la vittima muore uscendo in combat.
- Le nuove chiavi sono in resources/combat.yml; nei server gia' installati valgono i default del codice anche senza aggiungerle.

## Modifica 13 – "stuff double" / dupe con sell, shop, settings
Segnalazione: "in settings e shop la roba raddoppia e con il sell si puo' duplicare premendo il bottone". Due cause trovate:
1. Listener duplicati dopo ogni `/smpcore reload` (managers/ModuleManager.java): i sistemi registrano i listener in onEnable ma non li
   rimuovevano mai, quindi dopo N reload ogni click veniva gestito N volte (acquisti doppi, sell doppio, toggle settings che si annullano...).
   Ora `disableAll()` fa `HandlerList.unregisterAll(plugin)` e `enable/disable` di un singolo modulo tracciano e tolgono i suoi listener.
2. Azioni GUI dentro l'evento di click: `sellAll()` chiudeva l'inventario e lo shop/settings aprivano o chiudevano menu mentre il click era
   ancora in corso; con uno stack sul cursore questo puo' duplicarlo. Ora le azioni girano al tick successivo, dopo aver verificato che
   il player abbia ancora lo stesso menu aperto: sell (conferma e menu worth/history/multi/progress), shop (menu e acquisto), settings (comando + chiusura).
- Restano da verificare/sistemare: task ripetuti e expansion PlaceholderAPI dei moduli dopo un reload; lo stesso pattern (open/close dentro il click)
  e' presente in auction, order, bounties, crates, pay, teams, tpa, homes, warps, rtp, reports, help, rules, media.

## Da testare (modifiche 12-13)
19. Uccidi lo stesso player 2 volte di fila: il premio arriva solo la prima; uccidi un alt sullo stesso IP: nessun premio; uccidi in duello: nessun premio.
20. Fai `/smpcore reload` 2-3 volte, poi compra qualcosa nello shop e cambia un toggle nei settings: deve valere una sola volta.
21. Prendi uno stack col cursore e clicca il bottone di conferma del /sell: lo stack non deve raddoppiare.

## Modifica 14 – file/classi Java "Astral*" -> "SmpCore*"
- 38 file rinominati (AstralSell -> SmpCoreSell, AstralHomes -> SmpCoreHomes, ..., astralMaintenance -> SmpCoreMaintenance)
  e aggiornati tutti i riferimenti nel codice (anche i metodi isAstralSpawner -> isSmpCoreSpawner, reloadAstralChat -> reloadSmpCoreChat).
- Nessun "astral" rimasto nei .java. Verificato: nomi classe = nome file, nessun duplicato nello stesso package, nessun import ambiguo.
- Base di lavoro: lo zip caricato (senza il package license/LicenseManager e senza license.yml, SmpCore.java carica direttamente il plugin).

## Modifica 15 – errori di compilazione preesistenti nel sorgente (artefatti di decompilazione)
Con javac (senza le librerie Paper/Vault, quindi solo gli errori di scope/flusso) il sorgente originale dava 25 errori:
- variabili gia' definite: ModerationModule.eco (amount/bal nei case), ProfileModule (tn/ok), AdminShopCommand (shop/cfg), TpaCommand (accepting/on),
  OrdersGui, AdminMenus, SpawnerPanelGui, TeamCommand (int i dentro un for(int i)).
- lambda che catturano variabili riassegnate: line/value/reward/copy/name in auction+baltop ChatInputListener, bounties/lb/teams GuiListener,
  order/InputUtil, crates/GuiListener, ec/EcStorage.
Tutti corretti con modifiche minime. Ora javac non segnala piu' errori di questo tipo.
NON ho potuto verificare gli errori di tipo (mancano le API Paper/Vault/PlaceholderAPI): il primo `mvn clean package` potrebbe mostrarne altri.

## Modifica 16 – deferral delle azioni GUI estesa a tutti i menu (nuovo utils/GuiSafe.java)
- `GuiSafe.defer(player, azione)` esegue l'azione al tick successivo solo se il player ha ancora lo stesso menu aperto (`GuiSafe.close(player)` per la sola chiusura).
- Applicato in: auction, order (menu, non la chest di consegna), bounties, baltop, lb, crates (conferma e anteprima), homes, teams, tpa, warps,
  pay (conferma), help, rules, media, reports, rtp, tools, voicechat, duels (coda), spawners (conferma vendita). Insieme a sell/shop/settings (modifica 13).
- Non toccati: GUI staff (moderation Sus/inventari, profile), stats, storico punizioni.

## Da testare (modifiche 14-16)
22. Il plugin parte e /smpcore reload funziona; comandi e placeholder rispondono.
23. Apri e usa: /ah, /order, /bounty, /crates (anteprima e conferma), /homes, /team, /tpa, /warp, /pay con conferma, /rtp gui.
24. Con uno stack sul cursore clicca i bottoni di questi menu: lo stack non deve raddoppiare.

## Modifica 17 – errori di compilazione da `mvn clean package` (93 errori riportati)
Tutti artefatti di decompilazione (tipi generici persi). Corretti:
- CoreSystemsModule (35 errori): `List list = this.shutdown` (raw) -> `List<Runnable> list`, cosi' `list.add(h::stop)` e' valido.
- Collezioni raw nei for-each (`for(UUID id : new HashSet(...))` dava Object): ora `new HashSet<>(...)`/`new ArrayList<>(...)`/`new HashMap<>(...)`/`new LinkedHashMap<>(...)`
  (23 punti: crates/HologramManager, holograms, duels, rtpq, rtpzone, teams, tpa, shards/BoosterManager, moderation, links, spawners/SpawnerGui, order/SmpCoreOrder).
- `deserialize(Map<?,?>)` -> `deserialize((Map)map)` in auction (AuctionManager, AuctionListing), order (Order, OrderManager), sell/HistoryManager.
- Comparator senza tipo: baltop/BalanceCache, order/OrderMenus (2), sell/SellMenus, teams/TeamMenus, moderation/SusManager.
- Altri: SusListener (cast Class<? extends Event>), LinksModule (`orElse((RoleRank)null)`), crates/DataManager, tpa/TpaManager (`Set<UUID>`),
  holograms/HologramsModule (`List<TextDisplay>` tipizzato).
- Variabili duplicate: catch con stesso nome in DoubleJumpModule, DuelsModule (3), WelcomerModule (2), wl/CommandFilterListener, StatsModule (8 sui metodi con parametro `t`);
  ProfileModule (`online` dichiarato piu' volte nello switch).
Se dopo questo giro `mvn` mostra ancora errori, sono di un'altra fase del compilatore: incollali e li sistemo.

