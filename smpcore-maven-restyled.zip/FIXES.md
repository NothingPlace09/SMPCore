# SmpCore 1.5.0 – fix applicati

Nome, package (`me.nothing.smpcore`), permessi e cartella dati NON sono stati modificati.
Controllo fatto: sintassi (tree-sitter). Non compilato con Maven: esegui `mvn clean package`.

## Modifica 1 – systems/spawners/SpawnerListener.java
- Dupe off-hand: `consumeSpawnerUnits` svuotava sempre la mano principale. Ora usa lo slot reale
  (`event.getHand()`), nuovo helper `removeFromHand`.
- `max-stack` ora rispettato anche al primo piazzamento (shift-place di uno stack grande).
  Se `perItem > max-stack` il piazzamento viene annullato con il messaggio `stack-limit`.

## Modifica 2 – systems/ec/EcStorage.java, EcGui.java, EcListener.java
- Dupe EC vanilla: l'import dal vanilla avviene una sola volta (flag `players.<uuid>.enderchest.seeded`)
  e il vanilla viene svuotato dopo l'import.
- Perdita item dopo downgrade di rank: la cache tiene l'array completo e `save()` conserva le righe
  che il rank attuale non mostra.
- Dupe owner + `/ecsee`: un EC puo' essere aperto da una sola persona alla volta
  (messaggio opzionale `ec-in-use` in messages, default incluso nel codice).

## Da testare in gioco (modifiche 1-2)
1. Spawner in off-hand accanto a uno uguale -> deve consumarsi l'item in off-hand, la mano principale resta intatta.
2. Shift-place di uno stack oltre `max-stack` -> piazza il massimo, il resto resta in mano.
3. EC: svuota l'EC custom con item nel vanilla -> riaprendo NON devono ricomparire.
4. `/ecsee` su un player con EC aperto -> messaggio "already open".

## Modifica 3 – systems/auction/AuctionManager.java
- Item perso alla scadenza: se il venditore era offline il listing veniva chiuso senza restituire l'item.
  Ora il listing viene chiuso solo quando l'item e' restituito; da scaduto non e' acquistabile ne' annullabile,
  il timer riprova finche' il venditore torna online.

## Modifica 4 – systems/order/GuiListener.java (+ resources/order/messages.yml)
- Cancellazione admin (slot 13) con owner offline: gli item consegnati e non ritirati venivano distrutti.
  Ora l'operazione viene bloccata (nessun rimborso, nessuna cancellazione) finche' l'owner e' offline.
- Nuova chiave messaggio `order-delete-owner-offline` (in resources/order/messages.yml). Se manca nel
  messages.yml gia' deployato viene usato il testo di default scritto nel codice (`MessageManager.sendOrDefault`).

## Modifica 5 – systems/sell/GuiListener.java
- Item perso nel /sell: qualunque GLASS_PANE nell'area vendita non veniva venduta ne' restituita.
  Ora l'esclusione e' basata sullo slot (solo il bottone conferma), non sul tipo di materiale.

## Da testare (modifiche 3-5)
5. Metti in vendita, fai scadere con il venditore offline, rientra: l'item deve tornare.
6. Order con item consegnati non ritirati, owner offline, delete admin: deve dare il messaggio e non cancellare.
7. /sell con glass pane di vari colori: vengono vendute (o restituite se in blacklist), mai perse.

## Modifica 6 – combat: alias/namespace e teleport in combattimento
- Nuovo `systems/combat/CombatGuard.java`: helper unico (`isBlocked` / `deny`) che chiede al combat se il player e' taggato.
- `CombatListener`: i `blocked-commands` ora risolvono namespace e alias del comando reale
  (`/h`, `/essentials:home`, `/minecraft:tp` erano un bypass). Supporta anche voci con sottocomando (es. `team home`).
- Teleport volontari ora negati in combat, sia all'avvio sia al completamento del countdown (se ti tagghi durante
  il countdown il teleport viene annullato): `/team home` (TeamCommand), homes + GUI homes (homes/TeleportManager),
  warps/spawn (warps/TeleportManager), tpa accept (TpaManager), rtp (rtp/RTPManager).
- Non toccati di proposito: i teleport dei duelli e dello staff (permesso `smpcore.system.combat.bypass`).

## Da testare (modifica 6)
8. Tagga un player, poi prova `/essentials:home`, un alias di `/home` e `/minecraft:tp`: devono essere bloccati.
9. In combat: `/team home`, click su una home nella GUI, `/tpa` accettato, `/rtp`: tutti negati con il messaggio del combat.
10. Avvia un `/home` con countdown e fatti colpire: il teleport si annulla.
11. Un duello deve iniziare e finire normalmente anche se i player sono taggati.

## Modifica 7 – systems/tools/ToolListener.java
- Protezioni: i blocchi extra di drill, shovel, treechopper e hoe venivano rotti con `breakNaturally` senza `BlockBreakEvent`
  (claim/WorldGuard/CoreProtect non li vedevano). Ora ogni blocco extra passa da un `BlockBreakEvent` (helper `breakChecked`)
  e viene rotto solo se nessuno lo annulla. Effetto collaterale voluto: log e statistiche vedono anche i blocchi extra.
- Il drill non rompe piu' blocchi che `breakNaturally` distruggeva ignorando la durezza: portali dell'End, deepslate rinforzata,
  command block chain/repeating, structure block, jigsaw, chest/barile/ender chest/hopper/dropper/dispenser/forni/brewing stand/beacon/shulker.
- Treechopper: le foglie non consumano piu' il limite di 64 blocchi (alberi grandi restavano a meta') e segue anche i tronchi in diagonale.
- Hoe: raccoglie solo colture vere (grano, carote, patate, barbabietole, nether wart, torchflower, pitcher) invece di ogni blocco Ageable.
- Non risolti: la zappa (tillCube) trasforma ancora in farmland senza evento di protezione; l'hoe non replanta.

## Modifica 8 – banner nei config (resources/**)
- In 205 file di config il banner ASCII "ASTRAL" e' stato sostituito con "SMPCORE" (font ANSI Shadow) e la scritta
  "STUDIO" e' stata rimossa.

## Da testare (modifica 7)
12. Drill vicino al confine di un claim/regione WorldGuard: i blocchi protetti non devono rompersi.
13. Drill contro portale dell'End / deepslate rinforzata / una chest: non vengono rotti.
14. Treechopper su un albero grande (dark oak/jungle): deve abbattere tutti i tronchi fino a 64.
15. Hoe su un campo con canna da zucchero o cactus al massimo: non vengono rotti.

## Modifica 9 – teleport/countdown bloccati cambiando mondo (nuovo utils/MoveCheck.java)
- `Location#distance/distanceSquared` lanciano IllegalArgumentException se i mondi differiscono (portale durante il
  countdown): il task falliva a ogni tick, la console si riempiva e la sessione restava bloccata ("busy"/"already teleporting").
  Ora `MoveCheck.movedMoreThan(...)` considera un cambio di mondo come "ti sei mosso" e annulla il teleport.
- Applicato in: TeamCommand (team home), homes/TeleportManager, warps/TeleportManager, TpaManager (countdown + onMove), RTPCountdown.

## Modifica 10 – rimossa la scritta STUDIO dai banner dei config (vedi sopra).

## Modifica 11 – tutti gli "astral" -> "smpcore"
- Config (resources/**): testi, nomi modulo nei messaggi di reload, MOTD, TAB, regole, help, media, webhook username.
  `AstralSMP` -> `SmpCore`, `Astral+` -> `SmpCore+`, `Astral studio` -> `SmpCore`, gli altri `Astral` -> `SmpCore`.
- Codice: solo dentro le STRINGHE Java (log "enabled/disabled", help, prefissi di default, ecc.).
- Rinominati anche identificatori funzionali (aggiorna permessi/config se li usi):
  - Permessi: `AstralHide.reload` -> `SmpCoreHide.reload`, `AstralMobs.admin/use` -> `SmpCoreMobs.admin/use`,
    `AstralRTPQ.admin` -> `SmpCoreRTPQ.admin`.
  - Comandi (plugin.yml + codice coerenti): `astralpunishment` -> `smpcorepunishment`, alias `astraltools` -> `smpcoretools`,
    alias `astralauction` -> `smpcoreauction`. Alias del comando principale: rimossi `astralcore` e `AstralSMP`.
  - Identificatori PlaceholderAPI: `astralkeyall/combat/teams/sell/shards/shop/billford` -> `smpcorekeyall/...`.
  - Tag scoreboard degli holo crates: `astralcrates_holo` -> `smpcorecrates_holo` (entita' non persistenti).
- NON modificati di proposito (ora i nomi di classe SONO stati rinominati, vedi modifica 14): il link `discord.gg/AstralSMP` in rules.yml
  (e' un invito reale), `database: astralreports` in reports.yml (rinominarlo crea un database nuovo e vuoto),
  (il LicenseManager non c'e' piu' in questo zip). README spawners: percorso corretto in `plugins/SmpCore/spawners/spawners/` e comando `/as reload`.

## Da testare (modifiche 9-11)
16. Avvia un /home (o /tpa, /team home, /warp, /rtp) con countdown ed entra in un portale: il teleport si annulla senza errori in console.
17. `/smpcorepunishment` (ex astralpunishment) risponde; `/tools` e `/ah` funzionano.
18. Controlla TAB, MOTD, /help, /rules: niente "Astral" residuo (tranne il link discord di rules.yml).

## Modifica 12 – kill-reward farmabile (combat)
- Il cooldown era solo per killer (30s): con un alt si prendevano shard all'infinito. Ora in `CombatManager.applyReward(killer, victim)`:
  - `kill-reward.same-victim-cooldown` (default 600s): la STESSA vittima non da' premio piu' di una volta ogni 10 minuti;
  - `kill-reward.block-same-ip` (default true): nessun premio se killer e vittima hanno lo stesso IP;
  - `kill-reward.exclude-duels` (default true): nessun premio per le morti nei duelli (DuelsModule espone `consumeDuelDeath`);
  - `kill-reward.exclude-combat-log` (default true): nessun premio se la vittima muore uscendo in combat.
- Le nuove chiavi sono in resources/combat.yml; nei server gia' installati valgono i default del codice anche senza aggiungerle.

## Modifica 13 – "stuff double" / dupe con sell, shop, settings
Segnalazione: "in settings e shop la roba raddoppia e con il sell si puo' duplicare premendo il bottone". Due cause trovate:
1. Listener duplicati dopo ogni `/smpcore reload` (managers/ModuleManager.java): i sistemi registrano i listener in onEnable ma non li
   rimuovevano mai, quindi dopo N reload ogni click veniva gestito N volte (acquisti doppi, sell doppio, toggle settings che si annullano...).
   Ora `disableAll()` fa `HandlerList.unregisterAll(plugin)` e `enable/disable` di un singolo modulo tracciano e tolgono i suoi listener.
2. Azioni GUI dentro l'evento di click: `sellAll()` chiudeva l'inventario e lo shop/settings aprivano o chiudevano menu mentre il click era
   ancora in corso; con uno stack sul cursore questo puo' duplicarlo. Ora le azioni girano al tick successivo, dopo aver verificato che
   il player abbia ancora lo stesso menu aperto: sell (conferma e menu worth/history/multi/progress), shop (menu e acquisto), settings (comando + chiusura).
- Restano da verificare/sistemare: task ripetuti e expansion PlaceholderAPI dei moduli dopo un reload; lo stesso pattern (open/close dentro il click)
  e' presente in auction, order, bounties, crates, pay, teams, tpa, homes, warps, rtp, reports, help, rules, media.

## Da testare (modifiche 12-13)
19. Uccidi lo stesso player 2 volte di fila: il premio arriva solo la prima; uccidi un alt sullo stesso IP: nessun premio; uccidi in duello: nessun premio.
20. Fai `/smpcore reload` 2-3 volte, poi compra qualcosa nello shop e cambia un toggle nei settings: deve valere una sola volta.
21. Prendi uno stack col cursore e clicca il bottone di conferma del /sell: lo stack non deve raddoppiare.

## Modifica 14 – file/classi Java "Astral*" -> "SmpCore*"
- 38 file rinominati (AstralSell -> SmpCoreSell, AstralHomes -> SmpCoreHomes, ..., astralMaintenance -> SmpCoreMaintenance)
  e aggiornati tutti i riferimenti nel codice (anche i metodi isAstralSpawner -> isSmpCoreSpawner, reloadAstralChat -> reloadSmpCoreChat).
- Nessun "astral" rimasto nei .java. Verificato: nomi classe = nome file, nessun duplicato nello stesso package, nessun import ambiguo.
- Base di lavoro: lo zip caricato (senza il package license/LicenseManager e senza license.yml, SmpCore.java carica direttamente il plugin).

## Modifica 15 – errori di compilazione preesistenti nel sorgente (artefatti di decompilazione)
Con javac (senza le librerie Paper/Vault, quindi solo gli errori di scope/flusso) il sorgente originale dava 25 errori:
- variabili gia' definite: ModerationModule.eco (amount/bal nei case), ProfileModule (tn/ok), AdminShopCommand (shop/cfg), TpaCommand (accepting/on),
  OrdersGui, AdminMenus, SpawnerPanelGui, TeamCommand (int i dentro un for(int i)).
- lambda che catturano variabili riassegnate: line/value/reward/copy/name in auction+baltop ChatInputListener, bounties/lb/teams GuiListener,
  order/InputUtil, crates/GuiListener, ec/EcStorage.
Tutti corretti con modifiche minime. Ora javac non segnala piu' errori di questo tipo.
NON ho potuto verificare gli errori di tipo (mancano le API Paper/Vault/PlaceholderAPI): il primo `mvn clean package` potrebbe mostrarne altri.

## Modifica 16 – deferral delle azioni GUI estesa a tutti i menu (nuovo utils/GuiSafe.java)
- `GuiSafe.defer(player, azione)` esegue l'azione al tick successivo solo se il player ha ancora lo stesso menu aperto (`GuiSafe.close(player)` per la sola chiusura).
- Applicato in: auction, order (menu, non la chest di consegna), bounties, baltop, lb, crates (conferma e anteprima), homes, teams, tpa, warps,
  pay (conferma), help, rules, media, reports, rtp, tools, voicechat, duels (coda), spawners (conferma vendita). Insieme a sell/shop/settings (modifica 13).
- Non toccati: GUI staff (moderation Sus/inventari, profile), stats, storico punizioni.

## Da testare (modifiche 14-16)
22. Il plugin parte e /smpcore reload funziona; comandi e placeholder rispondono.
23. Apri e usa: /ah, /order, /bounty, /crates (anteprima e conferma), /homes, /team, /tpa, /warp, /pay con conferma, /rtp gui.
24. Con uno stack sul cursore clicca i bottoni di questi menu: lo stack non deve raddoppiare.

## Modifica 17 – errori di compilazione da `mvn clean package` (93 errori riportati)
Tutti artefatti di decompilazione (tipi generici persi). Corretti:
- CoreSystemsModule (35 errori): `List list = this.shutdown` (raw) -> `List<Runnable> list`, cosi' `list.add(h::stop)` e' valido.
- Collezioni raw nei for-each (`for(UUID id : new HashSet(...))` dava Object): ora `new HashSet<>(...)`/`new ArrayList<>(...)`/`new HashMap<>(...)`/`new LinkedHashMap<>(...)`
  (23 punti: crates/HologramManager, holograms, duels, rtpq, rtpzone, teams, tpa, shards/BoosterManager, moderation, links, spawners/SpawnerGui, order/SmpCoreOrder).
- `deserialize(Map<?,?>)` -> `deserialize((Map)map)` in auction (AuctionManager, AuctionListing), order (Order, OrderManager), sell/HistoryManager.
- Comparator senza tipo: baltop/BalanceCache, order/OrderMenus (2), sell/SellMenus, teams/TeamMenus, moderation/SusManager.
- Altri: SusListener (cast Class<? extends Event>), LinksModule (`orElse((RoleRank)null)`), crates/DataManager, tpa/TpaManager (`Set<UUID>`),
  holograms/HologramsModule (`List<TextDisplay>` tipizzato).
- Variabili duplicate: catch con stesso nome in DoubleJumpModule, DuelsModule (3), WelcomerModule (2), wl/CommandFilterListener, StatsModule (8 sui metodi con parametro `t`);
  ProfileModule (`online` dichiarato piu' volte nello switch).
Se dopo questo giro `mvn` mostra ancora errori, sono di un'altra fase del compilatore: incollali e li sistemo.

## Modifica 18 – avvio senza dipendenze opzionali (errore reale visto su Paper 1.21.11)
- `NoClassDefFoundError: com/comphenix/protocol/events/PacketListener` in `ModuleManager.loadModules`: `AntiHealthModule` usa ProtocolLib e veniva
  istanziato sempre, anche senza ProtocolLib, e l'Error (non Exception) faceva fallire tutto il plugin.
  Ora ogni modulo e' creato con `registerSafely/putSafely` (try/catch Throwable): se manca una libreria il modulo viene saltato con un avviso
  (`System 'anti-health-indicator' skipped: ...`) e il resto parte. `onEnable/onDisable` dei moduli catturano anche gli Error.
- Vault resta OBBLIGATORIO: `CoreEconomy implements Economy`, quindi senza il plugin Vault il jar non parte (come l'originale).

## Modifica 19 – bug segnalati in gioco (libro di benvenuto, shard shop, asta, duelli, report)

**Libro di benvenuto (pagina Voice Chat):** il testo usava `&n` come fosse un "a capo", ma `&n` e' il codice
Minecraft per il sottolineato: risultava tutto sottolineato, senza spazi, con un residuo `&nl%&nl%` letterale.
Riscritto in resources/safety.yml con vere righe vuote, come la prima pagina.

**Shard shop, riga di prezzo doppia:** `ShopMenus.buildShopItem` aggiungeva sempre in automatico una riga
prezzo (es. "Shards200") anche quando la lore dell'oggetto la scriveva gia' a mano (caso di shop/categories/shards.yml,
che ha "Buy Price: 200x Shards" gia' scritto). Aggiunta l'opzione `show-price` (per shop o per singolo item,
default true) e disattivata in shards.yml.

**Asta: l'oggetto messo in vendita non compariva nel menu principale (solo in "my items"):** filtro/ordinamento/ricerca
dell'asta (MenuSession.FILTER/SORT/SEARCH) restano attivi per tutta la sessione del player e non si azzerano mai da
soli, mentre "my items" non applica alcun filtro. Se in precedenza avevi usato l'icona filtro/ricerca, un item
appena messo in vendita che non rientrava in quel filtro spariva silenziosamente dal browse. Ora `/ah` azzera
filtro/ordinamento/ricerca all'apertura, e il menu principale mostra un avviso quando la lista risulta vuota per
colpa del filtro invece di restare bianco.

**PvP impossibile tra membri dello stesso team in duello:** `TeamListener.onDamage` bloccava il danno tra membri
dello stesso team senza eccezioni, anche dentro un duello valido tra i due. Aggiunto `DuelsModule.isDuelingEachOther`
e usato in TeamListener per lasciar passare il danno quando i due si stanno duellando tra loro.

**Duelli accessibili senza un'arena configurata:** prima si poteva mettersi in coda (/duels) e avviare un duello
anche senza `arenaPos1`/`arenaPos2` impostati (lo scontro avveniva senza restrizione di bordo). Ora sia `/duels`
che il nuovo `/duel` rifiutano con un messaggio chiaro finche' l'arena non e' impostata.

**Mancava "/duel <player>" (sfida diretta):** esisteva solo "/duels" (coda casuale). C'erano dei file GUI
(duels/gui/direct-duel.yml, confirm-duel.yml) per una sfida diretta con selezione di mappa/tempo/regione, ma
non erano collegati a NESSUN codice: nessun comando o click li apriva mai. Invece di indovinare quello schema
mai implementato, ho aggiunto una versione semplice, testuale, basata su richiesta:
- `/duel <player>` manda una richiesta diretta (scade dopo 60s);
- `/duelaccept` / `/dueldeny` per accettare o rifiutare.
Quei due file .yml restano quindi inutilizzati: se vuoi la versione con GUI e selezione mappa/tempo, e' un lavoro
a parte (schema arene/biomi/tempo da definire), dimmelo se vuoi che lo implementi.

**Report: "Please choose a valid reason" anche scrivendo un motivo sensato (es. "Cheating"):** non e' un bug di
parsing, e' per design: `/report <player> <reason>` accetta SOLO un motivo esatto dalla lista in reports.yml
(Hacking, KillAura, Fly, X-Ray, Reach, AutoClicker, Spam, Advertising, ChatAbuse, InappropriateName) — "Cheating"
non c'e' (l'equivalente e' "KillAura" o "Hacking"). Il vero problema era che il messaggio di errore non diceva
quali fossero i motivi validi, quindi chi non usava il TAB restava bloccato senza capire perche'. Ora il messaggio
elenca i motivi validi. Se preferisci accettare testo libero invece di un elenco fisso, e' un cambiamento diverso,
dimmelo.

## Da testare (modifica 19)
25. Apri /safety (o equivalente) e controlla la pagina Voice Chat: niente sottolineato, testo su piu' righe.
26. Shard shop: sotto ogni spawner deve comparire una sola riga di prezzo.
27. Metti in vendita un item dopo aver usato il filtro/ricerca dell'asta, poi fai /ah: l'item deve comparire.
28. Duello 1v1 tra due membri dello stesso team: il danno deve funzionare.
29. Senza arena impostata: /duels e /duel devono rifiutare con un messaggio, non avviare il duello.
30. /duel NomeGiocatore, poi /duelaccept dall'altro lato: il duello deve partire. /dueldeny deve annullare.
31. /report NomeGiocatore Cheating: ora deve elencare i motivi validi invece del solo "Please choose a valid reason.".

## Modifica 20 – bug dei duelli segnalati (wand, spettatore bloccato, uscita dall'arena)

**Kill reward "non funziona":** verificato che NON e' un bug — e' il comportamento voluto dalla modifica 12
(`block-same-ip: true` di default): se uccidi con lo stesso IP (es. un secondo client sulla tua rete) non arriva
nessun premio ne' messaggio, di proposito, per evitare il farm con un alt. Se vuoi permetterlo comunque, imposta
`block-same-ip: false` in combat.yml.

**Wand delle arene non faceva nulla:** esisteva il comando `/duelsadmin wand` che dava l'item, ma NESSUN listener
gestiva il click con quell'item (dead code). Ora left-click imposta pos1, right-click imposta pos2, con conferma
nello stesso stile grigio/azzurro degli altri messaggi ("Arena pos1 set: x, y, z", poi "Duel arena is ready" quando
entrambe le posizioni sono impostate). Lo stesso messaggio di conferma e' stato aggiunto anche a `/duelsadmin setpos1/2`.

**Vincitore fa /leave, il perdente resta bloccato in arena da spettatore:** il timer del loot era condiviso tra
vincitore e perdente; se il vincitore usciva prima con /leave, quel timer veniva cancellato ma il perdente non
veniva mai riportato fuori (restava in modalita' spettatore nell'arena, potenzialmente per sempre). Ora i due sono
collegati esplicitamente: se uno dei due esce durante il loot, l'altro viene riportato fuori subito.

**Nessun blocco fisico dell'arena (elytra, perle):** l'unica protezione era il world border GLOBALE del mondo (non
solo dei duellanti), che tra l'altro parte solo 60s dopo l'inizio del duello e comunque in vanilla non blocca
davvero l'attraversamento (spinge indietro con danno nel tempo). Ora, mentre sei in un duello attivo o stai
guardando come spettatore: l'elytra non plana, le perle dell'ender non si possono lanciare, e se esci comunque dai
confini di pos1/pos2 (con un margine) vieni riportato dentro con un avviso.
**Nota importante non risolta:** il world border "che si stringe" a meta' duello resta quello GLOBALE del mondo,
quindi durante un duello si stringe per TUTTI i giocatori in quel mondo, non solo per i due duellanti. Sistemarlo
per bene richiede un world border per-player (l'API Paper lo supporta), ma e' un cambiamento piu' ampio che non ho
toccato in questo giro: dimmi se vuoi che lo faccia.

**Il resto della configurazione arene (FAWE, temi multipli, item vietati, cancel-break-outside-arena):**
`duels/config.yml` descrive un sistema molto piu' ambizioso (arene multiple da schematic FastAsyncWorldEdit,
clonate ad ogni match, con item vietati e protezione dei blocchi) che pero' NON e' mai stato implementato nel
codice: e' rimasto solo nel file di config, inapplicato. Il sistema realmente funzionante e' quello a singola
arena (pos1/pos2) gia' visto. Costruire il sistema a schematic multiplo e' un lavoro grosso a parte (serve FAWE
installato, un mondo dedicato, un allocatore di istanze): non l'ho fatto, dimmelo se lo vuoi.

## Modifica 21 – /duel con GUI mappa/tempo/regione (EU) e sistema Ranked

**"/duel <player>" ora apre una GUI** (i file duels/gui/direct-duel.yml e confirm-duel.yml esistevano gia' nelle
risorse ma non erano collegati a NESSUN codice: anche questo era rimasto solo un file inutilizzato). La GUI mostra
mappa e tempo, che puoi cambiare cliccando (elenco cosmetico configurabile in codice: 4 mappe, 4 tempi), e la
regione, sempre "EU Central" — tutto puramente visivo, senza alcun effetto su matchmaking o connessione, come
richiesto. Al bersaglio si apre automaticamente la GUI di conferma con le stesse informazioni (fallback: se non e'
disponibile, resta comunque valido il testo in chat con /duelaccept e /dueldeny di prima).

**Sistema Ranked.** "/duels" ora apre prima una scelta tra Normal Queue e Ranked Queue. La Ranked riusa la stessa
GUI queue.yml, aggiungendo una riga "Rank: <nome>" nella sezione statistiche.
- Elo: si parte da 1000. Vincendo si guadagnano 100-120 Elo (casuale), perdendo se ne perdono 100 (mai sotto 1000).
- Rank: Bronze, Silver, Gold, Diamond, Mythic, Legendary, Champion, ciascuno con 3 livelli da 500 Elo
  (es. Bronze 1: 1000-1499, Bronze 2: 1500-1999, ... Champion 3: 10000+), esattamente come specificato.
- Matchmaking ranked diviso in due fasce che non si incontrano mai: Bronze-Diamond e Mythic-Champion.
- Un pareggio ranked non cambia l'Elo di nessuno dei due.
- Elo/wins/losses/streak sono salvati in duels/stats.yml (stesso file gia' usato per le statistiche esistenti,
  ora con un campo elo in piu' per player). Il placeholder %elo% nella GUI, prima fisso a "1000" per chiunque,
  ora mostra l'Elo reale.
- Vincere/perdere un duello RANKED manda anche un messaggio con il nuovo Elo e rank.
- I duelli diretti (/duel) e quelli con /duels -> Normal restano sempre non classificati (nessun cambio di Elo).

## Da testare (modifiche 20-21)
32. /duelsadmin wand, poi left-click e right-click su due blocchi: devono comparire i messaggi di conferma.
33. Fai un duello, il vincitore fa /leave prima che scada il loot: il perdente deve tornare a spawn subito, non restare bloccato.
34. Durante un duello prova a planare con elytra e a lanciare una perla: entrambi devono essere bloccati. Prova anche a correre fuori dai bordi dell'arena: devi essere respinto dentro.
35. /duel NomeGiocatore: deve aprirsi la GUI con mappa/tempo/regione EU; cambia mappa e tempo, poi manda la richiesta: al bersaglio deve aprirsi la GUI di conferma.
36. /duels: deve aprirsi la scelta Normal/Ranked. Normal Queue deve comportarsi come prima. Ranked Queue deve mostrare il tuo rank.
37. Fai un duello ranked e vincilo: controlla che l'Elo salga di 100-120 e il rank eventualmente cambi; perdilo: controlla che scenda di 100 (mai sotto 1000).
38. Con un secondo player di rank molto diverso (es. uno Diamond e uno Champion), verifica che il matchmaking ranked non li accoppi mai.

## Modifica 22 – arene nominate, schematic opzionali, escape-teleport (invece di push-back)

**Arene nominate.** Prima esisteva una sola arena globale (pos1/pos2). Ora puoi salvarne quante ne vuoi:
1. Imposta pos1/pos2 (wand o /duelsadmin setpos1/setpos2) e, opzionalmente, spawn1/spawn2 (dove partono i due
   combattenti: /duelsadmin setspawn1/setspawn2).
2. `/duelsadmin savearena <nome>` salva il tutto come arena nominata (in duels/arenas.yml) e resetta pos1/pos2/spawn1/spawn2
   cosi' puoi impostare subito la prossima.
3. `/duelsadmin listarenas` / `/duelsadmin deletearena <nome>` per gestirle.
Le arene nominate compaiono con il loro vero nome nel selettore "Map" della GUI di `/duel <player>` (prima erano
4 nomi finti fissi, usati ancora come fallback se non hai salvato nessuna arena). Per le code (/duels Normal e
Ranked) l'arena viene scelta a caso tra quelle salvate. Se non salvi nessuna arena nominata, tutto continua a
funzionare come prima con l'unica arena pos1/pos2 (retrocompatibile).

**Mondo delle arene via config.** Riuso la chiave che esisteva gia' (ma non era mai stata collegata a nulla) in
duels/config.yml: `arena.duel-world` (default: "duels"). Se impostata, sia `/duelsadmin savearena` (con un avviso,
non un blocco) sia la scelta casuale per le code considerano SOLO le arene in quel mondo. Se il tuo mondo si
chiama diversamente (o vuoi permettere arene in qualsiasi mondo), cambia/svuota quella chiave.

**Schematic opzionali (SPERIMENTALE, non testato).** `/duelsadmin setschematic <arena> <file.schem>` collega uno
schematic (in duels/schematics/) a un'arena nominata. Se e' collegato: prima di ogni match lo schematic viene
incollato con l'angolo inferiore su pos1 (richiede il plugin WorldEdit o FastAsyncWorldEdit installato), e dopo il
match la zona (pos1-pos2) viene ripulita a blocchi d'aria con la normale API di Bukkit (nessuna dipendenza extra
per la pulizia). Le arene SENZA schematic non vengono mai toccate/ripulite (restano come le costruisci a mano).
**Importante:** a differenza di tutto il resto di questo lavoro, l'incolla via WorldEdit e' scritto per reflection
pura (stesso approccio gia' usato nel plugin per WorldGuard, quindi NESSUNA dipendenza Maven aggiunta) perche' qui
non ho ne' WorldEdit ne' un server per testarlo. Se non incolla nulla, guarda il log della console: probabilmente
una firma dell'API e' cambiata tra versioni di WorldEdit e va corretta (dimmi l'errore esatto).

**Escape-teleport invece di push-back.** Su tua richiesta: chi esce dai confini dell'arena non viene piu' "respinto"
sul posto (sensazione di freeze), ma teletrasportato al punto impostato con `/duelsadmin setspawn` (nuovo, diverso
da setspawn1/2 che sono dove iniziano i combattenti). Se stavi combattendo attivamente conta come abbandono/forfeit
(vince l'avversario, senza pero' far cadere il tuo inventario visto che resti online); se eri spettatore o vincitore
in fase di loot, esci semplicemente da quella fase (e se eri l'ultimo rimasto, l'altro viene comunque riportato
fuori come nella modifica 20). Se non imposti /duelsadmin setspawn, si usa lo spawn generico del server.

## Modifica 23 – fix: i click nella GUI aperta dopo /duels non facevano nulla
Causa trovata: aprire una NUOVA inventory (con `Player#openInventory`) mentre un'altra del modulo era gia' aperta
fa scattare un `InventoryCloseEvent` sincrono per quella vecchia. Il codice scriveva "questa e' la GUI ora aperta"
PRIMA di chiamare `openInventory(...)`, quindi quel close-event (scattato dentro la chiamata stessa) cancellava
subito dopo l'informazione appena scritta: risultato, la GUI si vedeva ma i click non venivano piu' riconosciuti.
Succedeva passando da "/duels" (scelta modalita') alla coda vera, e cambiando mappa/tempo nella GUI di "/duel
<player>". Sistemato scrivendo lo stato DOPO aver aperto l'inventory in tutti e 4 i punti coinvolti.

## Modifica 24 – GUI di /duels editabile (duels/gui/mode-select.yml)
La scelta Normal/Ranked di "/duels" era scritta a mano in Java. Ora, come le altre GUI del modulo, legge da un file:
resources/duels/gui/mode-select.yml (title, rows, nome/lore/materiale dei 2 item). Gli slot 11 (Normal) e 15
(Ranked) restano fissi (sono quelli letti dal click handler), il resto e' liberamente modificabile. Se il file
manca, si ripiega sulla versione precedente scritta in Java.

## Modifica 25 – "/team gui"
Confrontato con il vecchio plugin Teams standalone (stesso autore "nothing") che hai caricato: e' risultato che
SmpCore ha GIA' lo stesso identico menu (stesso design: la tua squadra, membri, permessi, pvp toggle — TeamMenus
gia' esistente), semplicemente senza un sottocomando "gui" esplicito (si apriva solo con "/team" senza argomenti
o come fallback su un sottocomando non riconosciuto). Aggiunto "/team gui" come sottocomando esplicito e nel tab
completion, che apre esattamente quel menu — nessun altro codice duplicato o nuovo.

## Da testare (modifiche 22-25)
39. /duelsadmin setpos1, setpos2, savearena TestArena: controlla che compaia in /duelsadmin listarenas.
40. /duel su un altro player: nel selettore Map deve comparire "TestArena" (non piu' i nomi finti). Manda la richiesta e fai partire il duello: i due devono comparire dentro quell'arena specifica.
41. /duels -> Normal e poi Ranked: i click su Search/Cancel/Wait Time devono funzionare in entrambe (prima il bug faceva sembrare la GUI "morta").
42. /duelsadmin setspawn in un punto a scelta, poi durante un duello prova a uscire dai confini: devi essere teletrasportato li', non respinto sul posto; se eri in un duello attivo deve contare come sconfitta per l'avversario.
43. Se hai WorldEdit/FAWE: /duelsadmin setschematic TestArena arena.schem (con un file gia' presente in duels/schematics/), poi avvia un match su quell'arena e controlla in console se compare un errore di paste.
44. Modifica resources/duels/gui/mode-select.yml (es. cambia un nome) e verifica che il cambiamento compaia in gioco dopo un reload.
45. /team gui: deve aprire lo stesso menu di sempre.

## Modifica 26 – ultimi residui "astral" (minifont nascosto + link/database)
- Trovati e sistemati 2 residui che il controllo testuale precedente (modifica 11) non poteva vedere: in
  `resources/tools/config.yml` e `resources/tools/messages.yml` il prefisso dei messaggi era scritto in "minifont"
  (piccole maiuscole Unicode, es. ᴀ ꜱ ᴛ invece delle lettere normali): "ᴀꜱᴛʀᴀʟᴛᴏᴏʟꜱ" (ASTRALTOOLS) -> "ꜱᴍᴘᴄᴏʀᴇᴛᴏᴏʟꜱ"
  (SMPCORETOOLS), stessa mappatura di caratteri gia' usata nel resto del plugin (member manager, ender chest, ecc).
- `reports.yml`: `database: astralreports` -> `smpcorereports` (su richiesta, si riparte vuoti: se questo server
  usa gia' MySQL con dati nel vecchio database "astralreports", vanno migrati a mano, altrimenti con `type: SQLITE`
  di default questa chiave non e' nemmeno usata).
- `rules.yml`: `discord.gg/AstralSMP` -> `discord.gg/SmpCore`. ATTENZIONE: "SmpCore" e' un placeholder, non un
  invito Discord reale — sostituiscilo con il tuo vero codice invito, altrimenti il link in game non funziona.
- Ricontrollato tutto il progetto sia in testo normale sia decodificando il minifont: nessun altro residuo trovato.

## Modifica 27 – hologram "Top Ranked", spettatore che scappa = /leave, verifica elo su morte da soli

**Hologram "Top Ranked":** avevi ragione, l'avevi gia' fatto (mio errore, avevo cercato "topranked"/"top_ranked"
e non l'ho trovato al primo giro). C'e' in resources/holograms.yml, voce `duelsranked`, stesso stile identico
alle altre classifiche (money, shards, ecc): titolo "ᴛᴏᴘ ʀᴀɴᴋᴇᴅ", top 10 con `%smpcore_duels_top_name_<1-10>%` /
`%smpcore_duels_top_value_<1-10>%` (valore tipo "Bronze 1 - 1107"), riga del viewer con `%smpcore_duels_rank%` /
`%smpcore_duels_value%`. Nessuna modifica necessaria qui.

**Spettatore (perdente) che esce dai confini dell'arena = esattamente come /leave.** Prima, uscendo dai confini,
uno spettatore veniva mandato al "duel escape spawn" (/duelsadmin setspawn). Ora va allo spawn del server, la
stessa destinazione di un /leave manuale — richiesto esplicitamente. Il vincitore che esce dai confini durante il
loot va ancora al duel escape spawn (sta comunque abbandonando il loot in anticipo, comportamento diverso da un
/leave "pulito"): se vuoi lo stesso trattamento anche per lui, dimmelo.

**Elo sulla morte "da soli" (caduta, lava, mob...) durante un ranked: controllato, NON ho trovato un bug.**
`onDeath` in DuelsModule assegna l'elo controllando solo "questo giocatore era in un duello attivo quando e'
morto?" (`this.inDuel.get(id)`), MAI come e' morto: non controlla ne' l'arma ne' se c'e' un killer. Lo stesso vale
per l'abbandono per disconnessione e per la fuga dall'arena (forfeit). Quindi, a leggere il codice, una morte per
caduta o lava dentro un duello ranked dovrebbe gia' dare l'elo all'avversario esattamente come una morte per PvP.
Non ho trovato in nessun altro punto del plugin (safety, combat) una protezione che impedisca la morte per caduta
o lava dentro l'arena, quindi non riesco a spiegare perche' tu abbia visto il contrario.
Un possibile equivoco: il modulo COMBAT ha un sistema SEPARATO di kill-reward (shards, non elo) che PUO' davvero
dare la ricompensa solo per un'uccisione PvP reale (killer != null) — e' un sistema diverso da quello dei duelli,
volutamente cosi'. Se il problema che hai visto riguarda quello (shards), non e' un bug.
Se invece parli davvero dell'Elo dei duelli e resta un problema concreto, dimmi esattamente come hai fatto morire
il giocatore (comando /kill, caduta, lava, mob) e cosa hai visto (nessun messaggio? numero sbagliato?): con questo
codice davanti non trovo la causa, mi serve un caso preciso per continuare a cercare.

## Da testare (modifica 27)
46. Durante un duello, da spettatore (dopo essere morto/aver perso), prova a uscire dai confini dell'arena: deve mandarti allo spawn del server, non al duel escape spawn.
47. In un duello RANKED, lasciati morire per caduta o lava (senza che l'avversario ti colpisca): controlla se l'avversario riceve comunque l'Elo e il messaggio di vittoria ranked.

