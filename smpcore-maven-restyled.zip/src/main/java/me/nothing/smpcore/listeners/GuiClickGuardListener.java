package me.nothing.smpcore.listeners;

import org.bukkit.event.Listener;

public class GuiClickGuardListener implements Listener {
}
