package me.nothing.smpcore.utils;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class TextUtil {
   private static final Pattern HEX_AMP = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final Pattern HEX_HASH = Pattern.compile("(?<!&)#([A-Fa-f0-9]{6})");
   private static final Pattern HEX_TAG = Pattern.compile("<#([A-Fa-f0-9]{6})>");
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('§').build();

   private TextUtil() {
   }

   public static String color(String input) {
      if (input == null) {
         return "";
      } else {
         String s = HEX_TAG.matcher(input).replaceAll("&#$1");
         s = s.replaceAll("</#[A-Fa-f0-9]{6}>", "");
         Matcher m = HEX_AMP.matcher(s);
         StringBuffer sb = new StringBuffer();

         while(m.find()) {
            String hex = m.group(1);
            StringBuilder rep = new StringBuilder("§x");

            for(char c : hex.toCharArray()) {
               rep.append('§').append(c);
            }

            m.appendReplacement(sb, Matcher.quoteReplacement(rep.toString()));
         }

         m.appendTail(sb);
         s = sb.toString();
         m = HEX_HASH.matcher(s);
         sb = new StringBuffer();

         while(m.find()) {
            String hex = m.group(1);
            StringBuilder rep = new StringBuilder("§x");

            for(char c : hex.toCharArray()) {
               rep.append('§').append(c);
            }

            m.appendReplacement(sb, Matcher.quoteReplacement(rep.toString()));
         }

         m.appendTail(sb);
         return sb.toString().replace('&', '§');
      }
   }

   public static Component component(String input) {
      return LEGACY.deserialize(color(input)).decoration(TextDecoration.ITALIC, false);
   }

   public static List<Component> componentList(List<String> lines) {
      List<Component> out = new ArrayList();
      if (lines == null) {
         return out;
      } else {
         for(String line : lines) {
            out.add(component(line));
         }

         return out;
      }
   }

   public static void send(CommandSender sender, String msg) {
      if (sender != null && msg != null) {
         sender.sendMessage(component(msg));
      }
   }

   public static void actionBar(Player player, String msg) {
      if (player != null && msg != null) {
         HotbarUtil.send(player, component(msg));
      }
   }
}
