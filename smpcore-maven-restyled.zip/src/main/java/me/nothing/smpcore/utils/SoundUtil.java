package me.nothing.smpcore.utils;

import me.nothing.smpcore.systems.settings.SettingsModule;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private SoundUtil() {
   }

   public static void play(Player player, Location location, Sound sound, float volume, float pitch) {
      if (player != null && location != null && sound != null) {
         try {
            SettingsModule settings = SettingsModule.get();
            if (settings != null && settings.isSoundsOff(player.getUniqueId())) {
               return;
            }
         } catch (Throwable t) {
         }

         player.playSound(location, sound, volume, pitch);
      }
   }
}
