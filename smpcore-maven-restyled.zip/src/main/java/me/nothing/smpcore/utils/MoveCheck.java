package me.nothing.smpcore.utils;

import org.bukkit.Location;

/**
 * Controllo "si e' mosso troppo" sicuro tra mondi diversi.
 * Location#distance/distanceSquared lanciano IllegalArgumentException se i mondi differiscono
 * (es. il player entra in un portale durante il countdown): il task falliva a ogni tick e la sessione restava bloccata.
 */
public final class MoveCheck {
   private MoveCheck() {
   }

   public static boolean movedMoreThan(Location now, Location start, double maxDistance) {
      return movedMoreThanSquared(now, start, maxDistance * maxDistance);
   }

   public static boolean movedMoreThanSquared(Location now, Location start, double maxDistanceSquared) {
      if (now != null && start != null) {
         return now.getWorld() != null && now.getWorld().equals(start.getWorld()) ? now.distanceSquared(start) > maxDistanceSquared : true;
      } else {
         return false;
      }
   }
}
