package me.nothing.smpcore.utils;

import me.nothing.smpcore.SmpCore;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Esegue le azioni dei menu al tick SUCCESSIVO al click.
 * Aprire o chiudere inventari mentre l'InventoryClickEvent e' ancora in corso (soprattutto con uno stack sul cursore)
 * puo' duplicare lo stack. L'azione parte solo se il player ha ancora aperto lo stesso menu del click: un secondo click
 * "vecchio" nello stesso tick non viene eseguito due volte.
 */
public final class GuiSafe {
   private GuiSafe() {
   }

   /** Chiude l'inventario al tick successivo (con gli stessi controlli di defer). */
   public static void close(Player player) {
      defer(player, player::closeInventory);
   }

   public static void defer(Player player, Runnable action) {
      SmpCore core = SmpCore.get();
      if (core != null && player != null) {
         final Inventory top = player.getOpenInventory().getTopInventory();
         Bukkit.getScheduler().runTask(core, () -> {
            if (player.isOnline() && top.equals(player.getOpenInventory().getTopInventory())) {
               action.run();
            }

         });
      } else {
         action.run();
      }
   }
}
