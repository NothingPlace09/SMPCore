package me.nothing.smpcore.modules;

public interface Module {
   String getName();

   void onEnable();

   void onDisable();

   void reload();
}
