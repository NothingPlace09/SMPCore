package me.nothing.smpcore.managers;

import java.util.function.Supplier;
import org.bukkit.plugin.RegisteredListener;
import org.bukkit.event.HandlerList;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.commands.CommandRegistry;
import me.nothing.smpcore.listeners.GuiClickGuardListener;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.CoreSystemsModule;
import me.nothing.smpcore.systems.antihealth.AntiHealthModule;
import me.nothing.smpcore.systems.doublejump.DoubleJumpModule;
import me.nothing.smpcore.systems.duels.DuelsModule;
import me.nothing.smpcore.systems.holograms.HologramsModule;
import me.nothing.smpcore.systems.homes.HomesModule;
import me.nothing.smpcore.systems.links.LinksModule;
import me.nothing.smpcore.systems.moderation.ModerationModule;
import me.nothing.smpcore.systems.msg.MsgModule;
import me.nothing.smpcore.systems.nightvision.NightVisionModule;
import me.nothing.smpcore.systems.pay.PayModule;
import me.nothing.smpcore.systems.phantoms.PhantomsModule;
import me.nothing.smpcore.systems.profile.ProfileModule;
import me.nothing.smpcore.systems.punishment2.PunishmentModule;
import me.nothing.smpcore.systems.rtpzone.RtpZoneModule;
import me.nothing.smpcore.systems.scoreboard.ScoreboardModule;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.systems.stats.StatsModule;
import me.nothing.smpcore.systems.tab.TabModule;
import me.nothing.smpcore.systems.voicechat.VoiceChatModule;
import me.nothing.smpcore.systems.welcomer.WelcomerModule;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ModuleManager {
   private final SmpCore plugin;
   private final Map<String, Module> modules = new HashMap();

   public ModuleManager(SmpCore plugin) {
      this.plugin = plugin;
   }

   private final Map<String, List<RegisteredListener>> moduleListeners = new HashMap();

   /**
    * Crea il modulo dentro un try/catch: se manca una dipendenza opzionale (es. ProtocolLib per anti-health-indicator)
    * il NoClassDefFoundError e' un Error e prima faceva fallire l'intero plugin. Ora il modulo viene saltato con un avviso.
    */
   private void registerSafely(String key, Supplier<Module> factory) {
      try {
         this.registerIfEnabled(key, (Module)factory.get());
      } catch (Throwable t) {
         this.plugin.getLogger().warning("System '" + key + "' skipped: " + t.getClass().getSimpleName() + " - " + t.getMessage());
      }

   }

   private void putSafely(String key, Supplier<Module> factory) {
      try {
         this.modules.put(key, (Module)factory.get());
      } catch (Throwable t) {
         this.plugin.getLogger().warning("System '" + key + "' skipped: " + t.getClass().getSimpleName() + " - " + t.getMessage());
      }

   }

   public void loadModules() {
      this.modules.clear();
      this.registerSafely("msg", () -> new MsgModule(this.plugin));
      this.registerSafely("pay", () -> new PayModule(this.plugin));
      this.registerSafely("stats", () -> new StatsModule(this.plugin));
      this.registerSafely("anti-health-indicator", () -> new AntiHealthModule(this.plugin));
      this.registerSafely("settings", () -> new SettingsModule(this.plugin));
      this.registerSafely("scoreboard", () -> new ScoreboardModule(this.plugin));
      this.putSafely("nightvision", () -> new NightVisionModule(this.plugin));
      this.putSafely("tab", () -> new TabModule(this.plugin));
      this.registerSafely("homes", () -> new HomesModule(this.plugin));
      this.registerSafely("moderation", () -> new ModerationModule(this.plugin));
      this.registerSafely("welcomer", () -> new WelcomerModule(this.plugin));
      this.registerSafely("doublejump", () -> new DoubleJumpModule(this.plugin));
      this.registerSafely("profile", () -> new ProfileModule(this.plugin));
      this.registerSafely("duels", () -> new DuelsModule(this.plugin));
      this.registerSafely("links", () -> new LinksModule(this.plugin));
      this.registerSafely("voicechat", () -> new VoiceChatModule(this.plugin));
      this.registerSafely("punishment", () -> new PunishmentModule(this.plugin));
      this.registerSafely("phantoms", () -> new PhantomsModule(this.plugin));
      this.registerSafely("holograms", () -> new HologramsModule(this.plugin));
      this.registerSafely("rtp", () -> new RtpZoneModule(this.plugin));
      this.putSafely("core-systems", () -> new CoreSystemsModule(this.plugin));

      for(Module m : this.modules.values()) {
         try {
            m.onEnable();
            this.plugin.getLogger().info("Enabled system: " + m.getName());
         } catch (Throwable e) {
            this.plugin.getLogger().log(Level.WARNING, "Failed enabling " + m.getName(), e);
         }
      }

      try {
         this.plugin.getServer().getPluginManager().registerEvents(new GuiClickGuardListener(), this.plugin);
      } catch (Exception e) {
      }

      this.registerFallbacks();
      this.plugin.getLogger().info("Loaded " + this.modules.size() + " system modules.");
   }

   private void registerFallbacks() {
      CommandRegistry reg = this.plugin.commands();
      String[] cmds = new String[]{"ah", "sell", "sellmulti", "worth", "worthtoggle", "sellaxe", "sellhistory", "orders", "crates", "baltop", "billford", "bounty", "teams", "tpa", "tpahere", "tpaccept", "tpadeny", "warps", "setwarp", "delwarp", "shop", "shards", "spawners", "tools", "echest", "rtp", "rtpqueue", "daily", "help", "hide", "keyall", "media", "mobs", "rules", "report", "reports", "maintenance", "combat", "chat", "clearchat", "lb", "punish", "chainmail", "teamchat", "ordertoggle", "teamtoggle", "fastcrystal"};

      for(String cmd : cmds) {
         reg.registerHandlerIfAbsent(cmd, (sender, args) -> {
            String sys = this.systemOf(cmd);
            if (sys != null && !this.plugin.configs().isEnabled(sys)) {
               sender.sendMessage("§cSystem disabled: " + sys);
               return true;
            } else {
               sender.sendMessage("§8[§bSmp§fCore§8] §7/" + cmd + " §fis available. Full GUI handlers load with system pack.");
               if (sender instanceof Player) {
                  Player p = (Player)sender;
                  Inventory inv = Bukkit.createInventory((InventoryHolder)null, 27, "§8" + cmd.toUpperCase());
                  ItemStack item = new ItemStack(Material.BOOK);
                  ItemMeta meta = item.getItemMeta();
                  if (meta != null) {
                     meta.setDisplayName("§b/" + cmd);
                     meta.setLore(List.of("§7System: §f" + (sys == null ? cmd : sys), "§7Enable in main.config.yml"));
                     item.setItemMeta(meta);
                  }

                  inv.setItem(13, item);
                  p.openInventory(inv);
               }

               return true;
            }
         });
      }

   }

   private String systemOf(String cmd) {
      String str;
      switch (cmd) {
         case "ah":
            str = "auction-house";
            break;
         case "sell":
         case "sellmulti":
         case "worth":
         case "worthtoggle":
         case "sellaxe":
         case "sellhistory":
            str = "sell";
            break;
         case "orders":
         case "ordertoggle":
            str = "orders";
            break;
         case "crates":
            str = "crates";
            break;
         case "baltop":
            str = "baltop";
            break;
         case "billford":
            str = "billford";
            break;
         case "bounty":
            str = "bounties";
            break;
         case "teams":
         case "teamchat":
         case "teamtoggle":
            str = "teams";
            break;
         case "tpa":
         case "tpahere":
         case "tpaccept":
         case "tpadeny":
            str = "tpa";
            break;
         case "warps":
         case "setwarp":
         case "delwarp":
            str = "warps";
            break;
         case "shop":
            str = "shop";
            break;
         case "shards":
            str = "shards";
            break;
         case "spawners":
            str = "spawners";
            break;
         case "tools":
            str = "tools";
            break;
         case "echest":
            str = "enderchest";
            break;
         case "rtp":
            str = "rtp";
            break;
         case "rtpqueue":
         case "rtpq":
         case "rtpzone":
            str = "rtp";
            break;
         case "daily":
            str = "daily";
            break;
         case "help":
            str = "help";
            break;
         case "hide":
            str = "hide";
            break;
         case "keyall":
            str = "keyall";
            break;
         case "media":
            str = "media";
            break;
         case "mobs":
            str = "mobs";
            break;
         case "rules":
            str = "rules";
            break;
         case "report":
         case "reports":
            str = "reports";
            break;
         case "maintenance":
            str = "maintenance";
            break;
         case "combat":
            str = "combat";
            break;
         case "chat":
         case "clearchat":
            str = "chat";
            break;
         case "lb":
            str = "leaderboards";
            break;
         case "punish":
            str = "punishment";
            break;
         case "chainmail":
            str = "chainmail";
            break;
         case "fastcrystal":
            str = "settings";
            break;
         default:
            str = null;
      }

      return str;
   }

   private void registerIfEnabled(String key, Module module) {
      if (this.plugin.configs().isEnabled(key)) {
         this.modules.put(key.toLowerCase(), module);
      }

   }

   public void reloadModules() {
      this.disableAll();
      this.loadModules();
   }

   public void disableAll() {
      for(Module m : this.modules.values()) {
         try {
            m.onDisable();
         } catch (Throwable e) {
            this.plugin.getLogger().log(Level.WARNING, "Error disabling " + m.getName(), e);
         }
      }

      // FIX "stuff double": i sistemi registrano i listener in onEnable ma non li rimuovevano mai. Dopo ogni
      // /smpcore reload ogni click/evento veniva gestito N volte (acquisti shop doppi, sell/settings doppi...).
      HandlerList.unregisterAll(this.plugin);
      this.moduleListeners.clear();
      this.modules.clear();
   }

   /** Listener del plugin registrati finora (per sapere cosa ha aggiunto un singolo modulo). */
   private List<RegisteredListener> listenerSnapshot() {
      return new ArrayList(HandlerList.getRegisteredListeners(this.plugin));
   }

   public void enable(String name) {
      String key = name.toLowerCase().replace("_", "-");
      if (!this.modules.containsKey(key)) {
         this.plugin.configs().setEnabled(key, true);
         List<RegisteredListener> before = this.listenerSnapshot();
         Module m = this.create(key);
         if (m != null) {
            this.modules.put(key, m);
            m.onEnable();
            List<RegisteredListener> added = this.listenerSnapshot();
            added.removeAll(before);
            this.moduleListeners.put(key, added);
         }

      }
   }

   public void disable(String name) {
      String key = name.toLowerCase().replace("_", "-");
      Module m = (Module)this.modules.remove(key);
      if (m != null) {
         m.onDisable();
         List<RegisteredListener> added = (List)this.moduleListeners.remove(key);
         if (added != null) {
            for(HandlerList handlers : HandlerList.getHandlerLists()) {
               for(RegisteredListener rl : added) {
                  handlers.unregister(rl);
               }
            }
         }
      }

      this.plugin.configs().setEnabled(key, false);
   }

   private Module create(String key) {
      Object obj;
      switch (key) {
         case "msg" -> obj = new MsgModule(this.plugin);
         case "pay" -> obj = new PayModule(this.plugin);
         case "stats" -> obj = new StatsModule(this.plugin);
         case "settings" -> obj = new SettingsModule(this.plugin);
         case "scoreboard" -> obj = new ScoreboardModule(this.plugin);
         case "nightvision" -> obj = new NightVisionModule(this.plugin);
         case "tab" -> obj = new TabModule(this.plugin);
         case "homes" -> obj = new HomesModule(this.plugin);
         case "links" -> obj = new LinksModule(this.plugin);
         case "voicechat" -> obj = new VoiceChatModule(this.plugin);
         default -> obj = null;
      }

      return (Module)obj;
   }

   public boolean isLoaded(String name) {
      return this.modules.containsKey(name.toLowerCase());
   }

   public Module get(String name) {
      return (Module)this.modules.get(name.toLowerCase());
   }
}
