package me.nothing.smpcore.economy;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import net.milkbowl.vault.economy.EconomyResponse.ResponseType;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

public final class CoreEconomy implements Economy {
   private static CoreEconomy INSTANCE;
   private static Economy vault;
   private static JavaPlugin plugin;
   private static YamlConfiguration yaml;
   private static File file;
   private static boolean vaultReady;
   private static boolean registeredSelf;

   private CoreEconomy() {
   }

   public static void init(JavaPlugin core) {
      plugin = core;
      vaultReady = false;
      vault = null;
      registeredSelf = false;
      INSTANCE = new CoreEconomy();

      try {
         if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
            if (rsp != null && rsp.getProvider() != null && !(rsp.getProvider() instanceof CoreEconomy)) {
               vault = (Economy)rsp.getProvider();
               vaultReady = true;
               core.getLogger().info("Economy: Vault provider " + vault.getName());
               return;
            }
         }
      } catch (Throwable t) {
         core.getLogger().warning("Vault economy lookup failed: " + t.getMessage());
      }

      loadYaml();

      try {
         if (Bukkit.getPluginManager().getPlugin("Vault") != null) {
            Bukkit.getServicesManager().register(Economy.class, INSTANCE, core, ServicePriority.Normal);
            registeredSelf = true;
            vault = INSTANCE;
            vaultReady = true;
            core.getLogger().info("Economy: registered SmpCore built-in economy with Vault (no external economy plugin required).");
         } else {
            core.getLogger().warning("Economy: Vault not found — using built-in balances only. Install Vault for full compatibility.");
         }
      } catch (Throwable t) {
         core.getLogger().warning("Economy: could not register Vault provider: " + t.getMessage());
      }

   }

   private static void loadYaml() {
      file = new File(plugin.getDataFolder(), "economy.yml");
      yaml = file.exists() ? YamlConfiguration.loadConfiguration(file) : new YamlConfiguration();
      if (!file.exists()) {
         yaml.set("settings.starting-balance", (double)10000.0F);
         save();
      }

   }

   public static boolean isReady() {
      return vaultReady || yaml != null;
   }

   public static boolean usingVault() {
      return vaultReady;
   }

   public static double balanceOf(OfflinePlayer player) {
      if (vaultReady && vault != null && !(vault instanceof CoreEconomy)) {
         return vault.getBalance(player);
      } else {
         ensureYaml();
         double start = yaml.getDouble("settings.starting-balance", (double)10000.0F);
         return yaml.getDouble("balances." + String.valueOf(player.getUniqueId()), start);
      }
   }

   public static double balanceOf(Player player) {
      return balanceOf((OfflinePlayer)player);
   }

   public static boolean hasFunds(Player player, double amount) {
      return balanceOf(player) >= amount;
   }

   public static boolean take(Player player, double amount) {
      if (amount < (double)0.0F) {
         return false;
      } else if (vaultReady && vault != null && !(vault instanceof CoreEconomy)) {
         return vault.withdrawPlayer(player, amount).transactionSuccess();
      } else {
         ensureYaml();
         double bal = balanceOf(player);
         if (bal < amount) {
            return false;
         } else {
            yaml.set("balances." + String.valueOf(player.getUniqueId()), bal - amount);
            save();
            return true;
         }
      }
   }

   public static boolean give(OfflinePlayer player, double amount) {
      if (amount < (double)0.0F) {
         return false;
      } else if (vaultReady && vault != null && !(vault instanceof CoreEconomy)) {
         return vault.depositPlayer(player, amount).transactionSuccess();
      } else {
         ensureYaml();
         double bal = balanceOf(player);
         yaml.set("balances." + String.valueOf(player.getUniqueId()), bal + amount);
         save();
         return true;
      }
   }

   public static boolean give(Player player, double amount) {
      return give((OfflinePlayer)player, amount);
   }

   public static boolean give(UUID uuid, double amount) {
      return give(Bukkit.getOfflinePlayer(uuid), amount);
   }

   public static void setBalance(OfflinePlayer player, double amount) {
      if (player != null) {
         if (amount < (double)0.0F) {
            amount = (double)0.0F;
         }

         if (vaultReady && vault != null && !(vault instanceof CoreEconomy)) {
            double cur = vault.getBalance(player);
            if (cur > amount) {
               vault.withdrawPlayer(player, cur - amount);
            } else if (amount > cur) {
               vault.depositPlayer(player, amount - cur);
            }

         } else {
            ensureYaml();
            yaml.set("balances." + String.valueOf(player.getUniqueId()), amount);
            save();
         }
      }
   }

   public static String formatMoney(double amount) {
      return compact(amount);
   }

   public static String compact(double amount) {
      String sign = amount < (double)0.0F ? "-" : "";
      double a = Math.abs(amount);
      if (a >= 1.0E12) {
         return sign + trim(a / 1.0E12) + "T";
      } else if (a >= (double)1.0E9F) {
         return sign + trim(a / (double)1.0E9F) + "B";
      } else if (a >= (double)1000000.0F) {
         return sign + trim(a / (double)1000000.0F) + "M";
      } else if (a >= (double)1000.0F) {
         return sign + trim(a / (double)1000.0F) + "K";
      } else {
         return a == (double)((long)a) ? sign + String.valueOf((long)a) : sign + String.format("%.2f", a);
      }
   }

   private static String trim(double v) {
      if (v >= (double)100.0F) {
         return String.valueOf((long)v);
      } else {
         return v >= (double)10.0F ? String.format("%.1f", v).replace(".0", "") : String.format("%.2f", v).replaceAll("0+$", "").replaceAll("\\.$", "");
      }
   }

   private static void ensureYaml() {
      if (yaml == null) {
         loadYaml();
      }

   }

   private static void save() {
      try {
         if (file != null && yaml != null) {
            yaml.save(file);
         }
      } catch (Exception e) {
         if (plugin != null) {
            plugin.getLogger().warning("economy.yml save failed: " + e.getMessage());
         }
      }

   }

   public boolean isEnabled() {
      return true;
   }

   public String getName() {
      return "SmpCore";
   }

   public boolean hasBankSupport() {
      return false;
   }

   public int fractionalDigits() {
      return 2;
   }

   public String format(double amount) {
      return compact(amount);
   }

   public String currencyNamePlural() {
      return "coins";
   }

   public String currencyNameSingular() {
      return "coin";
   }

   public boolean hasAccount(String playerName) {
      return true;
   }

   public boolean hasAccount(OfflinePlayer player) {
      return true;
   }

   public boolean hasAccount(String playerName, String worldName) {
      return true;
   }

   public boolean hasAccount(OfflinePlayer player, String worldName) {
      return true;
   }

   public double getBalance(String playerName) {
      return balanceOf(Bukkit.getOfflinePlayer(playerName));
   }

   public double getBalance(OfflinePlayer player) {
      return balanceOf(player);
   }

   public double getBalance(OfflinePlayer player, String world) {
      return balanceOf(player);
   }

   public double getBalance(String playerName, String world) {
      return balanceOf(Bukkit.getOfflinePlayer(playerName));
   }

   public boolean has(String playerName, double amount) {
      return this.getBalance(playerName) >= amount;
   }

   public boolean has(OfflinePlayer player, double amount) {
      return balanceOf(player) >= amount;
   }

   public boolean has(String playerName, String worldName, double amount) {
      return this.has(playerName, amount);
   }

   public boolean has(OfflinePlayer player, String worldName, double amount) {
      return this.has(player, amount);
   }

   public EconomyResponse withdrawPlayer(String playerName, double amount) {
      OfflinePlayer op = Bukkit.getOfflinePlayer(playerName);
      return this.withdrawPlayer(op, amount);
   }

   public EconomyResponse withdrawPlayer(OfflinePlayer player, double amount) {
      if (amount < (double)0.0F) {
         return new EconomyResponse((double)0.0F, this.getBalance(player), ResponseType.FAILURE, "Negative amounts not allowed");
      } else {
         ensureYaml();
         double bal = balanceOf(player);
         if (bal < amount) {
            return new EconomyResponse((double)0.0F, bal, ResponseType.FAILURE, "Insufficient funds");
         } else {
            yaml.set("balances." + String.valueOf(player.getUniqueId()), bal - amount);
            save();
            return new EconomyResponse(amount, bal - amount, ResponseType.SUCCESS, (String)null);
         }
      }
   }

   public EconomyResponse withdrawPlayer(String playerName, String worldName, double amount) {
      return this.withdrawPlayer(playerName, amount);
   }

   public EconomyResponse withdrawPlayer(OfflinePlayer player, String worldName, double amount) {
      return this.withdrawPlayer(player, amount);
   }

   public EconomyResponse depositPlayer(String playerName, double amount) {
      return this.depositPlayer(Bukkit.getOfflinePlayer(playerName), amount);
   }

   public EconomyResponse depositPlayer(OfflinePlayer player, double amount) {
      if (amount < (double)0.0F) {
         return new EconomyResponse((double)0.0F, this.getBalance(player), ResponseType.FAILURE, "Negative amounts not allowed");
      } else {
         ensureYaml();
         double bal = balanceOf(player);
         yaml.set("balances." + String.valueOf(player.getUniqueId()), bal + amount);
         save();
         return new EconomyResponse(amount, bal + amount, ResponseType.SUCCESS, (String)null);
      }
   }

   public EconomyResponse depositPlayer(String playerName, String worldName, double amount) {
      return this.depositPlayer(playerName, amount);
   }

   public EconomyResponse depositPlayer(OfflinePlayer player, String worldName, double amount) {
      return this.depositPlayer(player, amount);
   }

   public EconomyResponse createBank(String name, String player) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse createBank(String name, OfflinePlayer player) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse deleteBank(String name) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse bankBalance(String name) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse bankHas(String name, double amount) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse bankWithdraw(String name, double amount) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse bankDeposit(String name, double amount) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse isBankOwner(String name, String playerName) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse isBankOwner(String name, OfflinePlayer player) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse isBankMember(String name, String playerName) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public EconomyResponse isBankMember(String name, OfflinePlayer player) {
      return new EconomyResponse((double)0.0F, (double)0.0F, ResponseType.NOT_IMPLEMENTED, "Banks not supported");
   }

   public List<String> getBanks() {
      return Collections.emptyList();
   }

   public boolean createPlayerAccount(String playerName) {
      return true;
   }

   public boolean createPlayerAccount(OfflinePlayer player) {
      return true;
   }

   public boolean createPlayerAccount(String playerName, String worldName) {
      return true;
   }

   public boolean createPlayerAccount(OfflinePlayer player, String worldName) {
      return true;
   }

   public static double parseAmount(String raw) {
      if (raw == null) {
         return (double)-1.0F;
      } else {
         String s = raw.trim().toLowerCase(Locale.ROOT).replace(",", "");
         if (s.isEmpty()) {
            return (double)-1.0F;
         } else {
            double mult = (double)1.0F;
            char last = s.charAt(s.length() - 1);
            if (last == 'k') {
               mult = (double)1000.0F;
               s = s.substring(0, s.length() - 1);
            } else if (last == 'm') {
               mult = (double)1000000.0F;
               s = s.substring(0, s.length() - 1);
            } else if (last == 'b') {
               mult = (double)1.0E9F;
               s = s.substring(0, s.length() - 1);
            }

            try {
               double v = Double.parseDouble(s.trim()) * mult;
               return !(v < (double)0.0F) && !Double.isNaN(v) && !Double.isInfinite(v) ? v : (double)-1.0F;
            } catch (Exception e) {
               return (double)-1.0F;
            }
         }
      }
   }
}
