package me.nothing.smpcore;

import java.io.File;
import java.io.InputStream;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import me.nothing.smpcore.commands.CommandRegistry;
import me.nothing.smpcore.data.PlayerDataStore;
import me.nothing.smpcore.data.SystemDataStore;
import me.nothing.smpcore.economy.CoreEconomy;
import me.nothing.smpcore.managers.ConfigManager;
import me.nothing.smpcore.managers.MessageManager;
import me.nothing.smpcore.managers.ModuleManager;
import me.nothing.smpcore.placeholders.SmpCorePlaceholders;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public final class SmpCore extends JavaPlugin {
   private static SmpCore instance;
   private ConfigManager configManager;
   private MessageManager messageManager;
   private ModuleManager moduleManager;
   private CommandRegistry commandRegistry;
   private boolean fullyEnabled = false;

   public void onEnable() {
      instance = this;
      this.loadPlugin();
   }

   private void logCompatibility() {
      String server = Bukkit.getBukkitVersion();
      if (Bukkit.getPluginManager().getPlugin("ViaVersion") != null) {
         this.getLogger().info("ViaVersion detected — cross-version client support enabled.");
      }

      if (Bukkit.getPluginManager().getPlugin("ViaBackwards") != null) {
         this.getLogger().info("ViaBackwards detected — older client support enabled.");
      }

      if (Bukkit.getPluginManager().getPlugin("Geyser-Spigot") != null || Bukkit.getPluginManager().getPlugin("floodgate") != null) {
         this.getLogger().info("Geyser/Floodgate detected — Bedrock compatibility enabled.");
      }

      this.getLogger().info("Server compatibility: " + server);
   }

   private void loadPlugin() {
      if (!this.fullyEnabled) {
         this.fullyEnabled = true;
         this.getLogger().info("Loading SmpCore...");
         this.logCompatibility();
         File mainCfg = new File(this.getDataFolder(), "main.config.yml");
         if (!mainCfg.exists()) {
            try {
               InputStream in = this.getResource("main.config.yml");
               if (in != null) {
                  Files.copy(in, mainCfg.toPath(), new CopyOption[0]);
               }
            } catch (Exception e) {
            }
         }

         File oldConfig = new File(this.getDataFolder(), "config.yml");
         if (oldConfig.exists()) {
            oldConfig.delete();
         }

         PlayerDataStore.init(this);
         SystemDataStore.init(this);
         this.configManager = new ConfigManager(this);
         CoreEconomy.init(this);
         this.messageManager = new MessageManager(this);
         this.commandRegistry = new CommandRegistry(this);
         this.commandRegistry.registerAll();
         this.moduleManager = new ModuleManager(this);
         this.moduleManager.loadModules();
         this.commandRegistry.registerAll();
         if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            (new SmpCorePlaceholders(this)).register();
            this.getLogger().info("PlaceholderAPI hooked (%smpcore_*%).");
         }

         this.getLogger().info("SmpCore by nothing enabled.");
      }
   }

   public void onDisable() {
      if (this.moduleManager != null) {
         this.moduleManager.disableAll();
      }

      this.fullyEnabled = false;
      instance = null;
      this.getLogger().info("SmpCore disabled.");
   }

   public void reloadAll() {
      if (this.fullyEnabled) {
         this.reloadConfig();
         if (this.configManager != null) {
            this.configManager.reload();
         }

         if (this.messageManager != null) {
            this.messageManager.reload();
         }

         if (this.moduleManager != null) {
            this.moduleManager.reloadModules();
         }

      }
   }

   public static SmpCore get() {
      return instance;
   }

   public boolean isFullyEnabled() {
      return this.fullyEnabled;
   }

   public ConfigManager configs() {
      return this.configManager;
   }

   public MessageManager messages() {
      return this.messageManager;
   }

   public ModuleManager modules() {
      return this.moduleManager;
   }

   public CommandRegistry commands() {
      return this.commandRegistry;
   }

}
