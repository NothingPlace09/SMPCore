package me.nothing.smpcore.systems.antihealth;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.PacketType.Play.Server;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketEvent;
import com.comphenix.protocol.wrappers.WrappedAttribute;
import com.comphenix.protocol.wrappers.WrappedDataValue;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

public final class AntiHealthModule implements Module {
   private final SmpCore plugin;
   private FileConfiguration config;
   private ProtocolManager protocol;
   private PacketAdapter listener;

   public AntiHealthModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "anti-health-indicator";
   }

   public void onEnable() {
      File file = new File(this.plugin.getDataFolder(), "antihealthindicator.yml");
      if (!file.exists()) {
         try {
            this.plugin.saveResource("antihealthindicator.yml", false);
         } catch (Exception e) {
         }
      }

      this.config = YamlConfiguration.loadConfiguration(file);
      if (this.config.getBoolean("enabled", true)) {
         if (Bukkit.getPluginManager().getPlugin("ProtocolLib") == null) {
            this.plugin.getLogger().warning("ProtocolLib not found. Anti health indicator disabled.");
         } else {
            this.protocol = ProtocolLibrary.getProtocolManager();
            this.listener = new PacketAdapter(this.plugin, new PacketType[]{Server.ENTITY_METADATA, Server.UPDATE_ATTRIBUTES, Server.UPDATE_HEALTH}) {
               public void onPacketSending(PacketEvent event) {
                  if (AntiHealthModule.this.config.getBoolean("enabled", true)) {
                     try {
                        Entity target = (Entity)event.getPacket().getEntityModifier(event).read(0);
                        if (!(target instanceof Player) || target.equals(event.getPlayer())) {
                           return;
                        }

                        if (event.getPacketType() == Server.ENTITY_METADATA) {
                           List<WrappedDataValue> values = (List)event.getPacket().getDataValueCollectionModifier().read(0);
                           if (values == null) {
                              return;
                           }

                           List<WrappedDataValue> filtered = new ArrayList(values.size());

                           for(WrappedDataValue value : values) {
                              if (value.getIndex() != 9) {
                                 filtered.add(value);
                              }
                           }

                           event.getPacket().getDataValueCollectionModifier().write(0, filtered);
                        } else if (event.getPacketType() == Server.UPDATE_ATTRIBUTES) {
                           List<WrappedAttribute> values = (List)event.getPacket().getAttributeCollectionModifier().read(0);
                           if (values == null) {
                              return;
                           }

                           List<WrappedAttribute> filtered = new ArrayList(values.size());

                           for(WrappedAttribute value : values) {
                              if (!"generic.max_health".equalsIgnoreCase(value.getAttributeKey()) && !"minecraft:generic.max_health".equalsIgnoreCase(value.getAttributeKey())) {
                                 filtered.add(value);
                              }
                           }

                           event.getPacket().getAttributeCollectionModifier().write(0, filtered);
                        }
                     } catch (Throwable t) {
                     }

                  }
               }
            };
            this.protocol.addPacketListener(this.listener);
         }
      }
   }

   public void reload() {
      File file = new File(this.plugin.getDataFolder(), "antihealthindicator.yml");
      this.config = YamlConfiguration.loadConfiguration(file);
   }

   public void onDisable() {
      if (this.protocol != null && this.listener != null) {
         this.protocol.removePacketListener(this.listener);
      }

      this.listener = null;
      this.protocol = null;
   }
}
