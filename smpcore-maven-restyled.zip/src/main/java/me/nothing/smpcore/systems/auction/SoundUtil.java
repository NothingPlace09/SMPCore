package me.nothing.smpcore.systems.auction;

import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private SoundUtil() {
   }

   public static void play(Player player, String path) {
      if (player != null && SmpCoreAuction.get().getConfig().getBoolean(path + ".enabled", true)) {
         String name = SmpCoreAuction.get().getConfig().getString(path + ".sound", "UI_BUTTON_CLICK");
         if (name != null && !name.isEmpty()) {
            try {
               Sound sound = Sound.valueOf(name.toUpperCase().replace('.', '_').replace('-', '_'));
               float volume = (float)SmpCoreAuction.get().getConfig().getDouble(path + ".volume", (double)1.0F);
               float pitch = (float)SmpCoreAuction.get().getConfig().getDouble(path + ".pitch", (double)1.0F);
               me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), sound, volume, pitch);
            } catch (Exception e) {
               try {
                  me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
               } catch (Exception e2) {
               }
            }

         }
      }
   }

   public static void click(Player player) {
      play(player, "sounds.gui-click");
   }

   public static void error(Player player) {
      play(player, "sounds.error");
   }

   public static void sold(Player player) {
      play(player, "sounds.sold");
   }

   public static void bought(Player player) {
      play(player, "sounds.bought");
   }

   public static void open(Player player) {
      play(player, "sounds.gui-open");
   }
}
