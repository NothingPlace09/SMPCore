package me.nothing.smpcore.systems;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.auction.SmpCoreAuction;
import me.nothing.smpcore.systems.auction.AuctionCommand;
import me.nothing.smpcore.systems.baltop.SmpCoreBaltop;
import me.nothing.smpcore.systems.baltop.BaltopCommand;
import me.nothing.smpcore.systems.billford.SmpCoreBillford;
import me.nothing.smpcore.systems.billford.BillfordCommand;
import me.nothing.smpcore.systems.bounties.SmpCoreBounties;
import me.nothing.smpcore.systems.bounties.BountyCommand;
import me.nothing.smpcore.systems.chainmail.ChainmailListener;
import me.nothing.smpcore.systems.chat2.SmpCoreChat;
import me.nothing.smpcore.systems.chat2.SmpCoreChatCommand;
import me.nothing.smpcore.systems.chat2.ChatGamesCommand;
import me.nothing.smpcore.systems.chat2.ClearChatCommand;
import me.nothing.smpcore.systems.combat.SmpCoreCombat;
import me.nothing.smpcore.systems.combat.CombatCommand;
import me.nothing.smpcore.systems.crates.SmpCoreCrates;
import me.nothing.smpcore.systems.crates.CrateCommand;
import me.nothing.smpcore.systems.ec.SmpCoreEC;
import me.nothing.smpcore.systems.ec.EcCommand;
import me.nothing.smpcore.systems.help.SmpCoreHelp;
import me.nothing.smpcore.systems.help.HelpCommand;
import me.nothing.smpcore.systems.hide.SmpCoreHide;
import me.nothing.smpcore.systems.hide.HideCommand;
import me.nothing.smpcore.systems.keyall.SmpCoreKeyall;
import me.nothing.smpcore.systems.keyall.KeyallCommand;
import me.nothing.smpcore.systems.lb.SmpCoreLeaderboards;
import me.nothing.smpcore.systems.lb.LeaderboardCommand;
import me.nothing.smpcore.systems.maintenance.MaintenanceCommand;
import me.nothing.smpcore.systems.maintenance.SmpCoreMaintenance;
import me.nothing.smpcore.systems.media.SmpCoreMedia;
import me.nothing.smpcore.systems.media.DiscordCommand;
import me.nothing.smpcore.systems.media.MediaCommand;
import me.nothing.smpcore.systems.media.StoreCommand;
import me.nothing.smpcore.systems.mobs.SmpCoreMobs;
import me.nothing.smpcore.systems.mobs.SmpCoreMobsCommand;
import me.nothing.smpcore.systems.mobs.MobsToggleCommand;
import me.nothing.smpcore.systems.order.SmpCoreOrder;
import me.nothing.smpcore.systems.order.OrdersCommand;
import me.nothing.smpcore.systems.reports.SmpCoreReports;
import me.nothing.smpcore.systems.reports.ReportCommand;
import me.nothing.smpcore.systems.reports.ReportsCommand;
import me.nothing.smpcore.systems.rtp.SmpCoreRTP;
import me.nothing.smpcore.systems.rtp.RTPCommand;
import me.nothing.smpcore.systems.rtpq.SmpCoreRTPQ;
import me.nothing.smpcore.systems.rtpq.RTPQueueCommand;
import me.nothing.smpcore.systems.rules.SmpCoreRules;
import me.nothing.smpcore.systems.rules.RulesCommand;
import me.nothing.smpcore.systems.safety.SmpCoreSafety;
import me.nothing.smpcore.systems.safety.SafetyCommand;
import me.nothing.smpcore.systems.sell.SmpCoreSell;
import me.nothing.smpcore.systems.sell.HistoryCommand;
import me.nothing.smpcore.systems.sell.SellAxeCommand;
import me.nothing.smpcore.systems.sell.SellCommand;
import me.nothing.smpcore.systems.sell.SellMultiCommand;
import me.nothing.smpcore.systems.sell.WorthCommand;
import me.nothing.smpcore.systems.sell.WorthToggleCommand;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.systems.shards.SmpCoreShards;
import me.nothing.smpcore.systems.shards.ShardsCommand;
import me.nothing.smpcore.systems.shop.SmpCoreShop;
import me.nothing.smpcore.systems.shop.ShopCommand;
import me.nothing.smpcore.systems.spawners.SmpCoreCommand;
import me.nothing.smpcore.systems.spawners.SmpCoreSpawners;
import me.nothing.smpcore.systems.teams.SmpCoreTeams;
import me.nothing.smpcore.systems.teams.TeamCommand;
import me.nothing.smpcore.systems.tools.SmpCoreTools;
import me.nothing.smpcore.systems.tools.ToolsCommand;
import me.nothing.smpcore.systems.tpa.SmpCoreTPA;
import me.nothing.smpcore.systems.tpa.TpaCommand;
import me.nothing.smpcore.systems.warps.SmpCoreWarps;
import me.nothing.smpcore.systems.warps.WarpCommand;
import me.nothing.smpcore.systems.wl.SmpCoreWhitelister;
import me.nothing.smpcore.systems.wl.WhitelistCommand;
import me.nothing.smpcore.utils.TextUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public class CoreSystemsModule implements Module {
   private final SmpCore plugin;
   private final List<Runnable> shutdown = new ArrayList();

   public CoreSystemsModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "core-systems";
   }

   public void onEnable() {
      this.boot("auction-house", () -> {
         SmpCoreAuction h = new SmpCoreAuction();
         h.init(this.plugin, this.data("auction"));
         h.start();
         this.bind("ah", new AuctionCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("baltop", () -> {
         SmpCoreBaltop h = new SmpCoreBaltop();
         h.init(this.plugin, this.data("baltop"));
         h.start();
         this.bind("baltop", new BaltopCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("orders", () -> {
         SmpCoreOrder h = new SmpCoreOrder();
         h.init(this.plugin, this.data("order"));
         h.start();
         this.bind("orders", new OrdersCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("shop", () -> {
         SmpCoreShop h = new SmpCoreShop();
         h.init(this.plugin, this.data("shop"));
         h.start();
         this.bind("shop", new ShopCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("sell", () -> {
         SmpCoreSell h = new SmpCoreSell();
         h.init(this.plugin, this.data("sell"));
         h.start();
         this.bind("sell", new SellCommand(h));
         this.bind("worth", new WorthCommand(h));
         this.bind("worthtoggle", new WorthToggleCommand(h));
         this.bind("sellhistory", new HistoryCommand(h));

         try {
            this.bind("sellmulti", new SellMultiCommand(h));
         } catch (Throwable t) {
         }

         try {
            this.bind("sellaxe", new SellAxeCommand(h, h.getSellAxe()));
         } catch (Throwable t) {
         }

         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("leaderboards", () -> {
         SmpCoreLeaderboards h = new SmpCoreLeaderboards();
         h.init(this.plugin, this.data("lb"));
         h.start();
         this.bind("lb", new LeaderboardCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("billford", () -> {
         SmpCoreBillford h = new SmpCoreBillford();
         h.init(this.plugin, this.data("billford"));
         h.start();
         this.bind("billford", new BillfordCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("bounties", () -> {
         SmpCoreBounties h = new SmpCoreBounties();
         h.init(this.plugin, this.data("bounties"));
         h.start();
         this.bind("bounty", new BountyCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("crates", () -> {
         SmpCoreCrates h = new SmpCoreCrates();
         h.init(this.plugin, this.data("crates"));
         h.start();
         CrateCommand crateCmd = new CrateCommand(h);
         this.bind("crates", crateCmd);
         this.bind("crate", crateCmd);
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("shards", () -> {
         SmpCoreShards h = new SmpCoreShards();
         h.init(this.plugin, this.data("shards"));
         h.start();
         this.bind("shards", new ShardsCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("teams", () -> {
         SmpCoreTeams h = new SmpCoreTeams();
         h.init(this.plugin, this.data("teams"));
         h.start();
         TeamCommand cmd = new TeamCommand(h);
         this.bind("teams", cmd);
         this.bind("team", cmd);
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("tpa", () -> {
         SmpCoreTPA h = new SmpCoreTPA();
         h.init(this.plugin, this.data("tpa"));
         h.start();
         TpaCommand cmd = new TpaCommand(h);
         this.bind("tpa", cmd);
         this.bind("tpahere", cmd);
         this.bind("tpaccept", cmd);
         this.bind("tpadeny", cmd);
         this.bind("tpdeny", cmd);
         this.bind("tpacancel", cmd);
         this.bind("tpauto", cmd);
         this.bind("tpatoggle", cmd);
         this.bind("tpaheretoggle", cmd);
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("warps", () -> {
         SmpCoreWarps h = new SmpCoreWarps();
         h.init(this.plugin, this.data("warps"));
         h.start();
         WarpCommand cmd = new WarpCommand(h);
         this.bind("warps", cmd);
         this.bind("warp", cmd);
         this.bind("setwarp", cmd);
         this.bind("delwarp", cmd);
         this.bind("spawn", cmd);
         this.bind("setspawn", cmd);
         this.bind("delspawn", cmd);
         this.bind("afk", cmd);
         this.bind("setafk", cmd);
         this.bind("delafk", cmd);
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("tools", () -> {
         SmpCoreTools h = new SmpCoreTools();
         h.init(this.plugin, this.data("tools"));
         h.start();
         this.bind("tools", new ToolsCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("spawners", () -> {
         SmpCoreSpawners h = new SmpCoreSpawners();
         h.init(this.plugin, this.data("spawners"));
         h.start();
         SmpCoreCommand asCmd = new SmpCoreCommand(h);
         this.bind("spawners", asCmd);
         this.bind("as", asCmd);
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("chat", () -> {
         SmpCoreChat h = new SmpCoreChat();
         h.init(this.plugin, this.data("chat2"));
         h.start();
         this.bind("chat", new SmpCoreChatCommand(h));
         this.plugin.commands().registerHandler("chattoggle", (sender, args) -> {
            if (sender instanceof Player pl) {
               boolean on = h.getChatManager().togglePersonal(pl.getUniqueId());

               try {
                  Module mod = this.plugin.modules().get("settings");
                  if (mod instanceof SettingsModule sm) {
                     if (on && sm.isChatOff(pl.getUniqueId())) {
                        sm.toggleChatOff(pl.getUniqueId());
                     }

                     if (!on && !sm.isChatOff(pl.getUniqueId())) {
                        sm.toggleChatOff(pl.getUniqueId());
                     }
                  }
               } catch (Throwable t) {
               }

               if (on) {
                  TextUtil.send(pl, "&#00a3fbGeneral chat &#00FF00enabled&7.");
               } else {
                  TextUtil.send(pl, "&#00a3fbGeneral chat &#fc0404disabled&7.");
               }

               return true;
            } else {
               return true;
            }
         });

         try {
            this.bind("clearchat", new ClearChatCommand(h));
         } catch (Throwable t) {
         }

         try {
            this.bind("chatgames", new ChatGamesCommand(h));
         } catch (Throwable t) {
         }

         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("combat", () -> {
         SmpCoreCombat h = new SmpCoreCombat();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("combat", new CombatCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("enderchest", () -> {
         SmpCoreEC h = new SmpCoreEC();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("echest", new EcCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("help", () -> {
         SmpCoreHelp h = new SmpCoreHelp();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("help", new HelpCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("hide", () -> {
         SmpCoreHide h = new SmpCoreHide();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("hide", new HideCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("keyall", () -> {
         SmpCoreKeyall h = new SmpCoreKeyall();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("keyall", new KeyallCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("maintenance", () -> {
         SmpCoreMaintenance h = new SmpCoreMaintenance();
         h.init(this.plugin, this.data("maintenance"));
         h.start();
         this.bind("maintenance", new MaintenanceCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("media", () -> {
         SmpCoreMedia h = new SmpCoreMedia();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("media", new MediaCommand());
         this.bind("discord", new DiscordCommand());
         this.bind("store", new StoreCommand());
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("mobs", () -> {
         SmpCoreMobs h = new SmpCoreMobs();
         h.init(this.plugin, this.flatData());
         h.start();

         try {
            this.bind("mobs", new MobsToggleCommand(h));
         } catch (Throwable t) {
            try {
               this.bind("mobs", new SmpCoreMobsCommand(h));
            } catch (Throwable t2) {
            }
         }

         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("reports", () -> {
         SmpCoreReports h = new SmpCoreReports();
         h.init(this.plugin, this.data("reports"));
         h.start();
         this.bind("report", new ReportCommand(h));
         this.bind("reports", new ReportsCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("rtp", () -> {
         SmpCoreRTP h = new SmpCoreRTP();
         h.init(this.plugin, this.data("rtp"));
         h.start();
         this.bind("rtp", new RTPCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
         SmpCoreRTPQ q = new SmpCoreRTPQ();
         q.init(this.plugin, this.data("rtp"));
         q.start();
         this.bind("rtpqueue", new RTPQueueCommand(q));
         this.bind("rtpq", new RTPQueueCommand(q));
         list = this.shutdown;
         Objects.requireNonNull(q);
         list.add(q::stop);
      });
      this.boot("rules", () -> {
         SmpCoreRules h = new SmpCoreRules();
         h.init(this.plugin, this.flatData());
         h.start();
         this.bind("rules", new RulesCommand(h));
         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("safety", () -> {
         SmpCoreSafety h = new SmpCoreSafety();
         h.init(this.plugin, this.flatData());
         h.start();

         try {
            this.bind("safety", new SafetyCommand(h));
         } catch (Throwable t) {
         }

         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("whitelist", () -> {
         SmpCoreWhitelister h = new SmpCoreWhitelister();
         h.init(this.plugin, this.flatData());
         h.start();

         try {
            this.bind("wl", new WhitelistCommand(h));
         } catch (Throwable t) {
         }

         List<Runnable> list = this.shutdown;
         Objects.requireNonNull(h);
         list.add(h::stop);
      });
      this.boot("chainmail", () -> {
         ChainmailListener listener = new ChainmailListener(this.plugin);
         this.plugin.getServer().getPluginManager().registerEvents(listener, this.plugin);
         CommandExecutor cm = (sender, command, label, args) -> {
            if (sender instanceof Player player) {
               Module mod = this.plugin.modules().get("settings");
               if (mod instanceof SettingsModule sm) {
                  boolean enabled = sm.toggleChainmailKit(player.getUniqueId());
                  player.sendMessage(enabled ? "§aChainmail kit enabled." : "§cChainmail kit disabled.");
               } else {
                  listener.giveKit(player);
                  player.sendMessage("§aChainmail kit given.");
               }

               return true;
            } else {
               sender.sendMessage("Players only.");
               return true;
            }
         };
         this.bind("chainmail", cm);
         this.bind("cm", cm);
      });
   }

   private File data(String folder) {
      return new File(this.plugin.getDataFolder(), folder);
   }

   private File flatData() {
      return this.plugin.getDataFolder();
   }

   private void boot(String configKey, Runnable action) {
      if (!this.plugin.configs().isEnabled(configKey)) {
         this.plugin.getLogger().info("Skipped (disabled): " + configKey);
      } else {
         try {
            action.run();
            this.plugin.getLogger().info("Booted system: " + configKey);
         } catch (Throwable t) {
            this.plugin.getLogger().warning("Failed to boot " + configKey + ": " + t.getClass().getSimpleName() + " - " + t.getMessage());
            if (this.plugin.getConfig().getBoolean("settings.debug", false)) {
               t.printStackTrace();
            }
         }

      }
   }

   private void bind(String name, CommandExecutor executor) {
      if (executor != null) {
         this.plugin.commands().registerHandler(name, (sender, args) -> {
            try {
               Command fake = new Command(name) {
                  public boolean execute(CommandSender commandSender, String s, String[] strings) {
                     return false;
                  }
               };
               return executor.onCommand(sender, fake, name, args);
            } catch (Throwable t) {
               sender.sendMessage("§cError running /" + name + ": " + t.getMessage());
               this.plugin.getLogger().warning("/" + name + " error: " + t.getMessage());
               t.printStackTrace();
               return true;
            }
         });

         try {
            PluginCommand pc = this.plugin.getCommand(name);
            if (pc != null) {
               pc.setExecutor((sender, command, label, args) -> {
                  try {
                     return executor.onCommand(sender, command, label, args);
                  } catch (Throwable t) {
                     sender.sendMessage("§cError: " + t.getMessage());
                     return true;
                  }
               });
               if (executor instanceof TabCompleter) {
                  TabCompleter tc = (TabCompleter)executor;
                  pc.setTabCompleter(tc);
               }
            }
         } catch (Throwable t) {
         }

      }
   }

   public void onDisable() {
      for(Runnable r : this.shutdown) {
         try {
            r.run();
         } catch (Throwable t) {
         }
      }

      this.shutdown.clear();
   }

   public void reload() {
      this.onDisable();
      this.onEnable();
   }
}
