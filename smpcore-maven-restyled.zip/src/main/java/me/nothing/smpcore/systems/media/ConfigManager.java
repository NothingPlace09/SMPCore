package me.nothing.smpcore.systems.media;

import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {
   private final SmpCoreMedia plugin;

   public ConfigManager(SmpCoreMedia plugin) {
      this.plugin = plugin;
   }

   public FileConfiguration getConfig() {
      return this.plugin.getConfig();
   }

   public void reload() {
      this.plugin.reloadConfig();
   }
}
