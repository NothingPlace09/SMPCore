package me.nothing.smpcore.systems.rtpq;

import java.io.File;
import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class SmpCoreRTPQ extends SystemHost {
   private static SmpCoreRTPQ instance;
   private QueueManager queueManager;
   private WorldManager worldManager;

   public SmpCoreRTPQ() {
      super("rtp");
   }

   public void start() {
      instance = this;
      File qf = new File(this.getDataFolder(), "queue.yml");
      if (!qf.exists()) {
         try {
            this.saveResource("queue.yml", false);
         } catch (Exception e) {
         }
      }

      if (qf.exists()) {
         FileConfiguration qc = YamlConfiguration.loadConfiguration(qf);

         for(String key : qc.getKeys(true)) {
            this.getConfig().set(key, qc.get(key));
         }
      } else {
         this.saveDefaultConfig();
      }

      this.worldManager = new WorldManager(this);
      this.queueManager = new QueueManager(this);
      new RTPQueueCommand(this);
      this.getServer().getPluginManager().registerEvents(new MoveListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new JoinQuitListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new DialogListener(), this.getCore());
      this.getLogger().info("SmpCoreRTPQ enabled.");
   }

   public void stop() {
      if (this.queueManager != null) {
         this.queueManager.shutdown();
      }

      this.getLogger().info("SmpCoreRTPQ disabled.");
   }

   public static SmpCoreRTPQ getInstance() {
      return instance;
   }

   public QueueManager getQueueManager() {
      return this.queueManager;
   }

   public WorldManager getWorldManager() {
      return this.worldManager;
   }
}
