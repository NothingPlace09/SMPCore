package me.nothing.smpcore.systems.rtp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static String color(String text) {
      if (text != null && !text.isEmpty()) {
         Matcher m = HEX.matcher(text);
         StringBuffer buf = new StringBuffer();

         while(m.find()) {
            try {
               m.appendReplacement(buf, ChatColor.of("#" + m.group(1)).toString());
            } catch (Exception e) {
               m.appendReplacement(buf, "");
            }
         }

         m.appendTail(buf);
         return ChatColor.translateAlternateColorCodes('&', buf.toString());
      } else {
         return "";
      }
   }
}
