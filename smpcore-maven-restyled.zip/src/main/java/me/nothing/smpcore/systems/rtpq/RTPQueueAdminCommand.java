package me.nothing.smpcore.systems.rtpq;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class RTPQueueAdminCommand implements CommandExecutor {
   private final SmpCoreRTPQ plugin;

   public RTPQueueAdminCommand(SmpCoreRTPQ plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission(this.plugin.getConfig().getString("permissions.admin", "SmpCoreRTPQ.admin"))) {
         sender.sendMessage("§cNo permission.");
         return true;
      } else if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
         this.plugin.reloadConfig();
         sender.sendMessage("§aSmpCoreRTPQ configuration reloaded.");
         return true;
      } else {
         sender.sendMessage("§7Use /smpcorertpq reload");
         return true;
      }
   }
}
