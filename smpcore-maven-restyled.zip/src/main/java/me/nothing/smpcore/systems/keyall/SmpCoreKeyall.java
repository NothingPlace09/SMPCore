package me.nothing.smpcore.systems.keyall;

import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.Bukkit;

public final class SmpCoreKeyall extends SystemHost {
   private static SmpCoreKeyall instance;
   private KeyManager keys;
   private TimerManager timer;

   public SmpCoreKeyall() {
      super("keyall");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.keys = new KeyManager(this);
      this.timer = new TimerManager(this);
      new KeyallCommand(this);
      if (this.getCommand("keyall") != null) {
      }

      this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this.getCore());
      if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
         (new KeyallPlaceholders(this)).register();
         this.getLogger().info("PlaceholderAPI hooked.");
      }

      this.getLogger().info("SmpCoreKeyall enabled.");
   }

   public void stop() {
      if (this.timer != null) {
         this.timer.stop();
         this.timer.saveData();
      }

      instance = null;
   }

   public void reloadAll() {
      this.reloadConfig();
      this.keys.reload();
      this.timer.reloadSettings();
   }

   public static SmpCoreKeyall get() {
      return instance;
   }

   public KeyManager getKeys() {
      return this.keys;
   }

   public TimerManager getTimer() {
      return this.timer;
   }
}
