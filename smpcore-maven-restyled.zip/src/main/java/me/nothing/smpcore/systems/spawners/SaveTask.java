package me.nothing.smpcore.systems.spawners;

import org.bukkit.scheduler.BukkitRunnable;

public class SaveTask extends BukkitRunnable {
   private final SmpCoreSpawners plugin;

   public SaveTask(SmpCoreSpawners plugin) {
      this.plugin = plugin;
   }

   public void run() {
      this.plugin.getStorage().save();
   }
}
