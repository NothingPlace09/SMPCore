package me.nothing.smpcore.systems.crates;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class CratePlaceholders extends PlaceholderExpansion {
   private final SmpCoreCrates plugin;
   private final Map<String, CacheEntry> cache = new ConcurrentHashMap();
   private static final long TTL_MS = 250L;

   public CratePlaceholders(SmpCoreCrates plugin) {
      this.plugin = plugin;
   }

   public @NotNull String getIdentifier() {
      return "crate";
   }

   public @NotNull String getAuthor() {
      return "nothing";
   }

   public @NotNull String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onPlaceholderRequest(Player player, @NotNull String params) {
      if (params.startsWith("keys_")) {
         if (player == null) {
            return "0";
         } else {
            String crateId = params.substring(5);
            String str = String.valueOf(player.getUniqueId());
            String cacheKey = str + ":keys:" + crateId.toLowerCase();
            CacheEntry entry = (CacheEntry)this.cache.get(cacheKey);
            long now = System.currentTimeMillis();
            if (entry != null && now - entry.time < 250L) {
               return entry.value;
            } else {
               int total = this.plugin.getKeys().totalKeys(player, crateId);
               String value = String.valueOf(total);
               this.cache.put(cacheKey, new CacheEntry(value, now));
               return value;
            }
         }
      } else if (params.startsWith("name_")) {
         String crateId = params.substring(5);
         Crate crate = this.plugin.getCrates().get(crateId);
         return crate == null ? crateId : ColorUtil.strip(crate.getDisplayName());
      } else if (params.startsWith("virtual_")) {
         return player == null ? "0" : String.valueOf(this.plugin.getData().getVirtual(player.getUniqueId(), params.substring(8)));
      } else if (params.startsWith("physical_")) {
         return player == null ? "0" : String.valueOf(this.plugin.getKeys().countPhysical(player, params.substring(9)));
      } else {
         return null;
      }
   }

   private static record CacheEntry(String value, long time) {
   }
}
