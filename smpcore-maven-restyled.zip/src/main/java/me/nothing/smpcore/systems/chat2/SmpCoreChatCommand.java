package me.nothing.smpcore.systems.chat2;

import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.utils.SoundUtil;
import me.nothing.smpcore.utils.TextUtil;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SmpCoreChatCommand implements CommandExecutor {
   private final SmpCoreChat plugin;

   public SmpCoreChatCommand(SmpCoreChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         sender.sendMessage(MessageUtil.color("&bSmpCoreChat &7v1.0"));
         sender.sendMessage(MessageUtil.color("&7Use &b/smpcorechat reload &7or &b/smpcorechat info"));
         return true;
      } else if (args[0].equalsIgnoreCase("toggle")) {
         if (sender instanceof Player) {
            Player player = (Player)sender;
            boolean on = this.plugin.getChatManager().togglePersonal(player.getUniqueId());

            try {
               SmpCore core = SmpCore.get();
               if (core != null) {
                  Module mod = core.modules().get("settings");
                  if (mod instanceof SettingsModule) {
                     SettingsModule sm = (SettingsModule)mod;
                     sm.toggleChatOff(player.getUniqueId());
                  }
               }
            } catch (Throwable t) {
            }

            if (on) {
               TextUtil.send(player, "&#00a3fbGeneral chat &#00FF00enabled&7.");
            } else {
               TextUtil.send(player, "&#00a3fbGeneral chat &#fc0404disabled&7.");
            }

            return true;
         } else {
            sender.sendMessage("Players only.");
            return true;
         }
      } else if (args[0].equalsIgnoreCase("reload")) {
         if (sender instanceof Player) {
            Player player = (Player)sender;
            if (!player.isOp() && !player.hasPermission("smpcore.system.chat.reload")) {
               player.sendMessage(MessageUtil.color("&cYou don't have permission."));
               return true;
            }
         }

         this.plugin.reloadSmpCoreChat();
         sender.sendMessage(MessageUtil.color("&aSmpCoreChat reloaded successfully."));
         if (sender instanceof Player) {
            Player player = (Player)sender;
            SoundUtil.play(player, player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
         }

         return true;
      } else if (args[0].equalsIgnoreCase("info")) {
         sender.sendMessage(MessageUtil.color("&b&m----------------"));
         sender.sendMessage(MessageUtil.color("&bSmpCoreChat &7v1.0"));
         sender.sendMessage(MessageUtil.color("&7DiscordSRV: " + (this.plugin.getDiscordSRVHook().isEnabled() ? "&aEnabled" : "&cDisabled")));
         sender.sendMessage(MessageUtil.color("&b&m----------------"));
         return true;
      } else {
         sender.sendMessage(MessageUtil.color("&cUsage: /smpcorechat <reload|info>"));
         return true;
      }
   }
}
