package me.nothing.smpcore.systems.duels;

import java.io.File;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;

/**
 * Incolla uno schematic (WorldEdit/FastAsyncWorldEdit .schem) prima di un match e ripulisce la zona dopo,
 * usando SOLO reflection (come il resto del plugin fa gia' per WorldGuard) cosi' non serve alcuna dipendenza
 * Maven su WorldEdit: se WorldEdit/FAWE non e' installato, o qualcosa va storto, l'operazione fallisce in modo
 * silenzioso (log di un avviso) e il duello parte comunque nell'arena cosi' com'e', senza bloccare nulla.
 *
 * NOTA: questa parte non e' stata testata contro una build reale di WorldEdit/FAWE (non disponibile in
 * questo ambiente). Se "/duelsadmin setschematic" non incolla nulla, controlla i log della console: probabile
 * un cambiamento di firma nell'API tra versioni di WorldEdit.
 */
public final class SchematicUtil {
   private SchematicUtil() {
   }

   public static boolean isAvailable() {
      return Bukkit.getPluginManager().getPlugin("WorldEdit") != null;
   }

   /** Incolla lo schematic con l'angolo inferiore in `anchor`. Ritorna true se e' andato tutto bene. */
   public static boolean paste(File schemFile, Location anchor, Logger log) {
      if (schemFile != null && schemFile.exists() && anchor != null && isAvailable()) {
         try {
            Class<?> formatsClass = Class.forName("com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats");
            Object format = formatsClass.getMethod("findByFile", File.class).invoke((Object)null, schemFile);
            if (format == null) {
               log.warning("[Duels] Unknown schematic format: " + schemFile.getName());
               return false;
            } else {
               Object reader = format.getClass().getMethod("getReader", java.io.InputStream.class).invoke(format, new java.io.FileInputStream(schemFile));
               Object clipboard = reader.getClass().getMethod("read").invoke(reader);
               Class<?> bukkitAdapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
               Object weWorld = bukkitAdapter.getMethod("adapt", World.class).invoke((Object)null, anchor.getWorld());
               Object weVector = bukkitAdapter.getMethod("adapt", Location.class).invoke((Object)null, anchor);
               Class<?> blockVector3 = Class.forName("com.sk89q.worldedit.math.BlockVector3");
               Object origin = weVector.getClass().getMethod("toBlockPoint").invoke(weVector);
               Class<?> weClass = Class.forName("com.sk89q.worldedit.WorldEdit");
               Object we = weClass.getMethod("getInstance").invoke((Object)null);
               Object sessionManager = weClass.getMethod("getSessionManager").invoke(we);
               Class<?> editSessionBuilderClass = Class.forName("com.sk89q.worldedit.EditSessionBuilder");
               Object builder = weClass.getMethod("newEditSessionBuilder").invoke(we);
               builder = editSessionBuilderClass.getMethod("world", Class.forName("com.sk89q.worldedit.world.World")).invoke(builder, weWorld);
               Object editSession = editSessionBuilderClass.getMethod("build").invoke(builder);

               try {
                  Class<?> clipboardHolderClass = Class.forName("com.sk89q.worldedit.session.ClipboardHolder");
                  Object holder = clipboardHolderClass.getConstructor(Class.forName("com.sk89q.worldedit.extent.clipboard.Clipboard")).newInstance(clipboard);
                  Object pasteBuilder = clipboardHolderClass.getMethod("createPaste", Class.forName("com.sk89q.worldedit.extent.Extent")).invoke(holder, editSession);
                  Class<?> pasteBuilderClass = pasteBuilder.getClass();
                  pasteBuilder = pasteBuilderClass.getMethod("to", blockVector3).invoke(pasteBuilder, origin);
                  pasteBuilder = pasteBuilderClass.getMethod("ignoreAirBlocks", boolean.class).invoke(pasteBuilder, false);
                  Object operation = pasteBuilderClass.getMethod("build").invoke(pasteBuilder);
                  Class<?> operationsClass = Class.forName("com.sk89q.worldedit.function.operation.Operations");
                  operationsClass.getMethod("complete", Class.forName("com.sk89q.worldedit.function.operation.Operation")).invoke((Object)null, operation);
                  return true;
               } finally {
                  editSession.getClass().getMethod("close").invoke(editSession);
               }
            }
         } catch (Throwable t) {
            log.log(Level.WARNING, "[Duels] Failed to paste schematic " + schemFile.getName() + " (arena will be used as-is)", t);
            return false;
         }
      } else {
         return false;
      }
   }

   /**
    * Salva la regione tra pos1 e pos2 come schematic (.schem) nel file indicato, con l'origine del clipboard
    * impostata su pos1 (stesso punto che {@link #paste} userà come ancora quando la incollerà). Ritorna true
    * se e' andato tutto bene. Come paste(), usa SOLO reflection cosi' non serve alcuna dipendenza Maven su
    * WorldEdit; se WorldEdit/FAWE non e' installato l'operazione fallisce in modo silenzioso (log di un avviso).
    */
   public static boolean save(File outFile, Location pos1, Location pos2, Logger log) {
      if (outFile != null && pos1 != null && pos2 != null && pos1.getWorld() != null && isAvailable()) {
         try {
            outFile.getParentFile().mkdirs();
            Class<?> bukkitAdapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
            Object weWorld = bukkitAdapter.getMethod("adapt", World.class).invoke((Object)null, pos1.getWorld());
            Object weVec1 = bukkitAdapter.getMethod("adapt", Location.class).invoke((Object)null, pos1);
            Object weVec2 = bukkitAdapter.getMethod("adapt", Location.class).invoke((Object)null, pos2);
            Class<?> blockVector3 = Class.forName("com.sk89q.worldedit.math.BlockVector3");
            Object bp1 = weVec1.getClass().getMethod("toBlockPoint").invoke(weVec1);
            Object bp2 = weVec2.getClass().getMethod("toBlockPoint").invoke(weVec2);
            Class<?> extentClass = Class.forName("com.sk89q.worldedit.extent.Extent");
            Class<?> regionClass = Class.forName("com.sk89q.worldedit.regions.Region");
            Class<?> cuboidRegionClass = Class.forName("com.sk89q.worldedit.regions.CuboidRegion");
            Object region = cuboidRegionClass.getConstructor(extentClass, blockVector3, blockVector3).newInstance(weWorld, bp1, bp2);
            Object minPoint = cuboidRegionClass.getMethod("getMinimumPoint").invoke(region);
            Class<?> clipboardClass = Class.forName("com.sk89q.worldedit.extent.clipboard.Clipboard");
            Class<?> blockArrayClipboardClass = Class.forName("com.sk89q.worldedit.extent.clipboard.BlockArrayClipboard");
            Object clipboard = blockArrayClipboardClass.getConstructor(regionClass).newInstance(region);
            blockArrayClipboardClass.getMethod("setOrigin", blockVector3).invoke(clipboard, bp1);
            Class<?> weClass = Class.forName("com.sk89q.worldedit.WorldEdit");
            Object we = weClass.getMethod("getInstance").invoke((Object)null);
            Class<?> editSessionBuilderClass = Class.forName("com.sk89q.worldedit.EditSessionBuilder");
            Object builder = weClass.getMethod("newEditSessionBuilder").invoke(we);
            builder = editSessionBuilderClass.getMethod("world", Class.forName("com.sk89q.worldedit.world.World")).invoke(builder, weWorld);
            Object editSession = editSessionBuilderClass.getMethod("build").invoke(builder);

            try {
               Class<?> forwardExtentCopyClass = Class.forName("com.sk89q.worldedit.function.operation.ForwardExtentCopy");
               Object copy = forwardExtentCopyClass.getConstructor(extentClass, regionClass, extentClass, blockVector3).newInstance(editSession, region, clipboard, minPoint);
               forwardExtentCopyClass.getMethod("setCopyingEntities", boolean.class).invoke(copy, true);
               Class<?> operationsClass = Class.forName("com.sk89q.worldedit.function.operation.Operations");
               operationsClass.getMethod("complete", Class.forName("com.sk89q.worldedit.function.operation.Operation")).invoke((Object)null, copy);
            } finally {
               editSession.getClass().getMethod("close").invoke(editSession);
            }

            Class<?> formatsClass = Class.forName("com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats");
            Object format = formatsClass.getMethod("findByAlias", String.class).invoke((Object)null, "schem");
            if (format == null) {
               log.warning("[Duels] Sponge schematic format not available, cannot save " + outFile.getName());
               return false;
            } else {
               try (java.io.OutputStream os = new java.io.FileOutputStream(outFile)) {
                  Object writer = format.getClass().getMethod("getWriter", java.io.OutputStream.class).invoke(format, os);

                  try {
                     writer.getClass().getMethod("write", clipboardClass).invoke(writer, clipboard);
                  } finally {
                     writer.getClass().getMethod("close").invoke(writer);
                  }
               }

               return true;
            }
         } catch (Throwable t) {
            log.log(Level.WARNING, "[Duels] Failed to save schematic " + outFile.getName() + " (arena saved without one)", t);
            return false;
         }
      } else {
         return false;
      }
   }

   /** Cartella schematics del plugin WorldEdit installato (plugins/WorldEdit/schematics), o null se non installato. */
   public static File worldEditSchematicsFolder() {
      org.bukkit.plugin.Plugin we = Bukkit.getPluginManager().getPlugin("WorldEdit");
      return we == null ? null : new File(we.getDataFolder(), "schematics");
   }

   /** Copia lo schematic appena salvato anche nella cartella schematics di WorldEdit, cosi' e' selezionabile
    * anche con //schem load in gioco. Fallisce in modo silenzioso (solo un log) se qualcosa va storto. */
   public static void mirrorToWorldEdit(File savedFile, String fileName, Logger log) {
      try {
         File weFolder = worldEditSchematicsFolder();
         if (weFolder != null) {
            weFolder.mkdirs();
            java.nio.file.Files.copy(savedFile.toPath(), new File(weFolder, fileName).toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (Throwable t) {
         log.log(Level.WARNING, "[Duels] Could not copy schematic into WorldEdit's schematics folder", t);
      }

   }

   /** Ripulisce la zona riempiendola d'aria (nessuna dipendenza da WorldEdit: usa la normale API di Bukkit). */
   public static void clear(Arena arena) {
      if (arena != null && arena.getPos1() != null && arena.getPos2() != null) {
         World world = arena.getPos1().getWorld();
         if (world != null) {
            int minX = (int)Math.floor(arena.minX());
            int maxX = (int)Math.ceil(arena.maxX());
            int minY = (int)Math.floor(arena.minY());
            int maxY = (int)Math.ceil(arena.maxY());
            int minZ = (int)Math.floor(arena.minZ());
            int maxZ = (int)Math.ceil(arena.maxZ());

            for(int x = minX; x <= maxX; ++x) {
               for(int y = minY; y <= maxY; ++y) {
                  for(int z = minZ; z <= maxZ; ++z) {
                     world.getBlockAt(x, y, z).setType(org.bukkit.Material.AIR, false);
                  }
               }
            }

         }
      }
   }
}
