package me.nothing.smpcore.systems.crates;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').hexCharacter('#').build();

   private ColorUtil() {
   }

   public static Component parse(String text) {
      return (Component)(text != null && !text.isEmpty() ? LEGACY.deserialize(text.replace('§', '&')).decoration(TextDecoration.ITALIC, false) : Component.empty());
   }

   public static String strip(String text) {
      return text == null ? "" : text.replaceAll("(?i)§[0-9a-fk-orx]", "").replaceAll("(?i)&[0-9a-fk-orx]", "").replaceAll("&#[0-9a-fA-F]{6}", "");
   }
}
