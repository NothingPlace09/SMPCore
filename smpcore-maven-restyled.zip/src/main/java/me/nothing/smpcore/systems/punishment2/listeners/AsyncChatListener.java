package me.nothing.smpcore.systems.punishment2.listeners;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;

public class AsyncChatListener implements Listener {
   private final SmpCorePunishment plugin;

   public AsyncChatListener(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onChat(AsyncPlayerChatEvent event) {
   }
}
