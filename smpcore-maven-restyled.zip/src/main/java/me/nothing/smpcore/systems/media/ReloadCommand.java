package me.nothing.smpcore.systems.media;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {
   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("smpcore.system.admin")) {
         sender.sendMessage(ColorUtil.color(SmpCoreMedia.getInstance().getConfig().getString("messages.no-permission")));
         return true;
      } else if (args.length != 0 && args[0].equalsIgnoreCase("reload")) {
         SmpCoreMedia.getInstance().reloadConfig();
         sender.sendMessage(ColorUtil.color(SmpCoreMedia.getInstance().getConfig().getString("messages.reload")));
         return true;
      } else {
         sender.sendMessage(ColorUtil.color("&cUsage: /smpcoremedia reload"));
         return true;
      }
   }
}
