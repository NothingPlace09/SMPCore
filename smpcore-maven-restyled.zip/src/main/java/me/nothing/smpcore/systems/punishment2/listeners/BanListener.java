package me.nothing.smpcore.systems.punishment2.listeners;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class BanListener implements Listener {
   private final SmpCorePunishment plugin;

   public BanListener(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      for(Punishment punishment : this.plugin.getHistoryManager().getHistory(event.getPlayer().getUniqueId())) {
         if (punishment.getType().equalsIgnoreCase("BAN") && punishment.isActive()) {
            if (punishment.getExpireTime() == -1L || !TimeUtil.hasExpired(punishment.getExpireTime())) {
               event.getPlayer().kickPlayer("You are banned.");
               return;
            }

            punishment.setActive(false);
         }
      }

   }
}
