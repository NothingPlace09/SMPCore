package me.nothing.smpcore.systems.baltop;

import java.text.DecimalFormat;
import java.util.List;

public final class MoneyUtil {
   private MoneyUtil() {
   }

   public static String format(double amount) {
      SmpCoreBaltop plugin = SmpCoreBaltop.get();
      boolean abbr = plugin.getConfig().getBoolean("economy.abbreviations.enabled", true);
      if (abbr) {
         List<String> suffixes = plugin.getConfig().getStringList("economy.abbreviations.formats");
         if (suffixes == null || suffixes.isEmpty()) {
            suffixes = List.of("K", "M", "B", "T");
         }

         double abs = Math.abs(amount);
         if (abs >= 1.0E12 && suffixes.size() > 3) {
            String str = trim(amount / 1.0E12);
            return str + (String)suffixes.get(3);
         }

         if (abs >= (double)1.0E9F && suffixes.size() > 2) {
            String str = trim(amount / (double)1.0E9F);
            return str + (String)suffixes.get(2);
         }

         if (abs >= (double)1000000.0F && suffixes.size() > 1) {
            String str = trim(amount / (double)1000000.0F);
            return str + (String)suffixes.get(1);
         }

         if (abs >= (double)1000.0F && !suffixes.isEmpty()) {
            String str = trim(amount / (double)1000.0F);
            return str + (String)suffixes.get(0);
         }
      }

      String pattern = plugin.getConfig().getString("economy.currency-format", "#,##0.##");

      try {
         return (new DecimalFormat(pattern)).format(amount);
      } catch (Exception e) {
         return String.format("%.2f", amount);
      }
   }

   private static String trim(double value) {
      return value == (double)((long)value) ? String.valueOf((long)value) : String.format("%.1f", value).replace(".0", "");
   }
}
