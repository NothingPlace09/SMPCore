package me.nothing.smpcore.systems.duels;

import org.bukkit.Location;

/**
 * Un'arena nominata per i duelli: confine (pos1/pos2), punti di partenza dei due combattenti
 * (spawn1/spawn2) e, opzionalmente, uno schematic da incollare prima di ogni match e ripulire dopo.
 * Creata con "/duelsadmin savearena <nome>" dopo aver impostato pos1/pos2 (wand o comandi) e spawn1/spawn2.
 */
public class Arena {
   private final String name;
   private Location pos1;
   private Location pos2;
   private Location spawn1;
   private Location spawn2;
   /** Nome del file .schem in duels/schematics/, o null se l'arena non usa uno schematic. */
   private String schematic;

   public Arena(String name, Location pos1, Location pos2, Location spawn1, Location spawn2, String schematic) {
      this.name = name;
      this.pos1 = pos1;
      this.pos2 = pos2;
      this.spawn1 = spawn1;
      this.spawn2 = spawn2;
      this.schematic = schematic;
   }

   public String getName() {
      return this.name;
   }

   public Location getPos1() {
      return this.pos1;
   }

   public Location getPos2() {
      return this.pos2;
   }

   public Location getSpawn1() {
      return this.spawn1 != null ? this.spawn1 : this.pos1;
   }

   public Location getSpawn2() {
      return this.spawn2 != null ? this.spawn2 : this.pos2;
   }

   public String getSchematic() {
      return this.schematic;
   }

   public void setSchematic(String schematic) {
      this.schematic = schematic;
   }

   public boolean isInWorld(String worldName) {
      return this.pos1 != null && this.pos1.getWorld() != null && this.pos1.getWorld().getName().equalsIgnoreCase(worldName);
   }

   public double minX() {
      return Math.min(this.pos1.getX(), this.pos2.getX());
   }

   public double maxX() {
      return Math.max(this.pos1.getX(), this.pos2.getX());
   }

   public double minY() {
      return Math.min(this.pos1.getY(), this.pos2.getY());
   }

   public double maxY() {
      return Math.max(this.pos1.getY(), this.pos2.getY());
   }

   public double minZ() {
      return Math.min(this.pos1.getZ(), this.pos2.getZ());
   }

   public double maxZ() {
      return Math.max(this.pos1.getZ(), this.pos2.getZ());
   }
}
