package me.nothing.smpcore.systems.tools;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().character('&').hexColors().hexCharacter('#').build();

   private ColorUtil() {
   }

   public static Component parse(String input) {
      return (Component)(input != null && !input.isEmpty() ? LEGACY.deserialize(input.replace('§', '&')).decoration(TextDecoration.ITALIC, false) : Component.empty());
   }

   public static String strip(String input) {
      return input == null ? "" : input.replaceAll("(?i)[§&][0-9a-fk-orx]", "").replaceAll("(?i)&#[0-9a-fA-F]{6}", "");
   }
}
