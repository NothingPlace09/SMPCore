package me.nothing.smpcore.systems.baltop;

import java.io.File;
import me.nothing.smpcore.systems.SystemHost;

public final class SmpCoreBaltop extends SystemHost {
   private static SmpCoreBaltop instance;
   private EconomyHook economy;
   private MessageManager messages;
   private BalanceCache cache;

   public SmpCoreBaltop() {
      super("baltop");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.saveResourceSafe("messages.yml");
      this.saveResourceSafe("gui/main-gui.yml");
      this.economy = new EconomyHook();
      if (!this.economy.setup()) {
         this.getLogger().severe("Vault economy missing.");
         this.getLogger().warning("[system] init warning (continuing)");
      }

      this.messages = new MessageManager(this);
      this.cache = new BalanceCache(this);
      this.cache.start();
      new BaltopCommand(this);
      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new ChatInputListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new SignProtectListener(), this.getCore());
      this.getLogger().info("SmpCoreBaltop enabled.");
   }

   public void stop() {
      if (this.cache != null) {
         this.cache.stop();
      }

      instance = null;
   }

   private void saveResourceSafe(String name) {
      File out = new File(this.getDataFolder(), name);
      if (!out.exists()) {
         out.getParentFile().mkdirs();
         this.saveResource(name, false);
      }

   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.cache.stop();
      this.cache.start();
   }

   public static SmpCoreBaltop get() {
      return instance;
   }

   public EconomyHook getEconomy() {
      return this.economy;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public BalanceCache getCache() {
      return this.cache;
   }
}
