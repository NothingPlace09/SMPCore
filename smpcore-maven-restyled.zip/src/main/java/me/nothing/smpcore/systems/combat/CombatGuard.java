package me.nothing.smpcore.systems.combat;

import org.bukkit.entity.Player;

/**
 * Punto unico per chiedere al modulo combat se un teleport "volontario" (home, team home, warp, tpa, rtp)
 * va negato perche' il player e' in combattimento. Se il modulo combat non e' attivo non blocca nulla.
 */
public final class CombatGuard {
   private CombatGuard() {
   }

   public static boolean isBlocked(Player player) {
      if (player == null) {
         return false;
      } else {
         SmpCoreCombat combat = SmpCoreCombat.getInstance();
         if (combat != null && combat.getCombatManager() != null) {
            return !player.hasPermission("smpcore.system.combat.bypass") && combat.getCombatManager().isInCombat(player);
         } else {
            return false;
         }
      }
   }

   /** @return true se il teleport va negato (e avvisa il player con il messaggio command-blocked) */
   public static boolean deny(Player player) {
      if (!isBlocked(player)) {
         return false;
      } else {
         MessageUtil.send(player, "command-blocked");
         return true;
      }
   }
}
