package me.nothing.smpcore.systems.shards;

import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

public final class AfkRegionUtil {
   private AfkRegionUtil() {
   }

   public static boolean isEligible(Player player, FileConfiguration cfg) {
      if (player.hasPermission("smpcore.system.shards.everywhere")) {
         return true;
      } else {
         return !isWorldAllowed(player.getWorld(), cfg.getStringList("enabled-worlds")) ? false : isInAfkRegion(player, cfg.getStringList("enabled-regions"));
      }
   }

   public static boolean isInAfkZone(Player player, FileConfiguration cfg) {
      return !isWorldAllowed(player.getWorld(), cfg.getStringList("enabled-worlds")) ? false : isInAfkRegion(player, cfg.getStringList("enabled-regions"));
   }

   public static boolean isWorldAllowed(World world, List<String> worlds) {
      if (worlds != null && !worlds.isEmpty()) {
         String name = world.getName();

         for(String w : worlds) {
            if (w != null && w.equalsIgnoreCase(name)) {
               return true;
            }
         }

         return false;
      } else {
         return true;
      }
   }

   public static boolean isInAfkRegion(Player player, List<String> regions) {
      if (regions != null && !regions.isEmpty()) {
         return Bukkit.getPluginManager().getPlugin("WorldGuard") == null ? false : regionMatches(player.getLocation(), regions);
      } else {
         return false;
      }
   }

   private static boolean regionMatches(Location loc, List<String> names) {
      try {
         Class<?> wgClass = Class.forName("com.sk89q.worldguard.WorldGuard");
         Object wg = wgClass.getMethod("getInstance").invoke((Object)null);
         Object platform = wgClass.getMethod("getPlatform").invoke(wg);
         Object container = platform.getClass().getMethod("getRegionContainer").invoke(platform);
         Object query = container.getClass().getMethod("createQuery").invoke(container);
         Class<?> adapter = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
         Object weLoc = adapter.getMethod("adapt", Location.class).invoke((Object)null, loc);
         Object set = query.getClass().getMethod("getApplicableRegions", Class.forName("com.sk89q.worldedit.util.Location")).invoke(query, weLoc);

         for(Object region : (Iterable)set) {
            String id = (String)region.getClass().getMethod("getId").invoke(region);
            if (names.contains(id) || names.contains(id.toLowerCase())) {
               return true;
            }
         }
      } catch (Throwable t) {
      }

      return false;
   }
}
