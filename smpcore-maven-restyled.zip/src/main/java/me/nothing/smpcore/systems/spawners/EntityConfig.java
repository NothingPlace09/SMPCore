package me.nothing.smpcore.systems.spawners;

import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.Enumeration;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.EntityType;

public class EntityConfig {
   private final SmpCoreSpawners plugin;
   private final Map<EntityType, EntityDefinition> definitions = new EnumMap(EntityType.class);

   public EntityConfig(SmpCoreSpawners plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.definitions.clear();
      File folder = new File(this.plugin.getDataFolder(), "spawners");
      if (!folder.exists()) {
         folder.mkdirs();
      }

      this.saveDefaults(folder);
      File[] files = folder.listFiles((dir, n) -> n.toLowerCase(Locale.ROOT).endsWith(".yml"));
      if (files != null) {
         for(File file : files) {
            this.loadFile(file);
         }

         this.plugin.getLogger().info("Loaded " + this.definitions.size() + " spawner types from spawners/");
      }
   }

   private void saveDefaults(File folder) {
      try {
         URL url = this.plugin.getClass().getClassLoader().getResource("spawners");
         if (url == null) {
            return;
         }

         if (!url.getProtocol().equals("jar")) {
            File src = new File(url.toURI());
            File[] files = src.listFiles((d, n) -> n.endsWith(".yml"));
            if (files == null) {
               return;
            }

            for(File f : files) {
               File out = new File(folder, f.getName());
               if (!out.exists()) {
                  Files.copy(f.toPath(), out.toPath());
               }
            }

            return;
         }

         String path = url.getPath();
         String jarPath = path.substring(5, path.indexOf("!"));
         JarFile jar = new JarFile(URLDecoder.decode(jarPath, "UTF-8"));

         try {
            Enumeration<JarEntry> entries = jar.entries();

            while(entries.hasMoreElements()) {
               JarEntry e = (JarEntry)entries.nextElement();
               String name = e.getName();
               if (name.startsWith("spawners/spawners/") && name.endsWith(".yml")) {
                  String fileName = name.substring("spawners/spawners/".length());
                  if (!fileName.contains("/")) {
                     File out = new File(folder, fileName);
                     if (!out.exists()) {
                        out.getParentFile().mkdirs();
                        InputStream in = jar.getInputStream(e);

                        try {
                           Files.copy(in, out.toPath(), new CopyOption[0]);
                        } catch (Throwable t) {
                           if (in != null) {
                              try {
                                 in.close();
                              } catch (Throwable t2) {
                                 t.addSuppressed(t2);
                              }
                           }

                           throw t;
                        }

                        if (in != null) {
                           in.close();
                        }
                     }
                  }
               }
            }
         } catch (Throwable t) {
            try {
               jar.close();
            } catch (Throwable t2) {
               t.addSuppressed(t2);
            }

            throw t;
         }

         jar.close();
      } catch (Exception ex) {
         this.plugin.getLogger().warning("Could not extract default spawners: " + ex.getMessage());
         String[] fallback = new String[]{"zombie", "skeleton", "spider", "creeper", "enderman", "blaze", "iron_golem", "cow", "pig", "sheep", "chicken", "rabbit", "slime", "magma_cube", "guardian", "phantom", "turtle", "squid", "glow_squid", "piglin", "sniffer", "armadillo"};

         for(String name : fallback) {
            File out = new File(folder, name + ".yml");
            if (!out.exists()) {
               try {
                  InputStream in = this.plugin.getResource("spawners/spawners/" + name + ".yml");

                  try {
                     if (in != null) {
                        Files.copy(in, out.toPath(), new CopyOption[0]);
                     }
                  } catch (Throwable t) {
                     if (in != null) {
                        try {
                           in.close();
                        } catch (Throwable t2) {
                           t.addSuppressed(t2);
                        }
                     }

                     throw t;
                  }

                  if (in != null) {
                     in.close();
                  }
               } catch (Exception e) {
               }
            }
         }
      }

   }

   private void loadFile(File file) {
      String key = file.getName().replace(".yml", "").replace(".YAML", "").toUpperCase(Locale.ROOT);

      EntityType type;
      try {
         type = EntityType.valueOf(key);
      } catch (IllegalArgumentException e) {
         return;
      }

      FileConfiguration config = YamlConfiguration.loadConfiguration(file);
      String str = this.pretty(type);
      String display = config.getString("display", str + " Spawner");
      if (!display.contains("&#") && !display.contains("&")) {
         display = "&#1FFD98" + display;
      }

      int minMobs = config.getInt("min-mobs", 1);
      int maxMobs = Math.max(minMobs, config.getInt("max-mobs", 1));
      int delay = config.getInt("delay", 20);
      int exp = config.getInt("exp-per-cycle", 0);
      List<DropEntry> drops = new ArrayList();
      Map<Material, Double> prices = new EnumMap(Material.class);
      if (config.isConfigurationSection("items")) {
         ConfigurationSection items = config.getConfigurationSection("items");

         for(String id : items.getKeys(false)) {
            ConfigurationSection sec = items.getConfigurationSection(id);
            if (sec != null) {
               String matName = sec.getString("material");
               if (matName != null) {
                  Material mat;
                  try {
                     mat = Material.valueOf(matName.toUpperCase(Locale.ROOT));
                  } catch (IllegalArgumentException e) {
                     continue;
                  }

                  drops.add(new DropEntry(mat, 1, 1, 100));
               }
            }
         }
      }

      for(Map<?, ?> map : config.getMapList("drops")) {
         Object matObj = map.get("material");
         if (matObj != null) {
            try {
               Material mat = Material.valueOf(matObj.toString().toUpperCase(Locale.ROOT));
               int min = map.containsKey("min") ? ((Number)map.get("min")).intValue() : 1;
               int max = map.containsKey("max") ? ((Number)map.get("max")).intValue() : 1;
               int chance = map.containsKey("chance") ? ((Number)map.get("chance")).intValue() : 100;
               drops.add(new DropEntry(mat, min, Math.max(min, max), chance));
            } catch (IllegalArgumentException e) {
            }
         }
      }

      ConfigurationSection priceSec = config.getConfigurationSection("prices");
      if (priceSec == null) {
         priceSec = config.getConfigurationSection("sell-price");
      }

      if (priceSec != null) {
         for(String pKey : priceSec.getKeys(false)) {
            try {
               prices.put(Material.valueOf(pKey.toUpperCase(Locale.ROOT)), priceSec.getDouble(pKey));
            } catch (IllegalArgumentException e) {
            }
         }
      }

      if (drops.isEmpty()) {
         this.plugin.getLogger().warning("No drops defined in " + file.getName());
      }

      this.definitions.put(type, new EntityDefinition(type, display, minMobs, maxMobs, delay, exp, drops, prices));
   }

   private String pretty(EntityType type) {
      String raw = type.name().toLowerCase(Locale.ROOT).replace('_', ' ');
      StringBuilder sb = new StringBuilder();

      for(String p : raw.split(" ")) {
         if (!p.isEmpty()) {
            if (sb.length() > 0) {
               sb.append(' ');
            }

            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1));
         }
      }

      return sb.toString();
   }

   public EntityDefinition get(EntityType type) {
      return (EntityDefinition)this.definitions.get(type);
   }

   public boolean isSupported(EntityType type) {
      return this.definitions.containsKey(type);
   }

   public Map<EntityType, EntityDefinition> all() {
      return Collections.unmodifiableMap(this.definitions);
   }
}
