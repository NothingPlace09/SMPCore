package me.nothing.smpcore.systems.ec;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.utils.SoundUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public final class EcGui {
   private EcGui() {
   }

   public static int rowsFor(Player player, SmpCoreEC plugin) {
      for(int r = 6; r >= 1; --r) {
         if (player.hasPermission("smpcore.system.ec.rows." + r) || player.hasPermission("smpcore.system.ec.raw." + r)) {
            return r;
         }
      }

      int def = plugin.getConfig().getInt("default-rows", 3);
      return Math.max(1, Math.min(6, def));
   }

   public static void openOwn(Player player, SmpCoreEC plugin) {
      int rows = rowsFor(player, plugin);
      open(player, player.getUniqueId(), rows, false, plugin);
   }

   public static void openOther(Player viewer, Player target, SmpCoreEC plugin) {
      int rows = rowsFor(target, plugin);
      open(viewer, target.getUniqueId(), rows, true, plugin);
   }

   public static void openOffline(Player viewer, UUID targetId, int rows, SmpCoreEC plugin) {
      open(viewer, targetId, Math.max(1, Math.min(6, rows)), true, plugin);
   }

   /** owner -> viewer che ha attualmente aperto l'EC di quel proprietario */
   private static final Map<UUID, UUID> OPEN = new ConcurrentHashMap();

   public static void release(UUID owner, UUID viewer) {
      OPEN.remove(owner, viewer);
   }

   private static void open(Player viewer, UUID owner, int rows, boolean admin, SmpCoreEC plugin) {
      // FIX dupe: due inventari aperti sullo stesso EC (owner + /ecsee) salvavano a turno, vinceva l'ultimo
      UUID current = OPEN.get(owner);
      if (current != null && !current.equals(viewer.getUniqueId())) {
         Player other = Bukkit.getPlayer(current);
         if (other != null && other.isOnline() && other.getOpenInventory().getTopInventory().getHolder() instanceof EcHolder h && h.getOwner().equals(owner)) {
            viewer.sendMessage(ColorUtil.parse(plugin.getMessages().getString("ec-in-use", "&cThis ender chest is already open by someone else.")));
            return;
         }
      }

      int size = rows * 9;
      EcHolder holder = new EcHolder(owner, admin);
      String title = plugin.getConfig().getString("title", "&8ᴇɴᴅᴇʀ ᴄʜᴇsᴛ");
      Inventory inv = Bukkit.createInventory(holder, size, ColorUtil.parse(title));
      holder.setInventory(inv);
      Player ownerPlayer = Bukkit.getPlayer(owner);
      ItemStack[] contents;
      if (!admin && ownerPlayer != null) {
         if (plugin.getConfig().getBoolean("seed-from-vanilla", true) && !plugin.getStorage().fileFor(owner).exists()) {
            contents = plugin.getStorage().seedFromVanilla(ownerPlayer, size);
         } else {
            contents = plugin.getStorage().loadForPlayer(ownerPlayer, size);
         }
      } else if (ownerPlayer != null) {
         contents = plugin.getStorage().loadForPlayer(ownerPlayer, size);
      } else {
         contents = plugin.getStorage().load(owner, size);
      }

      inv.setContents(contents);
      viewer.openInventory(inv);
      OPEN.put(owner, viewer.getUniqueId());
      play(viewer, plugin, true);
   }

   public static void play(Player player, SmpCoreEC plugin, boolean open) {
      if (plugin.getConfig().getBoolean("play-sounds", true)) {
         String path = open ? "open-sound" : "close-sound";
         String name = plugin.getConfig().getString(path, open ? "BLOCK_ENDER_CHEST_OPEN" : "BLOCK_ENDER_CHEST_CLOSE");

         try {
            SoundUtil.play(player, player.getLocation(), Sound.valueOf(name), 1.0F, 1.0F);
         } catch (Exception e) {
         }

      }
   }
}
