package me.nothing.smpcore.systems.shop;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Material;

public final class MenuSession {
   public static final Map<UUID, View> VIEW = new ConcurrentHashMap();
   public static final Map<UUID, String> SHOP_ID = new ConcurrentHashMap();
   public static final Map<UUID, BuyData> BUY = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      VIEW.remove(id);
      SHOP_ID.remove(id);
      BUY.remove(id);
   }

   public static enum View {
      SHOP,
      BUY;

      private static View[] $values() {
         return new View[]{SHOP, BUY};
      }
   }

   public static final class BuyData {
      public final String shopId;
      public final String slotKey;
      public final Material material;
      public final String displayName;
      public final double unitPrice;
      public final String takeCommand;
      public final String giveCommand;
      public final String economy;
      public final String symbol;
      public final String balancePlaceholder;
      public final int maxAmount;
      public int amount = 1;

      public BuyData(String shopId, String slotKey, Material material, String displayName, double unitPrice, String takeCommand, String giveCommand, String economy, String symbol, String balancePlaceholder, int maxAmount) {
         this.shopId = shopId;
         this.slotKey = slotKey;
         this.material = material;
         this.displayName = displayName;
         this.unitPrice = unitPrice;
         this.takeCommand = takeCommand;
         this.giveCommand = giveCommand;
         this.economy = economy;
         this.symbol = symbol;
         this.balancePlaceholder = balancePlaceholder;
         this.maxAmount = Math.max(1, maxAmount);
      }
   }
}
