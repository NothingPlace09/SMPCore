package me.nothing.smpcore.systems.chat2;

import me.nothing.smpcore.utils.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ClearChatCommand implements CommandExecutor {
   private final SmpCoreChat plugin;

   public ClearChatCommand(SmpCoreChat plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.isOp() && !player.hasPermission("smpcore.system.chat.clear")) {
            player.sendMessage(MessageUtil.color(this.plugin.getConfigManager().getMessage("chat.no-permission")));
            return true;
         }
      }

      Component blank = Component.empty();

      for(Player online : Bukkit.getOnlinePlayers()) {
         for(int i = 0; i < 100; ++i) {
            online.sendMessage(blank);
         }
      }

      String str;
      if (sender instanceof Player p) {
         str = p.getName();
      } else {
         str = "Console";
      }

      String clearerName = str;
      String clearMessage = this.plugin.getConfigManager().getMessage("chat.cleared");
      clearMessage = clearMessage.replace("%player%", clearerName);
      Component broadcast = MessageUtil.colorComponent(clearMessage);

      for(Player online : Bukkit.getOnlinePlayers()) {
         online.sendMessage(broadcast);
         SoundUtil.play(online, online.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.0F);
      }

      if (!(sender instanceof Player)) {
         sender.sendMessage(MessageUtil.color(clearMessage));
      }

      return true;
   }
}
