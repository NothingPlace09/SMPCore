package me.nothing.smpcore.systems.wl;

import me.nothing.smpcore.systems.SystemHost;

public class SmpCoreWhitelister extends SystemHost {
   private static SmpCoreWhitelister instance;
   private WhitelistSettings settings;

   public SmpCoreWhitelister() {
      super("wl");
   }

   public void stop() {
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();

      try {
         this.settings = new WhitelistSettings(this);
         this.settings.load();
      } catch (Throwable t) {
         this.getLogger().warning("Whitelist settings: " + t.getMessage());
      }

      try {
         this.getServer().getPluginManager().registerEvents(new CommandFilterListener(this), this.getCore());
      } catch (Throwable t) {
         this.getLogger().warning("Whitelist listener: " + t.getMessage());
      }

      this.getLogger().info("SmpCoreWhitelister enabled.");
   }

   public void reloadAll() {
      this.reloadConfig();
      if (this.settings != null) {
         this.settings.load();
      }

   }

   public static SmpCoreWhitelister getInstance() {
      return instance;
   }

   public WhitelistSettings getSettings() {
      return this.settings;
   }
}
