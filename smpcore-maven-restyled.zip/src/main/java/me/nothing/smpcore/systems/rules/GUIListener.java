package me.nothing.smpcore.systems.rules;

import me.nothing.smpcore.utils.GuiSafe;
import me.nothing.smpcore.utils.SoundUtil;
import org.bukkit.Sound;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIListener implements Listener {
   private final SmpCoreRules plugin;

   public GUIListener(SmpCoreRules plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onClick(InventoryClickEvent event) {
      HumanEntity humanEntity = event.getWhoClicked();
      if (humanEntity instanceof Player player) {
         if (event.getView().title().equals(MessageUtil.color(this.plugin.getConfig().getString("gui.title")))) {
            event.setCancelled(true);
            if (event.getCurrentItem() != null) {
               if (this.plugin.getConfig().getBoolean("sound.enabled", true)) {
                  try {
                     Sound sound = Sound.valueOf(this.plugin.getConfig().getString("sound.type", "UI_BUTTON_CLICK"));
                     SoundUtil.play(player, player.getLocation(), sound, (float)this.plugin.getConfig().getDouble("sound.volume", (double)1.0F), (float)this.plugin.getConfig().getDouble("sound.pitch", (double)1.0F));
                  } catch (Exception e) {
                  }
               }

               GuiSafe.close(player);
            }
         }
      }
   }
}
