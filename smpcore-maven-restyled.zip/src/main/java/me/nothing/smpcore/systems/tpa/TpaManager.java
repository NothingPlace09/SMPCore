package me.nothing.smpcore.systems.tpa;

import me.nothing.smpcore.utils.MoveCheck;
import me.nothing.smpcore.systems.combat.CombatGuard;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import me.nothing.smpcore.utils.HotbarUtil;
import me.nothing.smpcore.utils.SoundUtil;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

public final class TpaManager {
   private final SmpCoreTPA plugin;
   private final Map<UUID, TpaRequest> incoming = new HashMap();
   private final Map<UUID, UUID> outgoing = new HashMap();
   private final Map<UUID, BukkitTask> timeoutTasks = new HashMap();
   private final Map<UUID, BukkitTask> teleportTasks = new HashMap();
   private final Set<UUID> teleporting = new HashSet();
   private final Map<UUID, Location> teleportStart = new HashMap();
   private final Set<UUID> tpAuto = new HashSet();
   private final Set<UUID> tpaDisabled = new HashSet();
   private final Set<UUID> tpahereDisabled = new HashSet();
   private final Set<UUID> confirmGuiDisabled = new HashSet();
   private final Map<UUID, Set<UUID>> ignoreList = new HashMap();
   private File settingsFile;
   private FileConfiguration settings;
   private BukkitTask tpAutoBarTask;

   public TpaManager(SmpCoreTPA plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      this.settingsFile = new File(this.plugin.getDataFolder(), "settings.yml");
      if (!this.settingsFile.exists()) {
         try {
            this.plugin.getDataFolder().mkdirs();
            this.settingsFile.createNewFile();
         } catch (IOException e) {
         }
      }

      this.settings = YamlConfiguration.loadConfiguration(this.settingsFile);
      this.tpAuto.clear();
      this.tpaDisabled.clear();
      this.tpahereDisabled.clear();
      this.confirmGuiDisabled.clear();
      this.ignoreList.clear();

      for(String raw : this.settings.getStringList("tpauto")) {
         try {
            this.tpAuto.add(UUID.fromString(raw));
         } catch (Exception e) {
         }
      }

      for(String raw : this.settings.getStringList("tpa-disabled")) {
         try {
            this.tpaDisabled.add(UUID.fromString(raw));
         } catch (Exception e) {
         }
      }

      for(String raw : this.settings.getStringList("tpahere-disabled")) {
         try {
            this.tpahereDisabled.add(UUID.fromString(raw));
         } catch (Exception e) {
         }
      }

      for(String raw : this.settings.getStringList("confirm-gui-disabled")) {
         try {
            this.confirmGuiDisabled.add(UUID.fromString(raw));
         } catch (Exception e) {
         }
      }

      if (this.settings.getConfigurationSection("ignore") != null) {
         for(String key : this.settings.getConfigurationSection("ignore").getKeys(false)) {
            try {
               UUID id = UUID.fromString(key);
               Set<UUID> set = new HashSet();

               for(String o : this.settings.getStringList("ignore." + key)) {
                  try {
                     set.add(UUID.fromString(o));
                  } catch (Exception e) {
                  }
               }

               this.ignoreList.put(id, set);
            } catch (Exception e) {
            }
         }
      }

   }

   public void saveSettings() {
      if (this.settings != null && this.settingsFile != null) {
         this.settings.set("tpauto", this.tpAuto.stream().map(UUID::toString).toList());
         this.settings.set("tpa-disabled", this.tpaDisabled.stream().map(UUID::toString).toList());
         this.settings.set("tpahere-disabled", this.tpahereDisabled.stream().map(UUID::toString).toList());
         this.settings.set("confirm-gui-disabled", this.confirmGuiDisabled.stream().map(UUID::toString).toList());
         this.settings.set("ignore", (Object)null);

         for(Map.Entry<UUID, Set<UUID>> e : this.ignoreList.entrySet()) {
            this.settings.set("ignore." + String.valueOf(e.getKey()), ((Set<UUID>)e.getValue()).stream().map(UUID::toString).toList());
         }

         try {
            this.settings.save(this.settingsFile);
         } catch (IOException e) {
         }

      }
   }

   public boolean isTpAuto(UUID id) {
      return this.tpAuto.contains(id);
   }

   public boolean toggleTpAuto(UUID id) {
      if (this.tpAuto.contains(id)) {
         this.tpAuto.remove(id);
         this.saveSettings();
         return false;
      } else {
         this.tpAuto.add(id);
         this.saveSettings();
         return true;
      }
   }

   public boolean isTpaDisabled(UUID id) {
      return this.tpaDisabled.contains(id);
   }

   public boolean toggleTpa(UUID id) {
      if (this.tpaDisabled.contains(id)) {
         this.tpaDisabled.remove(id);
         this.saveSettings();
         return true;
      } else {
         this.tpaDisabled.add(id);
         this.saveSettings();
         return false;
      }
   }

   public boolean isTpahereDisabled(UUID id) {
      return this.tpahereDisabled.contains(id);
   }

   public boolean toggleTpahere(UUID id) {
      if (this.tpahereDisabled.contains(id)) {
         this.tpahereDisabled.remove(id);
         this.saveSettings();
         return true;
      } else {
         this.tpahereDisabled.add(id);
         this.saveSettings();
         return false;
      }
   }

   public boolean isConfirmGuiEnabled(UUID id) {
      return !this.confirmGuiDisabled.contains(id);
   }

   public boolean toggleConfirmGui(UUID id) {
      if (this.confirmGuiDisabled.contains(id)) {
         this.confirmGuiDisabled.remove(id);
         this.saveSettings();
         return true;
      } else {
         this.confirmGuiDisabled.add(id);
         this.saveSettings();
         return false;
      }
   }

   public boolean isIgnoring(UUID player, UUID other) {
      Set<UUID> set = (Set)this.ignoreList.get(player);
      return set != null && set.contains(other);
   }

   public boolean toggleIgnore(UUID player, UUID other) {
      Set<UUID> set = (Set)this.ignoreList.computeIfAbsent(player, (k) -> new HashSet());
      if (set.contains(other)) {
         set.remove(other);
         this.saveSettings();
         return false;
      } else {
         set.add(other);
         this.saveSettings();
         return true;
      }
   }

   public TpaRequest getIncoming(UUID target) {
      return (TpaRequest)this.incoming.get(target);
   }

   public boolean hasOutgoing(UUID sender) {
      return this.outgoing.containsKey(sender);
   }

   public boolean isTeleporting(UUID id) {
      return this.teleporting.contains(id);
   }

   public void sendRequest(Player sender, Player target, TpaRequest.Type type) {
      TpaRequest request = new TpaRequest(sender.getUniqueId(), target.getUniqueId(), type);
      this.incoming.put(target.getUniqueId(), request);
      this.outgoing.put(sender.getUniqueId(), target.getUniqueId());
      int timeout = Math.max(5, this.plugin.getConfig().getInt("teleport.tpa-timeout-seconds", 60));
      this.cancelTimeout(target.getUniqueId());
      BukkitTask task = Bukkit.getScheduler().runTaskLater(this.plugin.getCore(), () -> {
         TpaRequest current = (TpaRequest)this.incoming.get(target.getUniqueId());
         if (current != null && current.getSender().equals(sender.getUniqueId())) {
            this.incoming.remove(target.getUniqueId());
            this.outgoing.remove(sender.getUniqueId());
            if (sender.isOnline()) {
               sender.sendMessage(ColorUtil.parse(this.msg("tpa-request-timeout", "&cYour teleport request to &#37BFF8{target}&c has expired.").replace("{target}", target.getName())));
            }

            if (target.isOnline()) {
               target.sendMessage(ColorUtil.parse(this.msg("tpa-request-expired", "&cThe teleport request from &#37BFF8{sender}&c has expired.").replace("{sender}", sender.getName())));
            }
         }

      }, (long)timeout * 20L);
      this.timeoutTasks.put(target.getUniqueId(), task);
      if (type == TpaRequest.Type.TPA) {
         sender.sendMessage(ColorUtil.parse(this.msg("tpa-request-sent", "&7Tpa request sent to &#37BFF8{target}&7.").replace("{target}", target.getName())));
         target.sendMessage(ColorUtil.parse(this.msg("tpa-request-received", "&7&#37BFF8{sender} &7wants to teleport to you.").replace("{sender}", sender.getName())));
         HotbarUtil.send(sender, ColorUtil.parse(this.msg("actionbar-tpa-sent", "&7Tpa sent to &#37BFF8{target}").replace("{target}", target.getName())));
         HotbarUtil.send(target, ColorUtil.parse(this.msg("actionbar-tpa-received", "&#37BFF8{sender} &7wants to teleport to you").replace("{sender}", sender.getName())));
      } else {
         sender.sendMessage(ColorUtil.parse(this.msg("tpahere-request-sent", "&7Tpahere request sent to &#37BFF8{target}&7.").replace("{target}", target.getName())));
         target.sendMessage(ColorUtil.parse(this.msg("tpahere-request-received", "&7&#37BFF8{sender} &7wants you to teleport to them.").replace("{sender}", sender.getName())));
         HotbarUtil.send(sender, ColorUtil.parse(this.msg("actionbar-tpahere-sent", "&7Tpahere sent to &#37BFF8{target}").replace("{target}", target.getName())));
         HotbarUtil.send(target, ColorUtil.parse(this.msg("actionbar-tpahere-received", "&#37BFF8{sender} &7requested tpahere").replace("{sender}", sender.getName())));
      }

      String click = this.msg("click-accept-text", "&#37BFF8[CLICK] ");
      String hover = this.msg("click-accept-hover", "Click to accept request");
      String orType = this.msg("or-type-text", "&7or type &#37BFF8/tpaccept {sender}").replace("{sender}", sender.getName());
      target.sendMessage(ColorUtil.parse(click).clickEvent(ClickEvent.runCommand("/tpaccept " + sender.getName())).hoverEvent(HoverEvent.showText(ColorUtil.parse(hover))).append(ColorUtil.parse(orType)));
      if (this.isTpAuto(target.getUniqueId())) {
         Bukkit.getScheduler().runTaskLater(this.plugin.getCore(), () -> {
            if (this.incoming.containsKey(target.getUniqueId())) {
               this.accept(target, sender.getName());
            }

         }, 5L);
      }

      this.play(sender, "success");
      this.play(target, "request");
   }

   public void openAcceptGui(Player target, String senderName) {
      TpaRequest request = (TpaRequest)this.incoming.get(target.getUniqueId());
      if (request == null) {
         target.sendMessage(ColorUtil.parse(this.msg("tpa-no-pending-request", "&cThis tpa does not exist.")));
      } else {
         Player sender = Bukkit.getPlayer(request.getSender());
         if (sender != null && sender.isOnline()) {
            if (senderName != null && !senderName.isBlank() && !sender.getName().equalsIgnoreCase(senderName)) {
               target.sendMessage(ColorUtil.parse(this.msg("tpa-no-active-request", "&cYou do not have an active teleport request from &#37BFF8{sender}&c.").replace("{sender}", senderName)));
            } else if (!this.isConfirmGuiEnabled(target.getUniqueId())) {
               this.accept(target, sender.getName());
            } else {
               TpaMenus.openAccept(target, sender, request.getType());
            }
         } else {
            this.clearRequest(request);
            target.sendMessage(ColorUtil.parse(this.msg("player-not-found", "&cPlayer not found!")));
         }
      }
   }

   public void accept(Player target, String senderName) {
      TpaRequest request = (TpaRequest)this.incoming.get(target.getUniqueId());
      if (request == null) {
         target.sendMessage(ColorUtil.parse(this.msg("tpa-no-pending-request", "&cThis tpa does not exist.")));
      } else {
         Player sender = Bukkit.getPlayer(request.getSender());
         if (sender != null && sender.isOnline()) {
            if (senderName != null && !senderName.isBlank() && !sender.getName().equalsIgnoreCase(senderName)) {
               target.sendMessage(ColorUtil.parse(this.msg("tpa-no-active-request", "&cYou do not have an active teleport request from &#37BFF8{sender}&c.").replace("{sender}", senderName)));
            } else {
               this.clearRequest(request);
               if (request.getType() == TpaRequest.Type.TPA) {
                  target.sendMessage(ColorUtil.parse(this.msg("tpa-accepted-target", "&7You accepted the tpa from &#37BFF8{sender}&7.").replace("{sender}", sender.getName())));
                  sender.sendMessage(ColorUtil.parse(this.msg("tpa-accepted-sender", "&7Your tpa to &#37BFF8{target} &7was accepted.").replace("{target}", target.getName())));
                  this.startTeleport(sender, target);
               } else {
                  target.sendMessage(ColorUtil.parse(this.msg("tpahere-accepted-target", "&7You accepted the tpahere.")));
                  sender.sendMessage(ColorUtil.parse(this.msg("tpahere-accepted-sender", "&7Your tpahere to &#37BFF8{target} &7was accepted.").replace("{target}", target.getName())));
                  this.startTeleport(target, sender);
               }

               this.play(target, "success");
               this.play(sender, "success");
            }
         } else {
            this.clearRequest(request);
            target.sendMessage(ColorUtil.parse(this.msg("player-not-found", "&cPlayer not found!")));
         }
      }
   }

   public void deny(Player target, String senderName) {
      TpaRequest request = (TpaRequest)this.incoming.get(target.getUniqueId());
      if (request == null) {
         target.sendMessage(ColorUtil.parse(this.msg("tpa-no-pending-request", "&cThis tpa does not exist.")));
      } else {
         Player sender = Bukkit.getPlayer(request.getSender());
         if (senderName != null && !senderName.isBlank() && sender != null && !sender.getName().equalsIgnoreCase(senderName)) {
            target.sendMessage(ColorUtil.parse(this.msg("tpa-no-active-request", "&cYou do not have an active teleport request from &#37BFF8{sender}&c.").replace("{sender}", senderName)));
         } else {
            this.clearRequest(request);
            if (request.getType() == TpaRequest.Type.TPA) {
               target.sendMessage(ColorUtil.parse(this.msg("tpa-denied-target", "&cYou denied &#37BFF8{sender}'s&c teleport request.").replace("{sender}", sender != null ? sender.getName() : "player")));
               if (sender != null) {
                  sender.sendMessage(ColorUtil.parse(this.msg("tpa-denied-sender", "&cYour teleport request to &#37BFF8{target}&c has been denied.").replace("{target}", target.getName())));
               }
            } else {
               target.sendMessage(ColorUtil.parse(this.msg("tpahere-denied-target", "&cYou denied &#37BFF8{sender}'s&c tpahere request.").replace("{sender}", sender != null ? sender.getName() : "player")));
               if (sender != null) {
                  sender.sendMessage(ColorUtil.parse(this.msg("tpahere-denied-sender", "&cYour tpahere request to &#37BFF8{target}&c has been denied.").replace("{target}", target.getName())));
               }
            }

            this.play(target, "error");
            if (sender != null) {
               this.play(sender, "error");
            }

         }
      }
   }

   public void cancel(Player sender) {
      UUID targetId = (UUID)this.outgoing.get(sender.getUniqueId());
      if (targetId == null) {
         sender.sendMessage(ColorUtil.parse(this.msg("tpa-no-pending-request", "&cThis tpa does not exist.")));
      } else {
         TpaRequest request = (TpaRequest)this.incoming.get(targetId);
         if (request != null && request.getSender().equals(sender.getUniqueId())) {
            this.clearRequest(request);
            sender.sendMessage(ColorUtil.parse(this.msg("tpa-cancelled-sender", "&cYou cancelled your teleport request.")));
            Player target = Bukkit.getPlayer(targetId);
            if (target != null) {
               target.sendMessage(ColorUtil.parse(this.msg("tpa-cancelled-target", "&c&#37BFF8{sender} &ccancelled their teleport request.").replace("{sender}", sender.getName())));
            }

         } else {
            this.outgoing.remove(sender.getUniqueId());
            sender.sendMessage(ColorUtil.parse(this.msg("tpa-no-pending-request", "&cThis tpa does not exist.")));
         }
      }
   }

   private void startTeleport(final Player traveler, final Player destination) {
      if (CombatGuard.deny(traveler)) {
         return;
      }

      final int delay = Math.max(0, this.plugin.getConfig().getInt("teleport.tpa-teleport-delay-seconds", 5));
      if (delay <= 0) {
         if (destination.isOnline()) {
            traveler.teleport(destination.getLocation().clone());
            traveler.sendMessage(ColorUtil.parse(this.msg("teleport-done", "&aTeleported!")));
            this.play(traveler, "teleport");
         }
      } else {
         this.cancelTeleport(traveler.getUniqueId());
         this.teleporting.add(traveler.getUniqueId());
         this.teleportStart.put(traveler.getUniqueId(), traveler.getLocation().clone());
         BukkitTask task = (new BukkitRunnable() {
            int left = delay;

            public void run() {
               if (!traveler.isOnline()) {
                  TpaManager.this.cleanupTeleport(traveler.getUniqueId());
                  this.cancel();
               } else {
                  Location start = (Location)TpaManager.this.teleportStart.get(traveler.getUniqueId());
                  double maxDist = TpaManager.this.plugin.getConfig().getDouble("teleport.cancel-distance", (double)0.5F);
                  if (start != null && MoveCheck.movedMoreThan(traveler.getLocation(), start, maxDist)) {
                     traveler.sendMessage(ColorUtil.parse(TpaManager.this.msg("tpa-moved-cancel", "&cTeleport cancelled: movement detected!")));
                     TpaManager.this.play(traveler, "error");
                     TpaManager.this.cleanupTeleport(traveler.getUniqueId());
                     this.cancel();
                  } else if (CombatGuard.isBlocked(traveler)) {
                     CombatGuard.deny(traveler);
                     TpaManager.this.cleanupTeleport(traveler.getUniqueId());
                     this.cancel();
                  } else if (this.left <= 0) {
                     if (!destination.isOnline()) {
                        TpaManager.this.cleanupTeleport(traveler.getUniqueId());
                        this.cancel();
                     } else {
                        traveler.teleport(destination.getLocation().clone());
                        traveler.sendMessage(ColorUtil.parse(TpaManager.this.msg("teleport-done", "&aTeleported!")));
                        TpaManager.this.play(traveler, "teleport");
                        TpaManager.this.cleanupTeleport(traveler.getUniqueId());
                        this.cancel();
                     }
                  } else {
                     HotbarUtil.send(traveler, ColorUtil.parse(TpaManager.this.msg("countdown-actionbar", "&7Teleporting in &#37BFF8{seconds} &7seconds").replace("{seconds}", String.valueOf(this.left))));
                     TpaManager.this.play(traveler, "countdown");
                     --this.left;
                  }
               }
            }
         }).runTaskTimer(this.plugin.getCore(), 0L, 20L);
         this.teleportTasks.put(traveler.getUniqueId(), task);
      }
   }

   public void onMove(Player player) {
      if (this.teleporting.contains(player.getUniqueId())) {
         Location start = (Location)this.teleportStart.get(player.getUniqueId());
         if (start != null) {
            double maxDist = this.plugin.getConfig().getDouble("teleport.cancel-distance", (double)0.5F);
            if (MoveCheck.movedMoreThan(player.getLocation(), start, maxDist)) {
               this.cancelTeleport(player.getUniqueId());
               player.sendMessage(ColorUtil.parse(this.msg("tpa-moved-cancel", "&cTeleport cancelled: movement detected!")));
               this.play(player, "error");
            }

         }
      }
   }

   private void clearRequest(TpaRequest request) {
      this.incoming.remove(request.getTarget());
      this.outgoing.remove(request.getSender());
      this.cancelTimeout(request.getTarget());
   }

   private void cancelTimeout(UUID target) {
      BukkitTask t = (BukkitTask)this.timeoutTasks.remove(target);
      if (t != null) {
         t.cancel();
      }

   }

   private void cancelTeleport(UUID id) {
      BukkitTask t = (BukkitTask)this.teleportTasks.remove(id);
      if (t != null) {
         t.cancel();
      }

      this.cleanupTeleport(id);
   }

   private void cleanupTeleport(UUID id) {
      this.teleporting.remove(id);
      this.teleportStart.remove(id);
      this.teleportTasks.remove(id);
   }

   public void startTpAutoBarTask() {
      this.stopTpAutoBarTask();
      this.tpAutoBarTask = Bukkit.getScheduler().runTaskTimer(this.plugin.getCore(), () -> {
         String bar = this.msg("tpauto-actionbar-on", "&aYou have tpauto on.");

         for(UUID id : new HashSet<>(this.tpAuto)) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
               HotbarUtil.send(p, ColorUtil.parse(bar));
            }
         }

      }, 20L, 20L);
   }

   public void stopTpAutoBarTask() {
      if (this.tpAutoBarTask != null) {
         this.tpAutoBarTask.cancel();
         this.tpAutoBarTask = null;
      }

   }

   public void playSound(Player player, String key) {
      this.play(player, key);
   }

   private String msg(String key, String def) {
      return this.plugin.getMessages().get(key, def);
   }

   private void play(Player player, String key) {
      try {
         String sound = this.plugin.getConfig().getString("sounds." + key, "");
         if (sound == null || sound.isBlank()) {
            return;
         }

         String normalized = sound.toUpperCase().replace('.', '_');
         float volume = (float)this.plugin.getConfig().getDouble("sounds." + key + "-volume", (double)1.0F);
         float pitch = (float)this.plugin.getConfig().getDouble("sounds." + key + "-pitch", (double)1.0F);
         SoundUtil.play(player, player.getLocation(), Sound.valueOf(normalized), volume, pitch);
      } catch (Exception e) {
      }

   }
}
