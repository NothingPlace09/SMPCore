package me.nothing.smpcore.systems.lb;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, View> VIEW = new ConcurrentHashMap();
   public static final Map<UUID, StatsManager.Board> BOARD = new ConcurrentHashMap();
   public static final Map<UUID, Integer> PAGE = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      VIEW.remove(id);
      BOARD.remove(id);
      PAGE.remove(id);
   }

   public static enum View {
      MAIN,
      BOARD,
      SEARCH;

      private static View[] $values() {
         return new View[]{MAIN, BOARD, SEARCH};
      }
   }
}
