package me.nothing.smpcore.systems.shop;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class ShopCommand implements CommandExecutor, TabCompleter {
   private final SmpCoreShop plugin;

   public ShopCommand(SmpCoreShop plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
         if (!sender.hasPermission("smpcore.system.shop.admin") && !sender.hasPermission("smpcore.system.shop.admin")) {
            sender.sendMessage(ColorUtil.parse(this.plugin.getMessages().get("no-permission")));
            return true;
         } else {
            this.plugin.reloadAll();
            sender.sendMessage(ColorUtil.parse(this.plugin.getMessages().get("reloaded")));
            return true;
         }
      } else if (sender instanceof Player) {
         Player player = (Player)sender;
         if (!player.hasPermission("smpcore.system.shop.use")) {
            player.sendMessage(ColorUtil.parse(this.plugin.getMessages().get("no-permission")));
            return true;
         } else {
            String shop = "main";
            if (args.length > 0) {
               String asked = args[0].toLowerCase();
               if (this.plugin.getShops().hasShop(asked)) {
                  shop = asked;
               }
            }

            ShopMenus.open(player, shop);
            return true;
         }
      } else {
         sender.sendMessage(ColorUtil.parse(this.plugin.getMessages().get("only-players")));
         return true;
      }
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      List<String> out = new ArrayList();
      if (args.length == 1) {
         if ("reload".startsWith(args[0].toLowerCase()) && sender.hasPermission("smpcore.system.shop.admin")) {
            out.add("reload");
         }

         for(String key : this.plugin.getShops().getShopIds()) {
            if (key.toLowerCase().startsWith(args[0].toLowerCase())) {
               out.add(key);
            }
         }
      }

      return out;
   }
}
