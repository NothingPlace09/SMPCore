package me.nothing.smpcore.systems.tools;

import me.nothing.smpcore.utils.GuiSafe;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;

public class GuiListener implements Listener {
   private final SmpCoreTools plugin;

   public GuiListener(SmpCoreTools plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onClick(InventoryClickEvent event) {
      if (event.getInventory().getHolder() instanceof ToolsGui) {
         event.setCancelled(true);
         HumanEntity humanEntity = event.getWhoClicked();
         if (humanEntity instanceof Player) {
            Player player = (Player)humanEntity;
            if (event.getClickedInventory() != null) {
               if (event.getClickedInventory().getHolder() == event.getInventory().getHolder()) {
                  ItemStack clicked = event.getCurrentItem();
                  if (clicked != null && !clicked.getType().isAir()) {
                     int closeSlot = this.plugin.getGuiConfig().getInt("close.slot", -1);
                     if (event.getSlot() == closeSlot) {
                        GuiSafe.close(player);
                     } else {
                        String type = this.plugin.getToolFactory().getType(clicked);
                        if (type != null) {
                           if (!player.hasPermission("smpcore.system.tools.admin")) {
                              MessageUtil.send(player, "no-permission");
                           } else {
                              ToolDefinition def = this.plugin.getToolManager().get(type);
                              if (def != null) {
                                 ItemStack give = this.plugin.getToolFactory().create(def);
                                 if (player.getInventory().firstEmpty() == -1) {
                                    MessageUtil.send(player, "inventory-full");
                                 } else {
                                    player.getInventory().addItem(new ItemStack[]{give});
                                    MessageUtil.send(player, "tool-received", "%tool%", def.getId());
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }
   }
}
