package me.nothing.smpcore.systems.homes;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public final class ColorUtil {
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final Pattern LEGACY_HEX = Pattern.compile("&x((?:&[A-Fa-f0-9]){6})");

   private ColorUtil() {
   }

   public static String color(String input) {
      if (input != null && !input.isEmpty()) {
         Matcher m = HEX.matcher(input);
         StringBuffer sb = new StringBuffer();

         while(m.find()) {
            m.appendReplacement(sb, ChatColor.of("#" + m.group(1)).toString());
         }

         m.appendTail(sb);
         input = sb.toString();
         m = LEGACY_HEX.matcher(input);
         sb = new StringBuffer();

         while(m.find()) {
            String hex = m.group(1).replace("&", "");
            m.appendReplacement(sb, ChatColor.of("#" + hex).toString());
         }

         m.appendTail(sb);
         return ChatColor.translateAlternateColorCodes('&', sb.toString());
      } else {
         return "";
      }
   }
}
