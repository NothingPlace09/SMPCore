package me.nothing.smpcore.systems.combat;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.utils.SoundUtil;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class CombatManager {
   private final SmpCoreCombat plugin;
   private final Map<UUID, Long> combatUntil = new ConcurrentHashMap();
   private final Map<UUID, Long> rewardCooldown = new ConcurrentHashMap();
   private final Map<String, Long> victimCooldown = new ConcurrentHashMap();
   private BukkitTask actionbarTask;
   private int duration;
   private boolean actionbarEnabled;
   private int actionbarInterval;

   public CombatManager(SmpCoreCombat plugin) {
      this.plugin = plugin;
      this.reload();
      this.startActionbar();
   }

   public void reload() {
      this.duration = this.plugin.getConfig().getInt("settings.combat-duration", 20);
      this.actionbarEnabled = this.plugin.getConfig().getBoolean("settings.actionbar-enabled", true);
      this.actionbarInterval = this.plugin.getConfig().getInt("settings.actionbar-interval", 10);
      if (this.actionbarTask != null) {
         this.actionbarTask.cancel();
      }

      this.startActionbar();
   }

   private void startActionbar() {
      if (this.actionbarEnabled) {
         this.actionbarTask = Bukkit.getScheduler().runTaskTimer(this.plugin.getCore(), () -> {
            long now = System.currentTimeMillis();

            for(Map.Entry<UUID, Long> e : this.combatUntil.entrySet()) {
               Player p = Bukkit.getPlayer((UUID)e.getKey());
               if (p != null && p.isOnline()) {
                  long left = ((Long)e.getValue() - now) / 1000L;
                  if (left <= 0L) {
                     this.leaveCombat(p, true);
                  } else {
                     String msg = MessageUtil.color("&7Combat: &7" + left + "s");
                     p.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(msg));
                  }
               }
            }

         }, (long)this.actionbarInterval, (long)this.actionbarInterval);
      }
   }

   public void tag(Player player) {
      if (!player.hasPermission("smpcore.system.combat.bypass")) {
         boolean was = this.isInCombat(player);
         long until = System.currentTimeMillis() + (long)this.duration * 1000L;
         this.combatUntil.put(player.getUniqueId(), until);
         if (!was) {
            MessageUtil.send(player, "enter-combat");
            this.playSound(player, "enter-combat");
         }

      }
   }

   public void tagBoth(Player a, Player b) {
      if (this.plugin.getConfig().getBoolean("settings.tag-attacker", true)) {
         this.tag(a);
      }

      if (this.plugin.getConfig().getBoolean("settings.tag-victim", true)) {
         this.tag(b);
      }

   }

   public void leaveCombat(Player player, boolean notify) {
      if (this.combatUntil.remove(player.getUniqueId()) != null && notify) {
         MessageUtil.send(player, "leave-combat");
         this.playSound(player, "leave-combat");
         player.spigot().sendMessage(ChatMessageType.ACTION_BAR, TextComponent.fromLegacyText(MessageUtil.color("&aYou are no longer in combat")));
      }

   }

   public boolean isInCombat(Player player) {
      Long until = (Long)this.combatUntil.get(player.getUniqueId());
      if (until == null) {
         return false;
      } else if (System.currentTimeMillis() >= until) {
         this.combatUntil.remove(player.getUniqueId());
         return false;
      } else {
         return true;
      }
   }

   public int getTimeLeft(Player player) {
      Long until = (Long)this.combatUntil.get(player.getUniqueId());
      if (until == null) {
         return 0;
      } else {
         long left = (until - System.currentTimeMillis()) / 1000L;
         return (int)Math.max(0L, left);
      }
   }

   public boolean canReward(Player killer) {
      if (!this.plugin.getConfig().getBoolean("kill-reward.enabled", true)) {
         return false;
      } else {
         Long last = (Long)this.rewardCooldown.get(killer.getUniqueId());
         int cd = this.plugin.getConfig().getInt("kill-reward.cooldown", 30);
         return last == null || System.currentTimeMillis() - last >= (long)cd * 1000L;
      }
   }

   /**
    * FIX farming: il cooldown era solo per killer, quindi un alt/amico uccidibile ogni 30s dava shard infiniti.
    * Ora: niente premio se killer e vittima hanno lo stesso IP, e la STESSA vittima non da' premio piu' di una volta
    * ogni same-victim-cooldown secondi (default 600).
    */
   public void applyReward(Player killer, Player victim) {
      if (killer != null && victim != null && !killer.getUniqueId().equals(victim.getUniqueId())) {
         if (this.plugin.getConfig().getBoolean("kill-reward.block-same-ip", true) && this.sameAddress(killer, victim)) {
            return;
         } else {
            long now = System.currentTimeMillis();
            long victimCd = (long)this.plugin.getConfig().getInt("kill-reward.same-victim-cooldown", 600) * 1000L;
            String pair = String.valueOf(killer.getUniqueId()) + ":" + String.valueOf(victim.getUniqueId());
            Long lastVictim = (Long)this.victimCooldown.get(pair);
            if (victimCd > 0L && lastVictim != null && now - lastVictim < victimCd) {
               MessageUtil.send(killer, "already-reward");
            } else {
               if (this.canReward(killer)) {
                  if (this.victimCooldown.size() > 2000) {
                     this.victimCooldown.values().removeIf((t) -> now - t > 3600000L);
                  }

                  this.victimCooldown.put(pair, now);
               }

               this.applyReward(killer);
            }
         }
      }
   }

   private boolean sameAddress(Player a, Player b) {
      try {
         return a.getAddress() != null && b.getAddress() != null && a.getAddress().getAddress().equals(b.getAddress().getAddress());
      } catch (Exception e) {
         return false;
      }
   }

   public void applyReward(Player killer) {
      if (!this.canReward(killer)) {
         MessageUtil.send(killer, "already-reward");
      } else {
         this.rewardCooldown.put(killer.getUniqueId(), System.currentTimeMillis());

         for(String cmd : this.plugin.getConfig().getStringList("kill-reward.commands")) {
            String parsed = cmd.replace("%killer%", killer.getName());
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), parsed);
         }

      }
   }

   public void playSound(Player player, String path) {
      String name = this.plugin.getConfig().getString("sounds." + path);
      if (name != null && !name.isEmpty()) {
         try {
            Sound sound = Sound.valueOf(name);
            SoundUtil.play(player, player.getLocation(), sound, 1.0F, 1.0F);
         } catch (IllegalArgumentException e) {
         }

      }
   }

   public void shutdown() {
      if (this.actionbarTask != null) {
         this.actionbarTask.cancel();
      }

      this.combatUntil.clear();
      this.rewardCooldown.clear();
      this.victimCooldown.clear();
   }

   public Map<UUID, Long> getCombatMap() {
      return this.combatUntil;
   }
}
