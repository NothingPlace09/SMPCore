package me.nothing.smpcore.systems.hide;

import me.nothing.smpcore.systems.SystemHost;

public class SmpCoreHide extends SystemHost {
   private static SmpCoreHide instance;
   private DataManager dataManager;
   private HideManager hideManager;
   private NameManager nameManager;
   private NameTagManager nameTagManager;
   private SkinManager skinManager;

   public SmpCoreHide() {
      super("hide");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.dataManager = new DataManager(this);
      this.nameManager = new NameManager(this);
      this.nameTagManager = new NameTagManager(this);
      this.skinManager = new SkinManager(this);
      this.hideManager = new HideManager(this);
      this.hideManager.load();
      this.getServer().getPluginManager().registerEvents(new PlayerJoinListener(this), this);
      this.getLogger().info("SmpCoreHide has been enabled!");
   }

   public void stop() {
      if (this.hideManager != null) {
         this.hideManager.save();
      }

      if (this.dataManager != null) {
         this.dataManager.save();
      }

   }

   public static SmpCoreHide getInstance() {
      return instance;
   }

   public DataManager getDataManager() {
      return this.dataManager;
   }

   public HideManager getHideManager() {
      return this.hideManager;
   }

   public NameManager getNameManager() {
      return this.nameManager;
   }

   public NameTagManager getNameTagManager() {
      return this.nameTagManager;
   }

   public SkinManager getSkinManager() {
      return this.skinManager;
   }
}
