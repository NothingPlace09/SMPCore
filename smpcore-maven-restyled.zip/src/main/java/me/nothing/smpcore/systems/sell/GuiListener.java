package me.nothing.smpcore.systems.sell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import me.nothing.smpcore.systems.lb.SmpCoreLeaderboards;
import org.bukkit.Material;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class GuiListener implements Listener {
   private final SmpCoreSell plugin;

   public GuiListener(SmpCoreSell plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onClick(InventoryClickEvent event) {
      HumanEntity humanEntity = event.getWhoClicked();
      if (humanEntity instanceof Player player) {
         MenuSession.View view = (MenuSession.View)MenuSession.VIEW.get(player.getUniqueId());
         if (view != null) {
            if (view == MenuSession.View.SELL) {
               this.handleSell(player, event);
            } else {
               event.setCancelled(true);
               if (event.getClickedInventory() != null && event.getClickedInventory() == event.getView().getTopInventory()) {
                  if (event.getClick() != ClickType.NUMBER_KEY && event.getClick() != ClickType.SWAP_OFFHAND) {
                     SoundUtil.click(player);
                     final int slot = event.getRawSlot();
                     final int page = (Integer)MenuSession.PAGE.getOrDefault(player.getUniqueId(), 0);
                     final MenuSession.View clickedView = view;
                     // FIX dupe: aprire/chiudere inventari DENTRO l'evento di click (con un item sul cursore) duplicava lo stack.
                     // L'azione viene eseguita al tick successivo, quando il click e' gia' concluso.
                     this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
                        if (player.isOnline() && MenuSession.VIEW.get(player.getUniqueId()) == clickedView) {
                           this.dispatchMenuClick(player, clickedView, slot, page);
                        }

                     });

                  }
               }
            }
         }
      }
   }

   private void dispatchMenuClick(Player player, MenuSession.View view, int slot, int page) {
      if (view == MenuSession.View.WORTH) {
         this.worth(player, slot, page);
      } else if (view == MenuSession.View.HISTORY) {
         this.history(player, slot, page);
      } else if (view == MenuSession.View.SELLMULTI) {
         this.sellMulti(player, slot);
      } else if (view == MenuSession.View.PROGRESS) {
         if (slot == 45) {
            SellMenus.openSellMulti(player);
            return;
         }

         if (slot == 1) {
            String cat = (String)MenuSession.PROGRESS_CATEGORY.get(player.getUniqueId());
            if (cat != null) {
               SellMenus.openCategoryItems(player, cat, 0);
            }
         }
      } else if (view == MenuSession.View.CATEGORY_ITEMS) {
         this.categoryItems(player, slot);
      }

   }

   private void categoryItems(Player player, int slot) {
      String cat = (String)MenuSession.PROGRESS_CATEGORY.get(player.getUniqueId());
      int page = (Integer)MenuSession.PAGE.getOrDefault(player.getUniqueId(), 0);
      if (slot == 45) {
         if (cat != null) {
            SellMenus.openCategoryItems(player, cat, page - 1);
         }

      } else if (slot == 53) {
         if (cat != null) {
            SellMenus.openCategoryItems(player, cat, page + 1);
         }

      } else {
         if (slot == 49) {
            if (cat != null) {
               SellMenus.openProgress(player, cat);
            } else {
               SellMenus.openSellMulti(player);
            }
         }

      }
   }

   private void sellMulti(Player player, int slot) {
      String str;
      switch (slot) {
         case 9 -> str = "crops";
         case 10 -> str = "ores";
         case 11 -> str = "mobs";
         case 12 -> str = "natural";
         case 13 -> str = "tools";
         case 14 -> str = "fish";
         case 15 -> str = "books";
         case 16 -> str = "potions";
         case 17 -> str = "blocks";
         default -> str = null;
      }

      String category = str;
      if (category != null) {
         SellMenus.openProgress(player, category);
      }
   }

   private void handleSell(Player player, InventoryClickEvent event) {
      int confirmSlot = this.plugin.getConfig().getInt("sell.confirm-slot", 44);
      int raw = event.getRawSlot();
      int topSize = event.getView().getTopInventory().getSize();
      boolean top = event.getClickedInventory() != null && event.getClickedInventory().equals(event.getView().getTopInventory());
      if (raw >= 36 && raw < topSize) {
         event.setCancelled(true);
         if (raw == confirmSlot) {
            SoundUtil.click(player);
            final Inventory sellInv = event.getView().getTopInventory();
            // FIX dupe: sellAll() chiude l'inventario; farlo dentro l'evento di click con un item sul cursore duplicava lo stack.
            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
               if (player.isOnline() && MenuSession.VIEW.get(player.getUniqueId()) == MenuSession.View.SELL && sellInv.equals(player.getOpenInventory().getTopInventory())) {
                  this.sellAll(player, sellInv, confirmSlot);
               }

            });
         }

         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (MenuSession.VIEW.get(player.getUniqueId()) == MenuSession.View.SELL) {
               this.returnBottomRowItems(player, event.getView().getTopInventory(), confirmSlot);
               SellMenus.updateConfirm(player, event.getView().getTopInventory());
            }

         });
      } else if (event.isShiftClick() && !top) {
         event.setCancelled(true);
         ItemStack clicked = event.getCurrentItem();
         if (clicked != null && !clicked.getType().isAir()) {
            this.moveIntoSellArea(player, event.getView().getTopInventory(), clicked, event.getSlot());
         }

         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (MenuSession.VIEW.get(player.getUniqueId()) == MenuSession.View.SELL) {
               this.returnBottomRowItems(player, event.getView().getTopInventory(), confirmSlot);
               SellMenus.updateConfirm(player, event.getView().getTopInventory());
            }

         });
      } else if (event.getClick() == ClickType.NUMBER_KEY && top && raw < 36) {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (MenuSession.VIEW.get(player.getUniqueId()) == MenuSession.View.SELL) {
               this.returnBottomRowItems(player, event.getView().getTopInventory(), confirmSlot);
               SellMenus.updateConfirm(player, event.getView().getTopInventory());
            }

         });
      } else {
         this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
            if (MenuSession.VIEW.get(player.getUniqueId()) == MenuSession.View.SELL) {
               this.returnBottomRowItems(player, event.getView().getTopInventory(), confirmSlot);
               SellMenus.updateConfirm(player, event.getView().getTopInventory());
            }

         });
      }
   }

   private void moveIntoSellArea(Player player, Inventory top, ItemStack source, int playerSlot) {
      ItemStack moving = source.clone();
      int left = moving.getAmount();

      for(int i = 0; i < 36 && left > 0; ++i) {
         ItemStack cur = top.getItem(i);
         if (cur != null && !cur.getType().isAir()) {
            if (cur.isSimilar(moving) && cur.getAmount() < cur.getMaxStackSize()) {
               int space = cur.getMaxStackSize() - cur.getAmount();
               int put = Math.min(space, left);
               cur.setAmount(cur.getAmount() + put);
               top.setItem(i, cur);
               left -= put;
            }
         } else {
            int put = Math.min(left, moving.getMaxStackSize());
            ItemStack place = moving.clone();
            place.setAmount(put);
            top.setItem(i, place);
            left -= put;
         }
      }

      if (left <= 0) {
         player.getInventory().setItem(playerSlot, (ItemStack)null);
      } else {
         source.setAmount(left);
         player.getInventory().setItem(playerSlot, source);
      }

   }

   private void returnBottomRowItems(Player player, Inventory inv, int confirmSlot) {
      if (inv != null) {
         int size = inv.getSize();

         for(int i = 36; i < size && i <= 44; ++i) {
            ItemStack stack = inv.getItem(i);
            if (stack != null && !stack.getType().isAir() && i != confirmSlot) {
               // FIX item loss: prima le glass pane fuori dallo slot conferma venivano cancellate
               inv.setItem(i, (ItemStack)null);
               Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{stack});
               left.values().forEach((s) -> player.getWorld().dropItemNaturally(player.getLocation(), s));
            }
         }

      }
   }

   private void sellAll(Player player, Inventory inv, int confirmSlot) {
      this.returnBottomRowItems(player, inv, confirmSlot);
      List<ItemStack> toReturn = new ArrayList();
      Map<Material, int[]> sold = new HashMap();
      double total = (double)0.0F;
      int itemCount = 0;

      for(int i = 0; i < Math.min(36, inv.getSize()); ++i) {
         ItemStack stack = inv.getItem(i);
         if (stack != null && !stack.getType().isAir()) {
            if (this.plugin.getBlacklist().isBlocked(stack)) {
               toReturn.add(stack.clone());
               inv.setItem(i, (ItemStack)null);
            } else {
               double pay = this.plugin.getPrices().getSellPrice(player, stack);
               total += pay;
               itemCount += stack.getAmount();
               sold.computeIfAbsent(stack.getType(), (k) -> new int[]{0, 0});
               int[] iArr = (int[])sold.get(stack.getType());
               iArr[0] += stack.getAmount();
               iArr = (int[])sold.get(stack.getType());
               iArr[1] += (int)Math.round(pay * (double)100.0F);
               String cat = this.plugin.getProgress().categoryOf(stack.getType());
               this.plugin.getProgress().addSold(player.getUniqueId(), cat, pay);
               inv.setItem(i, (ItemStack)null);
            }
         }
      }

      if (itemCount <= 0) {
         for(ItemStack stack : toReturn) {
            Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{stack});
            left.values().forEach((s) -> player.getWorld().dropItemNaturally(player.getLocation(), s));
         }

         this.plugin.getMessages().send(player, "nothing-to-sell");
         SoundUtil.error(player);
         SellMenus.updateConfirm(player, inv);
      } else {
         this.plugin.getEconomy().deposit(player, total);
         this.plugin.getProgress().addMoneyMade(player.getUniqueId(), total);

         try {
            SmpCoreLeaderboards _lb = SmpCoreLeaderboards.get();
            if (_lb != null && _lb.getStats() != null) {
               _lb.getStats().addSellEarned(player.getUniqueId(), total);
            }
         } catch (Throwable t) {
         }

         long now = System.currentTimeMillis();

         for(Map.Entry<Material, int[]> e : sold.entrySet()) {
            this.plugin.getHistory().add(new SellRecord(UUID.randomUUID(), player.getUniqueId(), (Material)e.getKey(), ((int[])e.getValue())[0], (double)((int[])e.getValue())[1] / (double)100.0F, now));
         }

         for(ItemStack stack : toReturn) {
            Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{stack});
            left.values().forEach((s) -> player.getWorld().dropItemNaturally(player.getLocation(), s));
         }

         if (!toReturn.isEmpty()) {
            this.plugin.getMessages().send(player, "blacklisted-returned", Map.of("count", String.valueOf(toReturn.size())));
         }

         this.plugin.getMessages().send(player, "sold", Map.of("amount", MoneyUtil.format(total)));
         this.plugin.getMessages().send(player, "sold-detail", Map.of("items", String.valueOf(itemCount), "amount", MoneyUtil.format(total)));
         SoundUtil.sell(player);
         player.closeInventory();
         if (this.plugin.getWorthLore() != null) {
            this.plugin.getServer().getScheduler().runTask(this.plugin, () -> this.plugin.getWorthLore().refresh(player));
         }

      }
   }

   private void worth(Player player, int slot, int page) {
      if (slot == 45) {
         SellMenus.openWorth(player, page - 1);
      } else if (slot == 53) {
         SellMenus.openWorth(player, page + 1);
      } else if (slot == 49) {
         SellMenus.openWorth(player, page);
      } else if (slot == 50) {
         InputUtil.requestSearch(player);
      } else if (slot == 47) {
         int sort = (Integer)MenuSession.SORT.getOrDefault(player.getUniqueId(), 0);
         MenuSession.SORT.put(player.getUniqueId(), (sort + 1) % 3);
         SellMenus.openWorth(player, 0);
      } else {
         if (slot == 48) {
            int filter = (Integer)MenuSession.FILTER.getOrDefault(player.getUniqueId(), 0);
            int size = Math.max(1, this.plugin.getFilters().names().size());
            MenuSession.FILTER.put(player.getUniqueId(), (filter + 1) % size);
            SellMenus.openWorth(player, 0);
         }

      }
   }

   private void history(Player player, int slot, int page) {
      if (slot == 45) {
         SellMenus.openHistory(player, page - 1);
      } else if (slot == 53) {
         SellMenus.openHistory(player, page + 1);
      } else {
         if (slot == 49) {
            player.closeInventory();
         }

      }
   }

   @EventHandler
   public void onDrag(InventoryDragEvent event) {
      HumanEntity humanEntity = event.getWhoClicked();
      if (humanEntity instanceof Player player) {
         MenuSession.View view = (MenuSession.View)MenuSession.VIEW.get(player.getUniqueId());
         if (view != null) {
            if (view != MenuSession.View.SELL) {
               event.setCancelled(true);
            } else {
               for(int s : event.getRawSlots()) {
                  if (s >= 36 && s <= 44) {
                     event.setCancelled(true);
                     break;
                  }
               }

               this.plugin.getServer().getScheduler().runTask(this.plugin, () -> {
                  if (MenuSession.VIEW.get(player.getUniqueId()) == MenuSession.View.SELL) {
                     int confirmSlot = this.plugin.getConfig().getInt("sell.confirm-slot", 44);
                     this.returnBottomRowItems(player, event.getView().getTopInventory(), confirmSlot);
                     SellMenus.updateConfirm(player, event.getView().getTopInventory());
                  }

               });
            }
         }
      }
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
      HumanEntity humanEntity = event.getPlayer();
      if (humanEntity instanceof Player player) {
         if (!MenuSession.SWITCHING.contains(player.getUniqueId())) {
            if (!Boolean.TRUE.equals(MenuSession.CHAT_SEARCH.get(player.getUniqueId()))) {
               if (!Boolean.TRUE.equals(MenuSession.SIGN_SEARCH.get(player.getUniqueId()))) {
                  MenuSession.View view = (MenuSession.View)MenuSession.VIEW.get(player.getUniqueId());
                  if (view == MenuSession.View.SELL) {
                     int confirmSlot = this.plugin.getConfig().getInt("sell.confirm-slot", 44);
                     Inventory inv = event.getInventory();

                     for(int i = 0; i < inv.getSize(); ++i) {
                        ItemStack stack = inv.getItem(i);
                        if (stack != null && !stack.getType().isAir() && i != confirmSlot) {
                           inv.setItem(i, (ItemStack)null);
                           Map<Integer, ItemStack> left = player.getInventory().addItem(new ItemStack[]{stack});
                           left.values().forEach((s) -> player.getWorld().dropItemNaturally(player.getLocation(), s));
                        }
                     }
                  }

                  MenuSession.clear(player.getUniqueId());
               }
            }
         }
      }
   }
}
