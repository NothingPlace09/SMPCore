package me.nothing.smpcore.systems.mobs;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class SmpCoreMobsCommand implements CommandExecutor {
   private final SmpCoreMobs plugin;

   public SmpCoreMobsCommand(SmpCoreMobs plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("SmpCoreMobs.admin")) {
         sender.sendMessage(ColorUtil.color(this.plugin.getConfig().getString("messages.no-permission")));
         return true;
      } else if (args.length == 0) {
         sender.sendMessage(ColorUtil.color("&7Usage: &f/smpcoremobs reload"));
         return true;
      } else if (args[0].equalsIgnoreCase("reload")) {
         this.plugin.reloadPlugin();
         sender.sendMessage(ColorUtil.color(this.plugin.getConfig().getString("messages.reload")));
         return true;
      } else {
         sender.sendMessage(ColorUtil.color("&cUnknown command."));
         return true;
      }
   }
}
