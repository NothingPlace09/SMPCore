package me.nothing.smpcore.systems.lb;

import me.nothing.smpcore.systems.SystemHost;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class SmpCoreLeaderboards extends SystemHost {
   private static SmpCoreLeaderboards instance;
   private MessageManager messages;
   private StatsManager stats;
   private Economy economy;

   public SmpCoreLeaderboards() {
      super("lb");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.messages = new MessageManager(this);
      this.stats = new StatsManager(this);
      this.setupEconomy();
      LeaderboardMenus.loadGuis(this);
      new LeaderboardCommand(this);
      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new SignProtectListener(), this.getCore());
      this.getServer().getPluginManager().registerEvents(new StatsListener(this), this.getCore());
      this.getServer().getScheduler().runTaskTimerAsynchronously(this.getCore(), () -> this.stats.refreshCache(), 40L, 1200L);
      this.getServer().getScheduler().runTaskTimer(this.getCore(), () -> this.stats.save(), 2400L, 2400L);
      this.getLogger().info("SmpCoreLeaderboards enabled.");
   }

   public void stop() {
      if (this.stats != null) {
         this.stats.save();
      }

      instance = null;
   }

   private void setupEconomy() {
      if (this.getServer().getPluginManager().getPlugin("Vault") != null) {
         RegisteredServiceProvider<Economy> rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
         if (rsp != null) {
            this.economy = (Economy)rsp.getProvider();
         }

      }
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.stats.reload();
      this.stats.refreshCache();
   }

   public static SmpCoreLeaderboards get() {
      return instance;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public StatsManager getStats() {
      return this.stats;
   }

   public Economy getEconomy() {
      return this.economy;
   }
}
