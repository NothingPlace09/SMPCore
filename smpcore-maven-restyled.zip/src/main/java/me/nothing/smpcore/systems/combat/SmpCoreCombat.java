package me.nothing.smpcore.systems.combat;

import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.Bukkit;

public final class SmpCoreCombat extends SystemHost {
   private static SmpCoreCombat instance;
   private CombatManager combatManager;

   public SmpCoreCombat() {
      super("combat");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      MessageUtil.init(this);
      this.combatManager = new CombatManager(this);
      this.getServer().getPluginManager().registerEvents(new CombatListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this.getCore());
      new CombatCommand(this);
      if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
         (new CombatExpansion(this)).register();
      }

      this.getLogger().info("SmpCoreCombat enabled.");
   }

   public void stop() {
      if (this.combatManager != null) {
         this.combatManager.shutdown();
      }

      this.getLogger().info("SmpCoreCombat disabled.");
   }

   public void reload() {
      this.reloadConfig();
      MessageUtil.init(this);
      this.combatManager.reload();
   }

   public static SmpCoreCombat getInstance() {
      return instance;
   }

   public CombatManager getCombatManager() {
      return this.combatManager;
   }
}
