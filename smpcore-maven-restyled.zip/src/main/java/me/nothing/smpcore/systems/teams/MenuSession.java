package me.nothing.smpcore.systems.teams;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, View> VIEW = new ConcurrentHashMap();
   public static final Map<UUID, Integer> PAGE = new ConcurrentHashMap();
   public static final Map<UUID, Sort> SORT = new ConcurrentHashMap();
   public static final Map<UUID, UUID> TARGET = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      VIEW.remove(id);
      PAGE.remove(id);
      SORT.remove(id);
      TARGET.remove(id);
   }

   public static Sort next(Sort current) {
      Sort sort;
      switch (current.ordinal()) {
         case 0 -> sort = MenuSession.Sort.ALPHABETICALLY;
         case 1 -> sort = MenuSession.Sort.JOIN_DATE;
         case 2 -> sort = MenuSession.Sort.ONLINE;
         default -> throw new MatchException((String)null, (Throwable)null);
      }

      return sort;
   }

   public static enum View {
      MAIN,
      MEMBER,
      SEARCH;

      private static View[] $values() {
         return new View[]{MAIN, MEMBER, SEARCH};
      }
   }

   public static enum Sort {
      ONLINE,
      ALPHABETICALLY,
      JOIN_DATE;

      private static Sort[] $values() {
         return new Sort[]{ONLINE, ALPHABETICALLY, JOIN_DATE};
      }
   }
}
