package me.nothing.smpcore.systems.tab;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.clip.placeholderapi.PlaceholderAPI;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.utils.TextUtil;
import net.kyori.adventure.text.Component;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

public class TabModule implements Module, Listener {
   private final SmpCore plugin;
   private FileConfiguration cfg;
   private int taskId = -1;
   private final List<String> groupOrder = new ArrayList();
   private boolean nameFormatting = true;
   private String disableCondition = "";
   private final Map<UUID, String> teamNames = new ConcurrentHashMap();

   public TabModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "tab";
   }

   public void onEnable() {
      this.loadConfig();
      this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
      this.taskId = Bukkit.getScheduler().scheduleSyncRepeatingTask(this.plugin, this::refreshAll, 20L, 40L);

      for(Player p : Bukkit.getOnlinePlayers()) {
         this.apply(p);
      }

   }

   public void onDisable() {
      if (this.taskId != -1) {
         Bukkit.getScheduler().cancelTask(this.taskId);
      }

      this.taskId = -1;

      for(Player p : Bukkit.getOnlinePlayers()) {
         p.sendPlayerListHeaderAndFooter(Component.empty(), Component.empty());
         this.clearTeam(p);
      }

      this.teamNames.clear();
   }

   public void reload() {
      this.onDisable();
      this.onEnable();
   }

   private void loadConfig() {
      File f = new File(this.plugin.getDataFolder(), "TAB.yml");
      if (!f.exists()) {
         try {
            this.plugin.saveResource("TAB.yml", false);
         } catch (Exception e) {
         }
      }

      this.cfg = f.exists() ? YamlConfiguration.loadConfiguration(f) : new YamlConfiguration();
      this.groupOrder.clear();
      this.nameFormatting = this.cfg.getBoolean("tab.tablist-name-formatting.enabled", true);
      this.disableCondition = this.cfg.getString("tab.tablist-name-formatting.disable-condition", "");

      for(String line : this.cfg.getStringList("tab.tablist-name-formatting.sorting-types")) {
         if (line != null && line.toUpperCase(Locale.ROOT).startsWith("GROUPS:")) {
            String body = line.substring(7);

            for(String g : body.split(",")) {
               String t = g.trim().toLowerCase(Locale.ROOT);
               if (!t.isEmpty()) {
                  this.groupOrder.add(t);
               }
            }
         }
      }

      if (this.groupOrder.isEmpty()) {
         this.groupOrder.add("default");
      }

   }

   @EventHandler
   public void onJoin(PlayerJoinEvent e) {
      Bukkit.getScheduler().runTask(this.plugin, () -> {
         this.apply(e.getPlayer());
         this.refreshAll();
      });
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent e) {
      this.clearTeam(e.getPlayer());
      this.teamNames.remove(e.getPlayer().getUniqueId());
      Bukkit.getScheduler().runTask(this.plugin, this::refreshAll);
   }

   private void refreshAll() {
      for(Player p : Bukkit.getOnlinePlayers()) {
         this.apply(p);
      }

   }

   private void apply(Player player) {
      if (player != null && player.isOnline() && this.cfg != null) {
         this.applyHeaderFooter(player);
         if (this.nameFormatting && !this.isDisabled(player)) {
            this.applySort(player);
         }

      }
   }

   private void applyHeaderFooter(Player player) {
      List<String> headerLines = this.cfg.getStringList("tab.header");
      List<String> footerLines = this.cfg.getStringList("tab.footer");
      String online = String.valueOf(Bukkit.getOnlinePlayers().size());
      Component header = this.joinLines(headerLines, player, online);
      Component footer = this.joinLines(footerLines, player, online);
      player.sendPlayerListHeaderAndFooter(header, footer);
   }

   private Component joinLines(List<String> lines, Player player, String online) {
      if (lines != null && !lines.isEmpty()) {
         List<Component> parts = new ArrayList();

         for(int i = 0; i < lines.size(); ++i) {
            String line = (String)lines.get(i);
            if (line == null) {
               line = "";
            }

            line = line.replace("%online%", online).replace("%player%", player.getName()).replace("%world%", player.getWorld() != null ? player.getWorld().getName() : "");

            try {
               if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
                  line = PlaceholderAPI.setPlaceholders(player, line);
               }
            } catch (Throwable t) {
            }

            parts.add(TextUtil.component(line));
            if (i < lines.size() - 1) {
               parts.add(Component.newline());
            }
         }

         Component out = Component.empty();

         for(Component c : parts) {
            out = out.append(c);
         }

         return out;
      } else {
         return Component.empty();
      }
   }

   private boolean isDisabled(Player player) {
      if (this.disableCondition != null && !this.disableCondition.isEmpty()) {
         String cond = this.disableCondition;
         String world = player.getWorld() != null ? player.getWorld().getName() : "";
         cond = cond.replace("%world%", world).replace("%player%", player.getName());
         if (!cond.contains("=")) {
            return false;
         } else {
            String[] parts = cond.split("=", 2);
            return parts.length == 2 && parts[0].trim().equalsIgnoreCase(parts[1].trim());
         }
      } else {
         return false;
      }
   }

   private void applySort(Player player) {
      String group = this.primaryGroup(player);
      int idx = this.groupOrder.indexOf(group.toLowerCase(Locale.ROOT));
      if (idx < 0) {
         idx = this.groupOrder.size();
      }

      String teamName = String.format(Locale.ROOT, "%02d_%s", Math.min(idx, 99), this.sanitize(group));
      if (teamName.length() > 16) {
         teamName = teamName.substring(0, 16);
      }

      Scoreboard board = player.getScoreboard();
      if (board == null) {
         board = Bukkit.getScoreboardManager().getMainScoreboard();
      }

      Team team = board.getTeam(teamName);
      if (team == null) {
         try {
            team = board.registerNewTeam(teamName);
         } catch (IllegalArgumentException e) {
            team = board.getTeam(teamName);
         }
      }

      if (team != null) {
         String old = (String)this.teamNames.get(player.getUniqueId());
         if (old != null && !old.equals(teamName)) {
            Team prev = board.getTeam(old);
            if (prev != null) {
               prev.removeEntry(player.getName());
            }
         }

         if (!team.hasEntry(player.getName())) {
            team.addEntry(player.getName());
         }

         this.teamNames.put(player.getUniqueId(), teamName);
         String prefix = this.groupPrefix(player);
         if (prefix != null && !prefix.isEmpty()) {
            try {
               player.playerListName(TextUtil.component(prefix + player.getName()));
            } catch (Throwable t) {
               player.setPlayerListName(TextUtil.color(prefix + player.getName()));
            }
         }

      }
   }

   private void clearTeam(Player player) {
      String old = (String)this.teamNames.remove(player.getUniqueId());
      if (old != null) {
         Scoreboard board = player.getScoreboard();
         if (board == null) {
            board = Bukkit.getScoreboardManager().getMainScoreboard();
         }

         Team team = board.getTeam(old);
         if (team != null) {
            team.removeEntry(player.getName());
         }

         try {
            player.playerListName((Component)null);
         } catch (Throwable t) {
            player.setPlayerListName((String)null);
         }

      }
   }

   private String sanitize(String s) {
      return s.replaceAll("[^a-zA-Z0-9_]", "");
   }

   private String primaryGroup(Player player) {
      try {
         if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            return "default";
         } else {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user == null) {
               return "default";
            } else {
               String g = user.getPrimaryGroup();
               return g != null ? g : "default";
            }
         }
      } catch (Throwable t) {
         return "default";
      }
   }

   private String groupPrefix(Player player) {
      try {
         if (Bukkit.getPluginManager().getPlugin("LuckPerms") == null) {
            return "";
         } else {
            LuckPerms api = LuckPermsProvider.get();
            User user = api.getUserManager().getUser(player.getUniqueId());
            if (user == null) {
               return "";
            } else {
               String prefix = user.getCachedData().getMetaData().getPrefix();
               return prefix != null ? prefix : "";
            }
         }
      } catch (Throwable t) {
         return "";
      }
   }
}
