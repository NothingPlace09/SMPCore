package me.nothing.smpcore.systems.rtp;

import me.nothing.smpcore.utils.GuiSafe;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIListener implements Listener {
   private final SmpCoreRTP plugin;

   public GUIListener(SmpCoreRTP plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onClick(InventoryClickEvent event) {
      HumanEntity humanEntity = event.getWhoClicked();
      if (humanEntity instanceof Player player) {
         if (event.getInventory().getHolder() instanceof RTPGUI.Holder) {
            event.setCancelled(true);
            if (event.getClickedInventory() != null) {
               GuiSafe.defer(player, () -> {
int slot = event.getSlot();
               FileConfiguration gui = ConfigUtil.getFile(this.plugin, "guis.yml");
               boolean nested = gui.contains("main-menu");
               String itemsPath = nested ? "main-menu.items" : "worlds";
               ConfigurationSection section = gui.getConfigurationSection(itemsPath);
               if (section != null) {
                  for(String key : section.getKeys(false)) {
                     String path = itemsPath + "." + key;
                     if (gui.getInt(path + ".slot") == slot) {
                        String world = gui.getString(path + ".world");
                        if (world == null || world.isEmpty()) {
                           String cmd = gui.getString(path + ".command", "");
                           String[] parts = cmd.trim().split("\\s+");
                           world = parts.length >= 2 ? parts[1] : key;
                        }

                        if (RTPCountdown.isRunning(player)) {
                           player.closeInventory();
                           MessageUtil.send(player, "errors.already-teleporting");
                           return;
                        }

                        player.closeInventory();
                        (new RTPCountdown(this.plugin, player, world)).start();
                        return;
                     }
                  }

               }
});
            }
         }
      }
   }
}
