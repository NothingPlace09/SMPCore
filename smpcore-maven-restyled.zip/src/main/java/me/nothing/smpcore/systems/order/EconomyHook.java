package me.nothing.smpcore.systems.order;

import java.util.UUID;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;

public class EconomyHook {
   private Economy economy;

   public boolean setup() {
      if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
         return false;
      } else {
         RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
         if (rsp == null) {
            return false;
         } else {
            this.economy = (Economy)rsp.getProvider();
            return this.economy != null;
         }
      }
   }

   public boolean isReady() {
      return this.economy != null;
   }

   public boolean has(Player player, double amount) {
      return this.economy != null && this.economy.has(player, amount);
   }

   public boolean withdraw(Player player, double amount) {
      return this.economy == null ? false : this.economy.withdrawPlayer(player, amount).transactionSuccess();
   }

   public boolean deposit(Player player, double amount) {
      return this.economy == null ? false : this.economy.depositPlayer(player, amount).transactionSuccess();
   }

   public boolean deposit(UUID uuid, double amount) {
      return this.economy == null ? false : this.economy.depositPlayer(Bukkit.getOfflinePlayer(uuid), amount).transactionSuccess();
   }

   public String format(double amount) {
      return this.economy == null ? String.format("%.2f", amount) : this.economy.format(amount);
   }
}
