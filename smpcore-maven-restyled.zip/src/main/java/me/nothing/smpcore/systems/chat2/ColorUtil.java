package me.nothing.smpcore.systems.chat2;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public class ColorUtil {
   private static final LegacyComponentSerializer SERIALIZER = LegacyComponentSerializer.builder().character('&').hexColors().build();

   public static String color(String message) {
      return message == null ? "" : message.replace("§", "&");
   }

   public static Component colorComponent(String message) {
      return message == null ? Component.empty() : SERIALIZER.deserialize(message);
   }
}
