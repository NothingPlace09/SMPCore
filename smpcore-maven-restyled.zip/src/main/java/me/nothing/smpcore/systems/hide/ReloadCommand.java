package me.nothing.smpcore.systems.hide;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {
   private final SmpCoreHide plugin;

   public ReloadCommand(SmpCoreHide plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("SmpCoreHide.reload")) {
         sender.sendMessage(MessageUtil.color("&cYou don't have permission."));
         return true;
      } else {
         this.plugin.reloadConfig();
         sender.sendMessage(MessageUtil.color("&7SmpCoreHide configuration reloaded."));
         return true;
      }
   }
}
