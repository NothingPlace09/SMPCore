package me.nothing.smpcore.systems.sell;

import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private SoundUtil() {
   }

   public static void play(Player player, String path) {
      if (player != null && SmpCoreSell.get().getConfig().getBoolean(path + ".enabled", true)) {
         String name = SmpCoreSell.get().getConfig().getString(path + ".sound", "UI_BUTTON_CLICK");

         try {
            Sound sound = Sound.valueOf(name.toUpperCase().replace('.', '_').replace('-', '_'));
            float vol = (float)SmpCoreSell.get().getConfig().getDouble(path + ".volume", (double)1.0F);
            float pitch = (float)SmpCoreSell.get().getConfig().getDouble(path + ".pitch", (double)1.0F);
            me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), sound, vol, pitch);
         } catch (Exception e) {
            try {
               me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
            } catch (Exception e2) {
            }
         }

      }
   }

   public static void click(Player player) {
      play(player, "sounds.gui-click");
   }

   public static void open(Player player) {
      play(player, "sounds.gui-open");
   }

   public static void sell(Player player) {
      play(player, "sounds.sell");
   }

   public static void error(Player player) {
      play(player, "sounds.error");
   }
}
