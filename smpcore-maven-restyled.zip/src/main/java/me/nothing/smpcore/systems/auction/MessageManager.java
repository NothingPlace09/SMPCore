package me.nothing.smpcore.systems.auction;

import java.io.File;
import java.util.Map;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class MessageManager {
   private final SmpCoreAuction plugin;
   private FileConfiguration messages;
   private boolean prefixEnabled;
   private String prefix;

   public MessageManager(SmpCoreAuction plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      File file = new File(this.plugin.getDataFolder(), "messages.yml");
      if (!file.exists()) {
         this.plugin.saveResource("messages.yml", false);
      }

      this.messages = YamlConfiguration.loadConfiguration(file);
      this.prefixEnabled = this.messages.getBoolean("prefix-enable", false);
      this.prefix = this.messages.getString("prefix", "");
      if (this.prefix == null) {
         this.prefix = "";
      }

   }

   public void send(CommandSender sender, String key) {
      this.send(sender, key, Map.of());
   }

   public void send(CommandSender sender, String key, Map<String, String> ph) {
      String raw = this.resolve(key);
      if (raw == null) {
         raw = key;
      }

      String str = this.prefixEnabled ? this.prefix : "";
      String out = str + raw;

      for(Map.Entry<String, String> e : ph.entrySet()) {
         out = out.replace("%" + (String)e.getKey() + "%", (CharSequence)(e.getValue() == null ? "" : (CharSequence)e.getValue()));
      }

      sender.sendMessage(ColorUtil.parse(out));
   }

   public String get(String key) {
      String raw = this.resolve(key);
      return raw == null ? key : raw;
   }

   public FileConfiguration raw() {
      return this.messages;
   }

   private String resolve(String key) {
      return this.messages.contains("messages." + key) ? this.messages.getString("messages." + key) : this.messages.getString(key);
   }
}
