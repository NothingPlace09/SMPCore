package me.nothing.smpcore.systems.rtp;

import me.nothing.smpcore.systems.SystemHost;

public final class SmpCoreRTP extends SystemHost {
   private static SmpCoreRTP instance;
   private RTPManager rtpManager;
   private CooldownManager cooldownManager;

   public SmpCoreRTP() {
      super("rtp");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.saveResource("messages.yml", false);
      this.saveResource("guis.yml", false);
      MessageUtil.reload(this);
      ConfigUtil.reloadAll(this);
      this.rtpManager = new RTPManager(this);
      this.cooldownManager = new CooldownManager();
      this.getServer().getPluginManager().registerEvents(new GUIListener(this), this.getCore());
      this.getLogger().info("SmpCoreRTP v" + this.getDescription().getVersion() + " enabled");
   }

   public void stop() {
      this.getLogger().info("SmpCoreRTP disabled");
   }

   public void reloadEverything() {
      this.reloadConfig();
      MessageUtil.reload(this);
      ConfigUtil.reloadAll(this);
      if (this.rtpManager != null) {
         this.rtpManager.reload();
      }

   }

   public static SmpCoreRTP get() {
      return instance;
   }

   public static SmpCoreRTP getInstance() {
      return instance;
   }

   public RTPManager getRTPManager() {
      return this.rtpManager;
   }

   public CooldownManager getCooldownManager() {
      return this.cooldownManager;
   }
}
