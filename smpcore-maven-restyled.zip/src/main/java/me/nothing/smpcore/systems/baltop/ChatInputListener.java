package me.nothing.smpcore.systems.baltop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class ChatInputListener implements Listener {
   private final SmpCoreBaltop plugin;

   public ChatInputListener(SmpCoreBaltop plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onChat(AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      if (Boolean.TRUE.equals(MenuSession.CHAT_SEARCH.get(player.getUniqueId()))) {
         event.setCancelled(true);
         String msg = event.getMessage().trim();
         this.plugin.getServer().getScheduler().runTask(this.plugin.getCore(), () -> {
            MenuSession.CHAT_SEARCH.remove(player.getUniqueId());
            if (msg.equalsIgnoreCase("cancel")) {
               this.plugin.getMessages().send(player, "search-cancelled");
               BaltopMenus.open(player, 0);
            } else {
               MenuSession.SEARCH.put(player.getUniqueId(), msg);
               BaltopMenus.open(player, 0);
            }
         });
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onSign(SignChangeEvent event) {
      Player player = event.getPlayer();
      if (InputUtil.isSignInput(player.getUniqueId())) {
         event.setCancelled(true);
         String line = "";

         try {
            Component component = event.line(0);
            if (component != null) {
               line = PlainTextComponentSerializer.plainText().serialize(component);
            }
         } catch (Throwable t) {
            String legacy = event.getLine(0);
            if (legacy != null) {
               line = legacy;
            }
         }

         line = line.trim();
         final String finalLine = line;
         this.plugin.getServer().getScheduler().runTask(this.plugin.getCore(), () -> {
            InputUtil.cleanup(player);
            if (!finalLine.isEmpty() && !finalLine.equalsIgnoreCase("cancel")) {
               MenuSession.SEARCH.put(player.getUniqueId(), finalLine);
               BaltopMenus.open(player, 0);
            } else {
               this.plugin.getMessages().send(player, "search-cancelled");
               BaltopMenus.open(player, 0);
            }
         });
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      InputUtil.cleanup(event.getPlayer());
      MenuSession.clear(event.getPlayer().getUniqueId());
   }
}
