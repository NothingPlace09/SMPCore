package me.nothing.smpcore.systems.chat2;

import org.bukkit.entity.Player;

public class ChatFormatter {
   private final SmpCoreChat plugin;

   public ChatFormatter(SmpCoreChat plugin) {
      this.plugin = plugin;
   }

   public String format(Player player, String message) {
      String format = this.plugin.getConfig().getString("chat-format.format", "%player%: %message%");
      format = format.replace("%player%", player.getName());
      format = format.replace("%message%", message);
      return PlaceholderUtil.replace(player, format);
   }
}
