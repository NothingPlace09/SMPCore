package me.nothing.smpcore.systems.shop;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ShopMenus {
   private ShopMenus() {
   }

   public static void open(Player player, String shopId) {
      FileConfiguration shop = SmpCoreShop.get().getShops().getShop(shopId);
      if (shop != null) {
         String title = shop.getString("title", "&8Shop");
         int size = Math.max(9, Math.min(54, shop.getInt("size", 27)));
         if (size % 9 != 0) {
            size = 27;
         }

         Inventory inv = Bukkit.createInventory(player, size, ColorUtil.parse(title));
         ConfigurationSection items = shop.getConfigurationSection("items");
         String type = shop.getString("type", "shop");
         String symbol = shop.getString("currency-symbol", SmpCoreShop.get().getConfig().getString("currency-symbol", "$"));
         // FIX prezzo duplicato: alcune categorie (shard shop) scrivono gia' il prezzo a mano nella lore.
         // Di default il prezzo veniva sempre aggiunto anche in quel caso ("Buy Price: 200x Shards" + "Shards200").
         boolean shopShowPrice = shop.getBoolean("show-price", true);
         if (items != null) {
            for(String key : items.getKeys(false)) {
               try {
                  int slot = Integer.parseInt(key);
                  if (slot >= 0 && slot < size) {
                     ConfigurationSection item = items.getConfigurationSection(key);
                     if (item != null) {
                        inv.setItem(slot, buildShopItem(item, type, symbol, item.getBoolean("show-price", shopShowPrice)));
                     }
                  }
               } catch (Exception e) {
               }
            }
         }

         if (type.equalsIgnoreCase("shop") && shop.contains("back-slot")) {
            int back = shop.getInt("back-slot", 18);
            if (back >= 0 && back < size) {
               inv.setItem(back, named(Material.RED_STAINED_GLASS_PANE, msg("back-name", "&cBack"), List.of(msg("back-lore", "&fClick to return"))));
            }
         }

         MenuSession.VIEW.put(player.getUniqueId(), MenuSession.View.SHOP);
         MenuSession.SHOP_ID.put(player.getUniqueId(), shopId);
         player.openInventory(inv);
      }
   }

   public static void openBuy(Player player, MenuSession.BuyData data) {
      String title = msg("buy-title", "&8ʙᴜʏɪɴɢ");
      Inventory inv = Bukkit.createInventory(player, 27, ColorUtil.parse(title));
      int amt = Math.min(data.maxAmount, Math.max(1, data.amount));
      ItemStack preview = new ItemStack(data.material, amt);
      ItemMeta meta = preview.getItemMeta();
      if (meta != null) {
         meta.displayName(ColorUtil.parse(data.displayName));
         List<Component> lore = new ArrayList();
         lore.add(ColorUtil.parse(msg("amount-lore", "&fAmount: &a%amount%").replace("%amount%", String.valueOf(data.amount))));
         lore.add(ColorUtil.parse(msg("price-lore", "&fPrice: &a%symbol%%price%").replace("%symbol%", data.symbol == null ? "$" : data.symbol).replace("%price%", format(data.unitPrice * (double)data.amount))));
         meta.lore(lore);
         preview.setItemMeta(meta);
      }

      inv.setItem(13, preview);
      inv.setItem(9, named(Material.RED_STAINED_GLASS_PANE, msg("minus64-name", "&cRemove 64"), List.of()));
      inv.setItem(10, named(Material.RED_STAINED_GLASS_PANE, msg("minus10-name", "&cRemove 10"), List.of()));
      inv.setItem(11, named(Material.RED_STAINED_GLASS_PANE, msg("minus-name", "&cRemove 1"), List.of()));
      inv.setItem(15, named(Material.LIME_STAINED_GLASS_PANE, msg("plus-name", "&aAdd 1"), List.of()));
      inv.setItem(16, named(Material.LIME_STAINED_GLASS_PANE, msg("plus10-name", "&aAdd 10"), List.of()));
      inv.setItem(17, named(Material.LIME_STAINED_GLASS_PANE, msg("plus64-name", "&aSet to 64"), List.of()));
      inv.setItem(21, named(Material.RED_STAINED_GLASS_PANE, msg("cancel-name", "&#fc0404ᴄᴀɴᴄᴇʟ"), List.of(msg("cancel-lore", "&fClick to cancel"))));
      inv.setItem(23, named(Material.LIME_STAINED_GLASS_PANE, msg("confirm-name", "&#04fc04ᴄᴏɴғɪʀᴍ"), List.of(msg("confirm-lore", "&fClick to buy"))));
      MenuSession.VIEW.put(player.getUniqueId(), MenuSession.View.BUY);
      MenuSession.BUY.put(player.getUniqueId(), data);
      player.openInventory(inv);
   }

   private static ItemStack buildShopItem(ConfigurationSection item, String type, String symbol, boolean showPrice) {
      Material mat = Material.STONE;

      try {
         mat = Material.valueOf(item.getString("material", "STONE").toUpperCase());
      } catch (Exception e) {
      }

      ItemStack stack = new ItemStack(mat);
      ItemMeta meta = stack.getItemMeta();
      if (meta != null) {
         meta.displayName(ColorUtil.parse(item.getString("name", mat.name())));
         List<Component> lore = new ArrayList();
         List<String> cfgLore = item.getStringList("lore");
         if (cfgLore != null) {
            for(String line : cfgLore) {
               lore.add(ColorUtil.parse(line));
            }
         }

         if (showPrice && type.equalsIgnoreCase("shop") && item.contains("price")) {
            double price = item.getDouble("price");
            lore.add(ColorUtil.parse("&a" + symbol + format(price)));
         }

         if (!lore.isEmpty()) {
            meta.lore(lore);
         }

         stack.setItemMeta(meta);
      }

      return stack;
   }

   private static ItemStack named(Material mat, String name, List<String> loreLines) {
      ItemStack item = new ItemStack(mat);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.displayName(ColorUtil.parse(name));
         if (loreLines != null && !loreLines.isEmpty()) {
            List<Component> lore = new ArrayList();

            for(String line : loreLines) {
               lore.add(ColorUtil.parse(line));
            }

            meta.lore(lore);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   private static String msg(String key, String def) {
      return SmpCoreShop.get().getMessages().get(key, def);
   }

   private static String format(double value) {
      return value == (double)((long)value) ? String.valueOf((long)value) : String.format("%.2f", value);
   }
}
