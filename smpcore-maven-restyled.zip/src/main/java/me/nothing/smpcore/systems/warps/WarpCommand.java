package me.nothing.smpcore.systems.warps;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class WarpCommand implements CommandExecutor, TabCompleter {
   private final SmpCoreWarps plugin;

   public WarpCommand(SmpCoreWarps plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      String name = command.getName().toLowerCase(Locale.ROOT);
      if (name.equals("warpreload")) {
         if (!sender.hasPermission("smpcore.system.warps.admin")) {
            this.msg(sender, "no-permission", "&cYou don't have permission!");
            return true;
         } else {
            this.plugin.reloadAll();
            this.msg(sender, "reload-success", "&aSmpCoreWarps reloaded.");
            return true;
         }
      } else if (sender instanceof Player) {
         Player player = (Player)sender;
         boolean flag;
         switch (name) {
            case "setwarp":
               if (!player.hasPermission("smpcore.system.warps.admin")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  this.msg(player, "setwarp-usage", "&7Correct usage: &#00A0FC/setwarp [warp name]");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (!this.plugin.getWarps().setWarp(args[0], player.getLocation())) {
                  this.msg(player, "warp-already-exists", "&7Warp &#00A0FC%warp% &7already exists.", "%warp%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  this.msg(player, "warp-set", "&7Warp &#00A0FC%warp% &7has been set to your location.", "%warp%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "delwarp":
               if (!player.hasPermission("smpcore.system.warps.admin")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  this.msg(player, "delwarp-usage", "&7Correct usage: &#00A0FC/delwarp [warp name]");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (!this.plugin.getWarps().deleteWarp(args[0])) {
                  this.msg(player, "warp-not-found", "&7Warp &#00A0FC%warp% &7does not exist.", "%warp%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  this.msg(player, "warp-deleted", "&#00A0FC%warp% &7warp has been removed.", "%warp%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "warp":
               if (!player.hasPermission("smpcore.system.warps.warp") && !player.hasPermission("smpcore.system.warps.use")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  String list = String.join(", ", this.plugin.getWarps().getWarps().keySet());
                  if (list.isEmpty()) {
                     list = "none";
                  }

                  this.msg(player, "available-warps", "&cUsage: /warp (destination)\n&cDestinations: %warps%", "%warps%", list);
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  NamedLocation warp = this.plugin.getWarps().getWarp(args[0]);
                  if (warp == null) {
                     this.msg(player, "warp-not-found", "&7Warp &#00A0FC%warp% &7does not exist.", "%warp%", args[0]);
                     boolean flag2 = true;
                     flag = flag2;
                  } else {
                     this.plugin.getTeleports().start(player, warp, "warp");
                     boolean flag2 = true;
                     flag = flag2;
                  }
               }
               break;
            case "spawn":
               if (!player.hasPermission("smpcore.system.warps.spawn") && !player.hasPermission("smpcore.system.warps.use")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length >= 1) {
                  NamedLocation spawn = this.plugin.getWarps().getSpawn(args[0]);
                  if (spawn == null) {
                     this.msg(player, "spawn-not-found", "&cSpawn not found!");
                     boolean flag2 = true;
                     flag = flag2;
                  } else {
                     this.plugin.getTeleports().start(player, spawn, "spawn");
                     boolean flag2 = true;
                     flag = flag2;
                  }
               } else {
                  if (this.plugin.getConfig().getBoolean("spawn-gui", true)) {
                     if (this.plugin.getWarps().getSpawns().isEmpty()) {
                        this.msg(player, "no-spawns", "&cNo spawns have been set yet!");
                        boolean flag2 = true;
                        flag = flag2;
                        break;
                     }

                     WarpMenus.openSpawn(player, 0);
                  } else {
                     NamedLocation spawn = this.plugin.getWarps().randomSpawn();
                     if (spawn == null) {
                        spawn = this.plugin.getWarps().defaultSpawn();
                     }

                     if (spawn == null) {
                        this.msg(player, "no-spawns", "&cNo spawns have been set yet!");
                        boolean flag2 = true;
                        flag = flag2;
                        break;
                     }

                     this.plugin.getTeleports().start(player, spawn, "spawn");
                  }

                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "setspawn":
               if (!player.hasPermission("smpcore.system.warps.admin")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  this.msg(player, "setspawn-usage", "&cUsage: /setspawn <name> [maxPlayers]");
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  int max = -1;
                  if (args.length >= 2) {
                     try {
                        max = Integer.parseInt(args[1]);
                     } catch (NumberFormatException e) {
                        this.msg(player, "invalid-number", "&cPlease provide a valid number for max players!");
                        boolean flag2 = true;
                        flag = flag2;
                        break;
                     }
                  }

                  this.plugin.getWarps().setSpawn(args[0], player.getLocation(), max);
                  this.msg(player, "setspawn-success", "&aSpawn %name% has been set!", "%name%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "delspawn":
               if (!player.hasPermission("smpcore.system.warps.admin")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  this.msg(player, "delspawn-usage", "&cUsage: /delspawn <name>");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (!this.plugin.getWarps().deleteSpawn(args[0])) {
                  this.msg(player, "spawn-not-found", "&cSpawn not found!");
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  this.msg(player, "delspawn-success", "&aSpawn %name% has been deleted!", "%name%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "afk":
               if (!player.hasPermission("smpcore.system.warps.afk") && !player.hasPermission("smpcore.system.warps.use")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length >= 1) {
                  NamedLocation afk = this.plugin.getWarps().getAfk(args[0]);
                  if (afk == null) {
                     this.msg(player, "afk-not-found", "&cAFK area not found!");
                     boolean flag2 = true;
                     flag = flag2;
                  } else {
                     this.plugin.getTeleports().start(player, afk, "afk");
                     boolean flag2 = true;
                     flag = flag2;
                  }
               } else {
                  if (this.plugin.getConfig().getBoolean("afk-gui", true)) {
                     if (this.plugin.getWarps().getAfks().isEmpty()) {
                        this.msg(player, "no-afk-areas", "&cNo AFK areas have been set yet!");
                        boolean flag2 = true;
                        flag = flag2;
                        break;
                     }

                     WarpMenus.openAfk(player, 0);
                  } else {
                     NamedLocation afk = this.plugin.getWarps().randomAfk();
                     if (afk == null) {
                        this.msg(player, "no-afk-areas", "&cNo AFK areas have been set yet!");
                        boolean flag2 = true;
                        flag = flag2;
                        break;
                     }

                     this.plugin.getTeleports().start(player, afk, "afk");
                  }

                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "setafk":
               if (!player.hasPermission("smpcore.system.warps.admin")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  this.msg(player, "setafk-usage", "&cUsage: /setafk <name> [maxPlayers]");
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  int max = -1;
                  if (args.length >= 2) {
                     try {
                        max = Integer.parseInt(args[1]);
                     } catch (NumberFormatException e) {
                        this.msg(player, "invalid-number", "&cPlease provide a valid number for max players!");
                        boolean flag2 = true;
                        flag = flag2;
                        break;
                     }
                  }

                  this.plugin.getWarps().setAfk(args[0], player.getLocation(), max);
                  this.msg(player, "setafk-success", "&aAFK area %name% has been set!", "%name%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            case "delafk":
               if (!player.hasPermission("smpcore.system.warps.admin")) {
                  this.msg(player, "no-permission", "&cYou don't have permission!");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (args.length < 1) {
                  this.msg(player, "delafk-usage", "&cUsage: /delafk <name>");
                  boolean flag2 = true;
                  flag = flag2;
               } else if (!this.plugin.getWarps().deleteAfk(args[0])) {
                  this.msg(player, "afk-not-found", "&cAFK area not found!");
                  boolean flag2 = true;
                  flag = flag2;
               } else {
                  this.msg(player, "delafk-success", "&aAFK area %name% has been deleted!", "%name%", args[0]);
                  boolean flag2 = true;
                  flag = flag2;
               }
               break;
            default:
               boolean flag2 = true;
               flag = flag2;
         }

         return flag;
      } else {
         this.msg(sender, "player-only", "&cOnly players can use this!");
         return true;
      }
   }

   private void msg(CommandSender sender, String key, String def, String... replacements) {
      String text = this.plugin.getMessages().get(key, def);
      if (text == null) {
         text = def;
      }

      if (replacements != null) {
         for(int i = 0; i + 1 < replacements.length; i += 2) {
            if (replacements[i] != null && replacements[i + 1] != null) {
               text = text.replace(replacements[i], replacements[i + 1]);
            }
         }
      }

      sender.sendMessage(ColorUtil.parse(text));
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      String name = command.getName().toLowerCase(Locale.ROOT);
      if (args.length == 1) {
         String p = args[0].toLowerCase(Locale.ROOT);
         List<String> options = new ArrayList();
         switch (name) {
            case "warp":
            case "delwarp":
               options.addAll(this.plugin.getWarps().getWarps().keySet());
               break;
            case "spawn":
            case "delspawn":
               options.addAll(this.plugin.getWarps().getSpawns().keySet());
               break;
            case "afk":
            case "delafk":
               options.addAll(this.plugin.getWarps().getAfks().keySet());
         }

         return (List)options.stream().filter((s) -> s.toLowerCase(Locale.ROOT).startsWith(p)).collect(Collectors.toList());
      } else {
         return new ArrayList();
      }
   }
}
