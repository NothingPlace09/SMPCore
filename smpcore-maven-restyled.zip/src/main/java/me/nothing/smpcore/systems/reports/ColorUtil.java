package me.nothing.smpcore.systems.reports;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public class ColorUtil {
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

   public static String color(String message) {
      for(Matcher matcher = HEX.matcher(message); matcher.find(); matcher = HEX.matcher(message)) {
         String hex = matcher.group(1);
         message = message.replace(matcher.group(), ChatColor.of("#" + hex).toString());
      }

      return ChatColor.translateAlternateColorCodes('&', message);
   }
}
