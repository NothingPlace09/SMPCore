package me.nothing.smpcore.systems.punishment2.commands;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.utils.ColorUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {
   private final SmpCorePunishment plugin;

   public ReloadCommand(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("smpcore.system.punishment.admin")) {
         sender.sendMessage(ColorUtil.color(this.plugin.getMessages().getString("no-permission", "&cYou do not have permission.")));
         return true;
      } else {
         this.plugin.reloadConfig();
         this.plugin.reloadMessages();
         if (this.plugin.getReasonManager() != null) {
            this.plugin.getReasonManager().load();
         }

         this.plugin.getLogger().info("SmpCorePunishment configurations reloaded.");
         sender.sendMessage(ColorUtil.color(this.plugin.getMessages().getString("reload.success", "&#00ff66Configuration files reloaded successfully.")));
         return true;
      }
   }
}
