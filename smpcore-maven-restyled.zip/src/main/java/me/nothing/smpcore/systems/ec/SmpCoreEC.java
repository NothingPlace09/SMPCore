package me.nothing.smpcore.systems.ec;

import java.io.File;
import java.util.logging.Logger;
import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class SmpCoreEC extends SystemHost {
   private static SmpCoreEC instance;
   private EcStorage storage;
   private FileConfiguration messages;

   public SmpCoreEC() {
      super("ec");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.messages = this.loadMessages();
      this.storage = new EcStorage(this);
      new EcCommand(this);
      Bukkit.getPluginManager().registerEvents(new EcListener(this), this.getCore());
      Logger logger = this.getLogger();
      File file = new File(this.getDataFolder(), "data");
      logger.info("SmpCoreEC enabled — data folder: " + file.getPath());
   }

   public void stop() {
      if (this.storage != null) {
         this.storage.flushAll();
      }

      instance = null;
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages = this.loadMessages();
   }

   private FileConfiguration loadMessages() {
      FileConfiguration msg = new YamlConfiguration();
      ConfigurationSection sec = this.getConfig().getConfigurationSection("messages");
      if (sec != null) {
         for(String key : sec.getKeys(true)) {
            msg.set(key, sec.get(key));
         }
      }

      return msg;
   }

   public static SmpCoreEC get() {
      return instance;
   }

   public EcStorage getStorage() {
      return this.storage;
   }

   public FileConfiguration getMessages() {
      return this.messages;
   }
}
