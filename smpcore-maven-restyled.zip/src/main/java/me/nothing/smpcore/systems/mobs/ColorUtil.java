package me.nothing.smpcore.systems.mobs;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;

public class ColorUtil {
   private static final Pattern HEX = Pattern.compile("&#([A-Fa-f0-9]{6})");

   public static String color(String message) {
      if (message == null) {
         return "";
      } else {
         Matcher matcher = HEX.matcher(message);
         StringBuffer buffer = new StringBuffer();

         while(matcher.find()) {
            String hex = matcher.group(1);

            try {
               matcher.appendReplacement(buffer, ChatColor.of("#" + hex).toString());
            } catch (Exception e) {
               matcher.appendReplacement(buffer, "");
            }
         }

         matcher.appendTail(buffer);
         return ChatColor.translateAlternateColorCodes('&', buffer.toString());
      }
   }
}
