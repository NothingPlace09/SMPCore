package me.nothing.smpcore.systems.safety;

import me.nothing.smpcore.systems.SystemHost;

public class SmpCoreSafety extends SystemHost {
   private static SmpCoreSafety instance;

   public SmpCoreSafety() {
      super("safety");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.getServer().getPluginManager().registerEvents(new JoinListener(this), this.getCore());
      this.getLogger().info("SmpCoreSafety enabled!");
   }

   public void stop() {
      this.getLogger().info("SmpCoreSafety disabled.");
   }

   public static SmpCoreSafety getInstance() {
      return instance;
   }
}
