package me.nothing.smpcore.systems.auction;

import java.io.File;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.entity.Player;

public final class SmpCoreAuction extends SystemHost {
   private static SmpCoreAuction instance;
   private AuctionManager auctions;
   private MessageManager messages;
   private EconomyHook economy;
   private BlockManager blocks;
   private WebhookManager webhooks;

   public SmpCoreAuction() {
      super("auction");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      if (!(new File(this.getDataFolder(), "messages.yml")).exists()) {
         this.saveResource("messages.yml", false);
      }

      this.saveGuiDefaults();
      this.reloadConfig();
      this.economy = new EconomyHook();
      if (!this.economy.setup()) {
         this.getLogger().severe("Vault economy missing. Install Vault and an economy plugin.");
         this.getLogger().warning("[auction] init warning (continuing)");
      }

      this.messages = new MessageManager(this);
      if (!(new File(this.getDataFolder(), "webhook.yml")).exists()) {
         this.saveResource("webhook.yml", false);
      }

      this.webhooks = new WebhookManager(this);
      this.auctions = new AuctionManager(this);
      this.blocks = new BlockManager(this);
      this.auctions.startTasks();
      new AuctionCommand(this);

      try {
         ((SmpCore)this.getCore()).commands().registerHandler("ahfastbuy", (s, a) -> {
            if (s instanceof Player p) {
               if (!p.hasPermission("smpcore.system.auction.fastbuy") && !p.hasPermission("smpcore.system.auction.use") && !p.isOp()) {
                  p.sendMessage("§cNo permission.");
                  return true;
               } else {
                  boolean next = !Boolean.TRUE.equals(MenuSession.FAST_BUY.get(p.getUniqueId()));
                  MenuSession.FAST_BUY.put(p.getUniqueId(), next);
                  p.sendMessage(next ? "§aAH fast buy §fenabled." : "§cAH fast buy §fdisabled.");
                  return true;
               }
            } else {
               return true;
            }
         });
      } catch (Throwable t) {
      }

      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new ChatInputListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new SignProtectListener(), this.getCore());
      this.getLogger().info("SmpCoreAuction enabled.");
   }

   public void stop() {
      if (this.auctions != null) {
         this.auctions.save();
      }

      instance = null;
   }

   private void saveGuiDefaults() {
      String[] files = new String[]{"gui/main.gui.yml", "gui/confirm.listing.gui.yml", "gui/confirm.purchase.gui.yml", "gui/my.items.gui.yml", "gui/transactions.gui.yml", "gui/shulker.view.gui.yml", "gui/admin.gui.yml"};

      for(String name : files) {
         File out = new File(this.getDataFolder(), name);
         if (!out.exists()) {
            out.getParentFile().mkdirs();
            this.saveResource(name, false);
         }
      }

   }

   public void reloadAll() {
      this.reloadConfig();
      if (this.messages != null) {
         this.messages.reload();
      }

      if (this.webhooks != null) {
         this.webhooks.reload();
      }

   }

   public static SmpCoreAuction get() {
      return instance;
   }

   public AuctionManager getAuctions() {
      return this.auctions;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public EconomyHook getEconomy() {
      return this.economy;
   }

   public BlockManager getBlocks() {
      return this.blocks;
   }

   public WebhookManager getWebhooks() {
      return this.webhooks;
   }
}
