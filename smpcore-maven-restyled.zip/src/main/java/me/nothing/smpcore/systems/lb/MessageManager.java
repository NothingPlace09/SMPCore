package me.nothing.smpcore.systems.lb;

import java.io.File;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public final class MessageManager {
   private final SmpCoreLeaderboards plugin;
   private FileConfiguration messages;

   public MessageManager(SmpCoreLeaderboards plugin) {
      this.plugin = plugin;
      this.reload();
   }

   public void reload() {
      File file = new File(this.plugin.getDataFolder(), "messages.yml");
      if (!file.exists()) {
         this.plugin.saveResource("messages.yml", false);
      }

      this.messages = YamlConfiguration.loadConfiguration(file);
   }

   public String get(String key, String def) {
      return this.messages.getString(key, def);
   }

   public String get(String key) {
      return this.messages.getString(key, key);
   }
}
