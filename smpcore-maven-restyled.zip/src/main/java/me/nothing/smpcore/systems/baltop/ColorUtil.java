package me.nothing.smpcore.systems.baltop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').hexCharacter('#').build();

   private ColorUtil() {
   }

   public static Component parse(String text) {
      return (Component)(text != null && !text.isEmpty() ? LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false) : Component.empty());
   }

   public static String strip(String text) {
      return text == null ? "" : LEGACY.serialize(LEGACY.deserialize(text)).replaceAll("§.", "");
   }
}
