package me.nothing.smpcore.systems.duels;

import me.nothing.smpcore.utils.GuiSafe;
import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.commands.CommandRegistry;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.systems.warps.SmpCoreWarps;
import me.nothing.smpcore.systems.warps.NamedLocation;
import me.nothing.smpcore.utils.HotbarUtil;
import me.nothing.smpcore.utils.SoundUtil;
import me.nothing.smpcore.utils.TextUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityToggleGlideEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.entity.EnderPearl;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.scheduler.BukkitTask;

public class DuelsModule implements Module, Listener {
   private final SmpCore plugin;
   private FileConfiguration cfg;
   private final Set<UUID> queue = ConcurrentHashMap.newKeySet();
   /** GUI attualmente aperta per player: coda normale/ranked, selezione modalita', sfida diretta, conferma sfida. */
   private enum GuiMode {
      QUEUE_NORMAL,
      QUEUE_RANKED,
      MODE_SELECT,
      DIRECT_DUEL,
      CONFIRM_DUEL
   }

   private final Map<UUID, GuiMode> openGui = new ConcurrentHashMap();
   private final Set<UUID> rankedQueue = ConcurrentHashMap.newKeySet();
   /** Contiene gli UUID di entrambi i partecipanti quando il duello attivo e' ranked (per assegnare l'Elo a fine match). */
   private final Set<UUID> rankedMatch = ConcurrentHashMap.newKeySet();
   /** Stato della GUI "sfida diretta" mentre e' aperta: sfidante -> [bersaglio, indiceMappa, indiceTempo]. */
   private final Map<UUID, Object[]> directDuelState = new ConcurrentHashMap();
   private static final String[] COSMETIC_MAPS = new String[]{"Sandstone Arena", "Frostpeak Arena", "Nether Colosseum", "Emerald Grove"};
   private static final String[] COSMETIC_TIMES = new String[]{"5 min", "10 min", "15 min", "No limit"};
   private static final String[] RANK_NAMES = new String[]{"Bronze", "Silver", "Gold", "Diamond", "Mythic", "Legendary", "Champion"};
   private final List<Arena> arenas = new ArrayList();
   /** Arena usata dal match attivo di ogni player (per confinamento e pulizia a fine duello). */
   private final Map<UUID, Arena> activeArenaOf = new ConcurrentHashMap();
   private final Map<UUID, BukkitTask> music = new ConcurrentHashMap();
   private final Map<UUID, UUID> inDuel = new ConcurrentHashMap();
   private final Set<UUID> duelDeaths = ConcurrentHashMap.newKeySet();
   private final Set<UUID> spectators = ConcurrentHashMap.newKeySet();
   private final Set<UUID> winners = ConcurrentHashMap.newKeySet();
   private final Set<UUID> drawVotes = ConcurrentHashMap.newKeySet();
   private final Map<UUID, BukkitTask> lootTasks = new ConcurrentHashMap();
   /** Collega vincitore<->perdente durante il loot, cosi' se uno dei due fa /leave l'altro non resta bloccato in arena. */
   private final Map<UUID, UUID> lootPair = new ConcurrentHashMap();
   private final Map<UUID, BukkitTask> borderTasks = new ConcurrentHashMap();
   private final Map<UUID, Long> matchStart = new ConcurrentHashMap();
   private final Map<UUID, int[]> stats = new ConcurrentHashMap();
   private final Set<UUID> returnToSpawnOnJoin = ConcurrentHashMap.newKeySet();
   private final Map<UUID, Location> pendingSpectator = new ConcurrentHashMap();
   private final Set<UUID> pvpDisabled = ConcurrentHashMap.newKeySet();
   private final Map<UUID, UUID> pendingDraw = new ConcurrentHashMap();
   /** target -> [challenger, expiresAtMillis, mapName, timeLabel] per le richieste dirette (/duel <player>). */
   private final Map<UUID, Object[]> pendingChallenge = new ConcurrentHashMap();
   private Location spawn1;
   private Location spawn2;
   /** Dove viene teletrasportato chi tenta di uscire dall'arena (/duelsadmin setspawn). Se nullo, si usa lo spawn del server. */
   private Location escapeSpawn;
   private Location arenaPos1;
   private Location arenaPos2;
   private final Map<UUID, Location> wandPos1 = new ConcurrentHashMap();

   public DuelsModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "duels";
   }

   public void onEnable() {
      File folder = new File(this.plugin.getDataFolder(), "duels");
      folder.mkdirs();
      new File(folder, "schematics").mkdirs();
      File f = new File(folder, "config.yml");
      if (!f.exists()) {
         try {
            this.plugin.saveResource("duels/config.yml", false);
         } catch (Exception e) {
         }
      }

      this.cfg = YamlConfiguration.loadConfiguration(f);
      File sounds = new File(folder, "sounds.yml");
      if (!sounds.exists()) {
         try {
            this.plugin.saveResource("duels/sounds.yml", false);
         } catch (Exception e) {
         }
      }

      File messages = new File(folder, "messages.yml");
      if (!messages.exists()) {
         try {
            this.plugin.saveResource("duels/messages.yml", false);
         } catch (Exception e) {
         }
      }

      this.loadStats();

      for(String g : new String[]{"queue.yml", "confirm-duel.yml", "direct-duel.yml"}) {
         File gf = new File(folder, g);
         if (!gf.exists()) {
            try {
               this.plugin.saveResource("duels/gui/" + g, false);
            } catch (Exception e) {
            }
         }
      }

      this.loadSpawns();
      this.plugin.getServer().getPluginManager().registerEvents(this, this.plugin);
      CommandRegistry reg = this.plugin.commands();
      reg.registerHandler("duels", this::queueCmd);
      reg.registerHandler("queue", this::queueCmd);
      reg.registerHandler("leave", this::leaveCmd);
      reg.registerHandler("draw", this::drawCmd);
      reg.registerHandler("spectate", this::spectateCmd);
      reg.registerHandler("duelsadmin", this::adminCmd);
      reg.registerHandler("duel", this::directDuelCmd);
      reg.registerHandler("duelaccept", this::duelAcceptCmd);
      reg.registerHandler("dueldeny", this::duelDenyCmd);
   }

   public void onDisable() {
      for(UUID id : new HashSet<>(this.music.keySet())) {
         this.stopMusic(Bukkit.getPlayer(id));
      }

      for(BukkitTask task : new HashSet<>(this.lootTasks.values())) {
         task.cancel();
      }

      this.lootTasks.clear();
      this.queue.clear();
      this.inDuel.clear();
      this.saveStats();
   }

   public void reload() {
      File f = new File(this.plugin.getDataFolder(), "duels/config.yml");
      if (f.exists()) {
         this.cfg = YamlConfiguration.loadConfiguration(f);
      }

      this.loadSpawns();
   }

   private void loadSpawns() {
      File sf = new File(this.plugin.getDataFolder(), "duels/spawn.yml");
      if (sf.exists()) {
         FileConfiguration s = YamlConfiguration.loadConfiguration(sf);
         this.spawn1 = this.readLoc(s, "spawn1");
         this.spawn2 = this.readLoc(s, "spawn2");
         this.arenaPos1 = this.readLoc(s, "pos1");
         this.arenaPos2 = this.readLoc(s, "pos2");
         this.escapeSpawn = this.readLoc(s, "escape-spawn");
      }

      this.loadArenas();
   }

   private void saveSpawns() {
      File sf = new File(this.plugin.getDataFolder(), "duels/spawn.yml");
      FileConfiguration s = new YamlConfiguration();
      this.writeLoc(s, "spawn1", this.spawn1);
      this.writeLoc(s, "spawn2", this.spawn2);
      this.writeLoc(s, "pos1", this.arenaPos1);
      this.writeLoc(s, "pos2", this.arenaPos2);
      this.writeLoc(s, "escape-spawn", this.escapeSpawn);

      try {
         s.save(sf);
      } catch (Exception e) {
      }

   }

   private Location readLoc(ConfigurationSection s, String path) {
      if (!s.contains(path + ".world")) {
         return null;
      } else {
         World w = Bukkit.getWorld(s.getString(path + ".world", "world"));
         return w == null ? null : new Location(w, s.getDouble(path + ".x"), s.getDouble(path + ".y"), s.getDouble(path + ".z"), (float)s.getDouble(path + ".yaw"), (float)s.getDouble(path + ".pitch"));
      }
   }

   private void writeLoc(FileConfiguration s, String path, Location loc) {
      if (loc != null && loc.getWorld() != null) {
         s.set(path + ".world", loc.getWorld().getName());
         s.set(path + ".x", loc.getX());
         s.set(path + ".y", loc.getY());
         s.set(path + ".z", loc.getZ());
         s.set(path + ".yaw", loc.getYaw());
         s.set(path + ".pitch", loc.getPitch());
      }
   }

   /**
    * Arene nominate (salvate con /duelsadmin savearena), ognuna col proprio confine, spawn dei due
    * combattenti e uno schematic opzionale. Se la lista e' vuota si ripiega sull'arena unica pos1/pos2
    * (retrocompatibile con le installazioni gia' esistenti che non hanno ancora salvato arene nominate).
    */
   private void loadArenas() {
      this.arenas.clear();
      File f = new File(this.plugin.getDataFolder(), "duels/arenas.yml");
      if (f.exists()) {
         FileConfiguration data = YamlConfiguration.loadConfiguration(f);
         ConfigurationSection sec = data.getConfigurationSection("arenas");
         if (sec != null) {
            for(String name : sec.getKeys(false)) {
               ConfigurationSection a = sec.getConfigurationSection(name);
               if (a != null) {
                  Location pos1 = this.readLoc(a, "pos1");
                  Location pos2 = this.readLoc(a, "pos2");
                  if (pos1 != null && pos2 != null) {
                     Location sp1 = this.readLoc(a, "spawn1");
                     Location sp2 = this.readLoc(a, "spawn2");
                     this.arenas.add(new Arena(name, pos1, pos2, sp1, sp2, a.getString("schematic", (String)null)));
                  }
               }
            }
         }
      }

   }

   private void saveArenas() {
      File f = new File(this.plugin.getDataFolder(), "duels/arenas.yml");
      FileConfiguration data = new YamlConfiguration();

      for(Arena a : this.arenas) {
         String base = "arenas." + a.getName();
         this.writeLoc(data, base + ".pos1", a.getPos1());
         this.writeLoc(data, base + ".pos2", a.getPos2());
         this.writeLoc(data, base + ".spawn1", a.getSpawn1());
         this.writeLoc(data, base + ".spawn2", a.getSpawn2());
         if (a.getSchematic() != null) {
            data.set(base + ".schematic", a.getSchematic());
         }
      }

      try {
         data.save(f);
      } catch (Exception e) {
         this.plugin.getLogger().warning("[Duels] Failed to save arenas.yml: " + e.getMessage());
      }

   }

   /** Nomi mostrati nel selettore "Map" della GUI /duel: arene reali se ne esistono, altrimenti la lista cosmetica di fallback. */
   private String[] mapNameOptions() {
      if (this.arenas.isEmpty()) {
         return COSMETIC_MAPS;
      } else {
         String[] names = new String[this.arenas.size()];

         for(int i = 0; i < names.length; ++i) {
            names[i] = ((Arena)this.arenas.get(i)).getName();
         }

         return names;
      }
   }

   private Arena findArena(String name) {
      for(Arena a : this.arenas) {
         if (a.getName().equalsIgnoreCase(name)) {
            return a;
         }
      }

      return null;
   }

   /** Scelta casuale tra le arene nominate configurate per il mondo richiesto (o tutte, se non e' impostato un mondo). */
   private Arena randomArena() {
      String worldFilter = this.plugin.getConfig().getString("arena.duel-world", "").trim();
      List<Arena> pool = new ArrayList();

      // FIX: un'arena resta "occupata" (activeArenaOf) per tutta la fase di loot, non solo durante il duello
      // vero e proprio, quindi qui va esclusa finche' non viene rilasciata (releaseArena) altrimenti un nuovo
      // match potrebbe incollare uno schematic sopra un'arena dove qualcuno sta ancora raccogliendo il loot.
      for(Arena a : this.arenas) {
         if ((worldFilter.isEmpty() || a.isInWorld(worldFilter)) && !this.activeArenaOf.containsValue(a)) {
            pool.add(a);
         }
      }

      return pool.isEmpty() ? null : (Arena)pool.get(ThreadLocalRandom.current().nextInt(pool.size()));
   }

   private boolean queueCmd(CommandSender sender, String[] args) {
      if (sender instanceof Player p) {
         if (this.arenas.isEmpty() && (this.arenaPos1 == null || this.arenaPos2 == null)) {
            // FIX: prima si poteva mettersi in coda ed avviare un duello anche senza un'arena configurata.
            TextUtil.send(p, "&cDuels are not available right now: no arena has been set up.");
            return true;
         } else if (this.inDuel.containsKey(p.getUniqueId())) {
            TextUtil.send(p, "&cYou are already in a duel.");
            return true;
         } else {
            this.openModeSelectGui(p);
            return true;
         }
      } else {
         return true;
      }
   }

   /** "/duels" apre prima la scelta tra Normal Queue e Ranked Queue. */
   /**
    * "/duels" apre prima questa scelta tra Normal Queue e Ranked Queue. Configurabile in
    * duels/gui/mode-select.yml (stesso formato degli altri file gui: title, rows, items.<key>.slot/material/name/lore).
    * Gli slot funzionali sono fissi: 11 = Normal Queue, 15 = Ranked Queue (puoi cambiare nome/lore/materiale,
    * non lo slot). %rank% ed %elo% nella lore mostrano il rank/Elo del giocatore.
    */
   private void openModeSelectGui(Player p) {
      Inventory inv = this.loadGui("mode-select.yml", "{dark-gray}Select Queue Type", p, false, Map.of());
      if (inv == null) {
         inv = Bukkit.createInventory((InventoryHolder)null, 27, TextUtil.component(this.token("{dark-gray}Select Queue Type")));
         inv.setItem(11, this.simple(Material.IRON_SWORD, "&#37BFF9Normal Queue", "&fClick to queue for a casual duel."));
         int elo = this.getElo(p.getUniqueId());
         List<Component> rankedLore = new ArrayList();
         rankedLore.add(TextUtil.component(this.token("{white}Click to queue for a ranked duel.")));
         rankedLore.add(TextUtil.component(this.token("{gray}Your rank: {accent}" + this.getRankName(elo))));
         ItemStack ranked = new ItemStack(Material.NETHERITE_SWORD);
         ItemMeta rm = ranked.getItemMeta();
         if (rm != null) {
            rm.displayName(TextUtil.component(this.token("{main}Ranked Queue")));
            rm.lore(rankedLore);
            ranked.setItemMeta(rm);
         }

         inv.setItem(15, ranked);
      }

      p.openInventory(inv);
      this.openGui.put(p.getUniqueId(), GuiMode.MODE_SELECT);
   }

   private void joinQueue(Player p) {
      this.joinQueue(p, false);
   }

   private void joinQueue(Player p, boolean ranked) {
      Set<UUID> pool = ranked ? this.rankedQueue : this.queue;
      if (this.inDuel.containsKey(p.getUniqueId())) {
         TextUtil.send(p, "&cYou are already in a duel.");
      } else if (pool.contains(p.getUniqueId())) {
         TextUtil.send(p, "&7Already searching...");
      } else {
         boolean highBucket = ranked && this.isHighRankBucket(this.getElo(p.getUniqueId()));

         for(UUID id : new ArrayList<>(pool)) {
            Player other = Bukkit.getPlayer(id);
            if (other != null && other.isOnline() && !other.equals(p) && !SettingsModule.isDuelRequestsDisabled(other.getUniqueId())) {
               // Ranked: Bronze-Diamond e Mythic-Champion usano due matchmaking separati, non si incontrano mai.
               if (!ranked || this.isHighRankBucket(this.getElo(id)) == highBucket) {
                  pool.remove(id);
                  this.stopMusic(other);
                  this.startDuel(p, other, ranked);
                  return;
               }
            }
         }

         pool.add(p.getUniqueId());
         this.startMusic(p);
         TextUtil.send(p, ranked ? "&7Searching for a ranked duel..." : "&7Searching for a duel...");
      }
   }

   /**
    * FIX: mancava un modo per sfidare direttamente un giocatore specifico, esisteva solo la coda casuale (/duels).
    * "/duel <player>" manda una richiesta diretta; il bersaglio la accetta con "/duelaccept" o rifiuta con "/dueldeny".
    */
   private boolean directDuelCmd(CommandSender sender, String[] args) {
      if (!(sender instanceof Player p)) {
         return true;
      } else if (args.length < 1) {
         TextUtil.send(p, "&cUsage: /duel <player>");
         return true;
      } else if (this.arenas.isEmpty() && (this.arenaPos1 == null || this.arenaPos2 == null)) {
         TextUtil.send(p, "&cDuels are not available right now: no arena has been set up.");
         return true;
      } else {
         Player target = Bukkit.getPlayer(args[0]);
         if (target == null || !target.isOnline()) {
            TextUtil.send(p, "&cThat player is not online.");
            return true;
         } else if (target.equals(p)) {
            TextUtil.send(p, "&cYou cannot duel yourself.");
            return true;
         } else if (this.inDuel.containsKey(p.getUniqueId())) {
            TextUtil.send(p, "&cYou are already in a duel.");
            return true;
         } else if (this.inDuel.containsKey(target.getUniqueId())) {
            TextUtil.send(p, "&cThat player is already in a duel.");
            return true;
         } else if (SettingsModule.isDuelRequestsDisabled(target.getUniqueId())) {
            TextUtil.send(p, "&cThat player is not accepting duel requests.");
            return true;
         } else {
            // "/duel <player>" ora apre la GUI mappa/tempo/regione invece di mandare subito la richiesta.
            this.directDuelState.put(p.getUniqueId(), new Object[]{target.getUniqueId(), 0, 0});
            this.openDirectDuelGui(p, target.getUniqueId());
            return true;
         }
      }
   }

   /**
    * GUI di "/duel <player>": mappa e tempo sono puramente cosmetici (nessun effetto reale su matchmaking o
    * connessione), come richiesto. La regione e' sempre "EU Central".
    */
   private void openDirectDuelGui(Player p, UUID targetId) {
      Player target = Bukkit.getPlayer(targetId);
      String targetName = target != null ? target.getName() : "?";
      Object[] state = (Object[])this.directDuelState.get(p.getUniqueId());
      String[] maps = this.mapNameOptions();
      int mapIdx = state != null ? Math.min((Integer)state[1], maps.length - 1) : 0;
      int timeIdx = state != null ? (Integer)state[2] : 0;
      Inventory inv = this.loadGui("direct-duel.yml", "{dark-gray}Create Duel - {accent}" + targetName, p, false, Map.of("%opponent%", targetName, "%duel_map_name%", maps[mapIdx], "%duel_time%", COSMETIC_TIMES[timeIdx]));
      if (inv == null) {
         inv = Bukkit.createInventory((InventoryHolder)null, 27, TextUtil.component(this.token("{dark-gray}Create Duel - {accent}" + targetName)));
         inv.setItem(10, this.simple(Material.RED_STAINED_GLASS_PANE, "&cCancel", "&7Click to cancel"));
         inv.setItem(12, this.simple(Material.SAND, "&#37BFF9Map", "&7(" + maps[mapIdx] + ")"));
         inv.setItem(13, this.simple(Material.CLOCK, "&#37BFF9Time", "&7(" + COSMETIC_TIMES[timeIdx] + ")"));
         inv.setItem(14, this.simple(Material.PAPER, "&#37BFF9Region", "&7EU Central"));
         inv.setItem(16, this.simple(Material.LIME_STAINED_GLASS_PANE, "&aSend", "&7Click to send request"));
      }

      p.openInventory(inv);
      this.openGui.put(p.getUniqueId(), GuiMode.DIRECT_DUEL);
   }

   private void sendDirectDuelChallenge(Player p, UUID targetId, String mapName, String timeLabel) {
      Player target = Bukkit.getPlayer(targetId);
      if (target == null || !target.isOnline()) {
         TextUtil.send(p, "&cThat player is no longer online.");
      } else if (this.inDuel.containsKey(p.getUniqueId()) || this.inDuel.containsKey(targetId)) {
         TextUtil.send(p, "&cOne of you is already in a duel.");
      } else if (SettingsModule.isDuelRequestsDisabled(targetId)) {
         TextUtil.send(p, "&cThat player is not accepting duel requests.");
      } else {
         this.pendingChallenge.put(targetId, new Object[]{p.getUniqueId(), System.currentTimeMillis() + 60000L, mapName, timeLabel});
         TextUtil.send(p, "&7Duel request sent to &f" + target.getName() + "&7. Waiting for them to accept...");
         TextUtil.send(target, "&f" + p.getName() + " &7challenged you to a duel! Type &f/duelaccept &7or &f/dueldeny&7 (expires in 60s).");
         this.openConfirmDuelGui(target, p.getName(), mapName, timeLabel);
      }
   }

   /** Aperta al bersaglio non appena arriva una richiesta diretta (fallback: /duelaccept o /dueldeny se ha chiuso la GUI). */
   private void openConfirmDuelGui(Player target, String challengerName, String mapName, String timeLabel) {
      if (!this.inDuel.containsKey(target.getUniqueId()) && this.openGui.get(target.getUniqueId()) == null) {
         Inventory inv = this.loadGui("confirm-duel.yml", "{dark-gray}Confirm Duel - {accent}" + challengerName, target, false, Map.of("%opponent%", challengerName, "%duel_map_name%", mapName, "%duel_time%", timeLabel));
         if (inv == null) {
            inv = Bukkit.createInventory((InventoryHolder)null, 27, TextUtil.component(this.token("{dark-gray}Confirm Duel - {accent}" + challengerName)));
            inv.setItem(10, this.simple(Material.RED_STAINED_GLASS_PANE, "&cDeny", "&7Click to deny"));
            inv.setItem(12, this.simple(Material.SAND, "&#37BFF9Map", "&7(" + mapName + ")"));
            inv.setItem(13, this.simple(Material.CLOCK, "&#37BFF9Time", "&7(" + timeLabel + ")"));
            inv.setItem(14, this.simple(Material.PAPER, "&#37BFF9Region", "&7EU Central"));
            inv.setItem(16, this.simple(Material.LIME_STAINED_GLASS_PANE, "&aAccept", "&7Click to start the duel"));
         }

         target.openInventory(inv);
         this.openGui.put(target.getUniqueId(), GuiMode.CONFIRM_DUEL);
      }
   }

   /** Carica un file GUI da duels/gui/<name>, sostituendo i placeholder forniti. Torna null se il file non esiste. */
   private Inventory loadGui(String name, String fallbackTitle, Player p, boolean ranked, Map<String, String> extra) {
      File guiFile = new File(this.plugin.getDataFolder(), "duels/gui/" + name);
      if (!guiFile.exists()) {
         try {
            this.plugin.saveResource("duels/gui/" + name, false);
         } catch (Exception e) {
         }
      }

      if (!guiFile.exists()) {
         return null;
      } else {
         FileConfiguration gui = YamlConfiguration.loadConfiguration(guiFile);
         String title = this.token(this.applyExtra(gui.getString("title", fallbackTitle), extra));
         int rows = Math.max(1, Math.min(6, gui.getInt("rows", 3)));
         Inventory inv = Bukkit.createInventory((InventoryHolder)null, rows * 9, TextUtil.component(title));
         ConfigurationSection items = gui.getConfigurationSection("items");
         if (items != null) {
            for(String key : items.getKeys(false)) {
               ConfigurationSection sec = items.getConfigurationSection(key);
               if (sec != null) {
                  int slot = sec.getInt("slot", -1);
                  if (slot >= 0 && slot < inv.getSize()) {
                     Material mat;
                     try {
                        mat = Material.valueOf(sec.getString("material", "STONE").toUpperCase());
                     } catch (Exception e) {
                        mat = Material.STONE;
                     }

                     ItemStack item = new ItemStack(mat);
                     ItemMeta meta = item.getItemMeta();
                     if (meta != null) {
                        meta.displayName(TextUtil.component(this.token(this.applyExtra(this.applyPlaceholders(sec.getString("name", key), p, ranked), extra))));
                        List<Component> lore = new ArrayList();

                        for(String line : sec.getStringList("lore")) {
                           lore.add(TextUtil.component(this.token(this.applyExtra(this.applyPlaceholders(line, p, ranked), extra))));
                        }

                        meta.lore(lore);
                        item.setItemMeta(meta);
                     }

                     inv.setItem(slot, item);
                  }
               }
            }
         }

         return inv;
      }
   }

   private String applyExtra(String text, Map<String, String> extra) {
      String out = text;

      for(Map.Entry<String, String> entry : extra.entrySet()) {
         out = out.replace((CharSequence)entry.getKey(), (CharSequence)entry.getValue());
      }

      return out;
   }

   private boolean duelAcceptCmd(CommandSender sender, String[] args) {
      if (!(sender instanceof Player p)) {
         return true;
      } else {
         this.openGui.remove(p.getUniqueId());
         Object[] req = (Object[])this.pendingChallenge.remove(p.getUniqueId());
         if (req == null) {
            TextUtil.send(p, "&cYou have no pending duel request.");
            return true;
         } else if (System.currentTimeMillis() > (Long)req[1]) {
            TextUtil.send(p, "&cThat duel request has expired.");
            return true;
         } else {
            Player challenger = Bukkit.getPlayer((UUID)req[0]);
            if (challenger != null && challenger.isOnline() && !this.inDuel.containsKey(challenger.getUniqueId()) && !this.inDuel.containsKey(p.getUniqueId())) {
               // Se la mappa scelta nella GUI corrisponde ad un'arena nominata reale, si usa quella; altrimenti (lista
               // cosmetica di fallback, nessuna arena salvata) l'arena viene scelta normalmente in startDuel.
               Arena chosen = req.length > 2 ? this.findArena((String)req[2]) : null;
               this.startDuel(challenger, p, false, chosen);
            } else {
               TextUtil.send(p, "&cThat player is no longer available.");
            }

            return true;
         }
      }
   }

   private boolean duelDenyCmd(CommandSender sender, String[] args) {
      if (!(sender instanceof Player p)) {
         return true;
      } else {
         this.openGui.remove(p.getUniqueId());
         Object[] req = (Object[])this.pendingChallenge.remove(p.getUniqueId());
         if (req != null) {
            Player challenger = Bukkit.getPlayer((UUID)req[0]);
            if (challenger != null) {
               TextUtil.send(challenger, "&f" + p.getName() + " &7denied your duel request.");
            }

            TextUtil.send(p, "&7Duel request denied.");
         } else {
            TextUtil.send(p, "&cYou have no pending duel request.");
         }

         return true;
      }
   }

   private void openQueueGui(Player p) {
      this.openQueueGui(p, false);
   }

   private void openQueueGui(Player p, boolean ranked) {
      File guiFile = new File(this.plugin.getDataFolder(), "duels/gui/queue.yml");
      if (!guiFile.exists()) {
         try {
            this.plugin.saveResource("duels/gui/queue.yml", false);
         } catch (Exception e) {
         }
      }

      FileConfiguration gui = guiFile.exists() ? YamlConfiguration.loadConfiguration(guiFile) : new YamlConfiguration();
      String title = gui.getString("title", "&8Select & Confirm");
      title = this.token(title) + (ranked ? " &7(Ranked)" : "");
      int rows = Math.max(1, Math.min(6, gui.getInt("rows", 3)));
      Inventory inv = Bukkit.createInventory((InventoryHolder)null, rows * 9, TextUtil.component(title));
      ConfigurationSection items = gui.getConfigurationSection("items");
      if (items != null) {
         for(String key : items.getKeys(false)) {
            ConfigurationSection sec = items.getConfigurationSection(key);
            if (sec != null) {
               int slot = sec.getInt("slot", -1);
               if (slot >= 0 && slot < inv.getSize()) {
                  Material mat;
                  try {
                     mat = Material.valueOf(sec.getString("material", "STONE").toUpperCase());
                  } catch (Exception e) {
                     mat = Material.STONE;
                  }

                  ItemStack item = new ItemStack(mat);
                  ItemMeta meta = item.getItemMeta();
                  if (meta != null) {
                     String name = this.token(this.applyPlaceholders(sec.getString("name", key), p, ranked));
                     meta.displayName(TextUtil.component(name));
                     List<Component> lore = new ArrayList();

                     for(String line : sec.getStringList("lore")) {
                        lore.add(TextUtil.component(this.token(this.applyPlaceholders(line, p, ranked))));
                     }

                     // Nella coda Ranked, la sezione statistiche mostra anche il rank attuale del giocatore.
                     if (ranked && key.equals("stats")) {
                        lore.add(TextUtil.component(this.token("{gray}Rank: {accent}" + this.getRankName(this.getElo(p.getUniqueId())))));
                     }

                     meta.lore(lore);
                     item.setItemMeta(meta);
                  }

                  inv.setItem(slot, item);
               }
            }
         }
      } else {
         Set<UUID> pool = ranked ? this.rankedQueue : this.queue;
         inv.setItem(10, this.simple(Material.RED_STAINED_GLASS_PANE, "&cCancel", "&7Click to cancel"));
         inv.setItem(12, this.simple(Material.COMPASS, "&#37BFF9Wait Time", "&7Queued: &f" + pool.size()));
         List<Component> statsLore = new ArrayList();
         statsLore.add(TextUtil.component("&7Elo / Wins / Losses"));
         if (ranked) {
            statsLore.add(TextUtil.component("&7Rank: &b" + this.getRankName(this.getElo(p.getUniqueId()))));
         }

         ItemStack statsItem = new ItemStack(Material.GRAY_DYE);
         ItemMeta statsMeta = statsItem.getItemMeta();
         if (statsMeta != null) {
            statsMeta.displayName(TextUtil.component("&#37BFF9Statistics"));
            statsMeta.lore(statsLore);
            statsItem.setItemMeta(statsMeta);
         }

         inv.setItem(13, statsItem);
         inv.setItem(14, this.simple(Material.FEATHER, "&#37BFF9Region", "&7Ping: &f" + p.getPing() + "ms"));
         inv.setItem(16, this.simple(Material.LIME_STAINED_GLASS_PANE, "&aSearch", "&7Click to search"));
      }

      p.openInventory(inv);
      this.openGui.put(p.getUniqueId(), ranked ? GuiMode.QUEUE_RANKED : GuiMode.QUEUE_NORMAL);
   }

   private String token(String s) {
      return s == null ? "" : s.replace("{dark-gray}", "&8").replace("{main}", "&#37BFF9").replace("{gray}", "&7").replace("{accent}", "&#37BFF9").replace("{white}", "&f").replace("{success}", "&#00FF00").replace("{error}", "&c");
   }

   private ItemStack simple(Material mat, String name, String lore) {
      ItemStack item = new ItemStack(mat);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.displayName(TextUtil.component(name));
         meta.lore(List.of(TextUtil.component(lore)));
         item.setItemMeta(meta);
      }

      return item;
   }

   private void startMusic(Player p) {
      if (!SettingsModule.isDuelSongsDisabled(p.getUniqueId())) {
         this.stopMusic(p);
         BukkitTask t = Bukkit.getScheduler().runTaskTimer(this.plugin, () -> {
            if (this.queue.contains(p.getUniqueId()) && p.isOnline()) {
               this.play(p, "queue-music");
            } else {
               this.stopMusic(p);
            }
         }, 0L, 600L);
         this.music.put(p.getUniqueId(), t);
      }
   }

   private void stopMusic(Player p) {
      if (p != null) {
         BukkitTask t = (BukkitTask)this.music.remove(p.getUniqueId());
         if (t != null) {
            t.cancel();
         }

         try {
            p.stopSound(Sound.MUSIC_DISC_OTHERSIDE);
         } catch (Throwable ignored) {
         }

         try {
            p.stopSound(Sound.MUSIC_DISC_PIGSTEP);
         } catch (Throwable ignored) {
         }

      }
   }

   private void startDuel(Player a, Player b) {
      this.startDuel(a, b, false, (Arena)null);
   }

   private void startDuel(Player a, Player b, boolean ranked) {
      this.startDuel(a, b, ranked, (Arena)null);
   }

   private void startDuel(Player a, Player b, boolean ranked, Arena chosen) {
      final Arena arena = chosen != null ? chosen : this.randomArena();
      this.stopMusic(a);
      this.stopMusic(b);
      a.closeInventory();
      b.closeInventory();
      int[] count = new int[]{3};
      Bukkit.getScheduler().runTaskTimer(this.plugin, (task) -> {
         if (a.isOnline() && b.isOnline()) {
            if (count[0] > 0) {
               String tTitle = this.token(this.message("game-startup-count-title", "{main}%seconds%").replace("%seconds%", String.valueOf(count[0])));
               this.showTitle(a, tTitle, "");
               this.showTitle(b, tTitle, "");
               this.play(a, "countdown");
               this.play(b, "countdown");
               String bar = this.message("duel-countdown-actionbar", "{gray}Duel starting in {accent}%amount%s{gray}!").replace("%amount%", String.valueOf(count[0]));
               TextUtil.actionBar(a, this.token(bar));
               TextUtil.actionBar(b, this.token(bar));
               int i = count[0]--;
            } else {
               task.cancel();
               this.beginMatch(a, b, ranked, arena);
            }
         } else {
            task.cancel();
            this.queue.remove(a.getUniqueId());
            this.queue.remove(b.getUniqueId());
            this.rankedQueue.remove(a.getUniqueId());
            this.rankedQueue.remove(b.getUniqueId());
         }
      }, 0L, 20L);
   }

   private void beginMatch(Player a, Player b) {
      this.beginMatch(a, b, false, (Arena)null);
   }

   private void beginMatch(Player a, Player b, boolean ranked) {
      this.beginMatch(a, b, ranked, (Arena)null);
   }

   private void beginMatch(Player a, Player b, boolean ranked, Arena arena) {
      if (arena != null && this.activeArenaOf.containsValue(arena)) {
         // FIX: l'arena scelta (esplicitamente o dal countdown avviato qualche secondo prima) potrebbe nel
         // frattempo essere finita occupata da un altro match ancora in fase di loot: ne prendiamo un'altra
         // libera invece di incollare lo schematic sopra chi sta ancora raccogliendo il loot.
         arena = this.randomArena();
      }

      if (arena != null) {
         this.activeArenaOf.put(a.getUniqueId(), arena);
         this.activeArenaOf.put(b.getUniqueId(), arena);
         if (arena.getSchematic() != null) {
            File schemFile = new File(this.plugin.getDataFolder(), "duels/schematics/" + arena.getSchematic());
            SchematicUtil.paste(schemFile, arena.getPos1(), this.plugin.getLogger());
         }
      }

      if (ranked) {
         this.rankedMatch.add(a.getUniqueId());
         this.rankedMatch.add(b.getUniqueId());
      }

      this.inDuel.put(a.getUniqueId(), b.getUniqueId());
      this.inDuel.put(b.getUniqueId(), a.getUniqueId());
      this.drawVotes.remove(a.getUniqueId());
      this.drawVotes.remove(b.getUniqueId());
      this.pendingDraw.remove(a.getUniqueId());
      this.pendingDraw.remove(b.getUniqueId());
      this.pvpDisabled.remove(a.getUniqueId());
      this.pvpDisabled.remove(b.getUniqueId());
      this.matchStart.put(a.getUniqueId(), System.currentTimeMillis());
      this.matchStart.put(b.getUniqueId(), System.currentTimeMillis());
      Location s1 = arena != null ? arena.getSpawn1().clone() : (this.spawn1 != null ? this.spawn1.clone() : a.getLocation().clone());
      Location s2 = arena != null ? arena.getSpawn2().clone() : (this.spawn2 != null ? this.spawn2.clone() : b.getLocation().clone());
      a.teleport(s1);
      b.teleport(s2);
      this.play(a, "duel-start");
      this.play(b, "duel-start");
      if (this.cfg.getBoolean("match.heal-on-start", true)) {
         try {
            a.setHealth(a.getMaxHealth());
            b.setHealth(b.getMaxHealth());
         } catch (Throwable t) {
         }
      }

      if (this.cfg.getBoolean("match.feed-on-start", true)) {
         a.setFoodLevel(20);
         b.setFoodLevel(20);
         a.setSaturation(20.0F);
         b.setSaturation(20.0F);
      }

      if (this.cfg.getBoolean("match.set-survival-on-start", true)) {
         a.setGameMode(GameMode.SURVIVAL);
         b.setGameMode(GameMode.SURVIVAL);
      }

      String title = this.token(this.message("game-started-title", "{error}CASUAL DUEL"));
      String subtitle = this.token(this.message("game-started-subtitle", "{white}Fight players and steal their loot"));
      this.showTitle(a, title, subtitle);
      this.showTitle(b, title, subtitle);
      this.play(a, "duel-started");
      this.play(b, "duel-started");
      TextUtil.send(a, "&7Duel started against &#37BFF9" + b.getName());
      TextUtil.send(b, "&7Duel started against &#37BFF9" + a.getName());
      this.scheduleBorder(a.getUniqueId(), b.getUniqueId());
   }

   private void scheduleBorder(UUID a, UUID b) {
      BukkitTask old = (BukkitTask)this.borderTasks.remove(a);
      if (old != null) {
         old.cancel();
      }

      BukkitTask task = Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         if (this.inDuel.containsKey(a) && this.inDuel.containsKey(b)) {
            Player pa = Bukkit.getPlayer(a);
            Player pb = Bukkit.getPlayer(b);
            if (pa != null && pb != null) {
               // Se il match usa un'arena nominata, il border si centra sui SUOI confini (pos1/pos2 dell'arena),
               // non piu' sempre sull'unica arena globale legacy.
               Arena matchArena = (Arena)this.activeArenaOf.get(a);
               Location bp1 = matchArena != null ? matchArena.getPos1() : this.arenaPos1;
               Location bp2 = matchArena != null ? matchArena.getPos2() : this.arenaPos2;
               if (bp1 != null && bp2 != null && bp1.getWorld() != null) {
                  try {
                     World w = bp1.getWorld();
                     double minX = Math.min(bp1.getX(), bp2.getX());
                     double maxX = Math.max(bp1.getX(), bp2.getX());
                     double minZ = Math.min(bp1.getZ(), bp2.getZ());
                     double maxZ = Math.max(bp1.getZ(), bp2.getZ());
                     double cx = (minX + maxX) / (double)2.0F;
                     double cz = (minZ + maxZ) / (double)2.0F;
                     double size = Math.max(Math.abs(maxX - minX), Math.abs(maxZ - minZ));
                     if (size < (double)20.0F) {
                        size = (double)50.0F;
                     }

                     WorldBorder border = w.getWorldBorder();
                     border.setCenter(cx, cz);
                     border.setSize(size);
                     border.setSize(Math.max((double)10.0F, size * 0.4), 60L);
                     String msg = this.token(this.message("border-shrink-150", "{gray}The border is shrinking to {accent}%border_size%{gray}.").replace("%border_size%", String.valueOf((int)(size * 0.4))));
                     TextUtil.send(pa, msg);
                     TextUtil.send(pb, msg);
                  } catch (Throwable t) {
                  }

               }
            }
         }
      }, 1200L);
      this.borderTasks.put(a, task);
      this.borderTasks.put(b, task);
   }

   /**
    * Chiamato appena il DUELLO finisce (morte, forfeit, disconnessione, pareggio): ripristina solo il world
    * border. NON tocca piu' lo schematic ne' l'arena "occupata" (activeArenaOf), perche' la fase di loot che
    * segue usa ancora quei confini per confinare vincitore/spettatore. Vedi releaseArena per quello.
    */
   private void resetBorder(UUID a, UUID b) {
      BukkitTask t = (BukkitTask)this.borderTasks.remove(a);
      if (t != null) {
         t.cancel();
      }

      this.borderTasks.remove(b);

      try {
         Arena matchArena = (Arena)this.activeArenaOf.get(a);
         if (matchArena == null) {
            matchArena = (Arena)this.activeArenaOf.get(b);
         }

         Location resetOn = matchArena != null ? matchArena.getPos1() : this.arenaPos1;
         if (resetOn != null && resetOn.getWorld() != null) {
            resetOn.getWorld().getWorldBorder().reset();
         }
      } catch (Throwable ignored) {
      }

   }

   /**
    * FEATURE (richiesta): l'arena NON viene piu' ripulita/riassegnata subito alla fine del duello, ma resta
    * "occupata" (con lo schematic ancora incollato) finche' la fase di loot non e' davvero finita: il vincitore
    * fa /leave, si disconnette, oppure il tempo di loot scade. Solo a quel punto viene richiamato questo
    * metodo, che libera l'arena (rimuovendola da activeArenaOf, cosi' randomArena() puo' riassegnarla) e la
    * ripulisce (rimessa ad aria) se aveva uno schematic.
    */
   private void releaseArena(UUID winnerId, UUID loserId) {
      Arena matchArena = (Arena)this.activeArenaOf.remove(winnerId);
      if (loserId != null) {
         Arena lo = (Arena)this.activeArenaOf.remove(loserId);
         if (matchArena == null) {
            matchArena = lo;
         }
      }

      if (matchArena != null && matchArena.getSchematic() != null) {
         SchematicUtil.clear(matchArena);
      }

   }

   private boolean leaveCmd(CommandSender sender, String[] args) {
      if (sender instanceof Player p) {
         UUID id = p.getUniqueId();
         if (this.inDuel.containsKey(id)) {
            TextUtil.send(p, "&cYou cannot leave an active duel. Use /draw or fight until the duel ends.");
            return true;
         } else {
            this.performLeaveLoot(p, (Location)null);
            return true;
         }
      } else {
         return true;
      }
   }

   /**
    * Esce dalla fase di loot (spettatore/perdente o vincitore). dest e' dove teletrasportare CHI ESCE: null =
    * spawn del server (teleportToSpawn), altrimenti quella location (usato dal contenimento dell'arena per
    * mandare al duel escape spawn invece che allo spawn generico).
    *
    * FEATURE (richiesta): il perdente e il vincitore NON sono piu' equivalenti qui.
    * - Se esce il VINCITORE, la fase di loot finisce per davvero: il timer si ferma e l'arena viene rilasciata
    *   (schematic ripulito, riassegnabile a un prossimo match).
    * - Se esce il PERDENTE/spettatore, esce solo lui: il vincitore resta dentro a raccogliere il loot finche'
    *   non fa /leave lui stesso o finche' il tempo non scade. L'arena resta occupata.
    */
   private void performLeaveLoot(Player p, Location dest) {
      UUID id = p.getUniqueId();
      this.queue.remove(id);
      this.stopMusic(p);
      boolean isWinner = this.winners.contains(id);
      boolean isLooting = isWinner || this.spectators.contains(id);
      if (isWinner) {
         UUID partnerId = (UUID)this.lootPair.get(id);
         Player partner = partnerId != null ? Bukkit.getPlayer(partnerId) : null;
         this.finishLootPhase(id, partnerId, dest);
         TextUtil.send(p, this.token(this.message("leave-loot", "{gray}You left the duel arena.")));
         if (partner != null && partner.isOnline()) {
            TextUtil.send(partner, this.token("{gray}The winner left, loot time is over."));
         }

         return;
      }

      if (isLooting) {
         // Il perdente esce da solo: NON tocchiamo il BukkitTask (e' condiviso con il vincitore, cancellarlo
         // fermerebbe anche il suo timer) ne' l'arena (non ancora rilasciata).
         this.lootPair.remove(id);
         this.spectators.remove(id);
         this.lootTasks.remove(id);
      }

      if (p.getGameMode() == GameMode.SPECTATOR) {
         p.setGameMode(GameMode.SURVIVAL);
      }

      if (dest != null) {
         p.teleport(dest);
      } else {
         this.teleportToSpawn(p);
      }

      TextUtil.send(p, this.token(this.message("leave-loot", "{gray}You left the duel arena.")));
   }

   /**
    * Chiude la fase di loot per davvero (vincitore che fa /leave, si disconnette, o tempo scaduto) e libera
    * l'arena. winnerDest e' dove teletrasportare il vincitore (null = spawn del server).
    */
   private void finishLootPhase(UUID winnerId, UUID loserId, Location winnerDest) {
      Player winner = Bukkit.getPlayer(winnerId);
      Player loser = loserId == null ? null : Bukkit.getPlayer(loserId);
      BukkitTask task = (BukkitTask)this.lootTasks.remove(winnerId);
      if (task != null) {
         task.cancel();
      }

      if (loserId != null) {
         BukkitTask other = (BukkitTask)this.lootTasks.remove(loserId);
         if (other != null && other != task) {
            other.cancel();
         }
      }

      this.winners.remove(winnerId);
      this.lootPair.remove(winnerId);
      if (loserId != null) {
         this.spectators.remove(loserId);
         this.lootPair.remove(loserId);
      }

      this.releaseArena(winnerId, loserId);
      if (winner != null && winner.isOnline()) {
         if (winner.getGameMode() == GameMode.SPECTATOR) {
            winner.setGameMode(GameMode.SURVIVAL);
         }

         if (winnerDest != null) {
            winner.teleport(winnerDest);
         } else {
            this.teleportToSpawn(winner);
         }
      }

      if (loser != null && loser.isOnline()) {
         if (loser.getGameMode() == GameMode.SPECTATOR) {
            loser.setGameMode(GameMode.SURVIVAL);
         }

         this.teleportToSpawn(loser);
      }

   }

   /**
    * Chi tenta di scappare da un duello ATTIVO (non in loot) viene considerato sconfitto per abbandono:
    * l'avversario vince, come quando qualcuno esce dal server a meta' duello, ma senza far cadere l'inventario
    * (chi scappa resta online, non ha senso svuotargli le tasche).
    */
   private void forfeitActiveDuel(Player p, Location dest) {
      UUID id = p.getUniqueId();
      UUID oppId = (UUID)this.inDuel.get(id);
      if (oppId != null) {
         Player opp = Bukkit.getPlayer(oppId);
         this.inDuel.remove(id);
         this.inDuel.remove(oppId);
         this.pendingDraw.remove(id);
         this.pendingDraw.remove(oppId);
         this.resetBorder(id, oppId);
         this.addStat(id, 1);
         this.addStat(oppId, 0);
         if (this.rankedMatch.remove(id) & this.rankedMatch.remove(oppId)) {
            this.applyRankedResult(oppId, id);
         }

         if (dest != null) {
            p.teleport(dest);
         } else {
            this.teleportToSpawn(p);
         }

         TextUtil.send(p, this.token("{error}You left the duel arena. This counts as a forfeit."));
         if (opp != null && opp.isOnline()) {
            this.showTitle(opp, this.token(this.message("game-won-title", "{success}You Won!")), this.token(this.message("game-won-subtitle", "{white}Your opponent left")));
            this.play(opp, "win");
            TextUtil.send(opp, "&aYour opponent left the arena. You win!");
            this.startLootPhase(opp, (Player)null);
         }
      }

   }

   /** Il tempo di loot e' scaduto naturalmente: stesso rilascio dell'arena di quando il vincitore fa /leave. */
   private void endLootPhase(UUID winnerId, UUID loserId) {
      Player winner = Bukkit.getPlayer(winnerId);
      Player loser = loserId == null ? null : Bukkit.getPlayer(loserId);
      this.finishLootPhase(winnerId, loserId, (Location)null);
      if (winner != null && winner.isOnline()) {
         HotbarUtil.send(winner, TextUtil.component("&7Loot time over."));
         this.showTitle(winner, this.token(this.message("game-won-title", "{success}You Won!")), this.token(this.message("game-won-subtitle", "{white}Loot time is over")));
      }

      if (loser != null && loser.isOnline()) {
         HotbarUtil.send(loser, TextUtil.component("&7Returning to spawn."));
      }

   }

   private void startLootPhase(final Player winner, final Player loser) {
      if (winner != null) {
         final int seconds = Math.max(1, this.cfg.getInt("match.loot-seconds", 240));
         this.winners.add(winner.getUniqueId());
         if (loser != null) {
            this.spectators.add(loser.getUniqueId());
            this.lootPair.put(winner.getUniqueId(), loser.getUniqueId());
            this.lootPair.put(loser.getUniqueId(), winner.getUniqueId());
         }

         this.showTitle(winner, this.token(this.message("game-won-title", "{success}You Won!")), this.token(this.message("game-won-subtitle", "{white}Get your loot before the time runs out")));
         if (loser != null) {
            this.showTitle(loser, this.token(this.message("game-lost-title", "{error}You lost...")), "");
         }

         this.play(winner, "win");
         if (loser != null) {
            this.play(loser, "lose");
         }

         BukkitTask oldWinner = (BukkitTask)this.lootTasks.remove(winner.getUniqueId());
         if (oldWinner != null) {
            oldWinner.cancel();
         }

         if (loser != null) {
            BukkitTask oldLoser = (BukkitTask)this.lootTasks.remove(loser.getUniqueId());
            if (oldLoser != null) {
               oldLoser.cancel();
            }
         }

         BukkitTask task = Bukkit.getScheduler().runTaskTimer(this.plugin, new Runnable() {
            int left = seconds;

            public void run() {
               if (this.left <= 0 || loser != null && !winner.isOnline() && !loser.isOnline()) {
                  BukkitTask current = (BukkitTask)DuelsModule.this.lootTasks.remove(winner.getUniqueId());
                  if (current != null) {
                     current.cancel();
                  }

                  if (loser != null) {
                     BukkitTask other = (BukkitTask)DuelsModule.this.lootTasks.remove(loser.getUniqueId());
                     if (other != null) {
                        other.cancel();
                     }
                  }

                  DuelsModule.this.endLootPhase(winner.getUniqueId(), loser == null ? null : loser.getUniqueId());
               } else {
                  String bar = DuelsModule.this.message("loot-time", "{gray}You have {accent}%seconds%s {gray}to collect loot.").replace("%seconds%", String.valueOf(this.left));
                  if (winner.isOnline()) {
                     HotbarUtil.send(winner, TextUtil.component(DuelsModule.this.token(bar)));
                  }

                  if (loser != null && loser.isOnline() && DuelsModule.this.spectators.contains(loser.getUniqueId())) {
                     // Il perdente potrebbe aver gia' fatto /leave da solo: in quel caso non e' piu' uno
                     // spettatore e non deve continuare a vedere il countdown del loot del vincitore.
                     HotbarUtil.send(loser, TextUtil.component(DuelsModule.this.token(bar)));
                  }

                  --this.left;
               }
            }
         }, 0L, 20L);
         this.lootTasks.put(winner.getUniqueId(), task);
         if (loser != null) {
            this.lootTasks.put(loser.getUniqueId(), task);
         }

      }
   }

   private boolean drawCmd(CommandSender sender, String[] args) {
      if (sender instanceof Player p) {
         UUID id = p.getUniqueId();
         UUID oppId = (UUID)this.inDuel.get(id);
         if (oppId == null) {
            TextUtil.send(p, "&cYou are not in a duel.");
            return true;
         } else {
            Player opp = Bukkit.getPlayer(oppId);
            if (this.pendingDraw.containsKey(oppId) && ((UUID)this.pendingDraw.get(oppId)).equals(id)) {
               TextUtil.send(p, this.token(this.message("draw-accepted", "{gray}Draw accepted.")));
               if (opp != null) {
                  TextUtil.send(opp, this.token(this.message("draw-accepted", "{gray}Draw accepted.")));
               }

               this.finishDraw(p, opp);
               return true;
            } else if (this.pendingDraw.containsKey(id)) {
               TextUtil.send(p, this.token(this.message("draw-already-sent", "{gray}You already requested a draw. Waiting for opponent...")));
               return true;
            } else {
               this.pendingDraw.put(id, oppId);
               TextUtil.send(p, this.token(this.message("draw-sent", "{gray}Draw request sent. Waiting for opponent...")));
               if (opp != null) {
                  TextUtil.send(opp, this.token(this.message("draw-received", "{accent}%player% {gray}requested a draw. Use {accent}/draw {gray}to accept.").replace("%player%", p.getName())));
               }

               return true;
            }
         }
      } else {
         return true;
      }
   }

   private void finishDraw(Player a, Player b) {
      // Un pareggio ranked non cambia l'Elo di nessuno dei due, ma il match esce comunque dal tracking ranked.
      if (a != null) {
         this.rankedMatch.remove(a.getUniqueId());
      }

      if (b != null) {
         this.rankedMatch.remove(b.getUniqueId());
      }

      if (a != null) {
         this.inDuel.remove(a.getUniqueId());
         this.pendingDraw.remove(a.getUniqueId());
         this.drawVotes.remove(a.getUniqueId());
         this.addStat(a.getUniqueId(), 2);
         this.pvpDisabled.add(a.getUniqueId());
      }

      if (b != null) {
         this.inDuel.remove(b.getUniqueId());
         this.pendingDraw.remove(b.getUniqueId());
         this.drawVotes.remove(b.getUniqueId());
         this.addStat(b.getUniqueId(), 2);
         this.pvpDisabled.add(b.getUniqueId());
      }

      UUID aid = a != null ? a.getUniqueId() : null;
      UUID bid = b != null ? b.getUniqueId() : null;
      if (aid != null && bid != null) {
         this.resetBorder(aid, bid);
         // Un pareggio non ha una fase di loot dopo: l'arena si libera subito, non c'e' nessuno che deve
         // raccogliere loot.
         this.releaseArena(aid, bid);
      }

      String title = this.token(this.message("game-draw-title", "{gray}DRAW"));
      String sub = this.token(this.message("game-draw-subtitle", "{gray}The duel ended with no winner."));
      if (a != null) {
         this.showTitle(a, title, sub);
         this.play(a, "draw");
      }

      if (b != null) {
         this.showTitle(b, title, sub);
         this.play(b, "draw");
      }

      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         if (a != null && a.isOnline()) {
            this.pvpDisabled.remove(a.getUniqueId());
            a.setGameMode(GameMode.SURVIVAL);
            this.teleportToSpawn(a);
         }

         if (b != null && b.isOnline()) {
            this.pvpDisabled.remove(b.getUniqueId());
            b.setGameMode(GameMode.SURVIVAL);
            this.teleportToSpawn(b);
         }

      }, 100L);
   }

   private int[] getStats(UUID id) {
      return (int[])this.stats.computeIfAbsent(id, (k) -> new int[]{0, 0, 0, 0, 1000});
   }

   private int getElo(UUID id) {
      return this.getStats(id)[4];
   }

   /**
    * Sistema Ranked: vincendo si guadagnano 100-120 Elo, perdendo se ne perdono 100 (mai sotto 1000).
    * 7 rank (Bronze..Champion) da 3 livelli ciascuno, 500 Elo a livello (1500 Elo a rank), a partire da 1000.
    */
   private void applyRankedResult(UUID winnerId, UUID loserId) {
      int[] w = this.getStats(winnerId);
      w[4] += 100 + ThreadLocalRandom.current().nextInt(21);
      int[] l = this.getStats(loserId);
      l[4] = Math.max(1000, l[4] - 100);
      this.saveStats();
   }

   private int getRankIndex(int elo) {
      int idx = (elo - 1000) / 1500;
      return Math.max(0, Math.min(RANK_NAMES.length - 1, idx));
   }

   private int getRankSubLevel(int elo) {
      int idx = this.getRankIndex(elo);
      int rem = elo - 1000 - idx * 1500;
      int sub = rem / 500 + 1;
      return Math.max(1, Math.min(3, sub));
   }

   private String getRankName(int elo) {
      return RANK_NAMES[this.getRankIndex(elo)] + " " + this.getRankSubLevel(elo);
   }

   /** Matchmaking ranked diviso in due fasce: Bronze-Diamond (low) e Mythic-Champion (high), non si incontrano mai. */
   private boolean isHighRankBucket(int elo) {
      return this.getRankIndex(elo) >= 4;
   }

   private String applyPlaceholders(String text, Player p, boolean ranked) {
      int[] s = this.getStats(p.getUniqueId());
      return text.replace("%amount_queued%", String.valueOf((ranked ? this.rankedQueue : this.queue).size())).replace("%player_ping%", String.valueOf(p.getPing())).replace("%estimated_wait%", "...").replace("%elo%", String.valueOf(s[4])).replace("%wins%", String.valueOf(s[0])).replace("%losses%", String.valueOf(s[1])).replace("%streak%", String.valueOf(s[3])).replace("%win_percentage%", this.getWinPercentage(p.getUniqueId())).replace("%rank%", this.getRankName(s[4]));
   }

   /** Classifica ranked ordinata per Elo decrescente, usata dagli hologram "top ranked". */
   private List<Map.Entry<UUID, int[]>> sortedByElo() {
      List<Map.Entry<UUID, int[]>> list = new ArrayList<>(this.stats.entrySet());
      list.sort((x, y) -> Integer.compare(((int[])y.getValue())[4], ((int[])x.getValue())[4]));
      return list;
   }

   /**
    * Nome del player in posizione "position" (1 = primo) della classifica ranked. Usato dal placeholder
    * %smpcore_duels_top_name_<n>% negli hologram (FEATURE richiesta: hologram "top ranked").
    */
   public String getDuelsTopName(int position) {
      List<Map.Entry<UUID, int[]>> sorted = this.sortedByElo();
      if (position < 1 || position > sorted.size()) {
         return "---";
      } else {
         String name = Bukkit.getOfflinePlayer(((Map.Entry<UUID, int[]>)sorted.get(position - 1)).getKey()).getName();
         return name != null ? name : "Unknown";
      }
   }

   /**
    * Rank+Elo del player in posizione "position", nello stile "Bronze 1 - 1107". Usato dal placeholder
    * %smpcore_duels_top_value_<n>% (o %smpcore_duels_top_rank_<n>%) negli hologram.
    */
   public String getDuelsTopRankLabel(int position) {
      List<Map.Entry<UUID, int[]>> sorted = this.sortedByElo();
      if (position < 1 || position > sorted.size()) {
         return "---";
      } else {
         int elo = ((int[])((Map.Entry<UUID, int[]>)sorted.get(position - 1)).getValue())[4];
         return this.getRankName(elo) + " - " + elo;
      }
   }

   /** Posizione del giocatore nella classifica ranked (1 = primo), o "-" se non ha ancora giocato ranked. */
   public String getDuelsViewerRank(UUID id) {
      if (id != null && this.stats.containsKey(id)) {
         List<Map.Entry<UUID, int[]>> sorted = this.sortedByElo();

         for(int i = 0; i < sorted.size(); ++i) {
            if (((Map.Entry<UUID, int[]>)sorted.get(i)).getKey().equals(id)) {
               return String.valueOf(i + 1);
            }
         }
      }

      return "-";
   }

   /** Rank+Elo del giocatore, nello stile "Bronze 1 - 1107". Usato dal placeholder %smpcore_duels_value%. */
   public String getDuelsViewerLabel(UUID id) {
      if (id == null) {
         return "---";
      } else {
         int elo = this.getElo(id);
         return this.getRankName(elo) + " - " + elo;
      }
   }

   private String getWinPercentage(UUID id) {
      int[] s = this.getStats(id);
      int games = s[0] + s[1];
      return games <= 0 ? "0.0" : String.format(Locale.US, "%.1f", (double)s[0] * (double)100.0F / (double)games);
   }

   private void addStat(UUID id, int type) {
      int[] s = this.getStats(id);
      if (type == 0) {
         int i = s[0]++;
         i = s[3]++;
      } else if (type == 1) {
         int i = s[1]++;
         s[3] = 0;
      } else if (type == 2) {
         int i = s[2]++;
      }

      this.saveStats();
   }

   private void loadStats() {
      File f = new File(this.plugin.getDataFolder(), "duels/stats.yml");
      if (f.exists()) {
         FileConfiguration data = YamlConfiguration.loadConfiguration(f);
         ConfigurationSection sec = data.getConfigurationSection("players");
         if (sec != null) {
            for(String raw : sec.getKeys(false)) {
               try {
                  UUID id = UUID.fromString(raw);
                  int[] s = new int[5];
                  s[0] = sec.getInt(raw + ".wins");
                  s[1] = sec.getInt(raw + ".losses");
                  s[2] = sec.getInt(raw + ".draws");
                  s[3] = sec.getInt(raw + ".streak", 0);
                  s[4] = sec.getInt(raw + ".elo", 1000);
                  this.stats.put(id, s);
               } catch (IllegalArgumentException e) {
               }
            }

         }
      }
   }

   private void saveStats() {
      File f = new File(this.plugin.getDataFolder(), "duels/stats.yml");
      FileConfiguration data = new YamlConfiguration();

      for(Map.Entry<UUID, int[]> entry : this.stats.entrySet()) {
         int[] s = (int[])entry.getValue();
         data.set("players." + String.valueOf(entry.getKey()) + ".wins", s[0]);
         data.set("players." + String.valueOf(entry.getKey()) + ".losses", s[1]);
         data.set("players." + String.valueOf(entry.getKey()) + ".draws", s[2]);
         data.set("players." + String.valueOf(entry.getKey()) + ".streak", s[3]);
         data.set("players." + String.valueOf(entry.getKey()) + ".elo", s[4]);
      }

      try {
         f.getParentFile().mkdirs();
         data.save(f);
      } catch (Exception e) {
      }

   }

   private boolean spectateCmd(CommandSender sender, String[] args) {
      if (sender instanceof Player p) {
         if (args.length < 1) {
            TextUtil.send(p, "&cUsage: /spectate <player>");
            return true;
         } else {
            Player t = Bukkit.getPlayerExact(args[0]);
            if (t != null && this.inDuel.containsKey(t.getUniqueId())) {
               this.spectators.add(p.getUniqueId());
               p.setGameMode(GameMode.SPECTATOR);
               p.teleport(t.getLocation());
               TextUtil.send(p, "&7Spectating &#37BFF9" + t.getName());
               return true;
            } else {
               TextUtil.send(p, "&cThat player is not in a duel.");
               return true;
            }
         }
      } else {
         return true;
      }
   }

   private boolean adminCmd(CommandSender sender, String[] args) {
      if (sender instanceof Player p) {
         if (!p.hasPermission("smpcore.system.duels.admin") && !p.isOp()) {
            TextUtil.send(p, "&cNo permission.");
            return true;
         } else if (args.length < 1) {
            TextUtil.send(p, "&c/duelsadmin wand|setspawn1|setspawn2|setpos1|setpos2|savearena|listarenas|deletearena|setschematic|setspawn");
            return true;
         } else {
            switch (args[0].toLowerCase()) {
               case "wand":
                  ItemStack wand = new ItemStack(Material.GOLDEN_AXE);
                  ItemMeta meta = wand.getItemMeta();
                  if (meta != null) {
                     meta.displayName(TextUtil.component("&6Duels Wand"));
                     wand.setItemMeta(meta);
                  }

                  p.getInventory().addItem(new ItemStack[]{wand});
                  TextUtil.send(p, "&7Given duels wand. Left click pos1, right click pos2.");
                  break;
               case "setspawn1":
                  this.spawn1 = p.getLocation();
                  this.saveSpawns();
                  TextUtil.send(p, "&aSpawn 1 set.");
                  break;
               case "setspawn2":
                  this.spawn2 = p.getLocation();
                  this.saveSpawns();
                  TextUtil.send(p, "&aSpawn 2 set.");
                  break;
               case "setpos1":
                  this.setArenaPos(p, 1, p.getLocation());
                  break;
               case "setpos2":
                  this.setArenaPos(p, 2, p.getLocation());
                  break;
               case "setspawn":
                  // Dove viene mandato chi tenta di uscire dall'arena durante un duello/loot (invece di essere respinto).
                  this.escapeSpawn = p.getLocation();
                  this.saveSpawns();
                  TextUtil.send(p, this.token("{success}Escape spawn set: {accent}" + p.getLocation().getBlockX() + ", " + p.getLocation().getBlockY() + ", " + p.getLocation().getBlockZ()));
                  break;
               case "savearena":
                  if (args.length < 2) {
                     TextUtil.send(p, "&cUsage: /duelsadmin savearena <name>");
                  } else if (this.arenaPos1 == null || this.arenaPos2 == null) {
                     TextUtil.send(p, "&cSet pos1 and pos2 first (wand or /duelsadmin setpos1/setpos2).");
                  } else {
                     String worldFilter = this.plugin.getConfig().getString("arena.duel-world", "").trim();
                     if (!worldFilter.isEmpty() && !p.getWorld().getName().equalsIgnoreCase(worldFilter)) {
                        TextUtil.send(p, this.token("{gray}Note: config.yml expects arenas in world \"" + worldFilter + "\", this one is in \"" + p.getWorld().getName() + "\"."));
                     }

                     String name = args[1];
                     this.arenas.removeIf((a) -> a.getName().equalsIgnoreCase(name));
                     Arena savedArena = new Arena(name, this.arenaPos1.clone(), this.arenaPos2.clone(), this.spawn1 != null ? this.spawn1.clone() : null, this.spawn2 != null ? this.spawn2.clone() : null, (String)null);
                     this.arenas.add(savedArena);

                     // FEATURE (richiesta): /savearena ora genera da solo lo schematic della regione pos1/pos2,
                     // sia dentro duels/schematics/ (usato dal plugin per incollarlo prima di ogni match) sia
                     // dentro la cartella schematics di WorldEdit stesso (selezionabile anche con //schem load).
                     String schemFileName = name + ".schem";
                     File duelsSchemDir = new File(this.plugin.getDataFolder(), "duels/schematics");
                     duelsSchemDir.mkdirs();
                     File duelsSchemFile = new File(duelsSchemDir, schemFileName);
                     boolean schemSaved = false;
                     if (!SchematicUtil.isAvailable()) {
                        TextUtil.send(p, this.token("{gray}WorldEdit/FAWE not found: arena saved without an auto-generated schematic. Use /duelsadmin setschematic to add one manually later."));
                     } else {
                        schemSaved = SchematicUtil.save(duelsSchemFile, this.arenaPos1, this.arenaPos2, this.plugin.getLogger());
                        if (schemSaved) {
                           savedArena.setSchematic(schemFileName);
                           SchematicUtil.mirrorToWorldEdit(duelsSchemFile, schemFileName, this.plugin.getLogger());
                        } else {
                           TextUtil.send(p, this.token("{gray}Could not auto-generate the schematic (see console for details); arena saved without one."));
                        }
                     }

                     this.saveArenas();
                     this.arenaPos1 = null;
                     this.arenaPos2 = null;
                     this.spawn1 = null;
                     this.spawn2 = null;
                     this.saveSpawns();
                     if (schemSaved) {
                        TextUtil.send(p, this.token("{success}Arena \"" + name + "\" saved with schematic {accent}" + schemFileName + "{success}. {gray}It will now be pasted before each match on this arena and cleared after loot ends. Set pos1/pos2 again for the next arena."));
                     } else {
                        TextUtil.send(p, this.token("{success}Arena \"" + name + "\" saved. {gray}This will now show up as a map in the duel GUIs. Set pos1/pos2 again for the next arena."));
                     }
                  }

                  break;
               case "listarenas":
                  if (this.arenas.isEmpty()) {
                     TextUtil.send(p, "&7No named arenas saved yet.");
                  } else {
                     for(Arena a : this.arenas) {
                        TextUtil.send(p, this.token("{gray}- {accent}" + a.getName() + " {gray}(" + a.getPos1().getWorld().getName() + (a.getSchematic() != null ? ", schematic: " + a.getSchematic() : "") + ")"));
                     }
                  }

                  break;
               case "deletearena":
                  if (args.length < 2) {
                     TextUtil.send(p, "&cUsage: /duelsadmin deletearena <name>");
                  } else if (this.arenas.removeIf((a) -> a.getName().equalsIgnoreCase(args[1]))) {
                     this.saveArenas();
                     TextUtil.send(p, this.token("{success}Arena \"" + args[1] + "\" deleted."));
                  } else {
                     TextUtil.send(p, "&cNo arena named \"" + args[1] + "\".");
                  }

                  break;
               case "setschematic":
                  if (args.length < 3) {
                     TextUtil.send(p, "&cUsage: /duelsadmin setschematic <arena> <file.schem>");
                  } else {
                     Arena target = this.findArena(args[1]);
                     if (target == null) {
                        TextUtil.send(p, "&cNo arena named \"" + args[1] + "\".");
                     } else {
                        target.setSchematic(args[2]);
                        this.saveArenas();
                        if (!SchematicUtil.isAvailable()) {
                           TextUtil.send(p, this.token("{gray}Saved, but WorldEdit/FAWE is not installed: the schematic will not be pasted until it is."));
                        } else {
                           TextUtil.send(p, this.token("{success}Arena \"" + args[1] + "\" will now paste {accent}duels/schematics/" + args[2] + " {success}before each match and clear it after."));
                        }
                     }
                  }

                  break;
               default:
                  TextUtil.send(p, "&cUnknown subcommand.");
            }

            return true;
         }
      } else {
         return true;
      }
   }

   /**
    * FIX: non c'era nessun blocco fisico dell'arena, solo il world border globale (che parte 60s dopo l'inizio
    * e comunque non impedisce di attraversarlo, solo spinge indietro con danno). Elytra e perle permettevano di
    * uscire dall'arena da subito. Ora, mentre un player e' in un duello attivo o sta guardando come spettatore
    * dopo averlo perso: l'elytra non plana, le perle dell'ender non si lanciano, e se esce comunque dai bordi
    * dell'arena (pos1/pos2) viene riportato dentro con un avviso.
    */
   private boolean isArenaConfined(UUID id) {
      return this.inDuel.containsKey(id) || this.spectators.contains(id) || this.winners.contains(id);
   }

   @EventHandler(ignoreCancelled = true)
   public void onDuelGlide(EntityToggleGlideEvent e) {
      if (e.isGliding() && e.getEntity() instanceof Player p && this.isArenaConfined(p.getUniqueId())) {
         e.setCancelled(true);
      }

   }

   @EventHandler(ignoreCancelled = true)
   public void onDuelProjectile(ProjectileLaunchEvent e) {
      if (e.getEntity() instanceof EnderPearl pearl && pearl.getShooter() instanceof Player p && this.isArenaConfined(p.getUniqueId())) {
         e.setCancelled(true);
         TextUtil.send(p, this.token("{error}You cannot use ender pearls during a duel."));
      }

   }

   @EventHandler(ignoreCancelled = true)
   public void onDuelMove(PlayerMoveEvent e) {
      Player p = e.getPlayer();
      UUID id = p.getUniqueId();
      if (this.isArenaConfined(id)) {
         Arena matchArena = (Arena)this.activeArenaOf.get(id);
         Location bp1 = matchArena != null ? matchArena.getPos1() : this.arenaPos1;
         Location bp2 = matchArena != null ? matchArena.getPos2() : this.arenaPos2;
         if (bp1 != null && bp2 != null && bp1.getWorld() != null && bp1.getWorld().equals(p.getWorld())) {
            double pad = 3.0;
            double minX = Math.min(bp1.getX(), bp2.getX()) - pad;
            double maxX = Math.max(bp1.getX(), bp2.getX()) + pad;
            double minZ = Math.min(bp1.getZ(), bp2.getZ()) - pad;
            double maxZ = Math.max(bp1.getZ(), bp2.getZ()) + pad;
            double minY = Math.min(bp1.getY(), bp2.getY()) - 20.0;
            double maxY = Math.max(bp1.getY(), bp2.getY()) + 40.0;
            Location to = e.getTo();
            if (to != null && (to.getX() < minX || to.getX() > maxX || to.getZ() < minZ || to.getZ() > maxZ || to.getY() < minY || to.getY() > maxY)) {
               // FIX (richiesto): invece di respingerti dentro (sensazione di "freeze"), vieni teletrasportato.
               // - Combattente attivo: conta come forfeit (vince l'avversario), portato al duel escape spawn
               //   (/duelsadmin setspawn), se impostato.
               // - Spettatore (il perdente, in game mode SPECTATOR durante il loot): e' esattamente come fare
               //   /leave, quindi va allo spawn del server (non al duel escape spawn).
               // - Vincitore in loot: resta al duel escape spawn (sta comunque abbandonando il loot in anticipo).
               if (this.inDuel.containsKey(id)) {
                  this.forfeitActiveDuel(p, this.escapeSpawn);
               } else if (this.spectators.contains(id)) {
                  this.performLeaveLoot(p, (Location)null);
               } else if (this.winners.contains(id)) {
                  this.performLeaveLoot(p, this.escapeSpawn);
               }

            }
         }
      }

   }

   /**
    * FIX: dare il wand non spiegava chiaramente cosa fare e cliccare con esso non faceva nulla (nessun listener
    * lo gestiva). Ora left-click imposta pos1, right-click imposta pos2, con conferma nello stesso stile
    * grigio/azzurro degli altri messaggi del modulo, e un avviso quando l'arena e' completa.
    */
   private void setArenaPos(Player p, int which, Location loc) {
      if (which == 1) {
         this.arenaPos1 = loc.clone();
      } else {
         this.arenaPos2 = loc.clone();
      }

      this.saveSpawns();
      TextUtil.send(p, this.token("{success}Arena pos" + which + " set: {accent}" + loc.getBlockX() + ", " + loc.getBlockY() + ", " + loc.getBlockZ()));
      if (this.arenaPos1 != null && this.arenaPos2 != null) {
         TextUtil.send(p, this.token("{success}Duel arena is ready. {gray}Both positions are set."));
      } else {
         TextUtil.send(p, this.token("{gray}Still missing pos" + (which == 1 ? 2 : 1) + ". Use the wand or /duelsadmin setpos" + (which == 1 ? 2 : 1) + "."));
      }

   }

   private boolean isDuelWand(ItemStack item) {
      if (item != null && item.getType() == Material.GOLDEN_AXE && item.hasItemMeta()) {
         ItemMeta meta = item.getItemMeta();
         return meta != null && meta.hasDisplayName() && net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(meta.displayName()).contains("Duels Wand");
      } else {
         return false;
      }
   }

   @EventHandler
   public void onWandUse(org.bukkit.event.player.PlayerInteractEvent e) {
      Player p = e.getPlayer();
      ItemStack hand = e.getItem();
      if (this.isDuelWand(hand)) {
         if (!p.hasPermission("smpcore.system.duels.admin") && !p.isOp()) {
            e.setCancelled(true);
         } else {
            org.bukkit.event.block.Action action = e.getAction();
            if (action == org.bukkit.event.block.Action.LEFT_CLICK_BLOCK || action == org.bukkit.event.block.Action.LEFT_CLICK_AIR) {
               e.setCancelled(true);
               Location loc = e.getClickedBlock() != null ? e.getClickedBlock().getLocation().add((double)0.5F, (double)0.5F, (double)0.5F) : p.getLocation();
               this.setArenaPos(p, 1, loc);
            } else if (action == org.bukkit.event.block.Action.RIGHT_CLICK_BLOCK || action == org.bukkit.event.block.Action.RIGHT_CLICK_AIR) {
               e.setCancelled(true);
               Location loc = e.getClickedBlock() != null ? e.getClickedBlock().getLocation().add((double)0.5F, (double)0.5F, (double)0.5F) : p.getLocation();
               this.setArenaPos(p, 2, loc);
            }
         }
      }
   }

   /** Usato dal combat: true (una sola volta) se questa morte e' avvenuta dentro un duello. */
   public boolean consumeDuelDeath(UUID id) {
      return this.duelDeaths.remove(id);
   }

   @EventHandler
   public void onDeath(PlayerDeathEvent e) {
      Player dead = e.getEntity();
      UUID id = dead.getUniqueId();
      UUID oppId = (UUID)this.inDuel.get(id);
      if (oppId != null) {
         this.duelDeaths.add(id);
         Player opp = Bukkit.getPlayer(oppId);
         this.returnToSpawnOnJoin.add(id);
         this.inDuel.remove(id);
         this.inDuel.remove(oppId);
         this.pendingDraw.remove(id);
         this.pendingDraw.remove(oppId);
         this.drawVotes.remove(id);
         this.drawVotes.remove(oppId);
         this.resetBorder(id, oppId);
         this.addStat(id, 1);
         if (oppId != null) {
            this.addStat(oppId, 0);
         }

         if (this.rankedMatch.remove(id) & this.rankedMatch.remove(oppId)) {
            this.applyRankedResult(oppId, id);
            if (opp != null && opp.isOnline()) {
               TextUtil.send(opp, this.token("{success}Ranked win! New Elo: {accent}" + this.getElo(oppId) + " {gray}(" + this.getRankName(this.getElo(oppId)) + ")"));
            }

            TextUtil.send(dead, this.token("{error}Ranked loss. New Elo: {accent}" + this.getElo(id) + " {gray}(" + this.getRankName(this.getElo(id)) + ")"));
         }

         Location deathLoc = dead.getLocation().clone();
         this.pendingSpectator.put(id, deathLoc);
         this.spectators.add(id);
         e.setKeepInventory(false);
         if (opp != null && opp.isOnline()) {
            String winnerTitle = this.token(this.message("game-won-title", "{success}You Won!"));
            String winnerSubtitle = this.token(this.message("game-won-subtitle", "{white}Get your loot before the time runs out"));
            String loserTitle = this.token(this.message("game-lost-title", "{error}You lost..."));
            this.showTitle(opp, winnerTitle, winnerSubtitle);
            this.showTitle(dead, loserTitle, "");
            this.play(opp, "win");
            this.play(dead, "lose");
            TextUtil.send(opp, this.token(this.message("game-won", "{success}Congrats! You won the duel.")));
            TextUtil.send(dead, this.token(this.message("game-lost", "{error}You lost the duel.")));
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               if (dead.isOnline()) {
                  dead.spigot().respawn();
               }

            });
            this.startLootPhase(opp, dead);
         } else {
            this.pendingSpectator.remove(id);
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               if (dead.isOnline()) {
                  dead.spigot().respawn();
                  dead.setGameMode(GameMode.SURVIVAL);
                  this.teleportToSpawn(dead);
               }
            });
         }
      }
   }

   @EventHandler
   public void onRespawn(PlayerRespawnEvent e) {
      UUID id = e.getPlayer().getUniqueId();
      Location loc = (Location)this.pendingSpectator.remove(id);
      if (loc != null) {
         e.setRespawnLocation(loc);
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            Player p = e.getPlayer();
            if (p.isOnline()) {
               p.setGameMode(GameMode.SPECTATOR);
               p.teleport(loc);
               this.spectators.add(id);
            }
         });
      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent e) {
      Player p = e.getPlayer();
      UUID id = p.getUniqueId();
      if (this.returnToSpawnOnJoin.remove(id)) {
         Bukkit.getScheduler().runTask(this.plugin, () -> {
            if (p.isOnline()) {
               this.spectators.remove(id);
               this.winners.remove(id);
               p.setGameMode(GameMode.SURVIVAL);
               this.teleportToSpawn(p);
            }
         });
      } else {
         if (this.spectators.remove(id) || this.winners.remove(id)) {
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               if (p.isOnline()) {
                  p.setGameMode(GameMode.SURVIVAL);
                  this.teleportToSpawn(p);
               }
            });
         }

      }
   }

   @EventHandler(
      ignoreCancelled = true
   )
   public void onDamage(EntityDamageByEntityEvent e) {
      Entity entity = e.getEntity();
      if (entity instanceof Player victim) {
         if (this.pvpDisabled.contains(victim.getUniqueId())) {
            e.setCancelled(true);
         } else {
            Player damager = null;
            Entity entity2 = e.getDamager();
            if (entity2 instanceof Player) {
               Player d = (Player)entity2;
               damager = d;
            } else {
               entity2 = e.getDamager();
               if (entity2 instanceof Projectile) {
                  Projectile proj = (Projectile)entity2;
                  ProjectileSource projectileSource = proj.getShooter();
                  if (projectileSource instanceof Player) {
                     Player d = (Player)projectileSource;
                     damager = d;
                  }
               }
            }

            if (damager != null && this.pvpDisabled.contains(damager.getUniqueId())) {
               e.setCancelled(true);
            }

         }
      }
   }

   @EventHandler
   public void onCmd(PlayerCommandPreprocessEvent e) {
      Player p = e.getPlayer();
      UUID id = p.getUniqueId();
      String msg = e.getMessage().toLowerCase(Locale.ROOT);
      String root = msg.length() > 1 ? msg.substring(1).split(" ")[0] : "";
      boolean fighting = this.inDuel.containsKey(id);
      boolean looting = this.winners.contains(id) || this.spectators.contains(id) || this.lootTasks.containsKey(id);
      if (fighting || looting) {
         if (fighting) {
            if (!root.equals("draw") && !root.equals("report") && !root.equals("r")) {
               e.setCancelled(true);
               TextUtil.send(p, "&cCommands are blocked during a duel. Allowed: /draw, /report");
            }
         } else {
            Set<String> allowed = new HashSet(List.of("leave", "home", "homes", "shop", "ah", "auction", "sell", "order", "orders", "draw", "report", "spectate"));
            if (!allowed.contains(root)) {
               e.setCancelled(true);
               TextUtil.send(p, "&cDuring loot you can only use /leave /home /shop /ah /sell /order");
            }

         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent e) {
      Player p = e.getPlayer();
      UUID id = p.getUniqueId();
      if (this.queue.remove(id)) {
         this.stopMusic(p);
      }

      this.rankedQueue.remove(id);
      this.openGui.remove(id);
      this.directDuelState.remove(id);
      this.pendingChallenge.remove(id);
      this.pendingChallenge.entrySet().removeIf((e2) -> id.equals(((Object[])e2.getValue())[0]));
      UUID oppId = (UUID)this.inDuel.get(id);
      if (oppId == null) {
         // Disconnessione durante la fase di loot (non un duello attivo): il comportamento dipende da chi era.
         if (this.winners.contains(id)) {
            // Il vincitore si disconnette: la fase di loot finisce per entrambi e l'arena si libera, come
            // se avesse fatto /leave.
            UUID partnerId = (UUID)this.lootPair.get(id);
            this.finishLootPhase(id, partnerId, (Location)null);
            this.returnToSpawnOnJoin.add(id);
         } else if (this.spectators.contains(id) || this.lootTasks.containsKey(id)) {
            // Il perdente/spettatore si disconnette: il vincitore resta a raccogliere il loot da solo (NON
            // va cancellato il BukkitTask, e' condiviso con il vincitore).
            this.lootPair.remove(id);
            this.spectators.remove(id);
            this.lootTasks.remove(id);
            this.returnToSpawnOnJoin.add(id);
         }

      } else {
         Player opp = Bukkit.getPlayer(oppId);
         this.returnToSpawnOnJoin.add(id);
         this.inDuel.remove(id);
         this.inDuel.remove(oppId);
         this.pendingDraw.remove(id);
         this.pendingDraw.remove(oppId);
         this.resetBorder(id, oppId);
         this.addStat(id, 1);
         this.addStat(oppId, 0);
         if (this.rankedMatch.remove(id) & this.rankedMatch.remove(oppId)) {
            this.applyRankedResult(oppId, id);
         }

         try {
            for(ItemStack item : p.getInventory().getContents()) {
               if (item != null && !item.getType().isAir()) {
                  p.getWorld().dropItemNaturally(p.getLocation(), item);
               }
            }

            p.getInventory().clear();
         } catch (Throwable t) {
         }

         if (opp != null && opp.isOnline()) {
            this.showTitle(opp, this.token(this.message("game-won-title", "{success}You Won!")), this.token(this.message("game-won-subtitle", "{white}Your opponent left")));
            this.play(opp, "win");
            TextUtil.send(opp, "&aYour opponent left the duel. You win!");
            this.startLootPhase(opp, (Player)null);
         }

      }
   }

   public boolean isInDuel(UUID id) {
      return this.inDuel.containsKey(id);
   }

   /** true se a e b sono attualmente in duello l'uno contro l'altro (usato per bypassare il friendly-fire del team). */
   public boolean isDuelingEachOther(UUID a, UUID b) {
      return a != null && b != null && b.equals(this.inDuel.get(a));
   }

   private String message(String key, String def) {
      File f = new File(this.plugin.getDataFolder(), "duels/messages.yml");
      if (!f.exists()) {
         return def;
      } else {
         FileConfiguration m = YamlConfiguration.loadConfiguration(f);
         return m.getString(key, def);
      }
   }

   private void showTitle(Player player, String title, String subtitle) {
      if (player != null && player.isOnline()) {
         try {
            player.sendTitle(TextUtil.color(title), TextUtil.color(subtitle), 10, 60, 10);
         } catch (Throwable t) {
         }

      }
   }

   private void play(Player player, String key) {
      if (player != null && player.isOnline()) {
         File f = new File(this.plugin.getDataFolder(), "duels/sounds.yml");
         if (f.exists()) {
            FileConfiguration sounds = YamlConfiguration.loadConfiguration(f);
            if (sounds.getBoolean(key + ".enabled", true)) {
               String raw = sounds.getString(key + ".sound", "");
               if (raw != null && !raw.isBlank()) {
                  try {
                     Sound sound = Sound.valueOf(raw.toUpperCase(Locale.ROOT));
                     float volume = (float)sounds.getDouble(key + ".volume", (double)1.0F);
                     float pitch = (float)sounds.getDouble(key + ".pitch", (double)1.0F);
                     SoundUtil.play(player, player.getLocation(), sound, volume, pitch);
                  } catch (Throwable t) {
                  }

               }
            }
         }
      }
   }

   private void teleportToSpawn(Player player) {
      if (player != null && player.isOnline()) {
         Location target = null;

         try {
            SmpCoreWarps warps = SmpCoreWarps.get();
            if (warps != null && warps.getWarps() != null) {
               NamedLocation spawn = warps.getWarps().defaultSpawn();
               if (spawn != null) {
                  target = spawn.toLocation();
               }
            }
         } catch (Throwable t) {
         }

         if (target == null) {
            target = this.plugin.getServer().getWorlds().isEmpty() ? null : ((World)this.plugin.getServer().getWorlds().get(0)).getSpawnLocation();
         }

         if (target != null) {
            player.teleport(target.clone());
         }

      }
   }

   @EventHandler
   public void onQueueClose(InventoryCloseEvent e) {
      HumanEntity humanEntity = e.getPlayer();
      if (humanEntity instanceof Player p) {
         this.openGui.remove(p.getUniqueId());
      }

   }

   @EventHandler
   public void onQueueClick(InventoryClickEvent e) {
      HumanEntity humanEntity = e.getWhoClicked();
      if (humanEntity instanceof Player p) {
         GuiMode mode = (GuiMode)this.openGui.get(p.getUniqueId());
         if (mode != null) {
            if (e.getClickedInventory() != null && e.getClickedInventory() == e.getView().getTopInventory()) {
               e.setCancelled(true);
               int slot = e.getRawSlot();
               ItemStack cur = e.getCurrentItem();
               if (cur != null && !cur.getType().isAir()) {
                  switch (mode) {
                     case MODE_SELECT:
                        this.handleModeSelectClick(p, slot);
                        break;
                     case QUEUE_NORMAL:
                     case QUEUE_RANKED:
                        this.handleQueueClick(p, slot, cur.getType(), mode == GuiMode.QUEUE_RANKED);
                        break;
                     case DIRECT_DUEL:
                        this.handleDirectDuelClick(p, slot, e.isRightClick());
                        break;
                     case CONFIRM_DUEL:
                        this.handleConfirmDuelClick(p, slot);
                  }
               }
            } else {
               e.setCancelled(true);
            }
         }
      }
   }

   private void handleModeSelectClick(Player p, int slot) {
      if (slot == 11) {
         GuiSafe.defer(p, () -> this.openQueueGui(p, false));
      } else if (slot == 15) {
         GuiSafe.defer(p, () -> this.openQueueGui(p, true));
      }

   }

   private void handleQueueClick(Player p, int slot, Material type, boolean ranked) {
      Set<UUID> pool = ranked ? this.rankedQueue : this.queue;
      if (type != Material.RED_STAINED_GLASS_PANE && slot != 10) {
         if (type == Material.LIME_STAINED_GLASS_PANE || slot == 16) {
            this.openGui.remove(p.getUniqueId());
            GuiSafe.defer(p, () -> {
               p.closeInventory();
               this.joinQueue(p, ranked);
            });
         }

      } else {
         if (pool.remove(p.getUniqueId())) {
            this.stopMusic(p);
            TextUtil.send(p, ranked ? "&7Left ranked queue." : "&7Left duel queue.");
         }

         this.openGui.remove(p.getUniqueId());
         GuiSafe.close(p);
      }
   }

   private void handleDirectDuelClick(Player p, int slot, boolean rightClick) {
      Object[] state = (Object[])this.directDuelState.get(p.getUniqueId());
      if (state != null) {
         if (slot == 10) {
            this.directDuelState.remove(p.getUniqueId());
            this.openGui.remove(p.getUniqueId());
            GuiSafe.close(p);
         } else if (slot == 12) {
            state[1] = ((Integer)state[1] + 1) % this.mapNameOptions().length;
            GuiSafe.defer(p, () -> this.openDirectDuelGui(p, (UUID)state[0]));
         } else if (slot == 13) {
            int idx = (Integer)state[2];
            idx = rightClick ? idx - 1 : idx + 1;
            idx = ((idx % COSMETIC_TIMES.length) + COSMETIC_TIMES.length) % COSMETIC_TIMES.length;
            state[2] = idx;
            GuiSafe.defer(p, () -> this.openDirectDuelGui(p, (UUID)state[0]));
         } else if (slot == 16) {
            this.directDuelState.remove(p.getUniqueId());
            this.openGui.remove(p.getUniqueId());
            GuiSafe.defer(p, () -> {
               p.closeInventory();
               this.sendDirectDuelChallenge(p, (UUID)state[0], this.mapNameOptions()[(Integer)state[1]], COSMETIC_TIMES[(Integer)state[2]]);
            });
         }
      }
   }

   private void handleConfirmDuelClick(Player p, int slot) {
      this.openGui.remove(p.getUniqueId());
      if (slot == 16) {
         GuiSafe.defer(p, () -> {
            p.closeInventory();
            this.duelAcceptCmd(p, new String[0]);
         });
      } else if (slot == 10) {
         GuiSafe.defer(p, () -> {
            p.closeInventory();
            this.duelDenyCmd(p, new String[0]);
         });
      }

   }
}
