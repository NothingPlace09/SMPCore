package me.nothing.smpcore.systems.rtpq;

import me.nothing.smpcore.utils.SoundUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class SoundUtils {
   public static void play(Player player, String soundName, float volume, float pitch) {
      try {
         Sound sound = Sound.valueOf(soundName.toUpperCase());
         SoundUtil.play(player, player.getLocation(), sound, volume, pitch);
      } catch (IllegalArgumentException e) {
      }

   }
}
