package me.nothing.smpcore.systems.rules;

import me.nothing.smpcore.systems.SystemHost;

public class SmpCoreRules extends SystemHost {
   private static SmpCoreRules instance;
   private ConfigManager configManager;

   public SmpCoreRules() {
      super("rules");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.configManager = new ConfigManager(this);
      this.getServer().getPluginManager().registerEvents(new GUIListener(this), this);
      this.getLogger().info("SmpCoreRules enabled successfully.");
   }

   public void stop() {
      this.getLogger().info("SmpCoreRules disabled.");
   }

   public static SmpCoreRules getInstance() {
      return instance;
   }

   public ConfigManager getConfigManager() {
      return this.configManager;
   }
}
