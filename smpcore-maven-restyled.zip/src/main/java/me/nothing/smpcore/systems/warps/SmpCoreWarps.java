package me.nothing.smpcore.systems.warps;

import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.command.PluginCommand;

public final class SmpCoreWarps extends SystemHost {
   private static SmpCoreWarps instance;
   private MessageManager messages;
   private WarpManager warps;
   private TeleportManager teleports;

   public SmpCoreWarps() {
      super("warps");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.messages = new MessageManager(this);
      this.warps = new WarpManager(this);
      this.teleports = new TeleportManager(this);
      WarpMenus.load(this);
      WarpCommand cmd = new WarpCommand(this);

      for(String name : new String[]{"warp", "setwarp", "delwarp", "spawn", "setspawn", "delspawn", "afk", "setafk", "delafk", "warpreload"}) {
         PluginCommand c = this.getCommand(name);
         if (c != null) {
            c.setExecutor(cmd);
            c.setTabCompleter(cmd);
         }
      }

      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new PlayerListener(this), this.getCore());
      this.getLogger().info("SmpCoreWarps enabled.");
   }

   public void stop() {
      if (this.warps != null) {
         this.warps.saveAll();
      }

      instance = null;
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.warps.reload();
      WarpMenus.load(this);
   }

   public static SmpCoreWarps get() {
      return instance;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public WarpManager getWarps() {
      return this.warps;
   }

   public TeleportManager getTeleports() {
      return this.teleports;
   }
}
