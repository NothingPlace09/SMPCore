package me.nothing.smpcore.systems.order;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemUtil {
   private ItemUtil() {
   }

   public static ItemStack named(Material material, String name, List<String> lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.displayName(ColorUtil.parse(name));
         if (lore != null && !lore.isEmpty()) {
            List<Component> lines = new ArrayList();

            for(String line : lore) {
               lines.add(ColorUtil.parse(line));
            }

            meta.lore(lines);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   public static String pretty(Material material) {
      String raw = material.name().toLowerCase().replace('_', ' ');
      StringBuilder sb = new StringBuilder();

      for(String part : raw.split(" ")) {
         if (!part.isEmpty()) {
            if (sb.length() > 0) {
               sb.append(' ');
            }

            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
         }
      }

      return sb.toString();
   }

   public static boolean matches(ItemStack stack, ItemStack template, boolean materialOnly) {
      if (stack != null && template != null && stack.getType() != Material.AIR) {
         if (materialOnly) {
            return stack.getType() == template.getType();
         } else {
            return stack.isSimilar(template);
         }
      } else {
         return false;
      }
   }

   public static int countMatching(Player player, ItemStack template, boolean materialOnly) {
      int total = 0;

      for(ItemStack stack : player.getInventory().getContents()) {
         if (matches(stack, template, materialOnly)) {
            total += stack.getAmount();
         }
      }

      return total;
   }

   public static int takeMatching(Player player, ItemStack template, int amount, boolean materialOnly) {
      int left = amount;
      ItemStack[] contents = player.getInventory().getContents();

      for(int i = 0; i < contents.length && left > 0; ++i) {
         ItemStack stack = contents[i];
         if (matches(stack, template, materialOnly)) {
            int take = Math.min(left, stack.getAmount());
            int next = stack.getAmount() - take;
            if (next <= 0) {
               contents[i] = null;
            } else {
               stack.setAmount(next);
            }

            left -= take;
         }
      }

      player.getInventory().setContents(contents);
      return amount - left;
   }
}
