package me.nothing.smpcore.systems.baltop;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.entity.Player;

public final class InputUtil {
   private static final Map<UUID, Location> SIGN_LOC = new HashMap();
   private static final Map<UUID, BlockData> OLD_DATA = new HashMap();
   private static final Set<Location> PROTECTED = new HashSet();

   private InputUtil() {
   }

   public static boolean useSign() {
      return SmpCoreBaltop.get().getConfig().getBoolean("chat-input.SignAPI", true);
   }

   public static boolean useChat() {
      return useSign() ? false : SmpCoreBaltop.get().getConfig().getBoolean("chat-input.ChatAPI", true);
   }

   public static void requestSearch(Player player) {
      if (useSign()) {
         openSign(player);
      } else {
         MenuSession.CHAT_SEARCH.put(player.getUniqueId(), true);
         player.closeInventory();
         SmpCoreBaltop.get().getMessages().send(player, "chat-input");
      }
   }

   public static void openSign(Player player) {
      UUID id = player.getUniqueId();
      cleanup(player);
      Location base = player.getLocation().clone();
      Location loc = base.clone();
      loc.setY((double)Math.max(player.getWorld().getMinHeight() + 1, base.getBlockY() - 2));
      Block block = loc.getBlock();
      SIGN_LOC.put(id, loc.clone());
      OLD_DATA.put(id, block.getBlockData().clone());
      MenuSession.SIGN_SEARCH.put(id, true);
      player.closeInventory();
      block.setType(Material.OAK_SIGN, false);
      BlockState blockState = block.getState();
      if (!(blockState instanceof Sign sign)) {
         fallbackChat(player);
      } else {
         List<String> configLines = SmpCoreBaltop.get().getConfig().getStringList("sign-gui");
         List<String> lines = configLines != null && !configLines.isEmpty() ? List.copyOf(configLines) : List.of("", "^^^^^^^^^^^^^^^", "   Player    ", "");
         SignSide side = sign.getSide(Side.FRONT);

         for(int i = 0; i < 4; ++i) {
            String raw = i < lines.size() && lines.get(i) != null ? (String)lines.get(i) : "";

            try {
               side.line(i, ColorUtil.parse(raw));
            } catch (Throwable t) {
               side.setLine(i, raw);
            }
         }

         sign.update(true, false);
         PROTECTED.add(loc.clone());
         Bukkit.getScheduler().runTaskLater(SmpCoreBaltop.get().getCore(), () -> {
            if (!player.isOnline()) {
               cleanup(player);
            } else {
               Block b = loc.getBlock();
               BlockState patt0$temp = b.getState();
               if (!(patt0$temp instanceof Sign)) {
                  fallbackChat(player);
               } else {
                  Sign opened = (Sign)patt0$temp;
                  SignSide openSide = opened.getSide(Side.FRONT);

                  for(int i = 0; i < 4; ++i) {
                     String raw = i < lines.size() && lines.get(i) != null ? (String)lines.get(i) : "";

                     try {
                        openSide.line(i, ColorUtil.parse(raw));
                     } catch (Throwable t) {
                        openSide.setLine(i, raw);
                     }
                  }

                  opened.update(true, false);

                  try {
                     player.openSign(opened, Side.FRONT);
                  } catch (Throwable t) {
                     fallbackChat(player);
                  }

               }
            }
         }, 2L);
      }
   }

   private static void fallbackChat(Player player) {
      cleanup(player);
      MenuSession.CHAT_SEARCH.put(player.getUniqueId(), true);
      SmpCoreBaltop.get().getMessages().send(player, "chat-input");
   }

   public static void cleanup(Player player) {
      UUID id = player.getUniqueId();
      MenuSession.SIGN_SEARCH.remove(id);
      Location loc = (Location)SIGN_LOC.remove(id);
      BlockData old = (BlockData)OLD_DATA.remove(id);
      if (loc != null) {
         PROTECTED.remove(loc);
         if (old != null) {
            loc.getBlock().setBlockData(old, false);
         }
      }

   }

   public static boolean isSignInput(UUID id) {
      return Boolean.TRUE.equals(MenuSession.SIGN_SEARCH.get(id));
   }

   public static boolean isProtectedSign(Location location) {
      if (location == null) {
         return false;
      } else {
         for(Location loc : PROTECTED) {
            if (loc.getWorld() != null && loc.getWorld().equals(location.getWorld()) && loc.getBlockX() == location.getBlockX() && loc.getBlockY() == location.getBlockY() && loc.getBlockZ() == location.getBlockZ()) {
               return true;
            }
         }

         return false;
      }
   }
}
