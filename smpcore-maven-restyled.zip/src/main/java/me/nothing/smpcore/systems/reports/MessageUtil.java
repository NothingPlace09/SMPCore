package me.nothing.smpcore.systems.reports;

import org.bukkit.entity.Player;

public class MessageUtil {
   public static void send(Player player, String message) {
      player.sendMessage(ColorUtil.color(message));
   }
}
