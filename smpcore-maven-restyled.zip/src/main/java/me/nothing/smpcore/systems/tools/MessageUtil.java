package me.nothing.smpcore.systems.tools;

import me.nothing.smpcore.utils.HotbarUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MessageUtil {
   private MessageUtil() {
   }

   public static void send(CommandSender sender, String path) {
      send(sender, path, (String[])null);
   }

   public static void send(CommandSender sender, String path, String... replacements) {
      String raw = SmpCoreTools.get().getMessages().getString(path, path);
      String prefix = SmpCoreTools.get().getMessages().getString("prefix", SmpCoreTools.get().getConfig().getString("prefix", ""));
      if (replacements != null) {
         for(int i = 0; i + 1 < replacements.length; i += 2) {
            if (replacements[i] != null && replacements[i + 1] != null) {
               raw = raw.replace(replacements[i], replacements[i + 1]);
            }
         }
      }

      Component msg = ColorUtil.parse(prefix + raw);
      sender.sendMessage(msg);
      if (sender instanceof Player player) {
         HotbarUtil.send(player, ColorUtil.parse(raw));
      }

   }
}
