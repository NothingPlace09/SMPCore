package me.nothing.smpcore.systems.billford;

import me.nothing.smpcore.systems.SystemHost;

public final class SmpCoreBillford extends SystemHost {
   private static SmpCoreBillford instance;
   private MessageManager messages;
   private BillfordManager billford;

   public SmpCoreBillford() {
      super("billford");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.messages = new MessageManager(this);
      this.billford = new BillfordManager(this);
      this.billford.startRotationTask();
      new BillfordCommand(this);
      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         (new BillfordPlaceholders(this)).register();
         this.getLogger().info("PlaceholderAPI hooked.");
      }

      this.getLogger().info("SmpCoreBillford enabled.");
   }

   public void stop() {
      if (this.billford != null) {
         this.billford.save();
         this.billford.stopRotationTask();
      }

      instance = null;
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.billford.reload();
   }

   public static SmpCoreBillford get() {
      return instance;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public BillfordManager getBillford() {
      return this.billford;
   }
}
