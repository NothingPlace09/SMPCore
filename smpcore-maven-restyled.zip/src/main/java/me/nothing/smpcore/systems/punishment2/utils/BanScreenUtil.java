package me.nothing.smpcore.systems.punishment2.utils;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;

public class BanScreenUtil {
   public static String create(SmpCorePunishment plugin, Punishment punishment) {
      StringBuilder screen = new StringBuilder();
      screen.append(ColorUtil.color(plugin.getMessages().getString("ban.screen.title", "&7Connection Lost")));

      for(String line : plugin.getMessages().getStringList("ban.screen.lines")) {
         screen.append("\n").append(ColorUtil.color(line.replace("{reason}", punishment.getReason()).replace("{time}", punishment.getDuration()).replace("{banid}", punishment.getBanId()).replace("{discord}", plugin.getConfig().getString("discord", "discord.gg/yourserver"))));
      }

      return screen.toString();
   }
}
