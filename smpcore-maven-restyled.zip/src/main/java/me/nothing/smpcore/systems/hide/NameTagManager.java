package me.nothing.smpcore.systems.hide;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;
import org.bukkit.scoreboard.Team.Option;
import org.bukkit.scoreboard.Team.OptionStatus;

public class NameTagManager {
   private final SmpCoreHide plugin;
   private final String TEAM_NAME = "SmpCoreHide";

   public NameTagManager(SmpCoreHide plugin) {
      this.plugin = plugin;
   }

   public void hideTag(Player player) {
      Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
      Team team = scoreboard.getTeam("SmpCoreHide");
      if (team == null) {
         team = scoreboard.registerNewTeam("SmpCoreHide");
      }

      team.setOption(Option.NAME_TAG_VISIBILITY, OptionStatus.NEVER);
      if (!team.hasEntry(player.getName())) {
         team.addEntry(player.getName());
      }

   }

   public void showTag(Player player) {
      Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
      Team team = scoreboard.getTeam("SmpCoreHide");
      if (team != null) {
         team.removeEntry(player.getName());
      }

   }
}
