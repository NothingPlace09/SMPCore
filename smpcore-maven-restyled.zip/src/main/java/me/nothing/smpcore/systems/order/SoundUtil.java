package me.nothing.smpcore.systems.order;

import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private SoundUtil() {
   }

   public static void play(Player player, String key) {
      if (player != null) {
         try {
            ConfigurationSection cfg = SmpCoreOrder.get().getConfig().getConfigurationSection("sounds." + key);
            if (cfg == null || !cfg.getBoolean("enabled", true)) {
               return;
            }

            String name = cfg.getString("sound", "UI_BUTTON_CLICK");
            float vol = (float)cfg.getDouble("volume", (double)1.0F);
            float pitch = (float)cfg.getDouble("pitch", (double)1.0F);

            Sound sound;
            try {
               sound = Sound.valueOf(name.toUpperCase().replace(".", "_").replace(" ", "_"));
            } catch (Exception e) {
               sound = Sound.UI_BUTTON_CLICK;
            }

            me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), sound, vol, pitch);
         } catch (Throwable t) {
         }

      }
   }

   public static void open(Player player) {
      play(player, "gui-open");

      try {
         me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), Sound.BLOCK_CHEST_OPEN, 0.7F, 1.0F);
      } catch (Throwable t) {
      }

   }

   public static void click(Player player) {
      play(player, "gui-click");
   }

   public static void error(Player player) {
      play(player, "error");
   }
}
