package me.nothing.smpcore.systems.bounties;

import me.nothing.smpcore.systems.SystemHost;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class SmpCoreBounties extends SystemHost {
   private static SmpCoreBounties instance;
   private MessageManager messages;
   private BountyManager bounties;
   private Economy economy;

   public SmpCoreBounties() {
      super("bounties");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      if (!this.setupEconomy()) {
         this.getLogger().warning("Vault economy missing — using CoreEconomy fallback.");
         this.getLogger().warning("[system] init warning (continuing)");
      }

      this.messages = new MessageManager(this);
      this.bounties = new BountyManager(this);
      BountyMenus.load(this);
      new BountyCommand(this);
      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new SignProtectListener(), this.getCore());
      this.getServer().getPluginManager().registerEvents(new KillListener(this), this.getCore());
      this.getLogger().info("SmpCoreBounties enabled.");
   }

   public void stop() {
      if (this.bounties != null) {
         this.bounties.save();
      }

      instance = null;
   }

   private boolean setupEconomy() {
      if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
         return false;
      } else {
         RegisteredServiceProvider<Economy> rsp = this.getServer().getServicesManager().getRegistration(Economy.class);
         if (rsp == null) {
            return false;
         } else {
            this.economy = (Economy)rsp.getProvider();
            return this.economy != null;
         }
      }
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.bounties.reload();
      BountyMenus.load(this);
   }

   public static SmpCoreBounties get() {
      return instance;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public BountyManager getBounties() {
      return this.bounties;
   }

   public Economy getEconomy() {
      return this.economy;
   }
}
