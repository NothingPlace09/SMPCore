package me.nothing.smpcore.systems.sell;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.sign.Side;
import org.bukkit.block.sign.SignSide;
import org.bukkit.entity.Player;

public final class InputUtil {
   private static final Map<UUID, Location> SIGN_LOC = new HashMap();
   private static final Map<UUID, BlockData> OLD_DATA = new HashMap();

   private InputUtil() {
   }

   public static boolean useSign() {
      return SmpCoreSell.get().getConfig().getBoolean("chat-input.SignAPI", true);
   }

   public static void requestSearch(Player player) {
      if (useSign()) {
         openSign(player, "search");
      } else {
         MenuSession.CHAT_SEARCH.put(player.getUniqueId(), true);
         player.closeInventory();
         SmpCoreSell.get().getMessages().send(player, "worth-search");
      }
   }

   public static void openSign(Player player, String type) {
      UUID id = player.getUniqueId();
      cleanup(player);
      Location base = player.getLocation().clone();
      Location loc = base.clone();
      loc.setY((double)Math.max(player.getWorld().getMinHeight() + 1, base.getBlockY() - 2));
      Block block = loc.getBlock();
      SIGN_LOC.put(id, loc.clone());
      OLD_DATA.put(id, block.getBlockData().clone());
      MenuSession.SIGN_SEARCH.put(id, true);
      player.closeInventory();
      block.setType(Material.OAK_SIGN, false);
      BlockState blockState = block.getState();
      if (!(blockState instanceof Sign sign)) {
         fallbackChat(player);
      } else {
         List<String> lines = SmpCoreSell.get().getConfig().getStringList("sign-gui." + type);
         if (lines == null || lines.isEmpty()) {
            lines = List.of("", "^^^^^^^^^^^^^^^", "   Search   ", "");
         }

         SignSide side = sign.getSide(Side.FRONT);

         for(int i = 0; i < Math.min(4, lines.size()); ++i) {
            side.setLine(i, lines.get(i) == null ? "" : (String)lines.get(i));
         }

         sign.update(true, false);
         Bukkit.getScheduler().runTask(SmpCoreSell.get().getCore(), () -> {
            if (!player.isOnline()) {
               cleanup(player);
            } else {
               Block b = loc.getBlock();
               BlockState patt0$temp = b.getState();
               if (patt0$temp instanceof Sign) {
                  Sign opened = (Sign)patt0$temp;

                  try {
                     player.openSign(opened, Side.FRONT);
                  } catch (Throwable t) {
                     fallbackChat(player);
                  }

               } else {
                  fallbackChat(player);
               }
            }
         });
      }
   }

   private static void fallbackChat(Player player) {
      cleanup(player);
      MenuSession.CHAT_SEARCH.put(player.getUniqueId(), true);
      SmpCoreSell.get().getMessages().send(player, "worth-search");
   }

   public static void cleanup(Player player) {
      UUID id = player.getUniqueId();
      MenuSession.SIGN_SEARCH.remove(id);
      Location loc = (Location)SIGN_LOC.remove(id);
      BlockData old = (BlockData)OLD_DATA.remove(id);
      if (loc != null && old != null) {
         loc.getBlock().setBlockData(old, false);
      }

   }

   public static boolean isSignInput(UUID id) {
      return Boolean.TRUE.equals(MenuSession.SIGN_SEARCH.get(id));
   }
}
