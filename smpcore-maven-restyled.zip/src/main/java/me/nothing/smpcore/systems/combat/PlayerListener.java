package me.nothing.smpcore.systems.combat;

import me.nothing.smpcore.systems.duels.DuelsModule;
import me.nothing.smpcore.SmpCore;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerListener implements Listener {
   private final SmpCoreCombat plugin;
   private final CombatManager manager;
   private final Set<UUID> quitKills = ConcurrentHashMap.newKeySet();

   public PlayerListener(SmpCoreCombat plugin) {
      this.plugin = plugin;
      this.manager = plugin.getCombatManager();
   }

   private boolean consumeDuelDeath(UUID id) {
      try {
         SmpCore core = SmpCore.get();
         if (core != null && core.modules() != null && core.modules().get("duels") instanceof DuelsModule duels) {
            return duels.consumeDuelDeath(id);
         }
      } catch (Throwable t) {
      }

      return false;
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      if (this.manager.isInCombat(player)) {
         if (this.plugin.getConfig().getBoolean("settings.kill-on-quit", true)) {
            this.quitKills.add(player.getUniqueId());

            try {
               player.setHealth((double)0.0F);
            } finally {
               this.quitKills.remove(player.getUniqueId());
            }

            String msg = this.plugin.getConfig().getString("messages.quit-punish", "&c%player% logged out during combat and was punished.");
            msg = msg.replace("%player%", player.getName());
            Bukkit.broadcastMessage(MessageUtil.color(msg));
         }

         this.manager.leaveCombat(player, false);
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onDeath(PlayerDeathEvent event) {
      Player victim = event.getEntity();
      Player killer = victim.getKiller();
      boolean duelDeath = this.consumeDuelDeath(victim.getUniqueId());
      boolean quitKill = this.quitKills.contains(victim.getUniqueId());
      this.manager.leaveCombat(victim, false);
      if (this.plugin.getConfig().getBoolean("kill-message.enabled", true)) {
         if (killer != null) {
            String weapon = "unknown";
            ItemStack hand = killer.getInventory().getItemInMainHand();
            if (hand != null && hand.getType() != Material.AIR) {
               weapon = hand.getType().name().toLowerCase().replace("_", " ");
            }

            String format = this.plugin.getConfig().getString("kill-message.format", "&c%killer% &7eliminated &c%victim% &7with &f%weapon%");
            if (hand == null || hand.getType() == Material.AIR) {
               format = this.plugin.getConfig().getString("kill-message.no-weapon", "&c%killer% &7eliminated &c%victim%");
            }

            String msg = format.replace("%killer%", killer.getName()).replace("%victim%", victim.getName()).replace("%weapon%", weapon);
            event.setDeathMessage(MessageUtil.color(msg));
         } else {
            String format = this.plugin.getConfig().getString("kill-message.natural-death", "&7%victim% &7died");
            event.setDeathMessage(MessageUtil.color(format.replace("%victim%", victim.getName())));
         }
      }

      // FIX farming: nessun premio per morti nei duelli o per logout in combat (configurabile)
      boolean skipReward = duelDeath && this.plugin.getConfig().getBoolean("kill-reward.exclude-duels", true) || quitKill && this.plugin.getConfig().getBoolean("kill-reward.exclude-combat-log", true);
      if (killer != null && !skipReward && this.plugin.getConfig().getBoolean("kill-reward.enabled", true)) {
         this.manager.applyReward(killer, victim);
      }

      if (killer != null) {
         this.manager.leaveCombat(killer, false);
      }

   }
}
