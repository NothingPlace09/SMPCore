package me.nothing.smpcore.systems.sell;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.systems.settings.SettingsModule;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class WorthDisplayListener implements Listener {
   private final SmpCoreSell plugin;
   private final NamespacedKey markerKey;
   private final NamespacedKey loreCountKey;
   private final Map<UUID, Integer> pendingApply = new HashMap();
   private final Set<UUID> disabledWorth = ConcurrentHashMap.newKeySet();

   public WorthDisplayListener(SmpCoreSell plugin) {
      this.plugin = plugin;
      this.markerKey = new NamespacedKey(plugin, "worth_lore");
      this.loreCountKey = new NamespacedKey(plugin, "worth_lore_lines");
   }

   private boolean enabled() {
      return this.plugin.getConfig().getBoolean("worth-lore.enabled", true);
   }

   private boolean playerInvEnabled() {
      return this.plugin.getConfig().getBoolean("worth-lore.player-inventory", true);
   }

   private boolean isPurePlayerInv(Player player) {
      try {
         InventoryType type = player.getOpenInventory().getType();
         return type == InventoryType.CRAFTING || type == InventoryType.PLAYER;
      } catch (Exception e) {
         return false;
      }
   }

   private boolean canShow(Player player) {
      if (SettingsModule.isWorthDisabled(player.getUniqueId())) {
         return false;
      } else if (this.disabledWorth.contains(player.getUniqueId())) {
         return false;
      } else {
         return this.enabled() && this.playerInvEnabled() && this.isPurePlayerInv(player);
      }
   }

   public boolean isWorthEnabled(Player player) {
      return player != null && !this.disabledWorth.contains(player.getUniqueId());
   }

   public boolean toggleWorth(Player player) {
      UUID id = player.getUniqueId();
      if (this.disabledWorth.contains(id)) {
         this.disabledWorth.remove(id);
         if (this.isPurePlayerInv(player)) {
            this.scheduleApply(player, 2L);
         }

         return true;
      } else {
         this.disabledWorth.add(id);
         this.forceStrip(player);
         player.updateInventory();
         return false;
      }
   }

   private void cancelPending(UUID id) {
      Integer task = (Integer)this.pendingApply.remove(id);
      if (task != null) {
         Bukkit.getScheduler().cancelTask(task);
      }

   }

   private void scheduleApply(final Player player, long delay) {
      if (this.enabled() && this.playerInvEnabled()) {
         final UUID id = player.getUniqueId();
         this.cancelPending(id);
         int taskId = Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            public void run() {
               WorthDisplayListener.this.pendingApply.remove(id);
               if (player.isOnline()) {
                  if (!WorthDisplayListener.this.canShow(player)) {
                     WorthDisplayListener.this.stripInventory(player.getInventory());
                     player.updateInventory();
                  } else {
                     WorthDisplayListener.this.applyInventory(player, player.getInventory());
                     player.updateInventory();
                  }
               }
            }
         }, delay).getTaskId();
         this.pendingApply.put(id, taskId);
      }
   }

   private void forceStrip(Player player) {
      this.cancelPending(player.getUniqueId());
      this.stripInventory(player.getInventory());
      player.updateInventory();
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onOpen(InventoryOpenEvent event) {
      if (event.getPlayer() instanceof Player) {
         Player player = (Player)event.getPlayer();
         if (this.enabled()) {
            InventoryType type = event.getView().getType();
            if (type != InventoryType.CRAFTING && type != InventoryType.PLAYER) {
               this.forceStrip(player);
               this.stripInventory(event.getInventory());
            } else {
               this.scheduleApply(player, 3L);
            }

         }
      }
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
      if (event.getPlayer() instanceof Player) {
         final Player player = (Player)event.getPlayer();
         this.cancelPending(player.getUniqueId());
         this.stripInventory(event.getInventory());
         Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
            public void run() {
               if (player.isOnline()) {
                  WorthDisplayListener.this.stripInventory(player.getInventory());
                  player.updateInventory();
               }
            }
         }, 1L);
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onClickLow(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (this.enabled()) {
            this.cancelPending(player.getUniqueId());
            this.stripInventory(player.getInventory());
            ItemStack current = event.getCurrentItem();
            if (current != null) {
               this.stripLore(current);
            }

            ItemStack cursor = event.getCursor();
            if (cursor != null && !cursor.getType().isAir()) {
               this.stripLore(cursor);
            }

            if (event.getClickedInventory() != null && !(event.getClickedInventory() instanceof PlayerInventory)) {
               this.stripInventory(event.getClickedInventory());
            }

            if (event.getHotbarButton() >= 0) {
               ItemStack hot = player.getInventory().getItem(event.getHotbarButton());
               if (hot != null) {
                  this.stripLore(hot);
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onClickHigh(InventoryClickEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (this.enabled()) {
            if (this.canShow(player)) {
               this.scheduleApply(player, 8L);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onDragLow(InventoryDragEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (this.enabled()) {
            this.cancelPending(player.getUniqueId());
            this.stripInventory(player.getInventory());
            ItemStack cursor = event.getOldCursor();
            if (cursor != null) {
               this.stripLore(cursor);
            }

            for(ItemStack stack : event.getNewItems().values()) {
               if (stack != null) {
                  this.stripLore(stack);
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onDragHigh(InventoryDragEvent event) {
      if (event.getWhoClicked() instanceof Player) {
         Player player = (Player)event.getWhoClicked();
         if (this.enabled()) {
            if (this.canShow(player)) {
               this.scheduleApply(player, 8L);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onPickup(EntityPickupItemEvent event) {
      if (event.getEntity() instanceof Player) {
         ItemStack ground = event.getItem().getItemStack();
         if (ground != null) {
            this.stripLore(ground);
            event.getItem().setItemStack(ground);
         }

      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      final Player player = event.getPlayer();
      Bukkit.getScheduler().runTaskLater(this.plugin, new Runnable() {
         public void run() {
            if (player.isOnline()) {
               WorthDisplayListener.this.stripInventory(player.getInventory());
               player.updateInventory();
            }

         }
      }, 15L);
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.cancelPending(event.getPlayer().getUniqueId());
      this.stripInventory(event.getPlayer().getInventory());
   }

   public void refresh(Player player) {
      if (player != null && player.isOnline()) {
         this.forceStrip(player);
         if (this.canShow(player)) {
            this.scheduleApply(player, 2L);
         }

      }
   }

   private void applyInventory(Player player, Inventory inv) {
      if (inv != null) {
         int size = inv.getSize();

         for(int i = 0; i < size; ++i) {
            ItemStack stack = inv.getItem(i);
            if (stack != null && !stack.getType().isAir() && !stack.getType().name().contains("STAINED_GLASS_PANE")) {
               ItemStack copy = stack.clone();
               if (this.applyLore(player, copy)) {
                  inv.setItem(i, copy);
               }
            }
         }

      }
   }

   private boolean applyLore(Player player, ItemStack stack) {
      if (this.plugin.getBlacklist().isBlocked(stack)) {
         this.stripLore(stack);
         return true;
      } else {
         ItemMeta meta = stack.getItemMeta();
         if (meta == null) {
            return false;
         } else {
            if (meta.getPersistentDataContainer().has(this.markerKey, PersistentDataType.BYTE)) {
               this.stripLore(stack);
               meta = stack.getItemMeta();
               if (meta == null) {
                  return false;
               }
            }

            double total = this.plugin.getPrices().getSellPrice(player, stack);
            if (total <= (double)0.0F) {
               return false;
            } else {
               double unit = stack.getAmount() > 0 ? total / (double)stack.getAmount() : total;
               List<String> template = this.plugin.getConfig().getStringList("worth-lore.lines");
               if (template == null || template.isEmpty()) {
                  template = new ArrayList();
                  template.add("&7Worth: &#00fc88%price%");
               }

               List<Component> lore;
               if (meta.hasLore() && meta.lore() != null) {
                  lore = new ArrayList(meta.lore());
               } else {
                  lore = new ArrayList();
               }

               int added = 0;

               for(int t = 0; t < template.size(); ++t) {
                  String line = (String)template.get(t);
                  String out = line.replace("%price%", MoneyUtil.format(total)).replace("%stack_price%", MoneyUtil.format(total)).replace("%unit%", MoneyUtil.format(unit)).replace("%amount%", String.valueOf(stack.getAmount()));
                  lore.add(ColorUtil.parse(out));
                  ++added;
               }

               meta.lore(lore);
               meta.getPersistentDataContainer().set(this.markerKey, PersistentDataType.BYTE, (byte)1);
               meta.getPersistentDataContainer().set(this.loreCountKey, PersistentDataType.INTEGER, added);
               stack.setItemMeta(meta);
               return true;
            }
         }
      }
   }

   private void stripInventory(Inventory inv) {
      if (inv != null) {
         int size = inv.getSize();

         for(int i = 0; i < size; ++i) {
            ItemStack stack = inv.getItem(i);
            if (stack != null && !stack.getType().isAir()) {
               ItemStack copy = stack.clone();
               if (this.stripLore(copy)) {
                  inv.setItem(i, copy);
               }
            }
         }

      }
   }

   private boolean stripLore(ItemStack stack) {
      if (stack == null) {
         return false;
      } else {
         ItemMeta meta = stack.getItemMeta();
         if (meta == null) {
            return false;
         } else if (!meta.getPersistentDataContainer().has(this.markerKey, PersistentDataType.BYTE)) {
            return false;
         } else {
            Integer count = (Integer)meta.getPersistentDataContainer().get(this.loreCountKey, PersistentDataType.INTEGER);
            List<Component> lore;
            if (meta.hasLore() && meta.lore() != null) {
               lore = new ArrayList(meta.lore());
            } else {
               lore = new ArrayList();
            }

            if (count != null && count > 0 && lore.size() >= count) {
               for(int i = 0; i < count; ++i) {
                  lore.remove(lore.size() - 1);
               }
            }

            if (lore.isEmpty()) {
               meta.lore((List)null);
            } else {
               meta.lore(lore);
            }

            meta.getPersistentDataContainer().remove(this.markerKey);
            meta.getPersistentDataContainer().remove(this.loreCountKey);
            stack.setItemMeta(meta);
            return true;
         }
      }
   }
}
