package me.nothing.smpcore.systems.order;

import java.util.Locale;

public final class MoneyUtil {
   private MoneyUtil() {
   }

   public static double parse(String input) {
      if (input == null) {
         throw new NumberFormatException("empty");
      } else {
         String raw = input.trim().replace(",", "").replace("$", "").replace(" ", "");
         if (raw.isEmpty()) {
            throw new NumberFormatException("empty");
         } else {
            char last = Character.toUpperCase(raw.charAt(raw.length() - 1));
            double mult = (double)1.0F;
            String num = raw;
            if (last == 'K' || last == 'M' || last == 'B' || last == 'T') {
               num = raw.substring(0, raw.length() - 1);
               double d;
               switch (last) {
                  case 'B' -> d = (double)1.0E9F;
                  case 'K' -> d = (double)1000.0F;
                  case 'M' -> d = (double)1000000.0F;
                  case 'T' -> d = 1.0E12;
                  default -> d = (double)1.0F;
               }

               mult = d;
            }

            return Double.parseDouble(num) * mult;
         }
      }
   }

   public static String format(double amount) {
      String symbol = SmpCoreOrder.get().getConfig().getString("currency-symbol", "$");
      boolean abbr = SmpCoreOrder.get().getConfig().getBoolean("economy.abbreviations.enabled", true);
      if (!abbr) {
         return symbol + String.format(Locale.US, "%.2f", amount);
      } else {
         double abs = Math.abs(amount);
         String suffix = "";
         double value;
         if (abs >= 1.0E12) {
            value = amount / 1.0E12;
            suffix = "T";
         } else if (abs >= (double)1.0E9F) {
            value = amount / (double)1.0E9F;
            suffix = "B";
         } else if (abs >= (double)1000000.0F) {
            value = amount / (double)1000000.0F;
            suffix = "M";
         } else {
            if (!(abs >= (double)1000.0F)) {
               return symbol + String.format(Locale.US, "%.2f", amount);
            }

            value = amount / (double)1000.0F;
            suffix = "K";
         }

         return Math.abs(value - Math.rint(value)) < 0.001 ? symbol + String.format(Locale.US, "%.0f%s", value, suffix) : symbol + String.format(Locale.US, "%.2f%s", value, suffix);
      }
   }
}
