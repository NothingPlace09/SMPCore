package me.nothing.smpcore.systems.help;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ItemBuilder {
   private final ItemStack item;
   private final ItemMeta meta;

   public ItemBuilder(Material material) {
      this.item = new ItemStack(material);
      this.meta = this.item.getItemMeta();
   }

   public ItemBuilder name(String name) {
      if (name != null) {
         this.meta.setDisplayName(ColorUtil.color(name));
      }

      return this;
   }

   public ItemBuilder lore(List<String> lore) {
      if (lore != null) {
         List<String> colored = lore.stream().map(ColorUtil::color).toList();
         this.meta.setLore(colored);
      }

      return this;
   }

   public ItemBuilder glow(boolean glow) {
      if (glow) {
         this.meta.setEnchantmentGlintOverride(true);
      }

      return this;
   }

   public ItemStack build() {
      this.item.setItemMeta(this.meta);
      return this.item;
   }
}
