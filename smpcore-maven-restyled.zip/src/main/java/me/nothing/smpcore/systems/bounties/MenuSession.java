package me.nothing.smpcore.systems.bounties;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, View> VIEW = new ConcurrentHashMap();
   public static final Map<UUID, Integer> PAGE = new ConcurrentHashMap();
   public static final Map<UUID, BountyManager.Sort> SORT = new ConcurrentHashMap();
   public static final Map<UUID, UUID> TARGET = new ConcurrentHashMap();
   public static final Map<UUID, Double> AMOUNT = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      VIEW.remove(id);
      PAGE.remove(id);
      SORT.remove(id);
      TARGET.remove(id);
      AMOUNT.remove(id);
   }

   public static enum View {
      MAIN,
      CONFIRM,
      ADMIN,
      SEARCH;

      private static View[] $values() {
         return new View[]{MAIN, CONFIRM, ADMIN, SEARCH};
      }
   }
}
