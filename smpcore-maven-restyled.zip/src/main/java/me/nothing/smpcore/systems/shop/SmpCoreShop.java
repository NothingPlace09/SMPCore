package me.nothing.smpcore.systems.shop;

import me.nothing.smpcore.systems.SystemHost;

public final class SmpCoreShop extends SystemHost {
   private static SmpCoreShop instance;
   private EconomyService economy;
   private SpendManager spend;
   private MessageManager messages;
   private ShopRegistry shops;

   public SmpCoreShop() {
      super("shop");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.economy = new EconomyService(this);
      if (!this.economy.setupVault()) {
         this.getLogger().warning("Vault economy not found. Vault shops will not work. Command economy still works.");
      }

      this.messages = new MessageManager(this);
      this.shops = new ShopRegistry(this);
      this.spend = new SpendManager(this);
      new ShopCommand(this);
      new AdminShopCommand(this);
      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      if (this.getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
         (new ShopPlaceholders(this)).register();
         this.getLogger().info("PlaceholderAPI hooked.");
      }

      this.getLogger().info("SmpCoreShop enabled.");
   }

   public void stop() {
      if (this.spend != null) {
         this.spend.save();
      }

      instance = null;
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.shops.reload();
   }

   public static SmpCoreShop get() {
      return instance;
   }

   public EconomyService getEconomy() {
      return this.economy;
   }

   public SpendManager getSpend() {
      return this.spend;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public ShopRegistry getShops() {
      return this.shops;
   }
}
