package me.nothing.smpcore.systems.hide;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HideCommand implements CommandExecutor {
   private final SmpCoreHide plugin;

   public HideCommand(SmpCoreHide plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.hasPermission("smpcore.system.hide.use")) {
            player.sendMessage(MessageUtil.color("&cYou don't have permission."));
            return true;
         } else {
            if (this.plugin.getHideManager().isHidden(player)) {
               this.plugin.getHideManager().unhide(player);
               player.sendMessage(MessageUtil.color(this.plugin.getConfig().getString("messages.unhide.chat")));
               MessageUtil.actionBar(player, this.plugin.getConfig().getString("messages.unhide.actionbar"));
            } else {
               this.plugin.getHideManager().hide(player);
               player.sendMessage(MessageUtil.color(this.plugin.getConfig().getString("messages.hide.chat")));
               MessageUtil.actionBar(player, this.plugin.getConfig().getString("messages.hide.actionbar"));
            }

            return true;
         }
      } else {
         sender.sendMessage("Only players can use this command.");
         return true;
      }
   }
}
