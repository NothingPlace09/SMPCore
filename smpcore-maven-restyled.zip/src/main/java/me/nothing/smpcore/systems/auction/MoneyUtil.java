package me.nothing.smpcore.systems.auction;

import java.util.Locale;

public final class MoneyUtil {
   private MoneyUtil() {
   }

   public static double parse(String input) {
      String raw = input.trim().replace(",", "").replace("$", "").replace(" ", "");
      if (raw.isEmpty()) {
         throw new NumberFormatException("empty");
      } else {
         char last = Character.toUpperCase(raw.charAt(raw.length() - 1));
         double mult = (double)1.0F;
         String num = raw;
         if (last == 'K' || last == 'M' || last == 'B' || last == 'T') {
            num = raw.substring(0, raw.length() - 1);
            double d;
            switch (last) {
               case 'B' -> d = (double)1.0E9F;
               case 'K' -> d = (double)1000.0F;
               case 'M' -> d = (double)1000000.0F;
               case 'T' -> d = 1.0E12;
               default -> d = (double)1.0F;
            }

            mult = d;
         }

         return Double.parseDouble(num) * mult;
      }
   }

   public static String format(double amount) {
      String symbol = SmpCoreAuction.get().getConfig().getString("currency-symbol", SmpCoreAuction.get().getConfig().getString("economy.currency-symbol", "$"));
      boolean abbr = SmpCoreAuction.get().getConfig().getBoolean("economy.abbreviations.enabled", true);
      if (!abbr) {
         return symbol + String.format(Locale.US, "%.2f", amount);
      } else {
         double abs = Math.abs(amount);
         if (abs >= 1.0E12) {
            return symbol + trim(amount / 1.0E12) + "T";
         } else if (abs >= (double)1.0E9F) {
            return symbol + trim(amount / (double)1.0E9F) + "B";
         } else if (abs >= (double)1000000.0F) {
            return symbol + trim(amount / (double)1000000.0F) + "M";
         } else {
            return abs >= (double)1000.0F ? symbol + trim(amount / (double)1000.0F) + "K" : symbol + String.format(Locale.US, "%.2f", amount);
         }
      }
   }

   private static String trim(double value) {
      return Math.abs(value - Math.rint(value)) < 0.001 ? String.format(Locale.US, "%.0f", value) : String.format(Locale.US, "%.2f", value);
   }
}
