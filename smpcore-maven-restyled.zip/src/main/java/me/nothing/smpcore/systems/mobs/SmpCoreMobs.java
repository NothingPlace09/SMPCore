package me.nothing.smpcore.systems.mobs;

import me.nothing.smpcore.systems.SystemHost;

public class SmpCoreMobs extends SystemHost {
   private static SmpCoreMobs instance;
   private PlayerDataManager playerDataManager;
   private double radiusSq;

   public SmpCoreMobs() {
      super("mobs");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.playerDataManager = new PlayerDataManager(this);
      this.refreshRadius();
      this.getServer().getPluginManager().registerEvents(new MobSpawnListener(this), this.getCore());
      this.getLogger().info("SmpCoreMobs enabled.");
   }

   public void stop() {
      if (this.playerDataManager != null) {
         this.playerDataManager.saveSync();
      }

      this.getLogger().info("SmpCoreMobs disabled.");
   }

   public void reloadPlugin() {
      this.reloadConfig();
      this.refreshRadius();
      if (this.playerDataManager != null) {
         this.playerDataManager.reload();
      }

   }

   public void refreshRadius() {
      double r = this.getConfig().getDouble("settings.radius", (double)64.0F);
      if (r < (double)1.0F) {
         r = (double)1.0F;
      }

      this.radiusSq = r * r;
   }

   public double getRadius() {
      return Math.sqrt(this.radiusSq);
   }

   public double getRadiusSq() {
      return this.radiusSq;
   }

   public PlayerDataManager getPlayerDataManager() {
      return this.playerDataManager;
   }

   public static SmpCoreMobs getInstance() {
      return instance;
   }
}
