package me.nothing.smpcore.systems.baltop;

import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {
   private SoundUtil() {
   }

   public static void play(Player player, String path) {
      if (player != null) {
         String name = SmpCoreBaltop.get().getConfig().getString(path, "UI_BUTTON_CLICK");

         try {
            me.nothing.smpcore.utils.SoundUtil.play(player, player.getLocation(), Sound.valueOf(name), 1.0F, 1.0F);
         } catch (Exception e) {
         }

      }
   }

   public static void click(Player player) {
      play(player, "sounds.click");
   }

   public static void open(Player player) {
      play(player, "sounds.open");
   }
}
