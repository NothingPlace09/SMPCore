package me.nothing.smpcore.systems.homes;

import me.nothing.smpcore.utils.MoveCheck;
import me.nothing.smpcore.systems.combat.CombatGuard;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import me.nothing.smpcore.utils.HotbarUtil;
import me.nothing.smpcore.utils.TextUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class TeleportManager {
   private final SmpCoreHomes plugin;
   private final Map<UUID, Session> active = new ConcurrentHashMap();

   public TeleportManager(SmpCoreHomes plugin) {
      this.plugin = plugin;
   }

   public boolean start(Player player, String homeId, Location dest) {
      UUID uuid = player.getUniqueId();
      if (CombatGuard.deny(player)) {
         this.plugin.homes().sound(player, "denied");
         return false;
      }

      if (this.active.containsKey(uuid)) {
         player.sendMessage(ColorUtil.color(this.plugin.configs().msg("busy")));
         this.plugin.homes().sound(player, "denied");
         return false;
      } else {
         int delay = this.plugin.configs().teleportDelay();
         if (!player.hasPermission("smpcore.system.homes.bypass") && delay > 0) {
            Location start = player.getLocation().clone();
            Session session = new Session(player, homeId, dest, start, delay);
            this.active.put(uuid, session);
            session.task = Bukkit.getScheduler().runTaskTimer(this.plugin.getCore(), () -> {
               if (!player.isOnline()) {
                  this.cancel(uuid);
               } else if (MoveCheck.movedMoreThan(player.getLocation(), session.start, this.plugin.configs().teleportDistance())) {
                  player.sendMessage(ColorUtil.color(this.plugin.configs().msg("moved")));
                  HotbarUtil.send(player, TextUtil.component(this.plugin.configs().actionBar("moved")));
                  this.plugin.homes().sound(player, "abort");
                  this.cancel(uuid);
               } else if (CombatGuard.isBlocked(player)) {
                  CombatGuard.deny(player);
                  this.cancel(uuid);
               } else if (session.left <= 0) {
                  player.teleport(session.dest);
                  HotbarUtil.send(player, TextUtil.component(this.plugin.configs().actionBar("arrived").replace("%home%", homeId)));
                  this.plugin.homes().sound(player, "arrive");
                  this.cancel(uuid);
               } else {
                  String count = String.valueOf(session.left);
                  if (this.plugin.configs().cooldownChat()) {
                     for(String line : this.plugin.configs().cooldownChatMsgs()) {
                        player.sendMessage(TextUtil.component(line.replace("%count%", count).replace("%home%", homeId)));
                     }
                  }

                  if (this.plugin.configs().cooldownActionbar()) {
                     for(String line : this.plugin.configs().cooldownActionbarMsgs()) {
                        HotbarUtil.send(player, TextUtil.component(line.replace("%count%", count).replace("%home%", homeId)));
                     }
                  }

                  this.plugin.homes().sound(player, "countdown");
                  --session.left;
               }
            }, 0L, 20L);
            return true;
         } else {
            player.teleport(dest);
            HotbarUtil.send(player, TextUtil.component(this.plugin.configs().actionBar("arrived").replace("%home%", homeId)));
            this.plugin.homes().sound(player, "arrive");
            return true;
         }
      }
   }

   public void cancel(UUID uuid) {
      Session s = (Session)this.active.remove(uuid);
      if (s != null && s.task != null) {
         s.task.cancel();
      }

   }

   public void cancelAll() {
      for(UUID id : this.active.keySet()) {
         this.cancel(id);
      }

   }

   public boolean isTeleporting(UUID uuid) {
      return this.active.containsKey(uuid);
   }

   private static final class Session {
      final Player player;
      final String homeId;
      final Location dest;
      final Location start;
      int left;
      BukkitTask task;

      Session(Player player, String homeId, Location dest, Location start, int delay) {
         this.player = player;
         this.homeId = homeId;
         this.dest = dest;
         this.start = start;
         this.left = delay;
      }
   }
}
