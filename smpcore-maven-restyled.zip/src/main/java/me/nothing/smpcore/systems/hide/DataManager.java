package me.nothing.smpcore.systems.hide;

import java.io.File;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.data.PlayerDataStore;
import org.bukkit.configuration.file.FileConfiguration;

public class DataManager {
   private final SmpCoreHide plugin;

   public DataManager(SmpCoreHide plugin) {
      this.plugin = plugin;
   }

   public FileConfiguration getConfig() {
      return PlayerDataStore.get().config();
   }

   public void save() {
      PlayerDataStore.get().save();
   }

   public void reload() {
      PlayerDataStore.init((SmpCore)this.plugin.getCore());
   }

   public File getFile() {
      return PlayerDataStore.get().file();
   }
}
