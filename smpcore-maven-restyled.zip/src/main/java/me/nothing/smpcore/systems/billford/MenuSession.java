package me.nothing.smpcore.systems.billford;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, Boolean> OPEN = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      OPEN.remove(id);
   }
}
