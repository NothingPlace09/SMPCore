package me.nothing.smpcore.systems.punishment2.listeners;

import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import me.nothing.smpcore.systems.punishment2.utils.TimeUtil;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerLoginEvent.Result;

public class JoinListener implements Listener {
   private final SmpCorePunishment plugin;

   public JoinListener(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onLogin(PlayerLoginEvent event) {
      if (!event.getPlayer().hasPermission("smpcore.system.punishment.bypass")) {
         Punishment ban = this.plugin.getDatabaseManager().getActivePunishment(event.getPlayer().getUniqueId(), "BAN");
         if (ban != null) {
            if (ban.getExpireTime() <= 0L || !TimeUtil.hasExpired(ban.getExpireTime())) {
               event.disallow(Result.KICK_OTHER, this.plugin.getBanScreenManager().createScreen(ban));
            }
         }
      }
   }
}
