package me.nothing.smpcore.systems.auction;

import java.util.ArrayList;
import java.util.List;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ItemUtil {
   private ItemUtil() {
   }

   public static ItemStack named(Material material, String name, List<String> lore) {
      ItemStack item = new ItemStack(material);
      ItemMeta meta = item.getItemMeta();
      if (meta != null) {
         meta.displayName(ColorUtil.parse(name));
         if (lore != null && !lore.isEmpty()) {
            List<Component> lines = new ArrayList();

            for(String line : lore) {
               lines.add(ColorUtil.parse(line));
            }

            meta.lore(lines);
         }

         item.setItemMeta(meta);
      }

      return item;
   }

   public static String pretty(Material material) {
      String raw = material.name().toLowerCase().replace('_', ' ');
      StringBuilder sb = new StringBuilder();

      for(String part : raw.split(" ")) {
         if (!part.isEmpty()) {
            if (sb.length() > 0) {
               sb.append(' ');
            }

            sb.append(Character.toUpperCase(part.charAt(0))).append(part.substring(1));
         }
      }

      return sb.toString();
   }

   public static String pretty(ItemStack item) {
      if (item == null) {
         return "Air";
      } else {
         return item.hasItemMeta() && item.getItemMeta().hasDisplayName() ? PlainTextComponentSerializer.plainText().serialize(item.getItemMeta().displayName()) : pretty(item.getType());
      }
   }
}
