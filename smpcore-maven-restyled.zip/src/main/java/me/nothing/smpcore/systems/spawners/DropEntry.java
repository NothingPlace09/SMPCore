package me.nothing.smpcore.systems.spawners;

import org.bukkit.Material;

public record DropEntry(Material material, int min, int max, int chance) {
}
