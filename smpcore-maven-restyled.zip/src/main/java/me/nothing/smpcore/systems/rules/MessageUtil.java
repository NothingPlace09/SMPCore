package me.nothing.smpcore.systems.rules;

import me.nothing.smpcore.utils.TextUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;

public class MessageUtil {
   public static Component color(String text) {
      return (Component)(text == null ? Component.empty() : TextUtil.component(text).decoration(TextDecoration.ITALIC, false));
   }
}
