package me.nothing.smpcore.systems.crates;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, Boolean> OPEN = new ConcurrentHashMap();
   public static final Map<UUID, Mode> MODE = new ConcurrentHashMap();
   public static final Map<UUID, String> CRATE = new ConcurrentHashMap();
   public static final Map<UUID, Reward> PENDING = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      OPEN.remove(id);
      MODE.remove(id);
      CRATE.remove(id);
      PENDING.remove(id);
   }

   public static enum Mode {
      PREVIEW,
      VIEW,
      CONFIRM,
      ROLLING;

      private static Mode[] $values() {
         return new Mode[]{PREVIEW, VIEW, CONFIRM, ROLLING};
      }
   }
}
