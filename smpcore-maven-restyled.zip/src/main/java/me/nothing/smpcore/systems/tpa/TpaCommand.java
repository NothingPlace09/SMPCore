package me.nothing.smpcore.systems.tpa;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;
import me.nothing.smpcore.utils.HotbarUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class TpaCommand implements CommandExecutor, TabCompleter {
   private final SmpCoreTPA plugin;

   public TpaCommand(SmpCoreTPA plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      String name = command.getName().toLowerCase(Locale.ROOT);
      if (name.equals("tpareload")) {
         if (!sender.hasPermission("smpcore.system.tpa.admin")) {
            this.msg(sender, "no-permission", "&cYou do not have permission!");
            return true;
         } else {
            this.plugin.reloadAll();
            this.msg(sender, "reloaded", "&aSmpCoreTPA reloaded.");
            return true;
         }
      } else if (sender instanceof Player) {
         Player player = (Player)sender;
         TpaManager mgr = this.plugin.getTpa();
         boolean flag;
         switch (name) {
            case "tpa":
               flag = this.sendTpa(player, args, TpaRequest.Type.TPA);
               break;
            case "tpahere":
               flag = this.sendTpa(player, args, TpaRequest.Type.TPAHERE);
               break;
            case "tpaccept":
               mgr.openAcceptGui(player, args.length > 0 ? args[0] : null);
               flag = true;
               break;
            case "tpadeny":
            case "tpdeny":
               mgr.deny(player, args.length > 0 ? args[0] : null);
               flag = true;
               break;
            case "tpacancel":
               mgr.cancel(player);
               flag = true;
               break;
            case "tpauto":
               boolean on = mgr.toggleTpAuto(player.getUniqueId());
               this.msg(player, on ? "tpauto-chat-on" : "tpauto-chat-off", on ? "&7You turned on tpauto." : "&7You turned off tpauto.");
               if (on) {
                  HotbarUtil.send(player, ColorUtil.parse(this.plugin.getMessages().get("tpauto-actionbar-on", "&aYou have tpauto on.")));
                  mgr.playSound(player, "tpauto");
               } else {
                  HotbarUtil.send(player, ColorUtil.parse(this.plugin.getMessages().get("tpauto-actionbar-off", "&7You turned off tpauto.")));
                  mgr.playSound(player, "tpauto-off");
               }

               flag = true;
               break;
            case "tpatoggle":
               boolean accepting = mgr.toggleTpa(player.getUniqueId());
               this.msg(player, accepting ? "tpa-settings-enabled" : "tpa-settings-disabled", accepting ? "&aYou are now accepting all TPA requests." : "&cYou are now blocking all TPA requests.");
               flag = true;
               break;
            case "tpaheretoggle":
               boolean acceptingHere = mgr.toggleTpahere(player.getUniqueId());
               this.msg(player, acceptingHere ? "tpa-here-enabled" : "tpa-here-disabled", acceptingHere ? "&aYou are now accepting /tpahere requests." : "&cYou are now blocking /tpahere requests.");
               flag = true;
               break;
            case "tpaconfirmtoggle":
               boolean onConfirm = mgr.toggleConfirmGui(player.getUniqueId());
               this.msg(player, onConfirm ? "confirm-gui-enabled" : "confirm-gui-disabled", onConfirm ? "&aConfirm GUI enabled for send and accept." : "&cConfirm GUI disabled. /tpa and /tpaccept are instant.");
               flag = true;
               break;
            case "tpaignore":
               if (args.length < 1) {
                  this.msg(player, "tpaignore-usage", "&cUsage: /tpaignore <player>");
                  flag = true;
               } else {
                  Player other = Bukkit.getPlayerExact(args[0]);
                  if (other == null) {
                     this.msg(player, "player-not-found", "&cPlayer not found!");
                     flag = true;
                  } else if (other.getUniqueId().equals(player.getUniqueId())) {
                     this.msg(player, "tpa-self", "&cYou cannot send a teleport request to yourself!");
                     flag = true;
                  } else {
                     boolean ignored = mgr.toggleIgnore(player.getUniqueId(), other.getUniqueId());
                     this.msg(player, ignored ? "tpaignore-on" : "tpaignore-off", ignored ? "&cYou are now ignoring &#37BFF8{player}&c." : "&aYou are no longer ignoring &#37BFF8{player}&a.", "{player}", other.getName());
                     flag = true;
                  }
               }
               break;
            default:
               flag = true;
         }

         return flag;
      } else {
         this.msg(sender, "player-only", "&cOnly players can use this!");
         return true;
      }
   }

   private boolean sendTpa(Player player, String[] args, TpaRequest.Type type) {
      if (args.length < 1) {
         this.msg(player, type == TpaRequest.Type.TPA ? "tpa-usage" : "tpahere-usage", type == TpaRequest.Type.TPA ? "&cUsage: /tpa <player>" : "&cUsage: /tpahere <player>");
         return true;
      } else {
         Player target = Bukkit.getPlayerExact(args[0]);
         if (target == null) {
            this.msg(player, "player-not-found", "&cPlayer not found!");
            return true;
         } else if (target.getUniqueId().equals(player.getUniqueId())) {
            this.msg(player, "tpa-self", "&cYou cannot send a teleport request to yourself!");
            return true;
         } else {
            TpaManager mgr = this.plugin.getTpa();
            if (mgr.isIgnoring(target.getUniqueId(), player.getUniqueId())) {
               this.msg(player, "tpa-ignored", "&c{player} is ignoring your teleport requests.", "{player}", target.getName());
               return true;
            } else if (type == TpaRequest.Type.TPA && mgr.isTpaDisabled(target.getUniqueId())) {
               this.msg(player, "tpa-receiver-disabled", "&c{player} has tpa requests disabled.", "{player}", target.getName());
               return true;
            } else if (type == TpaRequest.Type.TPAHERE && mgr.isTpahereDisabled(target.getUniqueId())) {
               this.msg(player, "tpa-here-receiver-disabled", "&c{player} has tpahere requests disabled.", "{player}", target.getName());
               return true;
            } else if (mgr.hasOutgoing(player.getUniqueId())) {
               this.msg(player, "tpa-already-sent", "&cYou have already sent a teleport request to &#37BFF8{target}&c. Please wait.", "{target}", args[0]);
               return true;
            } else if (mgr.getIncoming(target.getUniqueId()) != null) {
               this.msg(player, "tpa-already-has-request", "&#37BFF8{target}&c already has an incoming teleport request. Please wait.", "{target}", target.getName());
               return true;
            } else {
               if (mgr.isConfirmGuiEnabled(player.getUniqueId())) {
                  TpaMenus.openSend(player, target, type);
               } else {
                  mgr.sendRequest(player, target, type);
               }

               return true;
            }
         }
      }
   }

   private void msg(CommandSender sender, String key, String def, String... replacements) {
      String text = this.plugin.getMessages().get(key, def);
      if (text == null) {
         text = def;
      }

      if (replacements != null) {
         for(int i = 0; i + 1 < replacements.length; i += 2) {
            if (replacements[i] != null && replacements[i + 1] != null) {
               text = text.replace(replacements[i], replacements[i + 1]);
            }
         }
      }

      sender.sendMessage(ColorUtil.parse(text));
   }

   public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
      String name = command.getName().toLowerCase(Locale.ROOT);
      if (args.length != 1 || !name.equals("tpa") && !name.equals("tpahere") && !name.equals("tpaccept") && !name.equals("tpadeny") && !name.equals("tpdeny") && !name.equals("tpaignore")) {
         return new ArrayList();
      } else {
         String p = args[0].toLowerCase(Locale.ROOT);
         return (List)Bukkit.getOnlinePlayers().stream().map(Player::getName).filter((n) -> n.toLowerCase(Locale.ROOT).startsWith(p)).collect(Collectors.toList());
      }
   }
}
