package me.nothing.smpcore.systems.hide;

import me.nothing.smpcore.utils.HotbarUtil;
import me.nothing.smpcore.utils.TextUtil;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;

public class MessageUtil {
   public static String color(String message) {
      return ChatColor.translateAlternateColorCodes('&', message);
   }

   public static void actionBar(Player player, String message) {
      HotbarUtil.send(player, TextUtil.component(message));
   }
}
