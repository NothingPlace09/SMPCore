package me.nothing.smpcore.systems.warps;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, Boolean> OPEN = new ConcurrentHashMap();
   public static final Map<UUID, Type> MODE = new ConcurrentHashMap();
   public static final Map<UUID, Integer> PAGE = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      OPEN.remove(id);
      MODE.remove(id);
      PAGE.remove(id);
   }

   public static enum Type {
      SPAWN,
      AFK;

      private static Type[] $values() {
         return new Type[]{SPAWN, AFK};
      }
   }
}
