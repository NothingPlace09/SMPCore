package me.nothing.smpcore.systems.rtpq;

import org.bukkit.event.Listener;

public class DialogListener implements Listener {
}
