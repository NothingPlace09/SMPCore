package me.nothing.smpcore.systems.chat2;

import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;
import me.nothing.smpcore.systems.settings.SettingsModule;
import me.nothing.smpcore.utils.TextUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class ChatToggleListener implements Listener {
   private final SmpCoreChat plugin;
   private final ChatManager chatManager;

   public ChatToggleListener(SmpCoreChat plugin) {
      this(plugin, (ChatManager)null);
   }

   public ChatToggleListener(SmpCoreChat plugin, ChatManager chatManager) {
      this.plugin = plugin;
      this.chatManager = chatManager;
   }

   private boolean isOff(Player player) {
      ChatManager cm = this.chatManager != null ? this.chatManager : this.plugin.getChatManager();
      if (cm != null && cm.isPersonalOff(player.getUniqueId())) {
         return true;
      } else {
         try {
            JavaPlugin javaPlugin = this.plugin.getCore();
            if (javaPlugin instanceof SmpCore) {
               SmpCore core = (SmpCore)javaPlugin;
               Module mod = core.modules().get("settings");
               if (mod instanceof SettingsModule) {
                  SettingsModule sm = (SettingsModule)mod;
                  if (sm.isChatOff(player.getUniqueId())) {
                     return true;
                  }
               }
            }
         } catch (Throwable t) {
         }

         return false;
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onChat(AsyncPlayerChatEvent event) {
      Player player = event.getPlayer();
      if (this.isOff(player)) {
         event.setCancelled(true);
         TextUtil.send(player, "&#fc0404You have general chat disabled. &7Use &#00a3fb/chattoggle&7 or /settings.");
      } else {
         event.getRecipients().removeIf((viewer) -> {
            try {
               return this.isOff(viewer);
            } catch (Throwable t) {
               return false;
            }
         });
      }
   }
}
