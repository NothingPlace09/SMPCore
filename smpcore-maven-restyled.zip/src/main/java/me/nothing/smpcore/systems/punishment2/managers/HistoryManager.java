package me.nothing.smpcore.systems.punishment2.managers;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;
import me.nothing.smpcore.systems.punishment2.gui.HistoryGUI;
import me.nothing.smpcore.systems.punishment2.models.Punishment;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

public class HistoryManager {
   private final SmpCorePunishment plugin;

   public HistoryManager(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   public List<Punishment> getHistory(UUID uuid) {
      return this.plugin.getDatabaseManager().getHistory(uuid);
   }

   public List<Punishment> getVisibleHistory(UUID uuid) {
      List<Punishment> visible = new ArrayList();

      for(Punishment punishment : this.getHistory(uuid)) {
         if (!punishment.getType().equalsIgnoreCase("FREEZE") && !punishment.getType().equalsIgnoreCase("UNFREEZE")) {
            visible.add(punishment);
         }
      }

      return visible;
   }

   public void openHistory(Player viewer, OfflinePlayer target, int page) {
      HistoryGUI gui = new HistoryGUI(this.plugin);
      gui.open(viewer, target, page);
   }
}
