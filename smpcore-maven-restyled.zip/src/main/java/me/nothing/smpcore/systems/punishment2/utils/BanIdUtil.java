package me.nothing.smpcore.systems.punishment2.utils;

import java.security.SecureRandom;
import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;

public class BanIdUtil {
   private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
   private static final SecureRandom RANDOM = new SecureRandom();

   public static String generate() {
      String id;
      do {
         StringBuilder builder = new StringBuilder();
         int length = SmpCorePunishment.getInstance().getConfig().getInt("settings.ban-id-length", 5);

         for(int i = 0; i < length; ++i) {
            builder.append("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".charAt(RANDOM.nextInt("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".length())));
         }

         id = builder.toString();
      } while(exists(id));

      return id;
   }

   private static boolean exists(String id) {
      try {
         return SmpCorePunishment.getInstance().getDatabaseManager().banIdExists(id);
      } catch (Exception e) {
         return false;
      }
   }
}
