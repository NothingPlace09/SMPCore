package me.nothing.smpcore.systems.chat2;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public class MessageUtil {
   private static final MiniMessage MINI_MESSAGE = MiniMessage.miniMessage();
   private static final LegacyComponentSerializer LEGACY_SERIALIZER = LegacyComponentSerializer.builder().character('&').hexColors().build();

   public static String color(String message) {
      return message == null ? "" : LEGACY_SERIALIZER.serialize(LEGACY_SERIALIZER.deserialize(message));
   }

   public static Component component(String message) {
      return (Component)(message == null ? Component.empty() : MINI_MESSAGE.deserialize(message));
   }

   public static Component colorComponent(String message) {
      return message == null ? Component.empty() : LEGACY_SERIALIZER.deserialize(message);
   }
}
