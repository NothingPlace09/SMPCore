package me.nothing.smpcore.systems.punishment2.managers;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import me.nothing.smpcore.systems.punishment2.SmpCorePunishment;

public class FreezeManager {
   private final SmpCorePunishment plugin;
   private final Set<UUID> frozen = new HashSet();

   public FreezeManager(SmpCorePunishment plugin) {
      this.plugin = plugin;
   }

   public void freeze(UUID uuid) {
      this.frozen.add(uuid);
   }

   public void unfreeze(UUID uuid) {
      this.frozen.remove(uuid);
   }

   public boolean isFrozen(UUID uuid) {
      return this.frozen.contains(uuid);
   }

   public Set<UUID> getFrozenPlayers() {
      return this.frozen;
   }
}
