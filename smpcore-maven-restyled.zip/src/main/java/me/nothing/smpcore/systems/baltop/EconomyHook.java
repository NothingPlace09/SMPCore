package me.nothing.smpcore.systems.baltop;

import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;

public final class EconomyHook {
   private Economy economy;

   public boolean setup() {
      if (Bukkit.getPluginManager().getPlugin("Vault") == null) {
         return false;
      } else {
         RegisteredServiceProvider<Economy> rsp = Bukkit.getServicesManager().getRegistration(Economy.class);
         if (rsp == null) {
            return false;
         } else {
            this.economy = (Economy)rsp.getProvider();
            return this.economy != null;
         }
      }
   }

   public double getBalance(OfflinePlayer player) {
      if (this.economy != null && player != null) {
         try {
            return this.economy.getBalance(player);
         } catch (Exception e) {
            return (double)0.0F;
         }
      } else {
         return (double)0.0F;
      }
   }
}
