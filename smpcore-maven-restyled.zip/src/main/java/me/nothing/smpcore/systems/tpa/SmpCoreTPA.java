package me.nothing.smpcore.systems.tpa;

import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.command.PluginCommand;

public final class SmpCoreTPA extends SystemHost {
   private static SmpCoreTPA instance;
   private MessageManager messages;
   private TpaManager tpa;

   public SmpCoreTPA() {
      super("tpa");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.messages = new MessageManager(this);
      this.tpa = new TpaManager(this);
      TpaMenus.load(this);
      TpaCommand cmd = new TpaCommand(this);

      for(String name : new String[]{"tpa", "tpahere", "tpaccept", "tpadeny", "tpacancel", "tpauto", "tpatoggle", "tpaheretoggle", "tpaconfirmtoggle", "tpaignore", "tpareload"}) {
         PluginCommand c = this.getCommand(name);
         if (c != null) {
            c.setExecutor(cmd);
            c.setTabCompleter(cmd);
         }
      }

      this.getServer().getPluginManager().registerEvents(new GuiListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new MoveListener(this), this.getCore());
      this.tpa.startTpAutoBarTask();
      this.getLogger().info("SmpCoreTPA enabled.");
   }

   public void stop() {
      if (this.tpa != null) {
         this.tpa.stopTpAutoBarTask();
         this.tpa.saveSettings();
      }

      instance = null;
   }

   public void reloadAll() {
      this.reloadConfig();
      this.messages.reload();
      this.tpa.reload();
      TpaMenus.load(this);
   }

   public static SmpCoreTPA get() {
      return instance;
   }

   public MessageManager getMessages() {
      return this.messages;
   }

   public TpaManager getTpa() {
      return this.tpa;
   }
}
