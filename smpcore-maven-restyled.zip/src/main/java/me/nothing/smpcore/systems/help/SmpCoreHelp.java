package me.nothing.smpcore.systems.help;

import me.nothing.smpcore.systems.SystemHost;

public class SmpCoreHelp extends SystemHost {
   private static SmpCoreHelp instance;

   public SmpCoreHelp() {
      super("help");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      if (this.getCommand("help") != null) {
         new HelpCommand(this);
      }

      this.getServer().getPluginManager().registerEvents(new GUIListener(this), this.getCore());
      this.getLogger().info("--------------------------------");
      this.getLogger().info("SmpCoreHelp enabled successfully!");
      this.getLogger().info("Author: nothing");
      this.getLogger().info("--------------------------------");
   }

   public void stop() {
      this.getLogger().info("SmpCoreHelp disabled.");
   }

   public static SmpCoreHelp getInstance() {
      return instance;
   }

   public void reloadPlugin() {
      this.reloadConfig();
   }
}
