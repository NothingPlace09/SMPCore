package me.nothing.smpcore.systems.combat;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

public class CombatListener implements Listener {
   private final SmpCoreCombat plugin;
   private final CombatManager manager;

   public CombatListener(SmpCoreCombat plugin) {
      this.plugin = plugin;
      this.manager = plugin.getCombatManager();
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onDamage(EntityDamageByEntityEvent event) {
      Entity entity = event.getEntity();
      if (entity instanceof Player victim) {
         Player player = null;
         Entity entity2 = event.getDamager();
         if (entity2 instanceof Player p) {
            player = p;
         } else {
            entity2 = event.getDamager();
            if (entity2 instanceof Projectile proj) {
               ProjectileSource projectileSource = proj.getShooter();
               if (projectileSource instanceof Player p) {
                  player = p;
               }
            }
         }

         if (player != null && !player.equals(victim)) {
            if (!RegionUtil.isInSafeZone(victim) && !RegionUtil.isInSafeZone(player)) {
               this.manager.tagBoth(player, victim);
            }
         }
      }
   }

   /**
    * FIX bypass combat: prima si confrontava solo il nome esatto digitato, quindi bastava un alias
    * (/h) o il prefisso del plugin (/essentials:home, /minecraft:tp). Ora si risolvono namespace e alias
    * del comando reale e si confrontano con la lista blocked-commands (supporta anche voci tipo "team home").
    */
   private boolean isBlockedCommand(String msg, List<String> blocked) {
      String[] parts = msg.trim().split("\\s+", 2);
      String base = parts[0];
      String rest = parts.length > 1 ? parts[1].trim() : "";
      Set<String> names = new HashSet();
      names.add(base);
      int ns = base.indexOf(58);
      if (ns >= 0 && ns + 1 < base.length()) {
         names.add(base.substring(ns + 1));
      }

      try {
         PluginCommand resolved = Bukkit.getPluginCommand(base);
         if (resolved != null) {
            names.add(resolved.getName().toLowerCase(Locale.ROOT));

            for(String alias : resolved.getAliases()) {
               names.add(alias.toLowerCase(Locale.ROOT));
            }
         }
      } catch (Throwable var10) {
      }

      for(String entry : blocked) {
         if (entry != null) {
            String e = entry.toLowerCase(Locale.ROOT).trim();
            if (e.startsWith("/")) {
               e = e.substring(1);
            }

            if (!e.isEmpty()) {
               String[] ep = e.split("\\s+", 2);
               if (names.contains(ep[0])) {
                  if (ep.length == 1) {
                     return true;
                  }

                  String tail = ep[1].trim();
                  if (rest.equals(tail) || rest.startsWith(tail + " ")) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onCommand(PlayerCommandPreprocessEvent event) {
      Player player = event.getPlayer();
      if (this.manager.isInCombat(player)) {
         if (!player.hasPermission("smpcore.system.combat.bypass")) {
            String msg = event.getMessage().toLowerCase(Locale.ROOT);
            if (msg.startsWith("/")) {
               msg = msg.substring(1);
            }

            if (this.isBlockedCommand(msg, this.plugin.getConfig().getStringList("blocked-commands"))) {
               event.setCancelled(true);
               MessageUtil.send(player, "command-blocked");
               this.manager.playSound(player, "command-blocked");
               return;
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInteract(PlayerInteractEvent event) {
      Player player = event.getPlayer();
      if (this.manager.isInCombat(player)) {
         if (!player.hasPermission("smpcore.system.combat.bypass")) {
            ItemStack item = event.getItem();
            if (item != null) {
               List<String> blocked = this.plugin.getConfig().getStringList("blocked-items");
               String type = item.getType().name();

               for(String b : blocked) {
                  if (type.equalsIgnoreCase(b)) {
                     event.setCancelled(true);
                     MessageUtil.send(player, "item-blocked");
                     this.manager.playSound(player, "item-blocked");
                     return;
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onMove(PlayerMoveEvent event) {
      if (this.plugin.getConfig().getBoolean("anti-safe-zone.enabled", true)) {
         if (this.plugin.getConfig().getBoolean("anti-safe-zone.block-entry", true)) {
            Player player = event.getPlayer();
            if (this.manager.isInCombat(player)) {
               if (!player.hasPermission("smpcore.system.combat.bypass")) {
                  if (event.getTo() != null) {
                     if (event.getFrom().getBlockX() != event.getTo().getBlockX() || event.getFrom().getBlockY() != event.getTo().getBlockY() || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
                        if (RegionUtil.isInSafeZone(event.getTo()) && !RegionUtil.isInSafeZone(event.getFrom())) {
                           event.setCancelled(true);
                           String msg = this.plugin.getConfig().getString("anti-safe-zone.message", "&cYou cannot enter a safe zone while in combat!");
                           MessageUtil.sendRaw(player, msg);
                           if (this.plugin.getConfig().getBoolean("anti-safe-zone.show-barrier", true)) {
                              this.showBarrier(player, event.getTo());
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onTeleport(PlayerTeleportEvent event) {
      if (this.plugin.getConfig().getBoolean("anti-safe-zone.enabled", true)) {
         if (this.plugin.getConfig().getBoolean("anti-safe-zone.block-pearl", true)) {
            Player player = event.getPlayer();
            if (this.manager.isInCombat(player)) {
               if (!player.hasPermission("smpcore.system.combat.bypass")) {
                  if (event.getCause() == TeleportCause.ENDER_PEARL || event.getCause() == TeleportCause.CHORUS_FRUIT) {
                     if (event.getTo() != null && RegionUtil.isInSafeZone(event.getTo())) {
                        event.setCancelled(true);
                        String msg = this.plugin.getConfig().getString("anti-safe-zone.message", "&cYou cannot enter a safe zone while in combat!");
                        MessageUtil.sendRaw(player, msg);
                        this.manager.playSound(player, "item-blocked");
                     }

                  }
               }
            }
         }
      }
   }

   private void showBarrier(Player player, Location loc) {
      try {
         String particleName = this.plugin.getConfig().getString("anti-safe-zone.barrier-particle", "REDSTONE");
         Particle particle = Particle.valueOf(particleName);
         int radius = this.plugin.getConfig().getInt("anti-safe-zone.barrier-radius", 3);

         for(int x = -radius; x <= radius; ++x) {
            for(int z = -radius; z <= radius; ++z) {
               if (x * x + z * z <= radius * radius) {
                  Location pLoc = loc.clone().add((double)x, (double)1.0F, (double)z);
                  player.spawnParticle(particle, pLoc, 3, 0.1, 0.3, 0.1, (double)0.0F);
               }
            }
         }
      } catch (Exception e) {
      }

   }
}
