package me.nothing.smpcore.systems.reports;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class ReportsCommand implements CommandExecutor {
   private final SmpCoreReports plugin;

   public ReportsCommand(SmpCoreReports plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.hasPermission("smpcore.system.reports.staff")) {
            player.sendMessage(this.plugin.getConfig().getString("messages.no-permission").replace("&", "§"));
            return true;
         } else {
            ReportsGUI.open(player, this.plugin);
            return true;
         }
      } else {
         return true;
      }
   }
}
