package me.nothing.smpcore.systems.baltop;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, View> VIEW = new ConcurrentHashMap();
   public static final Map<UUID, Integer> PAGE = new ConcurrentHashMap();
   public static final Map<UUID, String> SEARCH = new ConcurrentHashMap();
   public static final Map<UUID, Boolean> CHAT_SEARCH = new ConcurrentHashMap();
   public static final Map<UUID, Boolean> SIGN_SEARCH = new ConcurrentHashMap();
   public static final Set<UUID> SWITCHING = ConcurrentHashMap.newKeySet();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      VIEW.remove(id);
      PAGE.remove(id);
      SEARCH.remove(id);
      CHAT_SEARCH.remove(id);
      SIGN_SEARCH.remove(id);
      SWITCHING.remove(id);
   }

   public static enum View {
      MAIN;

      private static View[] $values() {
         return new View[]{MAIN};
      }
   }
}
