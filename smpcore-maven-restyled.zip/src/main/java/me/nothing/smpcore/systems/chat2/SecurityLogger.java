package me.nothing.smpcore.systems.chat2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class SecurityLogger {
   private final SmpCoreChat plugin;
   private final File logFile;

   public SecurityLogger(SmpCoreChat plugin) {
      this.plugin = plugin;
      File folder = new File(plugin.getDataFolder(), "logs");
      if (!folder.exists()) {
         folder.mkdirs();
      }

      this.logFile = new File(folder, "security.log");
   }

   public void log(String message) {
      String str = String.valueOf(LocalDateTime.now());
      String finalMessage = "[" + str + "] " + message;
      this.plugin.getLogger().warning(message);

      try {
         FileWriter writer = new FileWriter(this.logFile, true);
         writer.write(finalMessage + System.lineSeparator());
         writer.close();
      } catch (IOException e) {
         this.plugin.getLogger().warning("Could not write security log.");
      }

   }
}
