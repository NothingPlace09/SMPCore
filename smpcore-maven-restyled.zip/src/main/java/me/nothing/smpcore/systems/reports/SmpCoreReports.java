package me.nothing.smpcore.systems.reports;

import me.nothing.smpcore.systems.SystemHost;

public final class SmpCoreReports extends SystemHost {
   private static SmpCoreReports instance;
   private DatabaseManager databaseManager;
   private CooldownManager cooldownManager;

   public SmpCoreReports() {
      super("reports");
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      this.databaseManager = new DatabaseManager(this);
      this.databaseManager.initialize();
      this.cooldownManager = new CooldownManager(this);
      this.getServer().getPluginManager().registerEvents(new GUIListener(this), this.getCore());
      this.getServer().getPluginManager().registerEvents(new InventoryListener(this), this.getCore());
      this.getLogger().info("SmpCoreReports Enabled");
   }

   public void stop() {
      if (this.databaseManager != null) {
         this.databaseManager.close();
      }

   }

   public static SmpCoreReports getInstance() {
      return instance;
   }

   public DatabaseManager getDatabaseManager() {
      return this.databaseManager;
   }

   public CooldownManager getCooldownManager() {
      return this.cooldownManager;
   }
}
