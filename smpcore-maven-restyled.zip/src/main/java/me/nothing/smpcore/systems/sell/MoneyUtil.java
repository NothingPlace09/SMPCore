package me.nothing.smpcore.systems.sell;

import java.util.Locale;

public final class MoneyUtil {
   private MoneyUtil() {
   }

   public static String format(double amount) {
      String symbol = SmpCoreSell.get().getConfig().getString("currency-symbol", "$");
      boolean abbr = SmpCoreSell.get().getConfig().getBoolean("economy.abbreviations.enabled", true);
      if (!abbr) {
         return Math.abs(amount - Math.rint(amount)) < 0.001 ? symbol + String.format(Locale.US, "%.0f", amount) : symbol + String.format(Locale.US, "%.2f", amount);
      } else {
         double abs = Math.abs(amount);
         if (abs >= 1.0E12) {
            return symbol + trim(amount / 1.0E12) + "T";
         } else if (abs >= (double)1.0E9F) {
            return symbol + trim(amount / (double)1.0E9F) + "B";
         } else if (abs >= (double)1000000.0F) {
            return symbol + trim(amount / (double)1000000.0F) + "M";
         } else if (abs >= (double)1000.0F) {
            return symbol + trim(amount / (double)1000.0F) + "k";
         } else {
            return Math.abs(amount - Math.rint(amount)) < 0.001 ? symbol + String.format(Locale.US, "%.0f", amount) : symbol + String.format(Locale.US, "%.2f", amount);
         }
      }
   }

   private static String trim(double v) {
      return Math.abs(v - Math.rint(v)) < 0.001 ? String.format(Locale.US, "%.0f", v) : String.format(Locale.US, "%.1f", v);
   }
}
