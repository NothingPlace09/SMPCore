package me.nothing.smpcore.systems.tpa;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class MenuSession {
   public static final Map<UUID, Boolean> OPEN = new ConcurrentHashMap();
   public static final Map<UUID, Mode> MODE = new ConcurrentHashMap();
   public static final Map<UUID, UUID> SENDER = new ConcurrentHashMap();
   public static final Map<UUID, UUID> TARGET = new ConcurrentHashMap();
   public static final Map<UUID, TpaRequest.Type> TYPE = new ConcurrentHashMap();

   private MenuSession() {
   }

   public static void clear(UUID id) {
      OPEN.remove(id);
      MODE.remove(id);
      SENDER.remove(id);
      TARGET.remove(id);
      TYPE.remove(id);
   }

   public static enum Mode {
      ACCEPT,
      SEND;

      private static Mode[] $values() {
         return new Mode[]{ACCEPT, SEND};
      }
   }
}
