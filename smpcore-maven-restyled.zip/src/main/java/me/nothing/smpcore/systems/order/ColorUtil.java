package me.nothing.smpcore.systems.order;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').build();

   private ColorUtil() {
   }

   public static Component parse(String text) {
      return (Component)(text == null ? Component.empty() : LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false));
   }

   public static String strip(String text) {
      return text == null ? "" : text.replaceAll("&#[0-9A-Fa-f]{6}", "").replaceAll("&[0-9a-fk-or]", "").replaceAll("§[0-9a-fk-or]", "");
   }
}
