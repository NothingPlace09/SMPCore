package me.nothing.smpcore.systems.keyall;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').hexCharacter('#').build();
   private static final MiniMessage MINI = MiniMessage.miniMessage();
   private static final Pattern HASH_HEX = Pattern.compile("(?<!&)#([A-Fa-f0-9]{6})");

   private ColorUtil() {
   }

   public static Component parse(String text) {
      if (text != null && !text.isEmpty()) {
         if (!text.contains("<click:") && !text.contains("<hover:") && !text.contains("<#")) {
            String legacy = HASH_HEX.matcher(text).replaceAll("&#$1");
            return LEGACY.deserialize(legacy).decoration(TextDecoration.ITALIC, false);
         } else {
            return MINI.deserialize(toMiniFriendly(text)).decoration(TextDecoration.ITALIC, false);
         }
      } else {
         return Component.empty();
      }
   }

   private static String toMiniFriendly(String input) {
      Matcher matcher = HASH_HEX.matcher(input);
      StringBuffer sb = new StringBuffer();

      while(matcher.find()) {
         matcher.appendReplacement(sb, "<#" + matcher.group(1) + ">");
      }

      matcher.appendTail(sb);
      String out = sb.toString();
      out = out.replace("&l", "<bold>").replace("&o", "<italic>").replace("&n", "<underlined>").replace("&m", "<strikethrough>").replace("&r", "<reset>").replace("&0", "<black>").replace("&1", "<dark_blue>").replace("&2", "<dark_green>").replace("&3", "<dark_aqua>").replace("&4", "<dark_red>").replace("&5", "<dark_purple>").replace("&6", "<gold>").replace("&7", "<gray>").replace("&8", "<dark_gray>").replace("&9", "<blue>").replace("&a", "<green>").replace("&b", "<aqua>").replace("&c", "<red>").replace("&d", "<light_purple>").replace("&e", "<yellow>").replace("&f", "<white>");
      return out;
   }
}
