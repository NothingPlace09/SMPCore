package me.nothing.smpcore.systems.auction;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').build();

   private ColorUtil() {
   }

   public static Component parse(String text) {
      return (Component)(text == null ? Component.empty() : LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false));
   }
}
