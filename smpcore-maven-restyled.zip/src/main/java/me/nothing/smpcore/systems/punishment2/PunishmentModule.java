package me.nothing.smpcore.systems.punishment2;

import java.io.File;
import me.nothing.smpcore.SmpCore;
import me.nothing.smpcore.modules.Module;

public class PunishmentModule implements Module {
   private final SmpCore plugin;
   private SmpCorePunishment punishment;

   public PunishmentModule(SmpCore plugin) {
      this.plugin = plugin;
   }

   public String getName() {
      return "punishment";
   }

   public void onEnable() {
      File dir = new File(this.plugin.getDataFolder(), "punishment");
      dir.mkdirs();

      for(String f : new String[]{"config.yml", "messages.yml", "reasons.yml", "webhook.yml"}) {
         File out = new File(dir, f);
         if (!out.exists()) {
            try {
               this.plugin.saveResource("punishment/" + f, false);
            } catch (Exception e) {
            }
         }
      }

      try {
         this.punishment = new SmpCorePunishment(this.plugin);
         this.punishment.enable();
         this.plugin.getLogger().info("Punishment system enabled.");
      } catch (Throwable t) {
         this.plugin.getLogger().warning("Punishment failed to start: " + t.getMessage());
         t.printStackTrace();
      }

   }

   public void onDisable() {
      if (this.punishment != null) {
         try {
            this.punishment.disable();
         } catch (Throwable t) {
         }
      }

   }

   public void reload() {
      this.onDisable();
      this.onEnable();
   }
}
