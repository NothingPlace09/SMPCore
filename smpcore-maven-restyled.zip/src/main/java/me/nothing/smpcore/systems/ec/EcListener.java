package me.nothing.smpcore.systems.ec;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.block.Block;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

public class EcListener implements Listener {
   private final SmpCoreEC plugin;

   public EcListener(SmpCoreEC plugin) {
      this.plugin = plugin;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInteract(PlayerInteractEvent event) {
      if (event.getHand() == EquipmentSlot.HAND) {
         if (event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            Block block = event.getClickedBlock();
            if (block != null && block.getType() == Material.ENDER_CHEST) {
               Player player = event.getPlayer();
               if (player.hasPermission("smpcore.system.ec.open")) {
                  event.setCancelled(true);
                  EcGui.openOwn(player, this.plugin);
               }
            }
         }
      }
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
      HumanEntity humanEntity = event.getPlayer();
      if (humanEntity instanceof Player player) {
         Inventory inv = event.getInventory();
         InventoryHolder inventoryHolder = inv.getHolder();
         if (inventoryHolder instanceof EcHolder holder) {
            ItemStack[] itemStackArr = inv.getContents();
            OfflinePlayer op = Bukkit.getOfflinePlayer(holder.getOwner());
            String n = op.getName();
            if (n != null) {
               this.plugin.getStorage().save(holder.getOwner(), itemStackArr, n);
            } else {
               this.plugin.getStorage().saveAsync(holder.getOwner(), itemStackArr);
            }

            EcGui.release(holder.getOwner(), player.getUniqueId());
            EcGui.play(player, this.plugin, false);
         }
      }
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      Player player = event.getPlayer();
      if (player.getOpenInventory() != null) {
         InventoryHolder inventoryHolder = player.getOpenInventory().getTopInventory().getHolder();
         if (inventoryHolder instanceof EcHolder) {
            EcHolder holder = (EcHolder)inventoryHolder;
            this.plugin.getStorage().save(holder.getOwner(), player.getOpenInventory().getTopInventory().getContents());
            EcGui.release(holder.getOwner(), player.getUniqueId());
         }
      }

   }
}
