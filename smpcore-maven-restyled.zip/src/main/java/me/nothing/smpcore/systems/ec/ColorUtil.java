package me.nothing.smpcore.systems.ec;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

public final class ColorUtil {
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().character('&').build();

   private ColorUtil() {
   }

   public static Component parse(String text) {
      return (Component)(text != null && !text.isEmpty() ? LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false) : Component.empty());
   }

   public static String plain(String text) {
      return text == null ? "" : text.replaceAll("&#[0-9A-Fa-f]{6}", "").replaceAll("&[0-9a-fk-or]", "").replaceAll("§[0-9a-fk-or]", "");
   }
}
