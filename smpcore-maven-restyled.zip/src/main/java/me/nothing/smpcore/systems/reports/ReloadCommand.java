package me.nothing.smpcore.systems.reports;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class ReloadCommand implements CommandExecutor {
   private final SmpCoreReports plugin;

   public ReloadCommand(SmpCoreReports plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (!sender.hasPermission("smpcore.system.reports.staff")) {
         sender.sendMessage("§cYou do not have permission.");
         return true;
      } else {
         this.plugin.reloadConfig();
         sender.sendMessage("§aSmpCoreReports configuration reloaded.");
         return true;
      }
   }
}
