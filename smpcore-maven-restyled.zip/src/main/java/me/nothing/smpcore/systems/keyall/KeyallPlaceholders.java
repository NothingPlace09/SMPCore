package me.nothing.smpcore.systems.keyall;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public final class KeyallPlaceholders extends PlaceholderExpansion {
   private final SmpCoreKeyall plugin;

   public KeyallPlaceholders(SmpCoreKeyall plugin) {
      this.plugin = plugin;
   }

   public @NotNull String getIdentifier() {
      return "smpcorekeyall";
   }

   public @NotNull String getAuthor() {
      return "nothing";
   }

   public @NotNull String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onPlaceholderRequest(Player player, @NotNull String params) {
      if (!params.isEmpty() && !params.equalsIgnoreCase("time") && !params.equalsIgnoreCase("timer") && !params.equalsIgnoreCase("remaining")) {
         return params.equalsIgnoreCase("seconds") ? String.valueOf(this.plugin.getTimer().getRemaining(player)) : this.plugin.getTimer().format(player);
      } else {
         return this.plugin.getTimer().format(player);
      }
   }
}
