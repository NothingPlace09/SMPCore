package me.nothing.smpcore.systems.maintenance;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;

public class MessageUtil {
   private final SmpCoreMaintenance plugin;
   private static final Pattern HEX_PATTERN = Pattern.compile("&#([A-Fa-f0-9]{6})");
   private static final Pattern OLD_HEX_PATTERN = Pattern.compile("<#([A-Fa-f0-9]{6})>");

   public MessageUtil(SmpCoreMaintenance plugin) {
      this.plugin = plugin;
   }

   public String color(String message) {
      if (message == null) {
         return "";
      } else {
         Matcher matcher = HEX_PATTERN.matcher(message);
         StringBuffer sb = new StringBuffer();

         while(matcher.find()) {
            matcher.appendReplacement(sb, ChatColor.of("#" + matcher.group(1)).toString());
         }

         matcher.appendTail(sb);
         message = sb.toString();
         matcher = OLD_HEX_PATTERN.matcher(message);
         sb = new StringBuffer();

         while(matcher.find()) {
            matcher.appendReplacement(sb, ChatColor.of("#" + matcher.group(1)).toString());
         }

         matcher.appendTail(sb);
         message = sb.toString();
         return ChatColor.translateAlternateColorCodes('&', message);
      }
   }

   public String get(String path) {
      FileConfiguration msg = this.plugin.getMessages();
      String prefix = msg.getString("prefix", "");
      String message = msg.getString(path, "");
      return this.color(prefix + message);
   }

   public String get(String path, String player) {
      return this.get(path).replace("%player%", player);
   }

   public void send(CommandSender sender, String path) {
      String msg = this.get(path);
      if (msg == null || msg.isBlank()) {
         String str;
         switch (path) {
            case "enabled" -> str = this.color("&aMaintenance mode enabled.");
            case "disabled" -> str = this.color("&cMaintenance mode disabled.");
            case "already-enabled" -> str = this.color("&cMaintenance is already enabled.");
            case "already-disabled" -> str = this.color("&cMaintenance is already disabled.");
            case "no-permission" -> str = this.color("&cNo permission.");
            case "reload" -> str = this.color("&aMaintenance reloaded.");
            default -> str = this.color("&7" + path);
         }

         msg = str;
      }

      sender.sendMessage(msg);
   }

   public void send(CommandSender sender, String path, String player) {
      String msg = this.get(path, player);
      if (msg == null || msg.isBlank()) {
         msg = this.color("&7" + path + " &f" + player);
      }

      sender.sendMessage(msg);
   }
}
