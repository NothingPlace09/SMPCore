package me.nothing.smpcore.systems.sell;

import org.bukkit.Bukkit;
import org.bukkit.Chunk;
import org.bukkit.World;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class SellAxeTask implements Runnable {
   private final SellAxeManager manager;
   private int tick;

   public SellAxeTask(SmpCoreSell plugin, SellAxeManager manager) {
      this.manager = manager;
   }

   public void run() {
      ++this.tick;

      for(Player player : Bukkit.getOnlinePlayers()) {
         this.updateInv(player.getInventory());
         this.updateInv(player.getEnderChest());
         if (player.getOpenInventory() != null) {
            this.updateInv(player.getOpenInventory().getTopInventory());
         }
      }

      if (this.tick % 15 == 0) {
         for(World world : Bukkit.getWorlds()) {
            for(Chunk chunk : world.getLoadedChunks()) {
               BlockState[] tiles;
               try {
                  tiles = chunk.getTileEntities();
               } catch (Throwable t) {
                  continue;
               }

               for(BlockState state : tiles) {
                  if (state instanceof Container) {
                     Container container = (Container)state;
                     this.updateInv(container.getInventory());
                  }
               }
            }
         }
      }

   }

   private void updateInv(Inventory inv) {
      if (inv != null) {
         ItemStack[] contents = inv.getContents();
         boolean changed = false;

         for(int i = 0; i < contents.length; ++i) {
            ItemStack stack = contents[i];
            if (stack != null && this.manager.isSellAxe(stack)) {
               if (this.manager.isExpired(stack)) {
                  contents[i] = null;
                  changed = true;
               } else if (this.manager.updateLore(stack)) {
                  contents[i] = stack;
                  changed = true;
               }
            }
         }

         if (changed) {
            inv.setContents(contents);
         }

      }
   }
}
