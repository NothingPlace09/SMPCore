package me.nothing.smpcore.systems.combat;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class CombatExpansion extends PlaceholderExpansion {
   private final SmpCoreCombat plugin;

   public CombatExpansion(SmpCoreCombat plugin) {
      this.plugin = plugin;
   }

   public @NotNull String getIdentifier() {
      return "smpcorecombat";
   }

   public @NotNull String getAuthor() {
      return "SmpCore";
   }

   public @NotNull String getVersion() {
      return this.plugin.getDescription().getVersion();
   }

   public boolean persist() {
      return true;
   }

   public String onPlaceholderRequest(Player player, @NotNull String params) {
      if (player == null) {
         return "";
      } else {
         CombatManager mgr = this.plugin.getCombatManager();
         String str;
         switch (params.toLowerCase()) {
            case "time_left":
            case "time":
               str = String.valueOf(mgr.getTimeLeft(player));
               break;
            case "status":
               str = mgr.isInCombat(player) ? "Combat" : "Safe";
               break;
            case "in_combat":
               str = String.valueOf(mgr.isInCombat(player));
               break;
            default:
               str = null;
         }

         return str;
      }
   }
}
