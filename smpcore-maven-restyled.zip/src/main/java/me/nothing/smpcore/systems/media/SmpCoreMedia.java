package me.nothing.smpcore.systems.media;

import me.nothing.smpcore.systems.SystemHost;
import org.bukkit.Bukkit;

public class SmpCoreMedia extends SystemHost {
   private static SmpCoreMedia instance;

   public SmpCoreMedia() {
      super("media");
   }

   public static SmpCoreMedia getInstance() {
      return instance;
   }

   public void start() {
      instance = this;
      this.saveDefaultConfig();
      Bukkit.getPluginManager().registerEvents(new InventoryListener(), this);
      this.getLogger().info("SmpCoreMedia has been enabled!");
   }

   public void stop() {
      this.getLogger().info("SmpCoreMedia has been disabled!");
   }
}
