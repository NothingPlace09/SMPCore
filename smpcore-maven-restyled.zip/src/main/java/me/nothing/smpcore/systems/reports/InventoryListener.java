package me.nothing.smpcore.systems.reports;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;

public class InventoryListener implements Listener {
   private final SmpCoreReports plugin;

   public InventoryListener(SmpCoreReports plugin) {
      this.plugin = plugin;
   }

   @EventHandler
   public void onClose(InventoryCloseEvent event) {
   }
}
