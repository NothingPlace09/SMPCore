package me.nothing.smpcore.systems.order;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockExplodeEvent;
import org.bukkit.event.block.BlockPhysicsEvent;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.entity.EntityExplodeEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class InputUtil implements Listener {
   private static final Map<UUID, MenuSession.ChatMode> SIGN_WAIT = new ConcurrentHashMap();
   private static final Map<UUID, Location> SIGN_LOC = new ConcurrentHashMap();
   private static final Map<UUID, Material> SIGN_PREV = new ConcurrentHashMap();
   private static final Set<String> PROTECTED = ConcurrentHashMap.newKeySet();
   private final SmpCoreOrder plugin;

   public InputUtil(SmpCoreOrder plugin) {
      this.plugin = plugin;
   }

   public static boolean useSign(SmpCoreOrder plugin) {
      return plugin.getConfig().getBoolean("chat-input.SignAPI", true) && !plugin.getConfig().getBoolean("chat-input.ChatAPI", false);
   }

   public static boolean useChat(SmpCoreOrder plugin) {
      if (plugin.getConfig().getBoolean("chat-input.ChatAPI", false)) {
         return true;
      } else {
         return !plugin.getConfig().getBoolean("chat-input.SignAPI", true);
      }
   }

   public void request(Player player, MenuSession.ChatMode mode) {
      UUID id = player.getUniqueId();
      MenuSession.View current = (MenuSession.View)MenuSession.VIEW.get(id);
      if (current != null) {
         MenuSession.INPUT_RETURN.put(id, current);
      }

      if (!useChat(this.plugin) && useSign(this.plugin)) {
         this.openSign(player, mode);
      } else {
         MenuSession.CHAT.put(id, mode);
         MenuSession.SWITCHING.add(id);
         player.closeInventory();
         Bukkit.getScheduler().runTaskLater(this.plugin.getCore(), () -> MenuSession.SWITCHING.remove(id), 2L);
         this.plugin.getMessages().send(player, "chat-input", Map.of("type", mode.name().toLowerCase()));
      }
   }

   private void openSign(Player player, MenuSession.ChatMode mode) {
      String str;
      switch (mode) {
         case AMOUNT -> str = "sign-gui.amount";
         case PRICE -> str = "sign-gui.price";
         case SEARCH -> str = "sign-gui.item";
         default -> str = "sign-gui.amount";
      }

      String path = str;
      List<String> lines = new ArrayList(this.plugin.getConfig().getStringList(path));

      while(lines.size() < 4) {
         lines.add("");
      }

      Block block = this.findAirBlock(player.getLocation());
      if (block == null) {
         MenuSession.CHAT.put(player.getUniqueId(), mode);
         player.closeInventory();
         this.plugin.getMessages().send(player, "chat-input", Map.of("type", mode.name().toLowerCase()));
      } else {
         UUID id = player.getUniqueId();
         Material prev = block.getType();
         SIGN_PREV.put(id, prev);
         SIGN_LOC.put(id, block.getLocation().clone());
         SIGN_WAIT.put(id, mode);
         PROTECTED.add(this.key(block.getLocation()));
         MenuSession.SWITCHING.add(id);
         player.closeInventory();
         block.setType(Material.OAK_SIGN, false);
         BlockState blockState = block.getState();
         if (blockState instanceof Sign) {
            Sign sign = (Sign)blockState;

            for(int i = 0; i < 4; ++i) {
               String raw = lines.get(i) == null ? "" : (String)lines.get(i);
               sign.getSide(Side.FRONT).line(i, ColorUtil.parse(raw));
            }

            sign.setWaxed(false);
            sign.update(true, false);
            Bukkit.getScheduler().runTaskLater(this.plugin.getCore(), () -> {
               if (player.isOnline() && SIGN_WAIT.containsKey(id)) {
                  Block b = ((Location)SIGN_LOC.get(id)).getBlock();
                  BlockState patt0$temp = b.getState();
                  if (patt0$temp instanceof Sign) {
                     Sign openSign = (Sign)patt0$temp;

                     for(int i = 0; i < 4; ++i) {
                        String raw = lines.get(i) == null ? "" : (String)lines.get(i);
                        openSign.getSide(Side.FRONT).line(i, ColorUtil.parse(raw));
                     }

                     openSign.setWaxed(false);
                     openSign.update(true, false);
                     player.openSign(openSign, Side.FRONT);
                     Bukkit.getScheduler().runTaskLater(this.plugin.getCore(), () -> MenuSession.SWITCHING.remove(id), 2L);
                  } else {
                     this.restore(id);
                     MenuSession.SWITCHING.remove(id);
                  }
               } else {
                  this.restore(id);
                  MenuSession.SWITCHING.remove(id);
               }
            }, 2L);
         } else {
            this.restore(id);
            MenuSession.SWITCHING.remove(id);
         }
      }
   }

   private Block findAirBlock(Location base) {
      Block block = base.getBlock();
      if (block.getType().isAir()) {
         return block;
      } else {
         for(int dy = 0; dy >= -3; --dy) {
            Block b = base.clone().add((double)0.0F, (double)dy, (double)0.0F).getBlock();
            if (b.getType().isAir()) {
               return b;
            }
         }

         for(BlockFace face : new BlockFace[]{BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST, BlockFace.UP}) {
            Block b = base.getBlock().getRelative(face);
            if (b.getType().isAir()) {
               return b;
            }
         }

         return null;
      }
   }

   private String key(Location loc) {
      String str = loc.getWorld().getName();
      return str + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
   }

   private boolean isProtected(Location loc) {
      return PROTECTED.contains(this.key(loc));
   }

   private void restore(UUID id) {
      Location loc = (Location)SIGN_LOC.remove(id);
      Material prev = (Material)SIGN_PREV.remove(id);
      SIGN_WAIT.remove(id);
      if (loc != null) {
         PROTECTED.remove(this.key(loc));
         Bukkit.getScheduler().runTask(this.plugin.getCore(), () -> {
            Block block = loc.getBlock();
            Material type = block.getType();
            if (type == Material.OAK_SIGN || type == Material.OAK_WALL_SIGN || type.name().endsWith("_SIGN")) {
               block.setType(prev != null && !prev.name().endsWith("_SIGN") ? prev : Material.AIR, false);
            }

         });
      }

   }

   @EventHandler
   public void onSign(SignChangeEvent event) {
      Player player = event.getPlayer();
      UUID id = player.getUniqueId();
      MenuSession.ChatMode mode = (MenuSession.ChatMode)SIGN_WAIT.get(id);
      if (mode != null) {
         event.setCancelled(true);
         String value = "";

         for(int i = 0; i < 4; ++i) {
            String line = event.getLine(i);
            if (line != null && !line.trim().isEmpty()) {
               value = line.trim();
               break;
            }
         }

         this.restore(id);
         final String finalValue = value;
         Bukkit.getScheduler().runTask(this.plugin.getCore(), () -> this.plugin.handleInput(player, mode, finalValue));
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onBreak(BlockBreakEvent event) {
      if (this.isProtected(event.getBlock().getLocation())) {
         event.setCancelled(true);
         event.setDropItems(false);
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onPhysics(BlockPhysicsEvent event) {
      if (this.isProtected(event.getBlock().getLocation())) {
         event.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onExplode(EntityExplodeEvent event) {
      event.blockList().removeIf((b) -> this.isProtected(b.getLocation()));
   }

   @EventHandler(
      priority = EventPriority.HIGHEST,
      ignoreCancelled = true
   )
   public void onBlockExplode(BlockExplodeEvent event) {
      event.blockList().removeIf((b) -> this.isProtected(b.getLocation()));
   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.restore(event.getPlayer().getUniqueId());
      MenuSession.CHAT.remove(event.getPlayer().getUniqueId());
      MenuSession.INPUT_RETURN.remove(event.getPlayer().getUniqueId());
   }
}
