package me.nothing.smpcore.systems.sell;

import me.nothing.smpcore.utils.HotbarUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class WorthToggleCommand implements CommandExecutor {
   private final SmpCoreSell plugin;

   public WorthToggleCommand(SmpCoreSell plugin) {
      this.plugin = plugin;
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (sender instanceof Player player) {
         if (!player.hasPermission("smpcore.system.sell.use") && !player.hasPermission("smpcore.system.sell.use")) {
            this.plugin.getMessages().send(player, "no-permission");
            return true;
         } else if (this.plugin.getWorthLore() == null) {
            return true;
         } else {
            boolean enabled = this.plugin.getWorthLore().toggleWorth(player);
            String msg = enabled ? this.plugin.getMessages().raw("worth-toggle-on", "&7ᴡᴏʀᴛʜ ʟᴏʀᴇ ᴇɴᴀʙʟᴇᴅ") : this.plugin.getMessages().raw("worth-toggle-off", "&7ᴡᴏʀᴛʜ ʟᴏʀᴇ ᴅɪsᴀʙʟᴇᴅ");
            Component component = ColorUtil.parse(msg);
            player.sendMessage(component);
            HotbarUtil.send(player, component);
            SoundUtil.click(player);
            return true;
         }
      } else {
         sender.sendMessage("Players only.");
         return true;
      }
   }
}
