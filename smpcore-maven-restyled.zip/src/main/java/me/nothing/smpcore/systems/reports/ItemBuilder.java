package me.nothing.smpcore.systems.reports;

import java.util.List;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class ItemBuilder {
   private final ItemStack item;

   public ItemBuilder(Material material) {
      this.item = new ItemStack(material);
   }

   public ItemBuilder name(String name) {
      ItemMeta meta = this.item.getItemMeta();
      if (meta != null) {
         meta.setDisplayName(ColorUtil.color(name));
         this.item.setItemMeta(meta);
      }

      return this;
   }

   public ItemBuilder lore(List<String> lore) {
      ItemMeta meta = this.item.getItemMeta();
      if (meta != null) {
         meta.setLore(lore.stream().map(ColorUtil::color).toList());
         this.item.setItemMeta(meta);
      }

      return this;
   }

   public ItemStack build() {
      return this.item;
   }
}
