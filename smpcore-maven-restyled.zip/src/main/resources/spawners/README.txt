SmpCore Spawners - Adding new spawners
====================================

You do not need to touch any Java code to add more spawner types.
Everything is driven by YAML files inside the spawners folder.

1. Open plugins/SmpCore/spawners/spawners/
2. Copy an existing file, for example skeleton.yml
3. Rename the copy to the mob you want, for example zombie.yml
4. Edit the file so the entity type and display match that mob

Basic layout of a spawner file:

  entity: ZOMBIE
  display: "&aZombie Spawner"
  generation-interval: 200
  drops:
    ROTTEN_FLESH:
      chance: 100
      min: 1
      max: 3
      sell-price: 2.5
    IRON_INGOT:
      chance: 10
      min: 1
      max: 1
      sell-price: 15.0

Notes:

- "entity" must be a valid Bukkit EntityType name (ZOMBIE, SKELETON, COW, etc.)
- File name does not have to match the entity, but keeping them the same is easier
- sell-price is what players get when they use Sell All (needs Vault + an economy plugin)
- chance is a percentage from 0 to 100
- After you save the file, run /as reload (or restart the server)

If the new type does not show up:

- Check the server log for load errors
- Make sure entity is spelled correctly and in UPPER_CASE
- Make sure the YAML indentation uses spaces, not tabs

Removing a type is the same idea: delete its .yml from the spawners folder and reload.
